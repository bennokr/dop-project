#include <stdio.h>
#include <ctype.h>
#include <strings.h>

int
main(int argc,char * argv[])
{
        int counter = 0;
        char buff[100000];
        char * COMMANDO;
	FILE *command;
	if(argc==2)
	{
        COMMANDO=argv[1];
        while (scanf("%[^\n]\n",buff) != EOF)
                {counter++; fprintf(stdout, "ID: %d\n", counter); fflush(stdout);
                if(command=popen(COMMANDO,"w"))
                        {
                         fprintf(command,"%s\n",buff);
                         pclose(command);
                        }
                else 
                        {
                        perror(COMMANDO);
                        }
                strcpy(buff,"");
                } 
      }      
 return 0;
}
