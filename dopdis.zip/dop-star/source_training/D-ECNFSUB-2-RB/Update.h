extern TreeCodeT CTCode; 
/**************/
void InitCodes(RootPtr RP);
void UpdateChC(RootPtr RP);
void UpdateChilds(PtrList Ch);
void UpdateAll(RootPtr RP);
void StartUpdate(RootPtr RP);
  void RevProb(ProbPtr P)  ;
