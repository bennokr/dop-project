/* enum OtsType {NON=0,LHS=1,RHS=2,BOTH=3};
#define OTSTYPE enum OtsType 
enum SType {Terminal=0,Nonterminal=1,OtherSym=2};
#define SoortType enum SType
#define TreeCodeT unsigned int
#define OwnCodeT unsigned int
*/
struct RootNode {
    PtrList Children;
    short int ChNum;
    char Name[SymLength];
    SoortType Soort; 
    ProbType Prob;
    TreeCodeT TreeC;
    OwnCodeT  OwnC;
    OTSTYPE   OTS;
    PtrList UnaryListAbove;
    PtrList UnaryListUnder;
};
typedef struct RootNode *RootPtr;
void ShowChild(PtrList Child);
void ShowUnder(PtrList Child);
void ShowRPtr(RootPtr RP);
extern RootPtr FillRPtr(PtrList L, int Chnum, char *N, SoortType So); 
extern void MapOnRoots(RootPtr RP, void (* fp)());
