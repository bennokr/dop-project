#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"

ProbList Probabilities = NULL;
/*************/

ProbPtr FillProb(ProbType P)
{ProbPtr Ptr = (ProbPtr) AllocElem(sizeof(struct ProbStruct));
 Ptr->Content = P;
 Ptr->Next = NULL; Ptr->Prev = NULL;
 return Ptr;
}
/***********/
void EqProbs(void *a, void *b, Boolean *EQ)
{ProbPtr A = (ProbPtr) a;
 ProbPtr B = (ProbPtr) b;
 *EQ = (A->Content == B->Content) ? true : false;
}
void EqSyms(void *a, void *b, Boolean *EQ)
{char *A = (char *) a;
 char *B = (char *) b;
 *EQ = (!strcmp(A,B)) ? true : false;
}
/*****************/
/* Queue */
/***********/
void ProbPtrMapF(ProbPtr L, void (* fp)())
{ProbPtr This = L;
 while (This != NULL) {(*fp)(This); This = This->Next;}
}
void ProbPtrMapB(ProbPtr L, void (* fp)())
{ProbPtr This = L;
 while (This != NULL) {(*fp)(This); This = This->Prev;}
}
void MapOnProbabilities(void (* fp)(), DirectionType DT)
{if (Probabilities != NULL) 
 switch (DT) {
  case FORWARD: ProbPtrMapF(Probabilities->First, fp); break;
  case BACKWARD: ProbPtrMapB(Probabilities->Last, fp); break;
  otherwise :  printf("Error in DirectionType\n"); exit(1); 
 }
}
/**************/
ProbPtr ProbEnStack(ProbType P, ProbPtr L)
{ProbPtr L1 = FillProb(P);
 L1->Prev = L; if (L!= NULL) L->Next = L1;
 return L1;
}
/***********/
void CrProbs()
{Probabilities = (ProbList) AllocElem(sizeof(struct ProbDList));
 Probabilities->First = NULL; Probabilities->Last = NULL;
}
void EnterProb(ProbType P)
{Boolean FirstTime = false;
 if (Probabilities == NULL) {CrProbs();FirstTime = true;}
 Probabilities->Last = ProbEnStack(P, Probabilities->Last);
 if (FirstTime == true) Probabilities->First = Probabilities->Last;
}


int probcount = 0;
void ShowProb(ProbPtr P)
{PRBLOGof(P->Content); probcount++;
 if ((probcount%8)==0) {probcount = 0;PRS("\n");}
}           
