/* What header files are necessary ? *******************************/

/********** INCLUDE HERE .unary_file.c  ****************************/
#include <.unary_file.c>
/**************************/

/** contains the functions that accompany the unary-bamboo package */

extern int *Array_Of_Place_Per_Sub;

NodeUnaryPtr PlaceOfUnaryForNode(TreeCodeT TCode, InTreeCodeT NCode)
{NodeUnaryPtr N_U_Ptr=NULL; TreeCodeT CU_T_N = TCode; NodeUnaryPtr RESULT = NULL;
 int start=Array_Of_Place_Per_Sub[TCode];

 if (start==-1) return NULL; /* unvalid case */

 while ((start<Nodes_Number) && (CU_T_N==TCode)) {
  N_U_Ptr = &(UnaryAboveNodes[start]); CU_T_N = N_U_Ptr->TreeC;
  if ((N_U_Ptr->TreeC == TCode) && (N_U_Ptr->NodeC == NCode)) RESULT = N_U_Ptr;
  else start++;
 }

 return RESULT;
}
char *SuffixOfN_U_Ptr(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; NodeUnaryPtr NUPtr=NULL;
 NUPtr = PlaceOfUnaryForNode(TCode, NCode);

 strcpy(RESULT,"");
 if (NUPtr == NULL) return RESULT;
 else {strcpy(RESULT,SuffixSub); return RESULT;}
}

char *PrefixOfN_U_Ptr(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; NodeUnaryPtr NUPtr=NULL;
 NUPtr = PlaceOfUnaryForNode(TCode, NCode);

 strcpy(RESULT,"");
 if (NUPtr == NULL) return RESULT;
 else {strcpy(RESULT,PrefixSub); return RESULT;}
}
