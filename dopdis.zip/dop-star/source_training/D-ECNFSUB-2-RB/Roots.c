#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"



RootPtr FillRPtr(PtrList L, int Chnum, char *N, SoortType So)
{RootPtr New = (RootPtr) AllocElem(sizeof(struct RootNode));
 New->Children = L;
 New->ChNum = Chnum;
 if (strlen(N) >= SymLength)                                                                                        {fprintf(stderr, "Please enlarge SymLength in Constants.c to %d\n", (strlen(N))); exit(1);}   
 if (N != NULL) strcpy(New->Name, N); else New->Name[0] = '\0';
 New->Soort = So;
 New->Prob = -1.0;
 New->TreeC = 0;
 New->OwnC = 0;
 New->OTS = NON;
 New->UnaryListAbove=NULL;
 New->UnaryListUnder=NULL;
 return New;
}
/* fp is a function that takes RootPtr */
void MapOnRoots(RootPtr RP, void (* fp)())
{void ReMap(void *Ch) {MapOnRoots((RootPtr) Ch, fp);}
	 if (RP != NULL)
		    {PListMapV(RP->Children, (void *) &ReMap);
			        fp(RP);
				   }
}
/*************************/
/*************************/
void ShowChild(PtrList Child)
{RootPtr RP;
 if (Child == NULL) PRS("NULLCH");
 else {RP = (RootPtr) Child->Ptr;
       PRS(RP->Name);
      }
}
int count = 1;
void ShowUnder(PtrList Child)
{RootPtr RP;
 count++;
 if (1==0) if ((count % 5) == 0) {PRS("\n"); count=1;}
 if (Child == NULL) PRS("NULLCH");
 else {RP = (RootPtr) Child->Ptr;
       ShowRPtr(RP); if (Child->Next != NULL) PRS(",");
      }
}
void ShowRPtr(RootPtr RP)
{if (RP == NULL) PRS("NULL\n");
 else {if (1==0) {PRI(RP->TreeC);PRI(RP->OwnC);PRS(": ");}
       PRS("(");PRS(RP->Name);PRS(",");
       /* PListMap(RP->Children, (void *) &ShowChild);PRS("\n");*/
       PRS("[");
       PListMap(RP->Children, (void *) &ShowUnder);
       PRS("]");
       if (RP->Prob != -1.0) {PRS(","); PRBSI(RP->Prob); PRS(")");}
       else PRS(")");
      }
}
/*************************/
/* A CLOSED PART */
/**************
int j = 0;
char *NewName(char *Name, int i)
{char *New = (char *) AllocElem(SymLength*sizeof(char));
 char *here = NULL;
 char J[10];

 strcpy(New, Name); 
 here = strchr(New, '_');
 if (here != NULL) {here[0] = '0'; * in case of terminals *
                    here[1] = '\0';
                   }
 else {i++; sprintf(J, "%d", i); strcat(New, J);}
 return New;
}
long int TreeNum = 0; 
long int k = 0;
void TransPtrList(PtrList P)
{RootPtr NewRP = NULL;
 RootPtr RP = (RootPtr) P->Ptr;
 PtrList NewCh = NULL;
 if (P->Next == NULL) ;
 else {TransPtrList(P->Next);
       NewCh = EnterP(P->Ptr, NewCh);     
       NewCh = EnterP(P->Next->Ptr, NewCh);
       P->Ptr = (void *) FillRPtr(NewCh, 2, 
                                  (NewName(RP->Name, k++)), Nonterminal);
       P->Next = NULL;
      }
}
void TransBigRules(RootPtr RP, int i)
{ PtrList This = (RP->Children)->Next;
  k = i;
  TransPtrList(This); if (k > j) j = k;
  k = 0;
}
void Terms2rules(PtrList Child)
{RootPtr NewRP = NULL;
 RootPtr RP = (RootPtr) Child->Ptr;
 PtrList NewCh = NULL;
 if (RP->Soort == Terminal) 
  {NewCh = EnterP((void *) RP, NewCh);
   NewRP = FillRPtr(NewCh, 1, (NewName(RP->Name, 0)), Nonterminal);
   Child->Ptr = (void *) NewRP;
  }
}
RootPtr TransRule(RootPtr RP)
{int IsHere = -1;
 PListMap(RP->Children, (void *) &Terms2rules);
 if (RP->ChNum > 2) {IsHere = FindRule(RP);
                     if (IsHere >= 0) TransBigRules(RP, IsHere);
                     else {ENTRule(RP, j);
                           TreeNum++;
                           TransBigRules(RP, j);
                          }
                    }
 else {IsHere = FindRule(RP);
       if (IsHere < 0) {TreeNum++; ENTRule(RP, j);}
       return RP;
      }
}
void TransChild(PtrList Child)
{RootPtr RP = (RootPtr) Child->Ptr;
 Child->Ptr = (void *) Transform2ECNF(RP);
}
RootPtr Transform2ECNF(RootPtr RP)
{int IsHere = -1;
 if (RP == NULL) return NULL;
 else {PListMap(RP->Children, (void *) &TransChild);
       if (RP->ChNum > 1) return (TransRule(RP));
       else {if (!strcmp(RP->Name, "*"));
             else if (RP->Soort == Terminal) ;
                  else {IsHere = FindRule(RP);
                   if (IsHere < 0) {TreeNum++; ENTRule(RP, j);}
                  }
             return RP;
            }
      }
}
************/
