#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"

extern int treenumber;

#define huge_string_length 67108864
#define Num_Of_Subs 4194304

char HugeStringAbove[huge_string_length];
char HugeStringUnder[huge_string_length];
int ArrayOfSubPlacesAbove[Num_Of_Subs];
int ArrayOfSubPlacesUnder[Num_Of_Subs];


char TempString[MaxTreeL];
int _num_of_unary_nodes_under=0;
int _num_of_unary_nodes_above=0;
Boolean INIT_ARRAY_A=false;
Boolean INIT_ARRAY_U=false;

extern FILE *UnaryPlacesFile;

void PrintUnaryListAbove(RootPtr RP)
{int i;
      void PrintUnaryList(RootPtr CH)
       {char UNARYTREE[MaxTreeL]; char REST[MaxTreeL];

	void GetUnary(void *Ptr)
         {strcat(UNARYTREE, "("); strcat(UNARYTREE, (char *) Ptr); strcat(UNARYTREE,",["); 
	  strcat(REST,"]"); strcat(REST, ")");
	 }

	strcpy(UNARYTREE,""); strcpy(REST,""); strcpy(TempString,"");
        if (CH->UnaryListAbove==NULL);
	else {if (ArrayOfSubPlacesAbove[treenumber]==-1) ArrayOfSubPlacesAbove[treenumber]=_num_of_unary_nodes_above;
	      PListMapV(CH->UnaryListAbove, (void *) &GetUnary); _num_of_unary_nodes_above++;
	      sprintf(TempString,"{%d, %d, \"%s\", \"%s\"}", CH->TreeC, CH->OwnC, UNARYTREE, REST);
	      if (strcmp(HugeStringAbove,"")) strcat(HugeStringAbove,",");
	      strcat(HugeStringAbove,TempString);

	      if ((_num_of_unary_nodes_above%3)==0) strcat(HugeStringAbove,"\n");
	     }
       }

  if (INIT_ARRAY_A==false)
    {INIT_ARRAY_A=true; strcpy(HugeStringAbove,""); for (i=0;i<Num_Of_Subs ;i++) ArrayOfSubPlacesAbove[i]=-1;}
  if (strlen(HugeStringAbove) >= huge_string_length) 
    {fprintf(stderr,"\nSUB-2-RBSTSG: error, HugeStringAbove too small\n");exit(1);}
  MapOnRoots(RP, (void *) &PrintUnaryList);
}

void PrintUnaryListUnder(RootPtr RP)
{int i;
      void PrintUnaryList(RootPtr CH)
       {char UNARYTREE[MaxTreeL]; char REST[MaxTreeL];

	void GetUnary(void *Ptr)
         {strcat(UNARYTREE, "("); strcat(UNARYTREE, (char *) Ptr); strcat(UNARYTREE,",["); 
	  strcat(REST,"]"); strcat(REST, ")");
	 }

	strcpy(UNARYTREE,""); strcpy(REST,""); strcpy(TempString,""); 
        if (CH->UnaryListUnder==NULL);
	else {if (ArrayOfSubPlacesUnder[treenumber]==-1) ArrayOfSubPlacesUnder[treenumber]=_num_of_unary_nodes_under;
	      PListMapV(CH->UnaryListUnder, (void *) &GetUnary); _num_of_unary_nodes_under++;
	      sprintf(TempString,"{%d, %d, \"%s\", \"%s\"}", CH->TreeC, CH->OwnC, UNARYTREE, REST);
	      if (strcmp(HugeStringUnder,"")) strcat(HugeStringUnder,",");
	      strcat(HugeStringUnder,TempString);
	      if ((_num_of_unary_nodes_under%3)==0) strcat(HugeStringUnder,"\n");
	     }
       }

  if (INIT_ARRAY_U==false)
    {INIT_ARRAY_U=true; strcpy(HugeStringUnder,""); for (i=0;i<Num_Of_Subs ;i++) ArrayOfSubPlacesUnder[i]=-1;}
  if (strlen(HugeStringUnder) >= huge_string_length) 
      {fprintf(stderr,"\nSUB-2-RBSTSG: error, HugeStringUnder too small\n");exit(1);}
  MapOnRoots(RP, (void *) &PrintUnaryList);
}

void PrintUnaryList(RootPtr RP)
{PrintUnaryListAbove(RP);
 PrintUnaryListUnder(RP);
}
/*******************************************/
void PrintUnaryPlaceArray()
{int i;
 if (INIT_ARRAY_A==false)
    {INIT_ARRAY_A=true; strcpy(HugeStringAbove,""); for (i=0;i<Num_Of_Subs ;i++) ArrayOfSubPlacesAbove[i]=-1;}
 if (INIT_ARRAY_U==false)
    {INIT_ARRAY_U=true; strcpy(HugeStringUnder,""); for (i=0;i<Num_Of_Subs ;i++) ArrayOfSubPlacesUnder[i]=-1;}

  fprintf(UnaryPlacesFile, "/**************************************************\n");
  fprintf(UnaryPlacesFile, "The following Array says that for subtree i\n");
  fprintf(UnaryPlacesFile, "the unaries are found from UnaryAboveNodes[i] on\n");
  fprintf(UnaryPlacesFile, "***************************************************/\n");
  fprintf(UnaryPlacesFile, "#define Numofsubs %d\n", treenumber);
  fprintf(UnaryPlacesFile, "int Above_Array_Of_Place_Per_Sub[Numofsubs] = {\n");
  for (i=0;i<treenumber;i++) 
    {fprintf(UnaryPlacesFile, "%d",ArrayOfSubPlacesAbove[i]); 
     if (i<(treenumber-1)) fprintf(UnaryPlacesFile, ",");
     if (((i+1)%30)==0) fprintf(UnaryPlacesFile, "\n");
    }
  fprintf(UnaryPlacesFile, "\n};\n/**************/\n");
  fprintf(UnaryPlacesFile, "/**************/\n");
  fprintf(UnaryPlacesFile, "/**************/\n");
  /*----------------------------------------------*/
  fprintf(UnaryPlacesFile, "/*----------------------------------------------*/\n");
  fprintf(UnaryPlacesFile, "int Under_Array_Of_Place_Per_Sub[Numofsubs] = {\n");
  for (i=0;i<treenumber;i++) 
    {fprintf(UnaryPlacesFile, "%d",ArrayOfSubPlacesUnder[i]); 
     if (i<(treenumber-1)) fprintf(UnaryPlacesFile, ",");
     if (((i+1)%30)==0) fprintf(UnaryPlacesFile, "\n");
    }
  fprintf(UnaryPlacesFile, "\n};\n/**************/\n");
  fprintf(UnaryPlacesFile, "/**************/\n");
  fprintf(UnaryPlacesFile, "/**************/\n");
}

void FinalPrintUnaryList()
{ PrintUnaryPlaceArray();
  fprintf(UnaryPlacesFile, "#define Nodes_Number_Above %d\n\n",_num_of_unary_nodes_above);
  if (_num_of_unary_nodes_above>0) {
    fprintf(UnaryPlacesFile,"struct Bamboo_Struct UnaryAboveNodes[Nodes_Number_Above] = {\n");
    fprintf(UnaryPlacesFile,"%s\n", HugeStringAbove);
    fprintf(UnaryPlacesFile,"};");
  }
  else fprintf(UnaryPlacesFile,"struct Bamboo_Struct *UnaryAboveNodes = NULL;");
    fprintf(UnaryPlacesFile, "\n/********************************************/\n\n");
  fprintf(UnaryPlacesFile, "#define Nodes_Number_Under %d\n\n",_num_of_unary_nodes_under);
  if (_num_of_unary_nodes_under>0) {
    fprintf(UnaryPlacesFile,"struct Bamboo_Struct UnaryUnderNodes[Nodes_Number_Under] = {\n");
    fprintf(UnaryPlacesFile,"%s\n", HugeStringUnder);
    fprintf(UnaryPlacesFile,"};");
  }
  else  fprintf(UnaryPlacesFile,"struct Bamboo_Struct *UnaryUnderNodes = NULL;");
}
