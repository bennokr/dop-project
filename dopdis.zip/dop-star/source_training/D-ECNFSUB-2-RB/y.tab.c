#ifndef lint
static char const 
yyrcsid[] = "$FreeBSD: src/usr.bin/yacc/skeleton.c,v 1.28 2000/01/17 02:04:06 bde Exp $";
#endif
#include <stdlib.h>
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYLEX yylex()
#define YYEMPTY -1
#define yyclearin (yychar=(YYEMPTY))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING() (yyerrflag!=0)
static int yygrowstack();
#define YYPREFIX "yy"
#line 2 "tree.y"
void WARN(int i);
#define YYSTYPE RootPtr
TreeCodeT treenumber=0;
extern RootPtr CheckUnaryRoot(RootPtr RP);

extern Boolean compile_unaries;
Boolean ONLY_PRINT_TREE = false;
Boolean Tree_Contains_Unary=false;
int treecount=0;
#line 27 "y.tab.c"
#define YYERRCODE 256
#define OPENER 257
#define CLOSER 258
#define SQOPEN 259
#define SQCLOS 260
#define COMMA 261
#define TREE 262
#define NONT 263
#define TERM 264
#define OTHER 265
#define DOT 266
#define NUMBER 267
const short yylhs[] = {                                        -1,
    0,    1,    1,    2,    3,    3,    3,    6,    5,    4,
    8,    8,    7,    7,
};
const short yylen[] = {                                         2,
    1,    2,    1,    2,    1,    1,    1,    6,    7,    9,
    1,    3,    1,    1,
};
const short yydefred[] = {                                      0,
    0,    0,    0,    3,    0,    5,    6,    7,   13,   14,
    0,    2,    4,    0,    0,    0,    0,   11,    0,    8,
    0,    0,    0,    9,    0,   12,    0,   10,
};
const short yydgoto[] = {                                       2,
    3,    4,    5,    6,    7,    8,   11,   20,
};
const short yysindex[] = {                                   -259,
 -258,    0, -259,    0, -256,    0,    0,    0,    0,    0,
 -247,    0,    0, -244, -251, -257, -248,    0, -250,    0,
 -257, -259, -242,    0, -241,    0, -257,    0,
};
const short yyrindex[] = {                                      0,
    0,    0,   18,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,
};
const short yygindex[] = {                                      0,
    0,   17,  -15,    0,    0,    0,    0,  -19,
};
#define YYTABLESIZE 20
const short yytable[] = {                                      17,
   18,   24,    1,   19,    9,   10,   25,   28,   16,   13,
    1,   21,   22,   14,   15,   26,   23,    1,   27,   12,
};
const short yycheck[] = {                                      15,
  258,   21,  262,  261,  263,  264,   22,   27,  260,  266,
  262,  260,  261,  261,  259,  258,  267,    0,  260,    3,
};
#define YYFINAL 2
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 267
#if YYDEBUG
const char * const yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"OPENER","CLOSER","SQOPEN",
"SQCLOS","COMMA","TREE","NONT","TERM","OTHER","DOT","NUMBER",
};
const char * const yyrule[] = {
"$accept : s",
"s : trees",
"trees : trees tree",
"trees : tree",
"tree : t DOT",
"t : t2",
"t : t1",
"t : t0",
"t0 : TREE name COMMA SQOPEN SQCLOS B",
"t1 : TREE name COMMA SQOPEN t SQCLOS B",
"t2 : TREE name COMMA SQOPEN t COMMA t SQCLOS B",
"B : CLOSER",
"B : COMMA NUMBER CLOSER",
"name : NONT",
"name : TERM",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#if YYDEBUG
#include <stdio.h>
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH 10000
#endif
#endif
#define YYINITSTACKSIZE 200
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short *yyss;
short *yysslim;
YYSTYPE *yyvs;
int yystacksize;
#line 88 "tree.y"
void WARN(int i)
{switch (i) {
   case 0: PRS("Warning: Tree without probability\n");
           break;
   case 1: PRS("Warning: Part of Tree with probability\n");
           break;
   otherwise: break;
 }
 exit(1);
}

/* repair an unary that is the root of a subtree of depth 1*/
RootPtr CheckUnaryRoot(RootPtr RP)
{RootPtr NEW; PtrList TempPL=NULL;
 NEW = RP;
 if ((RP->Children==NULL) && (RP->UnaryListAbove!=NULL)) /* unaries of depth 1 are not thrown away */
   {PtrList CHs = EnterP((void*) RP, NULL);
    NEW = FillRPtr(CHs, 1, ( (char *) RP->UnaryListAbove->Ptr), Nonterminal);
    NEW->Prob = RP->Prob;
    RP->Prob = -1.0;
    {FreePList(RP->UnaryListAbove); RP->UnaryListAbove=NULL; RP->UnaryListUnder=NULL;}
   }
 else /* if unary is at root: we put an unary in the list under! rather than above */
  if (RP->UnaryListAbove!=NULL) /* current root has a bamboo of unaries above it! */
   {PtrList CHs = EnterP((void*) RP, NULL);
    /* return the unary back and throw away the  unary_above list */
    NEW = FillRPtr(CHs, 1, ( (char *) RP->UnaryListAbove->Ptr), Nonterminal);
    NEW->Prob = RP->Prob; RP->Prob = -1.0;
    {TempPL = RP->UnaryListAbove; NEW->UnaryListUnder = TempPL->Next;  /* switch to under */
     TempPL->Next=NULL; FreePList(TempPL); if (RP->UnaryListUnder!=NULL) fprintf(stderr,"\n---------\n");
     RP->UnaryListAbove=NULL;
    }
     /* NEW holds the root now: now extract the unary into under the root */
    NEW->Children = RP->Children; NEW->ChNum = RP->ChNum; RP->Children=NULL; 
    NEW->UnaryListUnder = EnterP((void *) NewStringOf(RP->Name), NEW->UnaryListUnder);
   }

 return NEW;
}

#line 183 "y.tab.c"
/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack()
{
    int newsize, i;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = yystacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;
    i = yyssp - yyss;
    newss = yyss ? (short *)realloc(yyss, newsize * sizeof *newss) :
      (short *)malloc(newsize * sizeof *newss);
    if (newss == NULL)
        return -1;
    yyss = newss;
    yyssp = newss + i;
    newvs = yyvs ? (YYSTYPE *)realloc(yyvs, newsize * sizeof *newvs) :
      (YYSTYPE *)malloc(newsize * sizeof *newvs);
    if (newvs == NULL)
        return -1;
    yyvs = newvs;
    yyvsp = newvs + i;
    yystacksize = newsize;
    yysslim = yyss + newsize - 1;
    return 0;
}

#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab

#ifndef YYPARSE_PARAM
#if defined(__cplusplus) || __STDC__
#define YYPARSE_PARAM_ARG void
#define YYPARSE_PARAM_DECL
#else	/* ! ANSI-C/C++ */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif	/* ANSI-C/C++ */
#else	/* YYPARSE_PARAM */
#ifndef YYPARSE_PARAM_TYPE
#define YYPARSE_PARAM_TYPE void *
#endif
#if defined(__cplusplus) || __STDC__
#define YYPARSE_PARAM_ARG YYPARSE_PARAM_TYPE YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else	/* ! ANSI-C/C++ */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL YYPARSE_PARAM_TYPE YYPARSE_PARAM;
#endif	/* ANSI-C/C++ */
#endif	/* ! YYPARSE_PARAM */

int
yyparse (YYPARSE_PARAM_ARG)
    YYPARSE_PARAM_DECL
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register const char *yys;

    if ((yys = getenv("YYDEBUG")))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    if (yyss == NULL && yygrowstack()) goto yyoverflow;
    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate])) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yysslim && yygrowstack())
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#if defined(lint) || defined(__GNUC__)
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#if defined(lint) || defined(__GNUC__)
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yysslim && yygrowstack())
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 16 "tree.y"
{ if (ONLY_PRINT_TREE==false)  ShowAll();
                  FinalPrintUnaryList();
                }
break;
case 2:
#line 21 "tree.y"
{}
break;
case 3:
#line 23 "tree.y"
{}
break;
case 4:
#line 26 "tree.y"
{yyval = yyvsp[-1];
                 yyval = CheckUnaryRoot(yyval); 
                 if (1==0) {ShowRPtr(yyval);PRS(".\n"); }
                 if (ONLY_PRINT_TREE==true) {ShowRPtr(yyval);PRS(".\n"); }
                 else {StartUpdate(yyval); if (Tree_Contains_Unary== true) PrintUnaryList(yyval);}
                 if (1==0) if ((treenumber%100)==0) fprintf(stderr,"%d\n",treenumber); fflush(stderr); 
                 treenumber++;
                 if (yyval->Prob == -1.0) WARN(0);
                 FreeRPtr(yyval); 
                 Tree_Contains_Unary=false;
                 treecount++; if ((treecount%1000)==0) fprintf(stderr,"%d\n", treecount);
                }
break;
case 5:
#line 40 "tree.y"
{yyval = yyvsp[0];}
break;
case 6:
#line 42 "tree.y"
{yyval = yyvsp[0];}
break;
case 7:
#line 44 "tree.y"
{yyval = yyvsp[0];}
break;
case 8:
#line 47 "tree.y"
{yyval = yyvsp[-4];yyval->Prob = yyvsp[0]->Prob;
                 FreeRPtr(yyvsp[0]);
                }
break;
case 9:
#line 52 "tree.y"
{yyval = yyvsp[-5];
                 if ((strchr(yyvsp[-2]->Name,'_')!=NULL) || (_compile_unaries==false)) /* it is a word or keep unaries*/
                  {yyvsp[-5]->Children = EnterP((void *) yyvsp[-2], yyvsp[-5]->Children);
                   yyvsp[-5]->ChNum = 1; yyvsp[-5]->Prob = yyvsp[0]->Prob; 
                   if (yyvsp[-2]->Prob != -1.0) {printf("%s->%s 1\n", yyvsp[-5]->Name, yyvsp[-2]->Name);WARN(1);} 
                  }
                 else if (_compile_unaries==true) /* just skipping an unary */
                      {yyval=yyvsp[-2]; yyval->Prob=yyvsp[0]->Prob; 
                       yyval->UnaryListAbove = EnStack((void *) NewStringOf(yyvsp[-5]->Name), yyval->UnaryListAbove); 
                       Tree_Contains_Unary=true;
                      }
                 FreeRPtr(yyvsp[0]);
                }
break;
case 10:
#line 67 "tree.y"
{yyvsp[-7]->Children = EnterP((void *) yyvsp[-4], yyvsp[-7]->Children);
                 yyvsp[-7]->Children = EnterP((void *) yyvsp[-2], yyvsp[-7]->Children);
                 yyvsp[-7]->ChNum = 2; yyvsp[-7]->Prob = yyvsp[0]->Prob; yyval = yyvsp[-7];
                 if (yyvsp[-4]->Prob != -1.0) {printf("2");WARN(1);}
                 if (yyvsp[-2]->Prob != -1.0) {printf("3");WARN(1);}
                 FreeRPtr(yyvsp[0]);
                }
break;
case 11:
#line 76 "tree.y"
{yyval = FillRPtr(NULL, 0, ")", OtherSym); yyval->Prob = -1.0;}
break;
case 12:
#line 78 "tree.y"
{yyval = yyvsp[-1]; 
                 sscanf(yyvsp[-1]->Name, "%lf", &(yyval->Prob));
                }
break;
case 13:
#line 83 "tree.y"
{yyval = yyvsp[0];}
break;
case 14:
#line 85 "tree.y"
{yyval = yyvsp[0];}
break;
#line 469 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yysslim && yygrowstack())
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
