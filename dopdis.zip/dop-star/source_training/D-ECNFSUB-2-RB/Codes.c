#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"


CodePtr NewCode(RootPtr RP)
{CodePtr New = (CodePtr) AllocElem(sizeof(struct CodeStr));
 New->TreeC = RP->TreeC;
 New->OwnC = RP->OwnC;
 New->OTS = RP->OTS;
 return New;
}
void RelateCodes(void *C1, void *C2, int *relation)
{CodePtr PC1 = (CodePtr) C1;
 CodePtr PC2 = (CodePtr) C2;
 int I1, I2, I3;

 if ((PC1 == NULL) || (PC2 == NULL)) *relation = 1;
 else {
 I3 = (PC1->OwnC < PC2->OwnC) ? -1 : 0;
 I2 =  (PC1->OwnC > PC2->OwnC) ? 1 : I3;
 I1 = (PC1->TreeC < PC2->TreeC) ? -1 : I2;
 *relation = (PC1->TreeC > PC2->TreeC) ? 1 : I1;
 }
}
Boolean EqCs(ItemTree C1, ItemTree C2)
{int Rel = 0;
 RelateCodes(C1->Ptr, C2->Ptr, &Rel);
 return ((Rel == 0) ? true : false);
}
Boolean GrCs(ItemTree C1, ItemTree C2)
{int Rel = 0;
 RelateCodes(C1->Ptr, C2->Ptr, &Rel);
 return ((Rel > 0) ? true : false);
}
Boolean LeCs(ItemTree C1, ItemTree C2)
{int Rel = 0;
 RelateCodes(C1->Ptr, C2->Ptr, &Rel);
 return ((Rel < 0) ? true : false);
}
