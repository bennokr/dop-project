#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"
#include "GenHashUnit.h"
#include "GenHASHTABLE.h"





#define SymSize SymLength
TreeCodeT CTCode = 0;
static ItemTree NonTerminals = NULL;
static ItemTree Terminals = NULL;
/**************/
void InitCodes(RootPtr RP)
{RP->TreeC = CTCode;CTCode++;
 RP->OwnC = 1; 
}
Boolean OpenTree(RootPtr RP)
{if (RP == NULL) return false;
 else if (RP->Soort == Nonterminal)
          if (RP->Children == NULL) return true;
          else return false;
      else return false;
}
void UpdateOTS(RootPtr RP)
{RootPtr Lch, Rch;
 PtrList First, Second;
 Lch = NULL; Rch = NULL; First = NULL; Second = NULL;
 if (RP == NULL) ;
 else {if (RP->Children == NULL) RP->OTS = NON;
       else {First = RP->Children; Lch = (RootPtr) First->Ptr; 
             if (First->Next != NULL) {Second = First->Next;
                                       Rch = (RootPtr) Second->Ptr;}
             if (OpenTree(Lch)==true)
                if (OpenTree(Rch)==true) RP->OTS = BOTH;
                else RP->OTS = LHS;
             else if (OpenTree(Rch)==true) RP->OTS = RHS;
                  else RP->OTS = NON;
            }
      }
}
void UpdateChC(RootPtr RP)
{int ChildNum = 0;
     void UpChC(PtrList Ch)
        {RootPtr ChP = (RootPtr) Ch->Ptr;
         ChP->TreeC = RP->TreeC;
         ChP->OwnC = 2*(RP->OwnC) + ChildNum;
         ChildNum++;
        }
 PListMap(RP->Children, (void *) &UpChC);
}
/**************************************************/
extern HASHTABLE NontHashTab;
extern HASHTABLE TermHashTab;

ItemTree UpdateSymbol(RootPtr RP, ItemTree IT)
{char *New; Boolean Entered; ItemTree RES = NULL;
  { New = (char *) MultAlloc(SymSize, sizeof(char));
    strcpy(New, RP->Name);
    Entered = false;
    RES = EnterTree((void *) New, IT, &Entered);
    if (Entered == false) cfree(New);
    return RES;
  }
}

/* expensive */
void UpdateTerms(RootPtr RP)
{if (FindUnitInHT(TermHashTab, RP->Name) == NULL) /* saving time */
  {Terminals = UpdateSymbol(RP, Terminals); ENT2HTable(TermHashTab,RP->Name);}
}

/* expensive */
void UpdateNonTs(RootPtr RP)
{if (FindUnitInHT(NontHashTab, RP->Name) == NULL) /* saving time */
  {NonTerminals = UpdateSymbol(RP, NonTerminals); ENT2HTable(NontHashTab,RP->Name);}
}
/***********************/
void UpdateChilds(PtrList Ch)
{RootPtr ChP = (RootPtr) Ch->Ptr;
 UpdateAll(ChP);
}
void UpdateAll(RootPtr RP)
{UpdateChC(RP); /* computes codes for nodes of this tree */
 UpdateOTS(RP); /* computes the open nodes for every node */
 if (RP->Soort == Nonterminal) 
    {UpdateNonTs(RP);
     UpdateRules(RP);
     PListMap(RP->Children, (void *) &UpdateChilds);
    }                     
 else if (RP->Soort == Terminal) UpdateTerms(RP);
      else {printf("UpdateAll: expected NT or T but got smg undefined\n");
            exit(1);}
}
void UpdateProb(RootPtr RP)
{if (RP != NULL) EnterProb(RP->Prob);
 else {printf("Error in UpdateProbi\n"); exit(1);}
}
void StartUpdate(RootPtr RP)
{InitCodes(RP);
 UpdateProb(RP);  /* fast O(1) */
 UpdateAll(RP); 
}
/***********************/
int symcount=0;
void ShowSym(ItemTree P)
{char *Sym = (char *) P->Ptr;
 symcount++; if ((symcount%8) == 0) {PRS("\n");symcount=0;}
 PRS(Sym);PRS(" "); 
}

W_Rule(char *Rule)
{PRS(Rule);PRS(" ");
}
/******/
int i = 0;
void W_Codes(PtrList P)
{void W_Code(PtrList P1)
    {CodePtr Code = NULL; 
     if (P1 == NULL);
     else {Code = (CodePtr) P1->Ptr;
           if (Code == NULL) ;
           else {i++;
                 PRI(Code->TreeC);PRS(" ");PRI(Code->OwnC);PRS(" ");
                 PRI(Code->OTS);
                 if (P1->Next != NULL) PRS(", ");} /* if not last then... */
          }
     if (((i%5) == 0) && (P1->Next != NULL)) {PRS("\n");i=0;}
    }

 PListMap(P, (void *) &W_Code);
 i =0;
}
void ShowAll()
{
 {TreeMap(NonTerminals, (void *) &ShowSym);PRS(";\n");}
 {TreeMapTerm(Terminals, (void *) &ShowSym);PRS(";\n");}
  ShowRules();
  PRS("##\n"); 
  MapOnProbabilities((void *) &ShowProb,FORWARD);
  PRS("\n");
}
