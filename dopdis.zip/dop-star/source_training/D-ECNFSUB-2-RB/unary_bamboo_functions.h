/** contains the functions that accompany the unary-bamboo package */

struct Bamboo_Struct {
	 TreeCodeT TreeC;
	 InTreeCodeT NodeC;
	 char *PrefixSub;
	 char *SuffixSub;
};

typedef struct NodeUnary *NodeUnaryPtr;


extern char *SuffixOfN_U_Ptr(TreeCodeT TCode, InTreeCodeT NCode);
extern char *PrefixOfN_U_Ptr(TreeCodeT TCode, InTreeCodeT NCode);

