/*******/
enum OtsType {NON=0,LHS=1,RHS=2,BOTH=3};
#define OTSTYPE enum OtsType
enum SType {Terminal=0,Nonterminal=1,OtherSym=2};
#define SoortType enum SType
/*#define TreeCodeT  */
#define OwnCodeT InTreeCodeT
