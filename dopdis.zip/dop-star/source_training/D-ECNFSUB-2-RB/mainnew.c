#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN, *UnaryPlacesFile;
/**/
int Num_of_Unknowns = 0;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"
#include "GenHashUnit.h"
#include "GenHASHTABLE.h"
#include "PrintingUnary.h"


Boolean _compile_unaries = false;
/****************/
#include "y.tab.c"
#include "lex.yy.c"


char INF[30] ="\0";
char OUF[30] ="\0";
char UNARY[30]=".unary_file.c";

/**/
extern void TRANS();

/**********************/
HASHTABLE RuleHashTab; 
HASHTABLE NontHashTab; 
HASHTABLE TermHashTab; 
/*******************/
extern void USAGE();

int main(argc, argv, envp)
int argc;
char **argv, **envp;
{char* options = "Ui:o:"; /* set your choices here */
 char  opt_ch; int error_flag = 0;
 FILE *fopen();

 fpOUT = stdout; fpIN = stdin;

 opt_ch = getopt( argc, argv, options );
 while ( opt_ch != -1 )
   {switch( opt_ch ) {
     case 'U' : _compile_unaries = true; break;
     case 'i' : if ((fpIN = fopen(optarg, "r")) == NULL) printf("Can't open %s\n", *argv); break;
     case 'o' : if ((fpOUT = fopen(optarg, "w")) == NULL) printf("Can't open %s\n", *argv); break;
     case '?' : error_flag++; break;
    }
    opt_ch = getopt( argc, argv, options );
   }
        /* case file names without -i and -o */
   if ( argc - optind > 0 )
    if (fpIN == stdin)
     {if (argv[optind][0] != '-')
       {fpIN = fopen( argv[optind], "r" );
        if ( !fpIN )
         {fprintf( stderr, "File <%s> does not exist\n", argv[optind] ); exit( 1 );}
       }
      else error_flag++;
     }
    else /* input file read */
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
   if ( argc - ++optind > 0 )
    if (fpOUT == stdout)
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
    else error_flag++;
   else error_flag++;

         /* In case of error  */
   {char* basename = strrchr( argv[0], '/' );

   if ( error_flag ) {USAGE(); exit( 1 );}
   }

 {char TEXT[20];
  if (_compile_unaries==false) strcpy(TEXT,"not"); else strcpy(TEXT,"");
  fprintf(stderr,"SUB-2-RBSTSG: %s compiling unaries out for efficiency\n",TEXT);
 }
 TRANS();
}
/**********************/
void USAGE()
{fprintf(stderr, "USAGE: SUB-2-RBSTSG [options] [-i] inputfile [-o outputfile]\n");
 fprintf(stderr,"Options:\n");
 fprintf(stderr," -U: compile out unaries\n");
 exit(1);
}


void TRANS()
{Boolean STOP = false; 
 RuleHashTab = NewHTable(); NontHashTab = NewHTable(); TermHashTab = NewHTable();

  if ((UnaryPlacesFile = fopen(UNARY, "w")) == NULL) printf("Can't open %s\n", UNARY);

  yyparse(); 
  CTCode = 0;
  treenumber = 0;
  fclose(fpIN);
}
/***********************/
