#include "./Constants.h"

void yyerror(char *str);

/********************/
FILE *fpOUT, *fpIN, *fpCodes;
FILE *fpChsPl;
extern void PRINTTIME();
/************************************/
/*** General types and definitions */
enum RTypes {Unary = 1, Binary = 2, Term = 3, NONE = 0, Eps = 4};
#ifndef RType
#define RType enum RTypes 
#endif
/********************/
enum boolean {false = 0 , true = 1}; 
#define Boolean enum boolean 
/***
#ifndef false
#define false 0
#endif
#ifndef true
#define true 1
#endif
#ifndef Boolean
#define Boolean char
#endif
***/
/********************/
#ifndef MAXLENG 
#define MAXLENG 30
#endif
void *AllocElem(size_t size);
void *MultAlloc(size_t count, size_t elemsize);
void PRI(long int a);
void PRC(char *a);
void PRS(char *a);
void WRITE(char *a);
/*********************/
void PRB(ProbDomain a);
double POWER(double a);
void PRBM(float a);
