#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN, *UnaryPlacesFile;
/**/
int Num_of_Unknowns = 0;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"
#include "GenHashUnit.h"
#include "GenHASHTABLE.h"
#include "PrintingUnary.h"
/****************/
#include "y.tab.c"
#include "lex.yy.c"


char INF[30] ="\0";
char OUF[30] ="\0";
char UNARY[30]=".unary_file.c";

/**/

main(argc, argv)
int argc;
char *argv[];
{ FILE *fopen();
  void TRANS();

  fprintf(stderr,"\n\n%s: compiling dominating unaries out for efficiency\n\n", *argv);

  switch (argc) {
  case 1 : /* standard input and output */
                fpIN = stdin; fpOUT = stdout; TRANS();
                /* printf("Takes an input file\n"); */
                break;
  case 2 : /* standard output */
           strcpy(INF, *(argv+1));
           if ((fpIN = fopen(*++argv, "r")) == NULL)
                               printf("Can't open %s\n", *argv);
           else{fpOUT = stdout;
                TRANS();
               }
           break;
  case 3 : strcpy(INF, *(argv+1));
           strcpy(OUF, *(argv+2));
           if ((fpIN = fopen(*++argv, "r")) == NULL)
                               printf("Can't open %s\n", *argv);
           else if ((fpOUT = fopen(*++argv, "w")) == NULL)
                                printf("Can't open %s\n", *argv);
           else{TRANS();
                fclose(fpOUT);
               }
           break;
  default : printf("Too many arguments for %s\n", argv[0]);
            break;
 }
}
/**********************/
HASHTABLE RuleHashTab; 
HASHTABLE NontHashTab; 
HASHTABLE TermHashTab; 

void TRANS()
{Boolean STOP = false; 
 RuleHashTab = NewHTable(); NontHashTab = NewHTable(); TermHashTab = NewHTable();

  if ((UnaryPlacesFile = fopen(UNARY, "w")) == NULL) printf("Can't open %s\n", UNARY);

  yyparse(); 
  CTCode = 0;
  treenumber = 0;
  fclose(fpIN);
}
