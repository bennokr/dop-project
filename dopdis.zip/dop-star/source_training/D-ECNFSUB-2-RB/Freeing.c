#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"

extern void FreeRPtr(RootPtr RP);

void FreeANode(void *P)
   {FreeRPtr((RootPtr) P);}

void FreeRPtr(RootPtr RP)
{if (RP!=NULL) 
  {PListMapV(RP->Children, (void *) &FreeANode);
   FreePListN(RP->Children);
   free(RP);
  }
}
/**********************/
void FreePListC(PtrList CL)
{     void FreeCode(PtrList C)
        {if (((CodePtr) C->Ptr) != NULL) free((CodePtr) C->Ptr);}
 if (CL != NULL)
   {PListMap(CL, (void *) &FreeCode); FreePListN(CL);}
}
