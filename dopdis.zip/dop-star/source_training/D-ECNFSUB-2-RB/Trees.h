/* Assumed an Item.h in which type ItemTree is */
/* defined. Also it defines various other operations*/
/* on that type (see Item.h and Item.c)         */
/************************************************/
ItemTree CrTree();
/**************************/
/* searches for item in Tree and return a pointer to where */
/* the first time an item is encountred with the same RuleNo */
/* or else a pointer to where it should be entered (a pointer*/
/* to the last which is smaller than item.                   */
ItemTree SearchTree(ItemTree item, ItemTree Tree);
/*************************/
ItemTree EnterTree(void *item1, ItemTree Tree, Boolean *Entered);
void TreeMap(ItemTree Tree, void (* fp)());
/********************/
