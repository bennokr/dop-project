struct CodeStr {
     TreeCodeT TreeC;
     OwnCodeT OwnC; 
     OTSTYPE OTS;
};
typedef struct CodeStr *CodePtr;
CodePtr NewCode(RootPtr RP);
void RelateCodes(void *C1, void *C2, int *relation);
Boolean EqCs(ItemTree C1, ItemTree C2);
Boolean GrCs(ItemTree C1, ItemTree C2);
Boolean LeCs(ItemTree C1, ItemTree C2);
