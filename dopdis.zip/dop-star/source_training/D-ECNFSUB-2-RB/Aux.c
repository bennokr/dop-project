#include "./Universals.h"
#include "./Aux.h"


/**********************************/
/* PRE: size is the size of an obj*/
/*      the returned ptr must be  */
/*      cast into "ptr of obj"    */
/* Synopsis:                      */
/* Allocates space for an obj and */
/* returns a pointer to it.       */
void *AllocElem(size_t size)
{void *ptr;
 ptr = NULL;
 ptr = (void *) malloc(size);
 if (ptr == NULL) {printf("%30s\n", "Unable to allocate AllocElem");exit(1);}
 else return ptr;
}
void *MultAlloc(size_t count, size_t elemsize)
{void *ptr;
 ptr = NULL;
 if (count <= 0) return NULL;
 ptr = (void *) calloc(count, elemsize);
 if (ptr == NULL) {printf("%30s\n", "Unable to allocate MultAlloc"); exit(1);}
 else return ptr;
}
void PRI(long int a) { fprintf(fpOUT, "%ld ", a); }
void PRC(char *a) { fprintf(fpOUT,"%s", a); }
void PRS(char *a) {fprintf(fpOUT, "%s", a);}
/*
void PRS(char *a) { fputs(a, fpOUT); } 
*/
void PRBF(float a) {fprintf(fpOUT, "%e ", a);}
void PRBS(double a) {fprintf(fpOUT, "%f ", (float) a);}
void PRBSI(double a) {fprintf(fpOUT, "%f", (float) a);}
double POWER(double a)
{return ((double) pow((double) 10.0, (double) a));}
void PRB(ProbDomain a) {/* fprintf(fpOUT, "%12.16e ", ( a)); */
                        fprintf(fpOUT, "%6.6e ", (POWER((double) a))); 
                        }
void PRBM(float a) {fprintf(fpOUT, "%f\n", a);}
/**********/
/* writes out the log10 of a double */
void PRBLOGof(double a) {
  if (a>0) fprintf(fpOUT, "%e ",  log10(a));
  else {printf("Log problem "); printf("%e\n", a);}
}                                                        
/***********/
/*void WRITE(char *a) {fputs(a, fpOUT);}*/
void WRITE(char *a) {PRS(a);}

char *TOLOWER(char *a)
{char *new; int j = 0;
 int i = 0;

 new = (char *) AllocElem(SymLength*sizeof(char));
 new[0] = '\0';
 if (a != NULL)
  {while (a[i] != '\0')
    {if (isalpha(a[i])!= 0) {new[j] = (char) tolower((int) a[i]); i++;j++;}
     else {new[j] = a[i]; i++;j++;}}
   new[j] = '\0';
   return new;
  }
 else return NULL;
}

void yyerror(char *str)
{fprintf(stderr, str); exit(1);
}

char *NewStringOf(char *A)
{char *New = NULL; int Totlength = strlen(A) ;
 if (Totlength >= 1)
  {New = (char *) MultAlloc((size_t) (Totlength+1),(sizeof(char)));
   strcpy(New,A);
  }
 return New;
}                  
int Mod(int x, int y)
{return ((int) (fmod((double) x,(double) y))); }
