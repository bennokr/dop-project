#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h" 
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"
#include "GenHashUnit.h"
#include "GenHASHTABLE.h"

/*****
/* 
  A rule X->Alpha is considred a string "A Alpha" and stored in the tree found in a bucket
  in  the following array:
  An array of regions: a region for every char in a-zA-Z; every region consists of buckets:
   a bucket for every char in a-zA-Z. The regions correspond with the first letter of a Symbol
   and the bucket with the second char in Symbol. There also buckets for the case ``empty second
   char" in Symbol.
  Every bucket contain a tree that is ordered left smaller than right.
  With every rule we keep also a list of its occurrences (codes).
*/
/* A global internal for this module */

/****/
#define marge 10

void FreeRulePtr(RulePtr RP)
{if (RP == NULL);
 else {FreePListC(RP->Codes); RP->Codes=NULL; free(RP->NRule); free(RP);}
}

RulePtr NewRule(RootPtr RP)
{RulePtr New = (RulePtr) AllocElem(sizeof(struct RuleStr));
 CodePtr Code = NewCode(RP);
 New->NRule =  (char *) MultAlloc(sizeof(RP->Name)+marge, sizeof(struct RuleStr));
 
 strcpy(New->NRule, RP->Name);
 New->Codes = NULL; New->Codes = EnStack((void *) Code, New->Codes);
 return New;
}

RulePtr RPtr2Rule(RootPtr RP)
{RulePtr New;
    void CpyChName(PtrList CH)
       {RootPtr Rch = (RootPtr) CH->Ptr;
        strcat(New->NRule, " ");
        strcat(New->NRule, Rch->Name);
       }
 New = NewRule(RP);
 PListMap(RP->Children, (void *) &CpyChName);
 return New;
}
char *RPtr2RuleStr(RootPtr RP)
{static char RES[MaxTreeL];
    void CpyChName(PtrList CH) {RootPtr Rch = (RootPtr) CH->Ptr; strcat(RES, " "); strcat(RES, Rch->Name);}

 strcpy(RES,RP->Name);
 PListMap(RP->Children, (void *) &CpyChName);
 return RES;
}
/****************************/
extern HASHTABLE RuleHashTab;  /* the hashtable */

RulePtr FindRule(RootPtr RP)
{UnitPtr UP ; RulePtr result = NULL;
 if (RP == NULL) {printf("Err occurred in FindRule\n"); exit(1);}
 UP = FindUnitInHT(RuleHashTab, RPtr2RuleStr(RP));
 if (UP != NULL) return UP->TheRule;
 else return NULL;
}

void ENTRule(RootPtr RP)
{char *temp; RulePtr New; Boolean Entered = false; UnitPtr ThisUP;
 if ((FindRule(RP)) == NULL)
   {temp = RPtr2RuleStr(RP); ThisUP = ENT2HTable(RuleHashTab, temp); 
    ThisUP->TheRule = RPtr2Rule(RP); 
    {/* saving space */
     cfree(ThisUP->Rule); ThisUP->Rule = ThisUP->TheRule->NRule;}
   }
}
void ShowR(UnitPtr Rule)
{RulePtr RP = NULL;
 if (Rule == NULL) ;
 else RP = (RulePtr) Rule->TheRule;
 
 if (RP== NULL) ;
 else {W_Rule(RP->NRule);PRS("[");
       W_Codes(RP->Codes); PRS("]");
       PRS(";\n");}
}
void ShowRules()
{
 MapOnHTableUnits(RuleHashTab, (void *) &ShowR);
}                             

/**********************/
/*Only if rule exists */
/**********************/
void UpdCsOfR(RootPtr RP, RulePtr RuP)
{CodePtr Code = NewCode(RP);

 RuP->Codes = EnStack((void *) Code, RuP->Codes);
}
/****************************/
void UpdateRules(RootPtr RP)
{RulePtr IsHere = NULL;
 if (RP==NULL) ;
 else if (RP->Children == NULL);
      else {IsHere = FindRule(RP);
            if (IsHere != NULL) {UpdCsOfR(RP, IsHere);}
            else ENTRule(RP);
           }
}             
/************************************ CLOSED          *********************/
/************************************ CLOSED          *********************/
/************************************ CLOSED          *********************/
/************************************ CLOSED          *********************/
/* because its closed the following is set at 1 */
#define MaxI 1 
static ItemTree AllRules[MaxI];

void InitAllRules()
{int i;
 for (i=0; i<Max; i++) AllRules[i]=CrTree();
}
int ChNumber(char c)
{if (c == '-') return ((int) MINUS_base);
 else
 if (c == '_') return ((int) UNDERSC_base);
 else
 if (c == _ECNF_SYM) return ((int) STRUDEL_base);
 else
 if (islower((int) c) != 0) return (((int) c - 'a')+ LOWER_base);
 else if (isupper((int) c) != 0) return (((int) c - 'A')+UPPER_base);
      else if (isdigit((int) c) != 0) return (((int) c - '0') + DIGIT_base);
          else {fprintf(stderr,"Err: unidentified char start %c \n", c); exit(1);} 
}
char FstChsChar(RootPtr RP)
{if (RP->ChNum <=0) {fprintf(stderr,"Err: rule has no children ?\n");exit(1);}
 return (((RootPtr) RP->Children->Ptr)->Name[0]);
}
char LastChsChar(RootPtr RP)
{char *temp;
 if (RP->ChNum <=0) {fprintf(stderr,"Err: rule has no children ?\n");exit(1);}
 temp = ((RootPtr) RP->Children->Ptr)->Name;
 return (temp[strlen(temp)-1]);
}
int PlaceOfOLD(RootPtr RP)
{int Char1Num, Char2Num, Char3Num, Char4Num; int place;
 if (RP==NULL) {printf("Error in PlaceOf\n");exit(1);}
 Char1Num = ChNumber(RP->Name[0]);
 if (RP->Name[strlen(RP->Name) - 1] != '\0')  /* last char */
    Char2Num = (1+ChNumber(RP->Name[strlen(RP->Name) -1])); /* the 1 saves place for the case: no second char*/
 else Char2Num = 0;
 Char3Num = (1+ChNumber(FstChsChar(RP)));
 Char4Num = (1+ChNumber(LastChsChar(RP)));

 return ((FST_HASH_VAL*Char1Num) + (SKND_HASH_VAL*Char2Num) + ((THRD_HASH_VAL)* Char3Num) + Char3Num);
}

RulePtr FindRuleOLD(RootPtr RP)
{int place;
 RulePtr result;
 RulePtr ThisR = NULL;
          void CMPRRule(ItemTree R)
           {RulePtr AR = (RulePtr) R->Ptr;
            if (!strcmp(ThisR->NRule, AR->NRule)) result = AR;
           }
 result = NULL;
 if (RP == NULL) {printf("Err occurred in FindRule\n"); exit(1);}
 place = PlaceOfOLD(RP);
 ThisR = RPtr2Rule(RP);
 TreeMap(AllRules[place], (void *) &CMPRRule);
 FreeRulePtr(ThisR);
 return result;
}
void ENTRuleOLD(RootPtr RP)
{RulePtr New;
 int place = 0;
 Boolean Entered = false;

 place = PlaceOfOLD(RP); /* place = RP->Name[0]-'a'; */
   {New = RPtr2Rule(RP);
    AllRules[place] = EnterTree((void *) New, AllRules[place], &Entered);
    if (Entered == false) cfree(New);
   }
}
void FreeRulesOLD()
{int i;
 for (i=0; i < Max; i++) FreeRTree(AllRules[i]);
}
/************/
