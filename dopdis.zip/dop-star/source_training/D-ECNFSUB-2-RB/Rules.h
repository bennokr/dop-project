struct RuleStr {
    char *NRule;
    PtrList Codes;
};
typedef struct RuleStr *RulePtr;
/***********************/

#define NumOfLowAlpha 27
#define NumOfUpAlpha  27
#define NumOfDigit 11
#define NumOfOtherChars 7
#define NumOfChars (NumOfLowAlpha +NumOfUpAlpha + NumOfDigit + NumOfOtherChars)
#define Max        (NumOfChars * NumOfChars *NumOfChars *NumOfChars)

#define FST_HASH_VAL (NumOfChars * NumOfChars * NumOfChars)
#define SKND_HASH_VAL (NumOfChars * NumOfChars)
#define THRD_HASH_VAL (NumOfChars)

#define LOWER_base   0
#define UPPER_base   (NumOfLowAlpha)
#define DIGIT_base   (UPPER_base + NumOfLowAlpha)
#define STRUDEL_base (DIGIT_base + NumOfDigit )
#define MINUS_base   (STRUDEL_base + 1)
#define UNDERSC_base (MINUS_base + 1)


/********************************************/
/* extern ItemTree AllRules[Max];   */

void ShowRules(); 
void FreeRules();
RulePtr FindRule(RootPtr RP);
void UpdateRules(RootPtr RP) ;
