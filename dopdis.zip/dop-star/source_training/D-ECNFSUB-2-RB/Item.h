#define NumType double 
struct ITEMS {
  struct ITEMS       *Right  ; 
  struct ITEMS       *Left  ;
  void *Ptr;
  /* NumType AppNum;*/
};
typedef struct ITEMS *ItemTree;
ItemTree FillItem(void *Ptr);
/***************************************************/
/* AppToItem applies fp to a given item.           */
/* fp takes rule#, RType, DotPlace, right, left.   */
/* right and left are pointers in the tree to resp */
/* all "larger" items, all "smaller" items.        */
/* For Example: see PTreeItem                      */
Boolean EqItem(ItemTree item1, ItemTree item2);
Boolean GrItem(ItemTree item1, ItemTree item2);
Boolean LeItem(ItemTree item1, ItemTree item2);
Boolean LeqItem(ItemTree item1, ItemTree item2);
Boolean LeqItem(ItemTree item1, ItemTree item2);
/********************************/
