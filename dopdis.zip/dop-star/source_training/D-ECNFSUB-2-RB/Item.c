#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"



ItemTree FillItem(void *Ptr)
{ItemTree IDL = (ItemTree) AllocElem(sizeof(struct ITEMS));
 IDL->Right = (ItemTree) NULL; IDL->Left = (ItemTree) NULL; 
 IDL->Ptr = Ptr;
 /* IDL->AppNum=1;*/
 return IDL;}

Boolean EqItem(ItemTree item1, ItemTree item2)
{char *A = (char *) item1->Ptr;
 char *B = (char *) item2->Ptr;
 if (strcmp(A,B)==0) return true;
 else return false;
}           
Boolean GrItem(ItemTree item1, ItemTree item2)
{char *A = (char *) item1->Ptr;
 char *B = (char *) item2->Ptr;
 if (strcmp(A,B) > 0) return true;
 else return false;
}           
Boolean LeItem(ItemTree item1, ItemTree item2)
{char *A = (char *) item1->Ptr;
 char *B = (char *) item2->Ptr;
 if (strcmp(A,B) < 0) return true;
 else return false;
}           
Boolean GeqItem(ItemTree item1, ItemTree item2)
{return ((GrItem(item1, item2)) || (EqItem(item1, item2)));}
Boolean LeqItem(ItemTree item1, ItemTree item2)
{return ((LeItem(item1, item2)) || (EqItem(item1, item2)));}
/*****************************/
void VEqItems(void *PtrA, void *PtrB, Boolean *EQ)
{ItemTree A = (ItemTree) PtrA;
 ItemTree B = (ItemTree) PtrB;
 /* *EQ = EqItem(A, B); */
 *EQ = (A == B) ? true: false;
}
/*************************************************/
