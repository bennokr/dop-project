#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "Types.h"
#include "ProbList.h"
#include "Item.h"
#include "Trees.h"
#include "PtrList.h"
#include "Roots.h"
#include "Codes.h"
#include "Rules.h"
#include "Update.h"



void FreeSymTree(ItemTree I)
{if (I != NULL)
 {FreeSymTree(I->Right); FreeSymTree(I->Left); free(I);
 }
}
/************************************************/
ItemTree CrTree()
{return NULL;}

/**************************/
/* searches for item in Tree and return a pointer to where */
/* the first time an item is encountred with the same RuleNo */
/* or else a pointer to where it should be entered (a pointer*/
/* to the last which is smaller than item.                   */
ItemTree SearchTree(ItemTree item, ItemTree Tree)
{if (Tree == NULL) return NULL;
 else if (EqItem(item, Tree)) return Tree;
      else if (GrItem(item, Tree)==true) 
             if (Tree->Right == NULL) return Tree;
             else return SearchTree(item, Tree->Right);
             /* must be LeItem(item, Tree) */
           else if (LeItem(item, Tree)==true) 
                   if (Tree->Left == NULL) return Tree;
                   else return SearchTree(item, Tree->Left);
                else return Tree;
}
/**********************/
/* Special for codes */
ItemTree SearchTreeC(ItemTree item, ItemTree Tree)
{if (Tree == NULL) return NULL;
 else if (EqCs(item, Tree)==true) return Tree;
      else if (GrCs(item, Tree)==true) 
             if (Tree->Right == NULL) return Tree;
             else return SearchTreeC(item, Tree->Right);
             /* must be LeItem(item, Tree) */
           else if (LeCs(item, Tree)==true) 
                   if (Tree->Left == NULL) return Tree;
                   else return SearchTreeC(item, Tree->Left);
                else return Tree;
}
/*************************/
/* Keeps it as a set     */
/*************************/
/* Special for codes, just stacks them */
int balance = 1;
ItemTree EnterTreeC(void *item1, ItemTree Tree)
{ItemTree This;
 ItemTree item = (ItemTree) FillItem(item1); 
 if (Tree==NULL) return item;           /** first item ***/
 else if ((balance%2) == 0) {balance = 0;
                             item->Right = Tree; 
                             return (item);              
                            }
      else {balance++;
            item->Left = Tree; 
            return (item);              
           }
}
/****************/
ItemTree EnterTree(void *item1, ItemTree Tree, Boolean *Entered)
{ItemTree This;
 ItemTree item = (ItemTree) FillItem(item1); 
 *Entered = true;
 if (Tree==NULL) return item;           /** first item ***/
 else {This = (ItemTree) SearchTree(item, Tree);
      if (EqItem(item, This)==true) 
        {*Entered = false;FreeSymTree(item); return Tree;}
      else if (GrItem(item, This)==true) {*Entered = true;
                                          This->Right = item; return Tree;}
             /* must be Less(item, This) */
           else {*Entered = true; This->Left = item; return Tree;}
      }
}
/*************************/
/* An NLR visit **********/
/* Special for codes */
ItemTree RMost(ItemTree T)
{if (T == NULL) return NULL;
 else if (T->Right == NULL) return (T);
      else return (RMost(T->Right));
}
void TreeMapC(ItemTree Tree, void (* fp)())
{if (Tree != NULL) {TreeMapC(Tree->Left, fp);
                    (*fp)(Tree); 
                    TreeMapC(Tree->Right, fp);
                   }
}
void TreeMap(ItemTree Tree, void (* fp)())
{if (Tree != NULL) {(*fp)(Tree);
                    TreeMap(Tree->Left, fp);
                    TreeMap(Tree->Right, fp);
                   }
}
void TreeMapTerm(ItemTree Tree, void (* fp)())
{if (Tree != NULL) {TreeMapTerm(Tree->Left, fp);
                       (*fp)(Tree);
                    TreeMapTerm(Tree->Right, fp);
                   }
}
/*************************/
int TreeDepth(ItemTree Tree)
{int LD, RD;
 if (Tree == NULL) return 0;
 else {LD = TreeDepth(Tree->Left);
       RD = TreeDepth(Tree->Right);
       if (LD > RD) return (1+LD);
       else return (1+RD);
      }
}
int TreeCount(ItemTree Tree)
{int LD, RD;
 if (Tree == NULL) return 0;
 else {LD = TreeCount(Tree->Left);
       RD = TreeCount(Tree->Right);
       return (1+RD+LD);
      }
}
/**********************/
void FreeTree(ItemTree I)
{if (I != NULL)
  {FreeTree(I->Right);
   FreeTree(I->Left);
   free(I);}
}
void FreeRTree(ItemTree RI)
{if (RI!=NULL)
   {if (((RulePtr) RI->Ptr) != NULL) 
         {FreePListC(((RulePtr)(RI->Ptr))->Codes);
          free(((RulePtr)(RI->Ptr))->NRule);
          free((RulePtr)RI->Ptr);}
    FreeRTree(RI->Right);
    FreeRTree(RI->Left);
    free(RI);
   }           
}
