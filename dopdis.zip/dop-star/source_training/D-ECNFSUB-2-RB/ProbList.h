#define DirectionType Boolean
#define FORWARD true
#define BACKWARD false
/********************/
#define ProbType double
struct ProbStruct {
    ProbType Content;
struct ProbStruct *Next;
struct ProbStruct *Prev;
};
typedef struct ProbStruct *ProbPtr;

struct ProbDList {
   ProbPtr First;
   ProbPtr Last;
};
typedef struct ProbDList *ProbList;

/*******/

extern ProbList Probabilities;
/*******/
void MapOnProbabilities(void (* fp)(), DirectionType DT);
void EnterProb(ProbType P);
void ShowProb(ProbPtr P);
