/***************/
/* The general hash-table module based on PtrLists */
#ifndef Maxvalue
#define Maxvalue 4000001
#endif
/* A hashtable is an Array of PtrLists */ 
typedef PtrList *HASHLIST ;
struct HASHSTRUCT {
    HASHLIST TheHT;
    UnitNumType Num; /* number of units in table */
    FreqType SumFreq;
};
typedef struct HASHSTRUCT *HASHTABLE;
/***********************/
HASHTABLE AllocHashTable();
/*****************************/
void InitHTable(HASHTABLE HT);
/*****************************/
/* Allocates and initializes */
HASHTABLE NewHTable();
/*****************************/
int BucketOf(UnitPtr RU);
/***********************************************************************/
/* Enter a new tree structure under RP into the hashing table AllRules */
UnitPtr ENT2HTable(HASHTABLE HTP,char *String);
/****************************/
UnitPtr FindUnitInHT(HASHTABLE HTP, char *String);
/**************/
void FreeHTable(HASHTABLE HTP);
void MapOnHTableKey(HASHTABLE HTP, void (* fp)());
void MapOnHTableUnits(HASHTABLE HTP, void (* fp)());
FreqType TotalFreqOf(HASHTABLE HTP);
void RemoveHEntryOf(HASHTABLE HTP, char *String);
UnitNumType UnitNumOf(HASHTABLE HTP, char *String);
float FreqStdDev(HASHTABLE HTP);
float AverageFreq(HASHTABLE HTP);
char *MaxFreqKeyOf(HASHTABLE HTP);
