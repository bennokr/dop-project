#include "Universals.h"
#include "Constants.h"
#include "Aux.h"        

#ifndef T_MIN_SYM
#define T_MIN_SYM "_v_"
#define MT_MIN_SYM 'v'
#endif
#ifndef T_ECNF_SYM
#define T_ECNF_SYM "_e_"
#define MT_ECNF_SYM 'e'
#endif
#ifndef T_PERC_SYM
#define T_PERC_SYM "_p_"
#define MT_PERC_SYM 'p'
#endif

#define SET_OF_SYMS "@-%"

char Temp[SymLength];

char *TransformSym(char c)
{ strcpy(Temp,"");

  if (c == _ECNF_SYM) strcpy(Temp, T_ECNF_SYM);
  else
  if (c == '-') strcpy(Temp, T_MIN_SYM);
  else
  if (c == '%') strcpy(Temp, T_PERC_SYM);
  else {Temp[0] = c; Temp[1] ='\0';}

  return Temp;
}

int Mod(int x, int y)
{return ((int) (fmod((double) x,(double) y))); }
                                                                                                                                                  
/**********************************/
/* PRE: size is the size of an obj*/
/*      the returned ptr must be  */
/*      cast into "ptr of obj"    */
/* Synopsis:                      */
/* Allocates space for an obj and */
/* returns a pointer to it.       */
void *AllocElem(int size)
{void *ptr = NULL;
 ptr = (void *) calloc(1, size);
 if (ptr == NULL) printf("%30s\n", "Unable to allocate");
 else return ptr;
}
void PRL(long int a) {fprintf(fpOUT, "%d", a); }
void STDPRL(long int a) {printf("%ld", a); }
void PRI(int a) {fprintf(fpOUT, "%3d ", a); }
void PRC(char *a) { printf("%s ", a); }
void WRITE(char *a) {/*fputs(a, fpOUT);*/ fprintf(fpOUT, "%s", a);}
/********************/
extern char *ShortRepresent(char *WORD);

void WRITEX(char *a)
{int i; char TEMP[SymLength]; 

 strcpy(TEMP,"");
 if ((strpbrk(a, SET_OF_SYMS)) != NULL)
   {for (i=0; i < strlen(a); i++) strcat(TEMP, TransformSym(a[i])); }
 else strcpy(TEMP, a);
 
 WRITE(TEMP); /* making problems. WHY ? */ 

 if (1==0) WRITE(ShortRepresent(TEMP)); /* making problems. WHY ? */ 
}
/***************/
void PRS(char *a)
{/* fputs(a, fpOUT); fputs(" ", fpOUT);*/
 fprintf(fpOUT,"%s ", a);
}
/* void PRS(char *a) {WRITE(a);WRITE(" ");}*/
int KeyComp(KeyType A1, KeyType A2) {return strcmp(A1, A2);}
extern int GrammarNum;
void WGNum() {if (GrammarNum > 0) fprintf(fpOUT,"%d",GrammarNum);}

void *MultAlloc(size_t count, size_t elemsize)
{void *ptr;
 ptr = NULL;
 if (count <= 0) return NULL;
 ptr = (void *) calloc(count, elemsize);
 if (ptr == NULL) {printf("%30s\n", "Unable to allocate MultAlloc"); exit(1);}
 else return ptr;
}          

Boolean TerminalSym(char *sym)
{if (sym[strlen(sym)-1] == '_') return true;
 else return false;
}

char *NewStringOf(char *A)
{char *New = NULL; int Totlength = strlen(A) ;
 if (Totlength >= 1)
  {New = (char *) MultAlloc((size_t) (Totlength+1),(sizeof(char)));
   strcpy(New,A);
  }
 return New;
}

