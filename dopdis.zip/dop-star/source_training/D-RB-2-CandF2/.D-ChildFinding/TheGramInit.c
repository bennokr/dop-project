#include "time.h"
#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "float.h"
#include "math.h"
/************** My own files  ********/
/** General declations and definitions */
/*******************/
#include "/users.ruulst/simaan/DUtrecht/DPROGS/D-LargeDisam/Aux.h"
#include "/users.ruulst/simaan/DUtrecht/DPROGS/D-Interface/LEXICAL.h"
/*******************/
#include "/users.ruulst/simaan/DUtrecht/DPROGS/D-LargeDisam/CodeType.h"
#include "/users.ruulst/simaan/DUtrecht/DPROGS/D-LargeDisam/DefsGrammar.h"
/**************************/
extern NTDomain StartNonterminal ;
extern NTDomain NonTSize ;
extern TDomain TermsSize ;
extern RDomain TRSize  ;
extern RDomain URSize  ;
extern RDomain BRSize  ;
extern RDomain EpsRSize  ;

extern struct RuleStruct  *EpsRules;
extern struct RuleStruct *TRules ;
extern struct RuleStruct *URules ;
extern struct RuleStruct *BRules ;

extern struct NTStruct *NTArray ;
extern struct NTStruct *Rhs1Array ;
extern struct NTStruct *Rhs2Array ;
extern struct TermStruct *TermsArray ;

extern struct Place_Struct *T_R_Apps ;
extern struct Place_Struct *B_R_Apps ;
extern struct Place_Struct *Eps_R_Apps ;
extern struct Place_Struct *U_R_Apps ;
extern TreeCodeT TotalRootsNum ;
extern ProbDomain *TheProbOf ;
/**************************/
#include "Grammar.c"
/**************************/
void InitGrammar()
{
 StartNonterminal = IVStartNonterminal ;
 NonTSize = IVNonTSize ;
 TermsSize = IVTermsSize ;
 TRSize  = IVTRSize  ;
 URSize  = IVURSize ; 
 BRSize  = IVBRSize ;
 EpsRSize  = IVEpsRSize ;

 EpsRules = IVEpsRules;
 TRules = IVTRules ;
 URules = IVURules ;
 BRules = IVBRules ;

 NTArray = IVNTArray ;
 Rhs1Array = IVRhs1Array ;
 Rhs2Array = IVRhs2Array ;
 TermsArray = IVTermsArray ;

 T_R_Apps = IVT_R_Apps ;
 B_R_Apps = IVB_R_Apps ;
 Eps_R_Apps = IVEps_R_Apps ;
 U_R_Apps = IVU_R_Apps ;
 TotalRootsNum = IVTotalRootsNum ;
 TheProbOf = IVTheProbOf;
}
