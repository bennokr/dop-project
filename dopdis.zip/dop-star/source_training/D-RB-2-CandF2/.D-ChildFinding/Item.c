ItemTree FillItem(void *Ptr, PlacesT PL)
{ItemTree IDL = (ItemTree) AllocElem(sizeof(struct ITEMS));
 IDL->Right = (ItemTree) NULL; IDL->Left = (ItemTree) NULL; 
 IDL->Ptr = Ptr;
 IDL->Next = NULL;
 IDL->Address = PL;
 return IDL;}

void Show_Item(ItemTree I)
{NodePtr N = (NodePtr) I->Ptr;
 printf("%d %d \n", N->Code.TreeC, N->Code.OwnC);
 printf("%d \n", I->Address);
 printf("------\n");
}
