PtrList CrPList()
{return NULL;}
/***********/
PtrList NewPtr(void *Ptr)
{PtrList IDL = (PtrList) AllocElem(sizeof(struct PtrLStr));
 IDL->Next = NULL;
 IDL->Ptr = Ptr;
 return IDL;
}
/***********/
void FreePList(PtrList L)
{PtrList Head = L;
 PtrList Prev;
 while (Head != NULL) {
   Prev = Head;
   Head = Head->Next;
   free(Prev);
 }
}
/***********/
void FreePListC(PtrList CL)
{     void FreeCode(PtrList C)
        {if (((CodePtr) C->Ptr) != NULL) free((CodePtr) C->Ptr);}
 if (CL != NULL)
   {PListMap(CL, (void *) &FreeCode);
    FreePList(CL);}
}
/***********/
/* Queue */
PtrList EnterP(void *Ptra, PtrList L)
{PtrList this = L;
 PtrList Last = NULL;
 PtrList New = NewPtr(Ptra);
 
 while (this != NULL) {Last = this; this = this->Next;}
 if (Last != NULL) {Last->Next = New; return L;}
 else return New;
}
/***********/
void PListMap(PtrList L, void (* fp)())
{PtrList This = L;
 while(This != NULL) {(*fp)(This);
                       This = This->Next;
                     }
}
/**************/
PtrList EnStack(void *P, PtrList L)
{PtrList L1 = NewPtr(P);
 L1->Next = L;
 return L1;
}
/***********/
