#define IVStartNonterminal 2
#define IVNonTSize 3
/* enum Nonterminals  */
#define IVTermsSize 2
/* enum Terminals  */
/* struct RuleStruct {
       NTDomain lhs; 
       TDomain rhs1; 
       NTDomain rhs2; 
};
 *//** ** *** *****/
#define IVTRSize  2
#define IVURSize  1
#define IVBRSize  2
#define IVEpsRSize  0
/** Eps Rules **/
struct RuleStruct  *IVEpsRules = NULL;
/** Term Rules **/
struct RuleStruct IVTRules[IVTRSize] = {
{0,1,-1}, {1,0,-1}};
/** Unary Rules **/
struct RuleStruct IVURules[IVURSize] = {{2,1,-1}};
/** Binary Rules **/
struct RuleStruct IVBRules[IVBRSize] = {{1,1,0}, {0,0,0}};

/** The nonterminals arrays ***/
/* struct NTStruct {
        char *NT;
        RDomain *TRules;
        RDomain TCount;
        RDomain *URules;
        RDomain UCount;
        RDomain *BRules;
        RDomain BCount;
        RDomain *EpsRules;
        RDomain EpsCount;
};*/
#define _TBCOUNT 1
RDomain _TB[_TBCOUNT] =  {0};
#define _UBCOUNT 0
#define _UB  NULL
#define _BBCOUNT 1
RDomain _BB[_BBCOUNT] =  {1};
#define _EpsBCOUNT 0
#define _EpsB  NULL
#define _TSCOUNT 1
RDomain _TS[_TSCOUNT] =  {1};
#define _USCOUNT 0
#define _US  NULL
#define _BSCOUNT 1
RDomain _BS[_BSCOUNT] =  {0};
#define _EpsSCOUNT 0
#define _EpsS  NULL
#define _TSSCOUNT 0
#define _TSS  NULL
#define _USSCOUNT 1
RDomain _USS[_USSCOUNT] =  {0};
#define _BSSCOUNT 0
#define _BSS  NULL
#define _EpsSSCOUNT 0
#define _EpsSS  NULL
struct NTStruct IVNTArray[IVNonTSize] = {
{"B",_TB, _TBCOUNT, _UB, _UBCOUNT, _BB, _BBCOUNT, _EpsB, _EpsBCOUNT},
 {"S",_TS, _TSCOUNT, _US, _USCOUNT, _BS, _BSCOUNT, _EpsS, _EpsSCOUNT},
 {"SS",_TSS, _TSSCOUNT, _USS, _USSCOUNT, _BSS, _BSSCOUNT, _EpsSS, _EpsSSCOUNT}
}; /* End of NTArray */
#define _Rhs1TBCOUNT 0
#define _Rhs1TB  NULL
#define _Rhs1UBCOUNT 0
#define _Rhs1UB  NULL
#define _Rhs1BBCOUNT 1
RDomain _Rhs1BB[_Rhs1BBCOUNT] =  {1};
#define _Rhs1EpsBCOUNT 0
#define _Rhs1EpsB  NULL
#define _Rhs1TSCOUNT 0
#define _Rhs1TS  NULL
#define _Rhs1USCOUNT 1
RDomain _Rhs1US[_Rhs1USCOUNT] =  {0};
#define _Rhs1BSCOUNT 1
RDomain _Rhs1BS[_Rhs1BSCOUNT] =  {0};
#define _Rhs1EpsSCOUNT 0
#define _Rhs1EpsS  NULL
#define _Rhs1TSSCOUNT 0
#define _Rhs1TSS  NULL
#define _Rhs1USSCOUNT 0
#define _Rhs1USS  NULL
#define _Rhs1BSSCOUNT 0
#define _Rhs1BSS  NULL
#define _Rhs1EpsSSCOUNT 0
#define _Rhs1EpsSS  NULL
struct NTStruct IVRhs1Array[IVNonTSize] = {
{"B",_Rhs1TB, _Rhs1TBCOUNT, _Rhs1UB, _Rhs1UBCOUNT, _Rhs1BB, _Rhs1BBCOUNT, _Rhs1EpsB, _Rhs1EpsBCOUNT},
 {"S",_Rhs1TS, _Rhs1TSCOUNT, _Rhs1US, _Rhs1USCOUNT, _Rhs1BS, _Rhs1BSCOUNT, _Rhs1EpsS, _Rhs1EpsSCOUNT},
 {"SS",_Rhs1TSS, _Rhs1TSSCOUNT, _Rhs1USS, _Rhs1USSCOUNT, _Rhs1BSS, _Rhs1BSSCOUNT, _Rhs1EpsSS, _Rhs1EpsSSCOUNT}
}; /* End of Rhs1Array */
#define _Rhs2TBCOUNT 0
#define _Rhs2TB  NULL
#define _Rhs2UBCOUNT 0
#define _Rhs2UB  NULL
#define _Rhs2BBCOUNT 2
RDomain _Rhs2BB[_Rhs2BBCOUNT] =  {0, 
1};
#define _Rhs2EpsBCOUNT 0
#define _Rhs2EpsB  NULL
#define _Rhs2TSCOUNT 0
#define _Rhs2TS  NULL
#define _Rhs2USCOUNT 0
#define _Rhs2US  NULL
#define _Rhs2BSCOUNT 0
#define _Rhs2BS  NULL
#define _Rhs2EpsSCOUNT 0
#define _Rhs2EpsS  NULL
#define _Rhs2TSSCOUNT 0
#define _Rhs2TSS  NULL
#define _Rhs2USSCOUNT 0
#define _Rhs2USS  NULL
#define _Rhs2BSSCOUNT 0
#define _Rhs2BSS  NULL
#define _Rhs2EpsSSCOUNT 0
#define _Rhs2EpsSS  NULL
struct NTStruct IVRhs2Array[IVNonTSize] = {
{"B",_Rhs2TB, _Rhs2TBCOUNT, _Rhs2UB, _Rhs2UBCOUNT, _Rhs2BB, _Rhs2BBCOUNT, _Rhs2EpsB, _Rhs2EpsBCOUNT},
 {"S",_Rhs2TS, _Rhs2TSCOUNT, _Rhs2US, _Rhs2USCOUNT, _Rhs2BS, _Rhs2BSCOUNT, _Rhs2EpsS, _Rhs2EpsSCOUNT},
 {"SS",_Rhs2TSS, _Rhs2TSSCOUNT, _Rhs2USS, _Rhs2USSCOUNT, _Rhs2BSS, _Rhs2BSSCOUNT, _Rhs2EpsSS, _Rhs2EpsSSCOUNT}
}; /* End of Rhs2Array */
/* TermsArray ****/
/* struct TermStruct {
char *Term;
RDomain *TRules;
RDomain TCount;
};
 */#define _TaCOUNT 1
RDomain _Ta[_TaCOUNT] =  {1};
#define _TbCOUNT 1
RDomain _Tb[_TbCOUNT] =  {0};
struct TermStruct IVTermsArray[IVTermsSize] = {
{"a",_Ta, _TaCOUNT},
 {"b",_Tb, _TbCOUNT}
}; /* End of TermsArray */
/**************************************/
 /* enum OTSTYPE {NEITHER=0,ONLYLHS=1,ONLYRHS=2,BOTH=3};
 typedef enum OTSTYPE OTS_Type;
 struct Node_Type {
   CodeType Code;
   OTS_Type OTS;
 };*/ /* -- */
 /* struct Nodes_Struct {
         TreeCodeT Roots_Size; 
         InTreeCodeT Others_Size;
     struct Node_Type *Roots_Nodes,
                     *Others_Nodes;
 };*//* --- */
 /* struct Place_Str {
         TreeCodeT Roots_Size; 
         InTreeCodeT Others_Size;
         long int Roots_StartPos;
         long int Others_StartPos;
 };*//* --- */
 /**************************************/
 
#define  _T_Roots_Size1  1
#define  _T_Oths_Size1  1
#define _T_Roots_L1 0 
#define _T_Oths_L1 12 

#define  _T_Roots_Size0  0
#define  _T_Oths_Size0  4
#define  _T_Roots_L0 -1
#define _T_Oths_L0 24 
struct Place_Struct IVT_R_Apps[IVTRSize] = {
 {_T_Roots_Size0, _T_Oths_Size0, _T_Roots_L0, _T_Oths_L0}, 
{_T_Roots_Size1, _T_Oths_Size1, _T_Roots_L1, _T_Oths_L1}
};
 /* ---------------*/
 
#define  _B_Roots_Size1  1
#define  _B_Oths_Size1  1
#define _B_Roots_L1 72 
#define _B_Oths_L1 84 

#define  _B_Roots_Size0  2
#define  _B_Oths_Size0  0
#define _B_Roots_L0 96 
#define  _B_Oths_L0  -1
struct Place_Struct IVB_R_Apps[IVBRSize] = {
 {_B_Roots_Size0, _B_Oths_Size0, _B_Roots_L0, _B_Oths_L0}, 
{_B_Roots_Size1, _B_Oths_Size1, _B_Roots_L1, _B_Oths_L1}
};
 /*---------------*/
 struct Place_Struct IVEps_R_Apps[IVEpsRSize] = {
 };
 /*---------------*/
 
#define  _U_Roots_Size0  1
#define  _U_Oths_Size0  0
#define _U_Roots_L0 120 
#define  _U_Oths_L0  -1
struct Place_Struct IVU_R_Apps[IVURSize] = {
 {_U_Roots_Size0, _U_Oths_Size0, _U_Roots_L0, _U_Oths_L0}
};
 /*---------------*/
 #define IVTotalRootsNum 5
 ProbDomain IVTheProbOf[IVTotalRootsNum] = 
{ 0.000000, 0.000000, 0.000000, 0.000000
, 0.000000};
