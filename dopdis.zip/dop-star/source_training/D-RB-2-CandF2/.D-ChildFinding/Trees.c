/************************************************/
ItemTree CrTree()
{return NULL;}

/**************************/
/* searches for item in Tree and return a pointer to where */
/* the first time an item is encountred with the same RuleNo */
/* or else a pointer to where it should be entered (a pointer*/
/* to the last which is smaller than item.                   */
/**********************/
/* Special for codes */
enum Relate RelateCNodes(ItemTree I1, ItemTree I2)
{return (CodeREL(I1->Ptr, I2->Ptr));
}
ItemTree FindTree(ItemTree item, ItemTree Tree)
{enum Relate REL;
 if (Tree == NULL) return NULL;
 else 
   {REL = RelateCNodes(item, Tree);
    if (REL==EQL) return Tree;
    else if (REL==BIG) return (FindTree(item, Tree->Right));
         else return (FindTree(item, Tree->Left));
    }
}
ItemTree SearchTree(ItemTree item, ItemTree Tree)
{enum Relate REL;
 if (Tree == NULL) return NULL;
 else 
   {REL = RelateCNodes(item, Tree);
    if (REL==EQL) return Tree;
    else if (REL==BIG) if (Tree->Right == NULL) return Tree;
                       else return SearchTree(item, Tree->Right);
         else if (REL==SML) if (Tree->Left == NULL) return Tree;
                            else return SearchTree(item, Tree->Left);
              else return Tree;
    }
}
/*************************/
/* Keeps it as a set     */
/*************************/
ItemTree EnterTree(ItemTree item, ItemTree Tree)
{ItemTree This;
 enum Relate REL;

 if (Tree==NULL) return item;           /** first item ***/
 else {This = (ItemTree) SearchTree(item, Tree);
       REL = RelateCNodes(item, This);
      if (REL==EQL) return Tree;
      else if (REL==BIG) {This->Right = item; return Tree;}
           else {This->Left = item; return Tree;}
      }
}
/*************************/
void TreeLMap(ItemTree Tree, void (* fp)())
{ItemTree This = Tree;
  while (This != NULL) {(*fp)(This); This = This->Next;} 
}
void TreeMap(ItemTree Tree, void (* fp)())
{if (Tree != NULL) {TreeMap(Tree->Left, fp);
                    (*fp)(Tree);
                    TreeMap(Tree->Right, fp);
                   }
}
/*************************/
int TreeDepth(ItemTree Tree)
{int LD, RD;
 if (Tree == NULL) return 0;
 else {LD = TreeDepth(Tree->Left);
       RD = TreeDepth(Tree->Right);
       if (LD > RD) return (1+LD);
       else return (1+RD);
      }
}
int TreeCount(ItemTree Tree)
{int LD, RD;
 if (Tree == NULL) return 0;
 else {LD = TreeCount(Tree->Left);
       RD = TreeCount(Tree->Right);
       return (1+RD+LD);
      }
}
/**********************/
void FreeTree(ItemTree I)
{if (I != NULL)
  {FreeTree(I->Right);
   FreeTree(I->Left);
   free(I);}
}
