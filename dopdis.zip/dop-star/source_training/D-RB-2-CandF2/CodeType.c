#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"
/********************************/
void InitCode(CodePtr CP)
{CP->TreeC = 0; CP->OwnC = 0;}

CodePtr NewCPtr()
{CodePtr CdP = (CodePtr) AllocElem(sizeof(CodeType));
 InitCode(CdP); return CdP;
}
/* A root has code 1 always */
Boolean IsRoot(CodeType *C)
{if (C->OwnC == 1) return true; else return false;}
/****/
NodePtr NewNP(TreeCodeT num)
{NodePtr NP ;
 if (num == 0) return NULL;
 else {NP = (NodePtr) MultAlloc((size_t) num,sizeof(struct Node_Type));
       InitCode(&NP->Code); NP->OTS=0;
       return NP;}
}
/************************/
/* Takes a string "/c1/c2/c3" and generates a pointer to a code.  */
/************************/
NodePtr FromStrToCode(char *C)
{InTreeCodeT i;
 char *y;
 char *x = C; 
 NodePtr CdP = NULL;
 if (C != NULL)
  {CdP = NewNP(1);
   /*strcpy(y, C);*/
 y = C;
 y = strrchr(y, '/'); i = InTreeAToD(y+1); CdP->OTS = i;
 *y = '\0'; y = x;
 y = strrchr(y, '/'); i = InTreeAToD(y+1); CdP->Code.OwnC = i; 
 *y = '\0'; y =x;
 *y= '0'; CdP->Code.TreeC = TreeAToD(y);
 }
 return CdP;
}
