#include "/nfs/turing/tur4/simaan/D-NEWPARSER/Universals.h"
/********************************/
/* The types of codes and operations
   of of conversion on them     */
/* typedef unsigned int TreeCodeT;
typedef unsigned short int InTreeCodeT;
#define TreeAToD (unsigned int) atol
#define InTreeAToD (unsigned short int) atoi */
/********************************/
struct CodeTStruct {
     TreeCodeT TreeC;
     InTreeCodeT OwnC;
     InTreeCodeT OTS;
};
typedef struct CodeTStruct CodeType;
typedef CodeType *CodePtr; 

CodePtr NewCPtr()
{CodePtr CdP = (CodePtr) AllocElem(sizeof(CodeType));
 CdP->TreeC = 0;
 CdP->OwnC = 0;
 CdP->OTS = 0;
 return CdP;
}
Boolean Parent(CodePtr CP, CodePtr Ch)
{if (CP->TreeC == Ch->TreeC)
   if ((((float) Ch->OwnC) / ((float) CP->OwnC)) == ((float) 2)) return true;
   else return false;
 else return false;
}
/* A root has code 1 always */
Boolean IsRoot(CodeType *C)
{if (C->OwnC == 1) return true;
 else return false;
}
/************************/
/* Takes a string "/c1/c2/c3" and generates a pointer
   to a code.
*/
/************************/
CodePtr FromStrToCode(char *C)
{InTreeCodeT i;
 char *y;
 char *x = C; 
 CodePtr CdP = NULL;
 if (C != NULL)
  {CdP = NewCPtr();
   /*strcpy(y, C);*/
 y = C;
 y = strrchr(y, '/'); i = InTreeAToD(y+1); CdP->OTS = i;
 *y = '\0'; y = x;
 y = strrchr(y, '/'); i = InTreeAToD(y+1); CdP->OwnC = i; 
 *y = '\0'; y =x;
 *y= '0'; CdP->TreeC = TreeAToD(y);
 }
 return CdP;
}
