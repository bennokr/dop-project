/*********************************************************************/
/*********************************************************************/
/*    MODULE ELEMENTS i.e. filling and creating an element           */
/*********************************************************************/
List EnterKey(KeyType key)
{List x = NULL;
 x = (List) AllocElem(sizeof(struct ElemType)); 
 
 /* x->Key = key;*/
 KeyAssig(x->Key, key);
 x->Next = NULL;
 x->Data = NULL;
 return x;
}
/***********************************/
/* Checks whether key is in this   */
/* element.                        */
Boolean InElm(KeyType key, List L)
{int CMP;
 if (L == NULL) return false;
 else {CMP = KeyComp(L->Key, key);
       if (Eq(CMP)) return true;
       else return false;}
}
/*********************************************************************/
/*  THE MODULE Lists IS HEREUNDER                                    */
/*********************************************************************/
/* initializes  to NULL */
List CreateList()
{return NULL;}
/*********************************************************************/
/* Given  a list it returns a pointer to the second element
   in the list. In case the list is empty it returns NULL       */
List Next(List L)
{List This;
 This = (L == NULL) ? NULL : L->Next; 
 return This;
}
/*********************************************************************/
/* 
 Precond: L must exist;
 returns a pointer to the last item smaller than key in list
 otherwise: a pointer to the first item which is larger 
 *C counts the place of the wanted key from the beginning (1) 
--------------------------------------------------------------*/
List Search(KeyType key, List L, TDomain *C)
{List This, Follow;
 int CMP;
 if (L == NULL) {*C = 0; return NULL;}
 else {
   This = L;
   Follow = Next(This); *C = 1;
   while (Follow != NULL) 
    { CMP = KeyComp(Follow->Key, key);
     if (Leq(CMP))
        {This = Follow; Follow = Next(This); (*C)++;}
     else break;}
   return This;
 }
}
/*********************************************************************/
/* Enters elem into list pointed to by L in the right place keeping  */
/* the lexicographic order in good shape.                            */
/* Pre: L is a lexicographically ordered list such that one of three */
/*      is true: 1. given key is smaller than the first key          */
/*               2. given key ranks between first and second  keys   */
/*               3. given key is equal to first key                  */
List EnterElem(KeyType key, List L)
{List elem = EnterKey(key);
 List Start = L;
 int CMP;
 if (Start != NULL) CMP = KeyComp(Start->Key, key);
 if (Start != NULL) {if (Less(CMP)) 
                         {elem->Next = Start->Next;
                          Start->Next = elem;
                          return Start; 
                         }
                     else if (Greater(CMP)) 
                        {/* No smaller  or eq elements */
                         elem->Next = Start ;
                         return elem;
                        }
                     /* already exists                 */
                    else if (Eq(CMP)) return Start;
                }
 else return elem;  /* In case its first time */
}
/*********************************************************************/
/* Pre: list must exit i.e. at least must have value NULL.          */
/*      list must be ordered.                                       */
/*      Change must be the address of a boolean                     */
/* Post: an oredred list in which key also appears (an oredred set)  */
List Enter(KeyType key, List list, enum boolean *Change)
{List This, Start;
 TDomain C;
 *Change = true;
 if (list == NULL) return EnterElem(key, list);
 else {Start = Search(key, list, &C);
       *Change = InElm(key, Start) ? false : true;
       This = EnterElem(key, Start);
                             /* In case the new key is NOT smallest*/
                             /* or not new */
       if ((C > 1) || (*Change == false)) 
                      return list; 
       else return This;
      }
}
/*******************************************************/
void ListMap(List L, void (* fp)())
{List This = L;
 while (L != NULL) {(*fp)(L->Key, L->Next); L = L->Next;}
}
