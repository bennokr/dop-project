/********************************************************************/
/** Decl global variables **/
   /******* Current rule structure *********/
struct CRuleStruct {
         enum RType soort;
         NTDomain lhs;
         TDomain rhs1;
         NTDomain rhs2;
         Set Nptr;   /* a pointer to the lhs nonterminal in Nonterminals 
                        instead of saving it's name (maybe in the
                        future will be usefull. I could have saved
                        the name instead !!. The same applies for the
                        next 3 pointers (Sets)                      */
         Set Rhs1ptr;
         Set Rhs2ptr;
         Set Tptr;
         RDomain NUM;
   };
 struct CRuleStruct CRule = {Binary, -1, -1, -1, NULL, NULL, NULL, NULL, -1}; 
 struct CRuleStruct CRule1 = {Binary, -1, -1, -1, NULL, NULL, NULL, NULL, -1}; 
 Boolean NError=true;
 enum Rparts {lhs=0,rhs1=1,rhs2=2,Ended=3} CRside=lhs; 
 enum TRIO  {Lhs=0, Rhsone=1, Rhstwo=2};
/*************************************
void CopyRule(struct CRuleStruct *CR, struct CRuleStruct *CR1)
{CR1->soort = CR->soort; 
  CR1->lhs = CR->lhs;
  CR1->rhs1 = CR->rhs1;
  CR1->rhs2 = CR->rhs2;
  CR1->NUM = CR->NUM;
}
/*************************************
/****** Functions used in this spec. ****/
  TDomain c_2 = 0; /* only for better printing of output */
  void WRule(RDomain NUM, NTDomain lhs, TDomain rhs1, NTDomain rhs2, LIFO Next)
  {char Temp[15];
    if ((c_2++ % 9) == 0) WRITE("\n");
    WRITE("{"); 
    sprintf(Temp, "%d", lhs); WRITE(Temp);WRITE(",");
    sprintf(Temp, "%d", rhs1); WRITE(Temp);WRITE(",");
    sprintf(Temp, "%d", rhs2); WRITE(Temp);WRITE("}"); 
    if (Next != NULL) WRITE(", "); 
  }/* WRule */
  /*--------------*/
   TDomain cc = 0;   /* only for better printing of output */
   void WINT(TDomain a, void *Next)
   {char Temp[10];
    cc++;
    sprintf(Temp, "%d", a); WRITE(Temp);
    if (Next != NULL) WRITE(", ");
    if (cc%9 == 0) WRITE("\n");
   }
  /*--------------*/
char *SWITCHRT(enum RType RT)
{char *Soort = (char *) AllocElem(5*sizeof(char));
  switch (RT) {
       case Term : strcpy(Soort, "T");
               break;
       case Unary : strcpy(Soort, "U");
               break;
      case Binary : strcpy(Soort, "B");
               break;
      case Eps : strcpy(Soort, "Eps");
               break;
      default: printf("11:Error\n");
               strcpy(Soort, "\0");
               break;
     }/* switch */
 return Soort;
}
/*******************/
void UW_NT_Rs(char *a, enum RType RT, Set S, TDomain i, enum TRIO RHS)
{char Temp[6], Temp1[5];
 char *Soort;
     Soort = SWITCHRT(RT);
     if (RHS == Rhsone) strcpy(Temp1, "Rhs1");
       else if (RHS == Rhstwo) strcpy(Temp1, "Rhs2");
            else strcpy(Temp1, "");
     if (i > 0) {sprintf(Temp, "%d", i);
           WRITE("#undef ");
           WRITE(Temp1);
           WRITE(Soort);WRITE(a);WRITE("COUNT ");
           /* WRITE(Temp); */ WRITE("\n");
           /* WRITE("RDomain "); WRITE(Temp1); WRITE(Soort);WRITE(a);
           WRITE("["); WRITE(Temp1); WRITE(Soort);WRITE(a);
                                     WRITE("COUNT");WRITE("]");
           WRITE(" =  {");
           SetsMap(S, (void *) &WINT, RULE, RT);
           WRITE("};\n");*/
          }
     else {WRITE("#define ");
           WRITE(Temp1);
           WRITE(Soort);WRITE(a);WRITE("COUNT ");
           WRITE("0"); WRITE("\n");
           WRITE("#define "); WRITE(Temp1); WRITE(Soort); WRITE(a);
	   WRITE("  NULL\n");
          }
 free(Soort);
}
/***********/
void W_NT_Rs(char *a, enum RType RT, Set S, TDomain i, enum TRIO RHS)
{char Temp[6], Temp1[5];
 char *Soort;
     Soort = SWITCHRT(RT);
     if (RHS == Rhsone) strcpy(Temp1, "_Rhs1");
       else if (RHS == Rhstwo) strcpy(Temp1, "_Rhs2");
            else strcpy(Temp1, "_");
     if (i > 0) {sprintf(Temp, "%d", i); 
           WRITE("#define ");
           WRITE(Temp1);
              WRITE(Soort);WGNum();WRITE(a);WRITE("COUNT ");
           WRITE(Temp); WRITE("\n");
	   WRITE("RDomain ");
           WRITE(Temp1); WRITE(Soort);WGNum();WRITE(a);
           WRITE("["); WRITE(Temp1); WRITE(Soort);WGNum();WRITE(a);
                                     WRITE("COUNT");WRITE("]");
           WRITE(" =  {");
	   SetsMap(S, (void *) &WINT, RULE, RT);
	   WRITE("};\n");
	  }
     else {WRITE("#define ");
           WRITE(Temp1);
           WRITE(Soort);WGNum();WRITE(a);WRITE("COUNT ");
           WRITE("0"); WRITE("\n");
           WRITE("#define "); WRITE(Temp1); WRITE(Soort);WGNum();WRITE(a);
	   WRITE("  NULL\n");
          }
 free(Soort);
}
  /*--------------*/
  void WRArr(char *a, void *Next, Set NTSet, enum TorN TN, enum TRIO RHS)
  {char Temp[6];
   TDomain i;
   Set This;
     This = Seek(a, NTSet);
     /*** for terminal rules ***/
      i = DataSize(a, NTSet, Term);
      W_NT_Rs(a, Term, This, i, RHS);
    if (TN == NONS) {
      /*** for Unary rules ***/
      i = DataSize(a, NTSet, Unary);
      W_NT_Rs(a, Unary, This, i, RHS);
      /*** for Binary rules ***/
      i = DataSize(a, NTSet, Binary);
      W_NT_Rs(a, Binary, This, i, RHS);
      /*** for Epsilon rules ***/
      i = DataSize(a, NTSet, Eps);
      W_NT_Rs(a, Eps, This, i, RHS);
    }
  }/* WRArr */
  /*--------------*/
  void WRArrNT(char *a, void *Next)
  {WRArr(a, Next, Nonterminals, NONS, Lhs);}
  /** HERE To **/
  void WRArrRhs1(char *a, void *Next)
  {WRArr(a, Next, Rhs1Nons, NONS, Rhsone);}
  void WRArrRhs2(char *a, void *Next)
  {WRArr(a, Next, Rhs2Nons, NONS, Rhstwo);}
  /** HERE **/
  void WRArrT(char *a, void *Next)
  {WRArr(a, Next, Terminals, TERMS, Lhs);}
  /*--------------*/
  void NorTArrInit(char *a, void *Next, enum TorN TN, enum TRIO RHS)
  {char Temp1[6];

     if (RHS == Rhsone) strcpy(Temp1, "_Rhs1");
       else if (RHS == Rhstwo) strcpy(Temp1, "_Rhs2");
            else strcpy(Temp1, "_");
   WRITE("{\"");WRITE(a);WRITE("\","); /* the word or non-terminal */
   WRITE(Temp1);
   WRITE("T");WGNum();WRITE(a);WRITE(", ");
   WRITE(Temp1);
   WRITE("T");WGNum();WRITE(a);WRITE("COUNT");
   if (TN == NONS) {
      WRITE(", ");
      WRITE(Temp1);
      WRITE("U");WGNum();WRITE(a);WRITE(", ");
      WRITE(Temp1);
      WRITE("U");WGNum();WRITE(a);WRITE("COUNT");WRITE(", ");
      WRITE(Temp1);
      WRITE("B");WGNum();WRITE(a);WRITE(", ");
      WRITE(Temp1);
      WRITE("B");WGNum();WRITE(a);WRITE("COUNT");WRITE(", ");
      WRITE(Temp1);
      WRITE("Eps");WGNum();WRITE(a);WRITE(", ");
      WRITE(Temp1);
      WRITE("Eps");WGNum();WRITE(a);WRITE("COUNT");
   }
   WRITE("}");
   if (Next != NULL) WRITE(",\n ");
  }
  /*--------------*/
  void NTArrInit(char *a, void *Next)
  {NorTArrInit(a, Next, NONS, Lhs);}
  void NTArrInitRhs1(char *a, void *Next)
  {NorTArrInit(a, Next, NONS, Rhsone);}
  void NTArrInitRhs2(char *a, void *Next)
  {NorTArrInit(a, Next, NONS, Rhstwo);}
  void TArrInit(char *a, void *Next)
  {NorTArrInit(a, Next, TERMS, Lhs);}
  /*--------------*/
  void WNTarray()
  {WRITE("/* struct NTStruct {\n");
   WRITE("        char *NT;\n");
   WRITE("        RDomain *TRules;\n");
   WRITE("        RDomain TCount;\n");
   WRITE("        RDomain *URules;\n");
   WRITE("        RDomain UCount;\n");
   WRITE("        RDomain *BRules;\n");
   WRITE("        RDomain BCount;\n");
   WRITE("        RDomain *EpsRules;\n");
   WRITE("        RDomain EpsCount;\n");
   WRITE("};*/\n");
  /** First the lhs  ***/
     SetsMap(Nonterminals, (void *) &WRArrNT, KEY, NONE); 
   WRITE("struct NTStruct IVNTArray");WGNum();WRITE("[IVNonTSize");WGNum();WRITE("] = {\n");
     SetsMap(Nonterminals, (void *) &NTArrInit, KEY, NONE); 
   WRITE("\n}; /* End of NTArray */\n");
  /****** HERE , to : ****/
  /** then rhs1 ***/
     SetsMap(Rhs1Nons, (void *) &WRArrRhs1, KEY, NONE); 
   WRITE("struct NTStruct IVRhs1Array");WGNum();WRITE("[IVNonTSize");WGNum();WRITE("] = {\n");
     SetsMap(Rhs1Nons, (void *) &NTArrInitRhs1, KEY, NONE); 
   WRITE("\n}; /* End of Rhs1Array */\n");
  /** then rhs2 ***/
     SetsMap(Rhs2Nons, (void *) &WRArrRhs2, KEY, NONE); 
   WRITE("struct NTStruct IVRhs2Array");WGNum();WRITE("[IVNonTSize");WGNum();WRITE("] = {\n");
     SetsMap(Rhs2Nons, (void *) &NTArrInitRhs2, KEY, NONE); 
   WRITE("\n}; /* End of Rhs2Array */\n");
  /****** HERE ****/
   WRITE("/* TermsArray ****/\n"); 
   WRITE("/* struct TermStruct {\n");
           WRITE("char *Term;\n");
           WRITE("RDomain *TRules;\n");
           WRITE("RDomain TCount;\n");
   WRITE("};\n */");
     SetsMap(Terminals, (void *) &WRArrT, KEY, NONE); 
   WRITE("struct TermStruct IVTermsArray");WGNum();WRITE("[IVTermsSize");WGNum();WRITE("] = {\n");
     SetsMap(Terminals, (void *) &TArrInit, KEY, NONE); 
   WRITE("\n}; /* End of TermsArray */\n");
  }
/*********/
void PRINTALL()
{
   void WArray(enum RType RT, RDomain size)
   {char *Soort;
    char Temp[15];
    int i;
    Soort = SWITCHRT(RT);
    if (size != 0) {
      WRITE("struct RuleStruct IV");WRITE(Soort);WGNum();WRITE("Rules[IV");
      WRITE(Soort);WGNum();WRITE("RSize");WRITE("] = {");
      MapProds(Productions, RT, (void *) &WRule); WRITE("};\n");
    }
   else {WRITE("struct RuleStruct  *IV");WRITE(Soort);WGNum();WRITE("Rules = NULL;\n");}
    free(Soort);
   } /** WArray **/
   /***************************/
 
  char Temp[10];
  TDomain i, Tsize, Usize, Bsize, Epssize;

 /**** WRITE("enum RType {");
 WRITE("Unary=0, Binary=1,");
 WRITE(" Term=2, None=3, Eps = 4};\n");***/
 WRITE("/* struct RuleStruct {\n");
 /***WRITE("       enum RType RT;\n"); ***/
 WRITE("       NTDomain lhs; \n");
 WRITE("       TDomain rhs1; \n");
 WRITE("       NTDomain rhs2; \n");
 WRITE("};\n */");
 WRITE("/** ** *** *****/\n");
 Tsize = ProdsSize(Productions, Term);
 WRITE("#define IVT");WGNum();WRITE("RSize  "); sprintf(Temp, "%d", Tsize); 
 WRITE(Temp); WRITE("\n");
 Usize = ProdsSize(Productions, Unary);
 WRITE("#define IVU");WGNum();WRITE("RSize  "); sprintf(Temp, "%d", Usize); 
 WRITE(Temp); WRITE("\n");
 Bsize = ProdsSize(Productions, Binary);
 WRITE("#define IVB");WGNum();WRITE("RSize  "); sprintf(Temp, "%d", Bsize); 
 WRITE(Temp); WRITE("\n");
 Epssize = ProdsSize(Productions, Eps);
 WRITE("#define IVEps");WGNum();WRITE("RSize  "); sprintf(Temp, "%d", Epssize); 
 WRITE(Temp); WRITE("\n");
 /********** Now write all rules **********/
 WRITE("/** Eps Rules **/\n");
  WArray(Eps, Epssize);
 WRITE("/** Term Rules **/\n");
  WArray(Term, Tsize);
 WRITE("/** Unary Rules **/\n");
  WArray(Unary, Usize);
 WRITE("/** Binary Rules **/\n");
  WArray(Binary, Bsize);
 WRITE("\n/** The nonterminals arrays ***/\n");
 WNTarray();
 WR_DECLARATIONS(); 
 WR_Codes();
}
/************************/
void CRInit()
{CRule.soort = Binary;
 CRule.lhs = -1;
 CRule.rhs1 = -1;
 CRule.rhs2 = -1;
 CRule.Nptr = NULL;
 CRule.Rhs1ptr = NULL;
 CRule.Rhs2ptr = NULL;
 CRule.Tptr = NULL;
 CRule.NUM = -1;
}
/*****/
void ENTERrule()
{Prods prds;
 switch (CRule.soort) {
  case Unary   : prds = FillProd(CRule.NUM, CRule.lhs, CRule.rhs1, -1);
                 break;
  case Term    : prds = FillProd(CRule.NUM, CRule.lhs, CRule.rhs1, -1);
                 break;
  case Binary  : prds = FillProd(CRule.NUM, CRule.lhs, CRule.rhs1, CRule.rhs2);
                 break;
  case Eps     : prds = FillProd(CRule.NUM, CRule.lhs, -1, -1);
                 break;
  default      : break;
 }/*switch*/
 EnProd(Productions, prds, CRule.soort);
 free(prds); /* FREEING */
 UpdateData(CRule.NUM, CRule.Nptr->Cont->Key, Nonterminals, CRule.soort); 
 if (CRule.soort== Term) 
     UpdateData(CRule.NUM, CRule.Tptr->Cont->Key, Terminals, CRule.soort); 
 /*** HERE to: ***/
 else /* for rhs1 and rhs2 lists do the suitable UpdateData */ 
     if (CRule.soort != Eps)
     {UpdateData(CRule.NUM, CRule.Rhs1ptr->Cont->Key, Rhs1Nons, CRule.soort); 
      if (CRule.soort== Binary) 
       UpdateData(CRule.NUM, CRule.Rhs2ptr->Cont->Key, Rhs2Nons, CRule.soort); 
     }
 /*** HERE  ***/
}
/*****/
Boolean UpDateAll()
{/**** CRule.NUM = current; ****/
 CRule.NUM = ProdsSize(Productions, CRule.soort);
 switch (CRside) {
   case lhs  : printf("1:Rule too short\n"); return false; break;
   case rhs1 : if (CRule.soort == Eps) 
                {CRule.soort = Eps; ENTERrule(); return true; }
               else {printf("2:Err: Smg is wrong\n"); return false;}
               break;
   case rhs2 : if (CRule.soort == Unary) {ENTERrule(); return true;}
               else {printf("2:Err: Smg is wrong\n"); return false;}
               break;
   case Ended: switch (CRule.soort) {
                  case Term   : ENTERrule(); return true; break;
                  case Binary : ENTERrule(); return true; break;
                  default   : printf("3:smg is wrong\n"); return false;
                              break;
               }/*switch*/
               break;
   default   : printf("4:smg is wrong here\n");
               return false; break;
 }/*switch*/
}
/**********/
void TN_Decs()
{extern TDomain current;
 extern enum TorN TN;
 extern Set set;

 switch (TN) {
    case TERMS : TandN_Decs(set, TN);
                 current = 0;
                 Terminals = set;
                 TN = RULES;
                 CRInit();
                 InitCLists();
                 break;
    case NONS  : TandN_Decs(set, TN);
                 current = 0;
                 Nonterminals = set;
                 /** Here to **/
                 Rhs1Nons = AssignSet(Nonterminals); 
                 Rhs2Nons = AssignSet(Nonterminals); 
                 /** Here **/
                 set = CreateSet();
                 TN = TERMS;
                 break;
    case RULES : NError = UpDateAll();
                 UpdateRCs(CRule.NUM, CRule.soort, CCodes);
                 CCodes = NULL;
                 current++;
                 CRInit();
                 CRside = lhs;
                 break;
    case CODES :  PRS("Err: (;) appeared amid codes\n");
                 break;
    default : break;
 }/* switch */ 
}
Boolean AnalyseR(char *a)
{Set Tempptr;
  switch (CRside) {
   case lhs  : CRInit();
               CRule.Nptr = Seek(a, Nonterminals);
               if (!(Member(a, CRule.Nptr)))
                   {printf("%5:Err: unknown symbol\n"); return false;}
               else {CRule.lhs = SetSize(Nonterminals) - SetSize(CRule.Nptr);
                     CRule.soort = Eps; /* default */
                     CRside = rhs1; return true;}
               break;
   case rhs1 : /** first whether its Unary/Binary **/
               CRule.Rhs1ptr = Seek(a, Rhs1Nons);
               Tempptr = Seek(a, Nonterminals);
               if (Member(a, Tempptr))
                 {CRule.rhs1 = SetSize(Nonterminals) - SetSize(Tempptr);
                  CRule.soort = Unary;
                  CRside = rhs2; return true; break;}
               /** Next is the terminal case ***/
               else {CRule.Tptr = Seek(a, Terminals);
                     if (Member(a, CRule.Tptr))
                      {CRule.soort = Term; 
                       CRule.rhs1 = SetSize(Terminals) - SetSize(CRule.Tptr);
                       CRside = Ended; return true; break;}
                /** Otherwise it is an NError **/
                     else {printf("6:Error: unknown symbol %s  -- \n",a); 
                           return false;}
                    }
               break;
   case rhs2 : Tempptr = Seek(a, Nonterminals);
               CRule.Rhs2ptr = Seek(a, Rhs2Nons);
               if (!Member(a, Tempptr)) {
                   printf("7:Err: unknown symbol\n"); return false;}
               else {CRule.rhs2 = SetSize(Nonterminals) - SetSize(Tempptr);
                     CRule.soort = Binary; 
                     CRside = Ended; return true;}
               break;
   case Ended: printf("8:Err: rule soort: TOO LONG\n"); 
               return false; break;
   default   : printf("9:Err: rule soort\n"); 
               return false;
               break;
 } /* switch */
}
