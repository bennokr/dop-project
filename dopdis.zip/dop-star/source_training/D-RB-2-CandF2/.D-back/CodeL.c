PtrList CrPList()
{return NULL;}
/***********/
PtrList NewPtr(void *Ptr)
{PtrList IDL = (PtrList) AllocElem(sizeof(struct PtrLStr));
 IDL->Next = NULL;
 IDL->Ptr = Ptr;
 return IDL;
}
/***********/
enum Relate {SML = 0, EQL = 1, BIG =2, NIKS =3};
enum Relate RelateCodes(void *A, void *B)
{CodePtr A1 = (CodePtr) A;
 CodePtr B1 = (CodePtr) B;
 enum Relate TR,CR;
 TR = ((A1->TreeC == B1->TreeC) ? EQL : (A1->TreeC < B1->TreeC) ? SML : BIG);
 if (TR == SML) return SML;
 else if (TR == BIG) return BIG;
      else {CR = ((A1->OwnC == B1->OwnC) ? EQL : 
                 (A1->OwnC < B1->OwnC) ? SML : BIG);
            return CR;}
}
/**************/
/* order from small to big */
PtrList EnterPO(void *Ptra, PtrList L)
{PtrList this = L;
 Boolean HereVoor = false;
 enum Relate RR;
 PtrList Last = NULL;
 PtrList New = NewPtr(Ptra);
 
 if (L == NULL) return New;
 else {while ((this != NULL) && (HereVoor != true))
             {RR = RelateCodes(Ptra, this->Ptr);
              if (RR == BIG) {Last = this; 
                              this = this->Next;}
              else HereVoor = true;
             }
       if (Last != NULL) {New->Next = this;
                          Last->Next = New;
                          return L;}
       else {New->Next = L; return New;}
      }
}
/**************/
/* Queue */
PtrList EnterP(void *Ptra, PtrList L)
{PtrList this = L;
 PtrList Last = NULL;
 PtrList New = NewPtr(Ptra);
 
 while (this != NULL) {Last = this; this = this->Next;}
 if (Last != NULL) {Last->Next = New; return L;}
 else return New;
}
/***********/
void PListMap(PtrList L, void (* fp)())
{PtrList This = L;
 while(This != NULL) {(*fp)(This);
                       This = This->Next;
                     }
}
void FreePtrL(PtrList P)
{PtrList temp;
 if (P != NULL)
 do { temp = P->Next;
      free(P); P = temp;
    } while (P != NULL);
}
