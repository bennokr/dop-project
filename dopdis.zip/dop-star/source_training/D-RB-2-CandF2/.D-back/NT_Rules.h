/*** The type Rules must be defined externally         ************/
/******************************************************************/
/****** Queue of Rules                                            */
struct QUnit {
        Rules  Rule;           /* the rule */
        struct QUnit *Next;
};
typedef struct QUnit *Queue;  /* lists of rules */
/*****************************/
/* returns a Q with element R*/
Queue EnQUnit(Rules R);
/*****************************/
Queue CrQ();
/*****************************/
/* Enqueues R in Q           */
Queue Enqueue(Rules R, Queue Q);
/*****************************/
/* Maps func on Q            */
void QMap(Queue Q, void (*func)());

/******************************************************************/
/* rules are of four types: Unary, Binary or Trinary or Epsilon   */
struct RLists {
        Queue URules; /* Unary list of rules */
        RDomain  UCount;  /* their number        */
        Queue TRules; 
        RDomain  TCount;
        Queue BRules;
        RDomain  BCount;
        Queue EpsRules;
        RDomain  EpsCount;
};
typedef struct RLists *RulesPtr;
enum RType {Unary=1,Binary=2,Term=3,NONE=4,Eps=5};
/****************/
RulesPtr CrRules();
/****************/
/* ENter R into rulestructure */
/*   RPtr under rules type RT */
void EnRule(RulesPtr RPtr, Rules R, enum RType RT);
/*****************/
/* Maps func on all */
/* rules of type RT */
/* in RPtr.         */
void MapRules(RulesPtr RPtr, enum RType RT, void (*func)());
/********************/
RDomain RulesSize(RulesPtr RPtr, enum RType RT);
