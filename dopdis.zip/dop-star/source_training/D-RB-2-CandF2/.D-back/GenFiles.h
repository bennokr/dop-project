/************************************/
/* For large tree-banks I decided to*/
/* move all codes from the main mem.*/
/* to the file .CodesList.bin       */
/* The file is a binary-file of Node_Type structures. */
/* The codes of a rule are on the file after each other
   in the order they appeared in the RBSTSG file.     */
/* The number of the codes of a rule and the place on */
/* of the first of these codes on the file are maintained */
/* in main the program in a Place_Struct.                 */
/************************************/
/************************************/
/************************************/
struct RCodeTStruct {
     TreeCodeT TreeC;
     InTreeCodeT OwnC;
};
typedef struct RCodeTStruct RCodeType;
typedef RCodeType *RCodePtr;

#define NEITHER_enum 0
#define ONLYLHS_enum 1
#define ONLYRHS_enum 2
#define BOTH_enum 3
#define  OTS_Type char
/* enum Ots_Type {BOTH_enum=3,ONLYRHS=2,ONLYLHS=1,NEITHER_enum=0};
#define OTS_Type enum Ots_Type
*/

struct Node_Type {
   RCodeType Code;
   OTS_Type OTS;
   /* void *Data;  put probability here */
 }; /* -- */
typedef struct Node_Type *NodePtr;
/*********************/
void WR_DECLARATIONS();
void WR_A_Code(PtrList P);
void WR_C(RulesLPtr R);
void WR_Codes();
