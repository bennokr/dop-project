/**********************************/
/* PRE: size is the size of an obj*/
/*      the returned ptr must be  */
/*      cast into "ptr of obj"    */
/* Synopsis:                      */
/* Allocates space for an obj and */
/* returns a pointer to it.       */
void *AllocElem(int size)
{void *ptr = NULL;
 ptr = (void *) malloc(size);
 if (ptr == NULL) printf("%30s\n", "Unable to allocate");
 else return ptr;
}
void PRL(long int a) {fprintf(fpOUT, "%d", a); }
void STDPRL(long int a) {printf("%ld", a); }
void PRI(int a) {fprintf(fpOUT, "%3d ", a); }
void PRC(char *a) { printf("%s ", a); }
void WRITE(char *a) {fputs(a, fpOUT);}
void PRS(char *a) { fputs(a, fpOUT); fputs(" ", fpOUT);}
/* void PRS(char *a) {WRITE(a);WRITE(" ");}*/
int KeyComp(KeyType A1, KeyType A2) {return strcmp(A1, A2);}
extern int GrammarNum;
void WGNum() {if (GrammarNum > 0) fprintf(fpOUT,"%d",GrammarNum);}
