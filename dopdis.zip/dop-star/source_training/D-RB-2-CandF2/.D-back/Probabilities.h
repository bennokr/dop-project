Boolean HasBeenC = false;
/* #define ProbDomain float */
TreeCodeT TotalRsNum = 0;
void R_W_Probs();
