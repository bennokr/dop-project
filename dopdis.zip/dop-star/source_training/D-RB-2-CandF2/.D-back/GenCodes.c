void WR_DECLARATIONS()
{PRS("/**************************************/\n");
PRS("/* enum OTSTYPE {NEITHER=0,ONLYLHS=1,ONLYRHS=2,BOTH=3};\n");
PRS("typedef enum OTSTYPE OTS_Type;\n");
PRS("struct Node_Type {\n");
PRS("  CodeType Code;\n");
PRS("  OTS_Type OTS;\n");
/* PRS("  void *Data;\n");*/
PRS("};*/ /* -- */\n");
PRS("/* struct Nodes_Struct {\n");
PRS("        TreeCodeT Roots_Size; \n");
PRS("        InTreeCodeT Others_Size;\n");
PRS("    struct Node_Type *Roots_Nodes,\n");
PRS("                    *Others_Nodes;\n");
PRS("};*//* --- */\n");
PRS("/**************************************/\n");
}
/****************
ONLY FOR TESTING
void WR_A_Code(PtrList P)
{CodePtr CdP = NULL;
 if (P == NULL) ;
 else { ** PRS((char *) P->Ptr); PRS(" = ");
          CdP = FromStrToCode((char *) P->Ptr);**
       CdP = (CodePtr) P->Ptr;
       if (CdP != NULL) 
        {PRL(CdP->TreeC); ** PRI(CdP->ParentC); **
         PRI(CdP->OwnC); PRS(",  ");
        }
       else PRS("SHIT, ");
      }
}
void WR_C(RulesLPtr R)
{PRI(R->Rno); PRS("its codes:");
 PListMap(R->CodesL, (void *) &WR_A_Code);
 PRS("\n");
}
*****************/
void MaxRoot(PtrList CL, TreeCodeT *CMax)
{        void Maximize(void *C)
         {CodePtr CdP = (CodePtr) C;
          if (CdP->TreeC > *CMax) *CMax = CdP->TreeC;
         }
         void PTRL(PtrList P)
          {Maximize(P->Ptr); }
 PListMap(CL, (void *) &PTRL);
}
void WR_The_Code(void *C)
{CodePtr CdP = (CodePtr) C;
 WRITE("{");
     PRL(CdP->TreeC);
     WRITE(", ");PRL(CdP->OwnC);
 WRITE("}");
}
void WR_OTS(void *C)
{CodePtr CdP = (CodePtr) C;
 PRI(CdP->OTS);
}
int co = 0;
void GenCodeList(PtrList P)
{co++;
 WRITE("{");
 WR_The_Code(P->Ptr);WRITE(", "); WR_OTS(P->Ptr); /* WRITE(", NULL");*/
 WRITE("}");
 if (P->Next != NULL) WRITE(", ");
 if ((co%7) == 0) {WRITE("\n");co=0;}
}
void DefAndInit(RDomain Rno, enum RType RT, TreeCodeT RS, InTreeCodeT OthsS,
                PtrList RootsList, PtrList OthsList)
{char *Soort;
 char Temp[10], Temp1[20], Temp2[20];
 sprintf(Temp, "%d", Rno);
 sprintf(Temp1, "%d", RS);
 sprintf(Temp2, "%d", OthsS);
 Soort = (char *) SWITCHRT(RT);
 WRITE("#define  _"); WRITE(Soort);WRITE("_Roots_Size");WRITE(Temp);
 WRITE("  "); WRITE(Temp1);WRITE("\n");
 WRITE("#define  _"); WRITE(Soort);WRITE("_Oths_Size");WRITE(Temp);
 WRITE("  "); WRITE(Temp2);WRITE("\n");

 if (RS == 0) { WRITE("#define  _"); 
                WRITE(Soort);
                WRITE("_Roots_L");WRITE(Temp);WRITE("  NULL\n");
              }
 else {WRITE("struct Node_Type  _");
       WRITE(Soort);WRITE("_Roots_L");WRITE(Temp);
       WRITE("[");WRITE(Temp1);WRITE("] "); WRITE(" = ");
       WRITE("{"); PListMap(RootsList, &GenCodeList);
       WRITE("};\n"); 
      }
 if (OthsS == 0) { WRITE("#define  _"); WRITE(Soort);
                WRITE("_Oths_L");WRITE(Temp);WRITE("  NULL\n");
              }
 else {WRITE("struct Node_Type  _");
       WRITE(Soort);WRITE("_Oths_L");WRITE(Temp);
       WRITE("[");WRITE(Temp2);WRITE("] "); WRITE(" = ");
       WRITE("{"); PListMap(OthsList, &GenCodeList);
       WRITE("};\n"); 
      }
 free(Soort);
}
/************************/
void WR_Codes()
{/* extern TreeCodeT TotalRsNum;*/
 enum RType RT;
 char *Soort;
 RulesLPtr RevL;
   void WR_ListC(RulesLPtr R)
      {char Temp[10];
       sprintf(Temp, "%d", R->Rno);
       WRITE("{");
       WRITE("_"); WRITE(Soort);WRITE("_Roots_Size");WRITE(Temp);WRITE(", "); 
       WRITE("_"); WRITE(Soort);WRITE("_Oths_Size");WRITE(Temp); WRITE(", ");
       WRITE("_"); WRITE(Soort);WRITE("_Roots_L");WRITE(Temp);WRITE(", ");
       WRITE("_"); WRITE(Soort);WRITE("_Oths_L");WRITE(Temp);
       WRITE("}");
       if (R->Next != NULL) WRITE(", ");
       WRITE("\n");
      }
  void WR_CList(RulesLPtr R)
   {PtrList RootsL, OthsL;
    TreeCodeT RootsNum;
    TreeCodeT OthsNum;
            void Scheid(PtrList P)
              {CodePtr CdP = (CodePtr) P->Ptr;
               if (IsRoot(CdP) == true)
                     {RootsNum++;
                      RootsL = EnterP((void  *) CdP, RootsL);
                     }
               else {OthsNum++;
                     OthsL = EnterP((void *) CdP, OthsL);
                    }
              }
    RootsL = NULL; OthsL = NULL;
    RootsNum = 0; OthsNum = 0;
    PListMap(R->CodesL, (void *) &Scheid);
    if (RootsNum > 0) {MaxRoot(RootsL, &TotalRsNum); HasBeenC = true;}
    WRITE("\n");
    DefAndInit(R->Rno, RT, RootsNum, OthsNum, RootsL, OthsL);
   }
 RT = Term; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(T_List, &WR_CList);
 PRS("struct Nodes_Struct IVT_R_Apps[IVTRSize] = {\n");
 Map_CodesL((RevL = Reverse(T_List)), &WR_ListC);
 PRS("};\n");
 PRS("/* ---------------*/\n");
 free(Soort);
 RT = Binary; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(B_List, &WR_CList);
 PRS("struct Nodes_Struct IVB_R_Apps[IVBRSize] = {\n");
 Map_CodesL((RevL = Reverse(B_List)), &WR_ListC);
 PRS("};\n");
 PRS("/*---------------*/\n");
 free(Soort);
 RT = Eps; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(Eps_List, &WR_CList);
 PRS("struct Nodes_Struct IVEps_R_Apps[IVEpsRSize] = {\n");
 Map_CodesL((RevL = Reverse(Eps_List)), &WR_ListC);
 PRS("};\n");
 PRS("/*---------------*/\n");
 free(Soort);
 RT = Unary; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(U_List, &WR_CList);
 PRS("struct Nodes_Struct IVU_R_Apps[IVURSize] = {\n");
 Map_CodesL((RevL = Reverse(U_List)), &WR_ListC);
 PRS("};\n");
 PRS("/*---------------*/\n");
 WRITE("#define IVTotalRootsNum "); 
 if (HasBeenC == true) PRL((TotalRsNum+1));
 else PRL(TotalRsNum);
 PRS("\n");
}
