#define Boolean enum boolean
/************************************/
/*** General types and definitions */
enum boolean {false = 0 , true = 1};
void *AllocElem(int size);

void PRI(int a);
extern FILE *fpOUT;
void PRC(char *a);
void PRS(char *a);
void WRITE(char *a);
#define KEYINIT "\0"
/*********************************************************/
/*** Decalarations for the modules               *********/
/*********************************************************/
typedef char SymType[SymLength];  /* symbols are strings of chars    ***/
typedef short int RDomain; /*   rules are integers   ***/
typedef int TDomain; /*   Terms are integers   ***/
typedef int NTDomain; /*   Nons are integers   ***/
/***************************************************/
/*** declarations and defs for rules        ********/
typedef RDomain Rules;
/**************************************************/
/***************************************************/
/*** declarations and defs for Lists         ********/
/***************************************************/
/*** declare keytype ***/
typedef SymType KeyType; 
/*-------------*/
/* These macros define the relational op.s on the keys. Should be   */
/* redefined if key-type does not allow these  relational ops.      */
#define KeyAssig(A1, A2) (strcat(A1, A2))
int KeyComp(KeyType A1, KeyType A2); 
/*
#define Greater(A1, A2) ((strcmp(A1, A2) > 0))
#define Less(A1, A2) ((strcmp(A1, A2) < 0))
#define Leq(A1, A2) ((strcmp(A1, A2) <= 0))
#define Geq(A1, A2) ((strcmp(A1, A2) >= 0))
#define Eq(A1, A2) ((strcmp(A1, A2) == 0))
*/
#define Greater(A) (A > 0)
#define Less(A) (A < 0)
#define Leq(A)  (A <= 0)
#define Geq(A) (A >= 0)
#define Eq(A) (A == 0)
