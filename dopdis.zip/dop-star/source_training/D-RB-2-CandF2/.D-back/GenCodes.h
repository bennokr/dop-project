void WR_DECLARATIONS();
void WR_A_Code(PtrList P);
void WR_C(RulesLPtr R);
void WR_Codes();
