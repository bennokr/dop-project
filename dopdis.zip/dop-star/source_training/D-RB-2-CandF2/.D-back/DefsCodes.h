typedef Code_Domain int;
