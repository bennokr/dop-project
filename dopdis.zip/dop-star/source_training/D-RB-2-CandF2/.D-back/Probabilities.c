/* #define ProbDomain float */
/* ProDomain TheProbOf[TotalRootsNum];*/
extern FILE *fpIN;
void R_W_Probs()
{ProbDomain P;
 char *s;
 int i, j;

  j = 1;  
  if (HasBeenC == true) {
    WRITE("ProbDomain IVTheProbOf");WGNum();
                          WRITE("[IVTotalRootsNum");WGNum();WRITE("] = \n");
    if (TotalRsNum >= 0)
     {WRITE("{ ");
      do {
        i = fscanf(fpIN, "%f", &P); 
        if ((j != 1) && (i != EOF)) WRITE(", ");
        if (i != EOF) {fprintf(fpOUT, "%f", P); 
                       j++;
                       if ((j%5)==0) WRITE("\n"); 
                      }
       } while (i !=EOF);
     WRITE("};\n");
     } else;
   }
  else {WRITE("ProbDomain *IVTheProbOf");WGNum();WRITE(" = NULL;");}
}
