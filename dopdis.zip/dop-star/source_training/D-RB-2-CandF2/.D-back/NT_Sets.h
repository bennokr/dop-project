/********************************************************/
/***   Type Set must be declared and implemented *******/
/******************************************/
/* Sets of Nonterminals and their rules  **/
/* This module assumes two modules:      **/
/*       Lists and Rules                 **/
/******************************************/
/********************************************************/
struct SetType {
        List   Cont;
        RDomain   Size;
};
typedef struct SetType *Set;

Set CreateSet();
Set InitSet();
Boolean Last(Set set);
Set Add(KeyType key, Set set);
/*****************************/
/* a subset of set is returned */
/* of which key is first member*/
/* If key is not in set then   */
/* a subset is returned of set */
/* in which the first key is   */
/* the smallest larger than key*/ 
Set Seek(KeyType key, Set set);
/*** Membership check ***/
Boolean Member(KeyType key, Set set);
/** enter R of type RT as data for Key in set ***/
void UpdateData(RDomain R, KeyType key, Set set, enum RType RT);
enum PartT {KEY=0,RULE=1};
/***************************************/
/* Map fp as follows:                    */
/*     KR == RULE: take the FIRST  member*/
/*              of set and apply fp to   */
/*              each of its rules of type*/
/*              RT .                     */

void SetsMap(Set set, void (* fp)(), enum PartT KR, enum RType RT);
/****************************************/
/* Size of the set. I.e. number of keys */
RDomain SetSize(Set set);
/****************************************/
/* Number of the rules of type RT of key*/
/*                                      */
RDomain DataSize(KeyType key, Set set, enum RType RT);
Set AssignSet(Set set);
