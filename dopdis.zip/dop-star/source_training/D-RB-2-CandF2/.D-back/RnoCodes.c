/* struct RuleStruct {
     RDomain Rno;
     PtrList CodesL;
     struct RuleStruct *Next;
}
typedef struct RuleStruct *RulesLPtr;
*/
RulesLPtr Cr_CodesL() {return NULL;}
/**/
RulesLPtr EnR_CodesL(RDomain RN, PtrList CL, RulesLPtr L)
{RulesLPtr New = (RulesLPtr) AllocElem(sizeof(struct RuleStruct));
 New->Rno = RN;
 New->CodesL = CL;
 New->Next = L;
 return New;
}
/**/
void Map_CodesL(RulesLPtr L, void (* fp)())
{RulesLPtr This = L;
 while(This != NULL) {(*fp)(This);
                       This = This->Next;
                     }
}
RulesLPtr Reverse(RulesLPtr L)
{RulesLPtr LR = NULL;
     void Ent(RulesLPtr This)
       {LR = EnR_CodesL(This->Rno, This->CodesL, LR);}
 Map_CodesL(L, &Ent);
 return LR;
}
void FreeRLPtr(RulesLPtr L)
{RulesLPtr temp;
 if (L == NULL) ;
 else do {temp = L->Next;  
           free(L); L = temp; 
         } while (L != NULL);
}      
