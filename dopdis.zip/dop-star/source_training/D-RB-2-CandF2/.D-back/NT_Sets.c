/******************************************/
/* Sets of Nonterminals and their rules  **/
/* This module assumes two modules:      **/
/*   Lists and Rules                     **/
/******************************************/
Set CreateSet()
{return NULL;}
/*****************************************/
Set InitSet()
{Set set;
 set = (Set) AllocElem(sizeof(struct SetType));
 set->Cont = NULL;
 set->Size = 0;
 return set;
}
/************************/
Boolean Last(Set set)
{if (set == NULL) return true;
 else
 if (Next(set->Cont) == NULL) return true;
 else return false;
}
/************************/
/*Pre: set must exist   */
Set Add(KeyType key, Set set)
{Boolean b;
 Set set1 = (set == NULL) ? InitSet() : set;
 set1->Cont = Enter(key, set1->Cont, &b); 
 if (b) (set1->Size)++; /* else  no change in Size */
 return set1;
}
/************************/
/*Pre: set must exist   */
/************************/
Set Seek(KeyType key, Set set)
{TDomain C;
 Set Nset = InitSet();
 if (set == NULL) printf("Err: empty set");
 else { Nset->Cont = Search(key, set->Cont, &C); 
        Nset->Size = ((set->Size) - C) + 1;
      };
 return Nset;
}
/************************/
Boolean Member(KeyType key, Set set)
{TDomain C;
 List L;
 if (set == NULL) return false;
 else return (InElm(key, L = Search(key, set->Cont, &C)));
}
/************************/
void UpdateData(RDomain R, KeyType key, Set set, enum RType RT)
{TDomain C;
 List This = Search(key, set->Cont, &C);
 RulesPtr RPtr = (RulesPtr) This->Data;
 if (InElm(key, This)) {
    if (RPtr == NULL) {RPtr = CrRules(); This->Data = (void *) RPtr;};
    (EnRule(RPtr, R, RT));
 } else printf("%20s\n", "Err: strange key");
}
/*************************/
void SetsMap(Set set, void (* fp)(), enum PartT KR, enum RType RT)
{RulesPtr RPtr;
 List L;
 if (set == NULL) printf("Err: empty set");
 else 
  {L = set->Cont; 
   if (L == NULL) printf("Err: empty List");
   else
     switch (KR) {
      case RULE : RPtr = (RulesPtr) L->Data;
                  MapRules(RPtr, RT, fp);
                  break;
      case KEY : ListMap(L, fp);
                 break;
      default: break;
      } /* Switch */
  } /*. ELse */
}
/**********************************/
RDomain SetSize(Set set)
{if (set == NULL) return 0;
 else return (set->Size);} 
/**********************************/
RDomain DataSize(KeyType key, Set set, enum RType RT)
{Set S = Seek(key, set);
 if (Member(key, set)) return (RulesSize((RulesPtr) S->Cont->Data, RT));
 else return 0;
}
/***************************/
Set AssignSet(Set set)
{Set s = CreateSet();
 void CPY(KeyType Key, List Next)
  {s = Add(Key, s);}

 SetsMap(set, (void *) &CPY, KEY, NONE);
 return s;
}
