RCodePtr RNewCPtr(TreeCodeT TC, InTreeCodeT OC)
{RCodePtr CdP = (RCodePtr) AllocElem(sizeof(RCodeType));
 CdP->TreeC = TC;
 CdP->OwnC = OC;
 return CdP;
}
NodePtr NewNP(TreeCodeT TC, InTreeCodeT OC, OTS_Type OTS)
{NodePtr NP = (NodePtr) AllocElem(sizeof(struct Node_Type));
 /* NP->Code =   *RNewCPtr(TC, OC);*/
 NP->Code.TreeC = TC;
 NP->Code.OwnC = OC;
 NP->OTS = OTS;
 return NP;
}
/************************/
void FreeNP(NodePtr NP)
{if (NP != NULL) { /* free(&NP->Code);*/ free(NP); }}
/************************/
void WR_DECLARATIONS()
{
PRS("/**************************************/\n");
PRS("/* enum OTSTYPE {NEITHER=0,ONLYLHS=1,ONLYRHS=2,BOTH=3};\n"); 
PRS("typedef enum OTSTYPE OTS_Type;\n");
PRS("struct Node_Type {\n");
PRS("  CodeType Code;\n");
PRS("  OTS_Type OTS;\n");
/* PRS("  void *Data;\n");*/
PRS("};*/ /* -- */\n");
PRS("/* struct Nodes_Struct {\n");
PRS("        TreeCodeT Roots_Size; \n");
PRS("        InTreeCodeT Others_Size;\n");
PRS("    struct Node_Type *Roots_Nodes,\n");
PRS("                    *Others_Nodes;\n");
PRS("};*//* --- */\n");
PRS("/* struct Place_Str {\n");
PRS("        TreeCodeT Roots_Size; \n");
PRS("        InTreeCodeT Others_Size;\n");
PRS("        long int Roots_StartPos;\n");
PRS("        long int Others_StartPos;\n");
PRS("};*//* --- */\n");
PRS("/**************************************/\n");
}
/*****************/
void MaxRoot(PtrList CL, TreeCodeT *CMax)
{        void Maximize(void *C)
         {CodePtr CdP = (CodePtr) C;
          if (CdP->TreeC > *CMax) *CMax = CdP->TreeC;
         }
         void PTRL(PtrList P)
          {Maximize(P->Ptr); }
 PListMap(CL, (void *) &PTRL);
}
/**********************/
/* Put the code in a Struct Node_Type and then this on the file */
/**********************/
/* HERE */
void WriteCode(NodePtr NP)
{
 fwrite((void *) NP, sizeof(struct Node_Type), 1, fpOUTCodes);
}
void WR_The_Code(void *C)
{CodePtr CdP = (CodePtr) C;
 NodePtr NP = NewNP(CdP->TreeC, CdP->OwnC, CdP->OTS);
 WriteCode(NP); FreeNP(NP);
}
void GenCodeList(PtrList P)
{/* Get position at the file and write it */
 WR_The_Code(P->Ptr); /* WRITE-OTS */
}
/***********************/
void DefAndInit(RDomain Rno, enum RType RT, TreeCodeT RS, InTreeCodeT OthsS,
                PtrList RootsList, PtrList OthsList)
{char *Soort;
 long int Place; 
 char Temp[10], Temp1[20], Temp2[20];
 sprintf(Temp, "%d", Rno);
 sprintf(Temp1, "%d", RS);
 sprintf(Temp2, "%d", OthsS);
 Soort = (char *) SWITCHRT(RT);
 WRITE("#define  _");WRITE(Soort);WGNum();WRITE("_Roots_Size");WRITE(Temp);
 WRITE("  "); WRITE(Temp1);WRITE("\n");
 WRITE("#define  _"); WRITE(Soort);WGNum();WRITE("_Oths_Size");WRITE(Temp);
 WRITE("  "); WRITE(Temp2);WRITE("\n");

 if (RS == 0) { WRITE("#define  _"); WRITE(Soort);WGNum();
                WRITE("_Roots_L");WRITE(Temp);WRITE(" -1\n");
              }
 else {WRITE("#define _");WRITE(Soort);WGNum();WRITE("_Roots_L");WRITE(Temp);
                 /* here write start point on the file  and
                    write all strcuts on the file           */
                Place = ftell(fpOUTCodes);
                WRITE(" ");PRL(Place);WRITE(" ");
                PListMap(RootsList, &GenCodeList);
       WRITE("\n"); 
      }
 free(Soort);
 Soort = (char *) SWITCHRT(RT);
 if (OthsS == 0) { WRITE("#define  _"); WRITE(Soort);WGNum();
                WRITE("_Oths_L");WRITE(Temp);WRITE("  -1\n");
              }
 else {WRITE("#define _"); WRITE(Soort);WGNum();WRITE("_Oths_L");WRITE(Temp);
                 /* here write start point on the file  and
                    write all strcuts on the file           */
                Place = ftell(fpOUTCodes);
                WRITE(" ");PRL(Place);WRITE(" ");
                  PListMap(OthsList, &GenCodeList);
       WRITE("\n"); 
      }
 free(Soort);
}
/************************/
void WR_Codes()
{/* extern TreeCodeT TotalRsNum;*/
 enum RType RT;
 char *Soort;
 RulesLPtr RevL;
   void WR_ListC(RulesLPtr R)
      {char Temp[10];
       sprintf(Temp, "%d", R->Rno);
       WRITE("{");
       WRITE("_"); WRITE(Soort);WGNum();WRITE("_Roots_Size");WRITE(Temp);WRITE(", "); 
       WRITE("_"); WRITE(Soort);WGNum();WRITE("_Oths_Size");WRITE(Temp); WRITE(", ");
       WRITE("_"); WRITE(Soort);WGNum();WRITE("_Roots_L");WRITE(Temp);WRITE(", ");
       WRITE("_"); WRITE(Soort);WGNum();WRITE("_Oths_L");WRITE(Temp);
       WRITE("}");
       if (R->Next != NULL) WRITE(", ");
       WRITE("\n");
      }
  void WR_CList(RulesLPtr R)
   {PtrList RootsL, OthsL;
    TreeCodeT RootsNum;
    TreeCodeT OthsNum;
            void Scheid(PtrList P)
              {CodePtr CdP = (CodePtr) P->Ptr;
               if (IsRoot(CdP) == true)
                     {RootsNum++;
                      RootsL = EnterP((void  *) CdP, RootsL);
                     }
               else {OthsNum++;
                     OthsL = EnterP((void *) CdP, OthsL);
                    }
              }
    RootsL = NULL; OthsL = NULL;
    RootsNum = 0; OthsNum = 0;
    PListMap(R->CodesL, (void *) &Scheid);
    if (RootsNum > 0) {MaxRoot(RootsL, &TotalRsNum); HasBeenC = true;}
    WRITE("\n");
    DefAndInit(R->Rno, RT, RootsNum, OthsNum, RootsL, OthsL);
    FreePtrL(RootsL); FreePtrL(OthsL);
   }
 free(Soort);
 RT = Term; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(T_List, &WR_CList);
 WRITE("struct Place_Struct IVT_R_Apps");WGNum();
 WRITE("[IVT");WGNum();WRITE("RSize");PRS("] = {\n");
 Map_CodesL((RevL = Reverse(T_List)), &WR_ListC);
 FreeRLPtr(RevL);
 PRS("};\n");
 PRS("/* ---------------*/\n");
 free(Soort);
 RT = Binary; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(B_List, &WR_CList);
 WRITE("struct Place_Struct IVB_R_Apps");WGNum();
 WRITE("[IVB");WGNum();WRITE("RSize");PRS("] = {\n");
 Map_CodesL((RevL = Reverse(B_List)), &WR_ListC);
 FreeRLPtr(RevL);
 PRS("};\n");
 PRS("/*---------------*/\n");
 free(Soort);
 RT = Eps; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(Eps_List, &WR_CList);
 WRITE("struct Place_Struct IVEps_R_Apps");WGNum();
 WRITE("[IVEps");WGNum();WRITE("RSize");PRS("] = {\n");
 Map_CodesL((RevL = Reverse(Eps_List)), &WR_ListC);
 FreeRLPtr(RevL);
 PRS("};\n");
 PRS("/*---------------*/\n");
 free(Soort);
 RT = Unary; Soort = (char *) SWITCHRT(RT);
 Map_CodesL(U_List, &WR_CList);
 WRITE("struct Place_Struct IVU_R_Apps");WGNum();
 WRITE("[IVU");WGNum();WRITE("RSize");PRS("] = {\n");
 Map_CodesL((RevL = Reverse(U_List)), &WR_ListC);
 FreeRLPtr(RevL);
 PRS("};\n");
 PRS("/*---------------*/\n");
 WRITE("#define IVTotalRootsNum");WGNum();WRITE(" "); 
 if (HasBeenC == true) PRL((TotalRsNum+1));
 else PRL(TotalRsNum);
 PRS("\n");
}
