/* This program translates a CFG into a c file which includes */
/* declarations and definitions of variables and datastructures */
/* which can be used for a parser (CYK).                        */
/* Assumptions: Input file contains                                 
/*              1. a. A list of nonterminals, each an identifier 
                      as of prog. languages.
                   b. First nonterminals is the start symbol of
                      the CFG. 
                   c. This list of Nonterminals must end with ";".
                2. List of terminals (same req.s as for nonterminals
                   here above).
                3. A list of rules, each in CNF and ended with ";".
                4. The symbol "##" ends the input file. 
   Post conds: An output file is created which contains definitions
               and declarations of datastructures in c. The contents
               of this file represent the input CFG.  This maybe included 
               in a main program which also contains an
               implementation of a parsing algorithm, a procedure
               which implements an interface with the user. Such a
               program forms then a parser where the output file of
               the present program is in fact a representation of
               the CFG.
               For a figure of the representation see the figure
               Rep.ps in this directory.
*/
/***********************************/
#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "sys/types.h"
#include "sys/times.h"
#include "math.h"
/*** Decalrations files ***/
/****** External declarations *****/
FILE *fpOUT, *fpIN, *fpIN1, *fpOUTCodes, *fpCHS;
/*******************/
#include "../Constants.h"
#include "Aux.h"
#include "NT_Lists.h"
#include "NT_Rules.h"
#include "NT_Sets.h" 
#include "RulesQ.h" 
/*** implementation files ***/
#include "Aux.c"
#include "CodeType.c"
#include "NT_Lists.c"
#include "NT_Rules.c"
#include "NT_Sets.c"
#include "RulesQ.c" 
#include "CodeL.h"
#include "CodeL.c"
#include "RnoCodes.h"
#include "RnoCodes.c"
#include "CODES.c"
#include "Probabilities.h"
#include "GenFiles.h"
#include ".D-ChildFinding/FindChild.h"
#include ".D-ChildFinding/Item.h"
#include ".D-ChildFinding/Trees.h"
#include ".D-ChildFinding/Item.c"
#include ".D-ChildFinding/Trees.c"
#include ".D-ChildFinding/FindChild.c"
/************* See last line in this file for more ****/
enum TorN {TERMS=1,NONS=0,RULES=2,CODES=3};
extern void TandN_Decs(Set set, enum TorN TN);
char *CODESFNAME = ".CodesList.bin";
char *CHSFNAME = ".ChildPlace.bin";
/**********/
/*
*/
/*****************************************************************/
/*
extern int getopt( int argc, char* argv[], char* optstring );
extern char* optarg;
extern int optind, opterr;
*/

int GrammarNum = 0;
extern void Trans();
void main(argc, argv, envp)
int argc;
char **argv, **envp;
{char* options = "N:"; /* set your choices here */
 int  opt_ch;
 int error_flag = 0;
 char Temp[20] = "";

  FILE *fopen();
  clock_t start, finish;
  double duration;

  start = clock();
  fpOUT = stdout; fpIN = stdin;

  opt_ch = getopt( argc, argv, options );
  while ( opt_ch != -1 )
   {switch( opt_ch ) {
     case 'N' : GrammarNum = atoi(optarg); strcpy(Temp,optarg);
                break;
/*   case 'i' : if ((fpIN = fopen(optarg, "r")) == NULL) 
             printf("Can't open %s\n", *argv);
           break;
     case 'o' : if ((fpOUT = fopen(optarg, "w")) == NULL) 
             printf("Can't open %s\n", *argv);
           break;
*/
     case '?' : error_flag++; break;
    }
    opt_ch = getopt( argc, argv, options );
   }


        /* case file names without -i and -o */
   if ( argc - optind > 0 ) 
    if (fpIN == stdin)
     {if (argv[optind][0] != '-')
       {fpIN = fopen( argv[optind], "r" );
        if ( !fpIN ) 
         {fprintf( stderr, "File <%s> does not exist\n", argv[optind] ); exit( 1 );}
       }
      else error_flag++;
     }
    else /* input file read */
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
   if ( argc - ++optind > 0 ) 
    if (fpOUT == stdout)
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
    else error_flag++;
   else error_flag++;

         /* In case of error  */
   if ( error_flag )
   {char* basename = strrchr( argv[0], '/' );

    if ( basename ) basename++;
    else basename = argv[0];
    fprintf(stderr, "Usage: %s -R -i <infile> -o <outfile>"
               " [infile [outfile] ]\n", basename );
      fprintf( stderr, "  -R  Only for Right Linear Grammars\n" );
      exit( 1 );
   }
        /* .CodesList.bin1 and .CodesList.bin2 */
   if ((GrammarNum >= 0) && (GrammarNum <= 2)) ;
   else {fprintf(stderr,"Err: grammar number is not legal (choose 1 or 2)\n");exit(1);}
   if (GrammarNum > 0) {strcat(CODESFNAME,Temp); strcat(CHSFNAME,Temp);}
   if ((fpOUTCodes = fopen(CODESFNAME, "r")) == NULL)
      {fprintf(stderr,"Can't open %s\n",CODESFNAME);exit(1);}
   if ((fpCHS = fopen(CHSFNAME, "w")) == NULL)
      {fprintf(stderr,"Can't open %s\n", CHSFNAME); exit(1);}

  /** Do the parsing **/
 Trans();
 finish = clock();
 duration = (double) finish - start;
/* printf("Duration is :%f secs\n", duration/60);*/
 fclose(fpCHS);fclose(fpOUTCodes);
}
/*****************************************************************/
/*** The external variables to the next func.s  are hereunder ***/
enum TorN TN;
Set set; 
Set Nonterminals, Rhs1Nons, Rhs2Nons;
Set Terminals;
KeyType StartNont;
Boolean First = true;
TDomain current = 0;
ProdsPtr Productions;
/*****************************************************************/
/****** The translation procedure                              ***/
/*** Fills Nonterminals and Terminals and declares then in the  **/
/** output ****/
void Trans()
{int i;
 TN = NONS; 
 set = CreateSet(); 
 FindAllChs(); 
}
/****** what to do with each nonterminal/terminal ****/
/*** Generating a declaration of a  nonterminal/terminal   ***/
/*** checking whether to put an "," or ";" behind it.      ***/
void WRITES(char *a, void *Next)
{char Temp[10];
  if (current == 0) WRITE("{"); /** first element **/
  WRITE(a); 
  WRITE("=");
  sprintf(Temp, "%d", current++);
  WRITE(Temp); 
  if (Next == NULL) WRITE("};\n"); /** last element **/
  else WRITE(",");
  if (current == 9) WRITE("\n             ");
}

/** declaration for enumerated type NONTERMINALS ***/
/** and of the sizes of each of the sets        ***/
/**/
void TandN_Decs(Set set, enum TorN TN)
{char Temp[SymLength];
 char Temp1[SymLength]="\0";
 char Temp2[SymLength]="\0";
 TDomain size;
 TDomain Start;

 /** Size definition **/
 size = SetSize(set);
 switch (TN) {
    case TERMS : strcpy(Temp1, "IVTermsSize ");
                 strcpy(Temp2, "Terminals ");
                 break;
    case NONS  : WRITE("#define IVStartNonterminal ");
                 Start = size - SetSize(Seek(StartNont, set)); 
                 sprintf(Temp, "%d", Start); WRITE(Temp); WRITE("\n");
                 strcpy(Temp1, "IVNonTSize ");
                 strcpy(Temp2, "Nonterminals ");
                 break;
    default : printf("Err: not good"); break;
 } /* of case */
 WRITE("#define "); WRITE(Temp1); 
 sprintf(Temp, "%d", size); 
 WRITE(Temp); WRITE("\n");
 WRITE("/* enum ");
 WRITE(Temp2); /* SetsMap(set, (void *) &WRITES, KEY, NONE); */ WRITE(" */\n");
}
/******************************************************/
/**** Other file ***/
#include "Proc.c"
#include "GenFiles.c"
#include "lex.yy.c"
#include "Probabilities.c"
/******************************************************/
