struct PtrLStr {
       void  *Ptr;
       struct PtrLStr *Next;
};
typedef struct PtrLStr *PtrList;
/********************/
PtrList NewPtr(void *Ptr);
/************************** The observed functions are ***/
PtrList CrPList();
PtrList EnterP(void *Ptr, PtrList L);
void PListMap(PtrList L, void (* fp)());
PtrList EnterPO(void *Ptra, PtrList L);

