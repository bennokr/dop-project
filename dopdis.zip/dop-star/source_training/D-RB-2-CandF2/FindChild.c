#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"
#include "NT_Lists.h"
#include "NT_Rules.h"
#include "NT_Sets.h"
#include "RulesQ.h"
/*** implementation files ***/
#include "CodeL.h"
#include "RnoCodes.h"
#include "Probabilities.h"
#include "GenFiles.h"
#include "FindChs.h"
#include "FindChild.h"
#include "Item.h"         
#include "Trees.h"         

/******************************/
#define Lch_enum 1
#define Rch_enum 2
#define Child_Type char
/***********
#define PlacesT long int
struct Ch_Str {
      PlacesT LeftCh;
      PlacesT RightCh;
};
typedef struct Ch_Str *Ch_Ptr;
*********/
enum Relate RelateNodes(NodePtr A, NodePtr B)
{RCodePtr A1 = (RCodePtr) &(A->Code);
 RCodePtr B1 = (RCodePtr) &(B->Code);
 enum Relate TR,CR;
 TR = ((A1->TreeC == B1->TreeC) ? EQL : (A1->TreeC < B1->TreeC) ? SML : BIG);
 if (TR == SML) return SML;
 else if (TR == BIG) return BIG;
      else return ((A1->OwnC == B1->OwnC) ? EQL : (A1->OwnC < B1->OwnC) ? SML : BIG);
}

enum Relate CodeREL(e1, e2)
  const void *e1;
  const void *e2;
{NodePtr A = (NodePtr) e1;
 NodePtr B = (NodePtr) e2;
 return (RelateNodes(A, B));
}
/******************/
void InitChStr(Ch_Ptr Child)
{Child->LeftCh = -1; Child->RightCh = -1; }
/*******/
int GetFromFile(PlacesT WS, NodePtr Node)
{int RD = 0;
 int Err = fseek(fpOUTCodes, WS, SEEK_SET);
 if (Err != 0) {printf("Error in Seeking codes file.\n");exit(1);}
 else {RD = fread((void *) Node, sizeof(struct Node_Type), 1, fpOUTCodes);
       return RD;
      }
}
/*********/
void ComputeChOf(NodePtr NPp, Child_Type Chnum, NodePtr Ch)
{Ch->Code.TreeC = NPp->Code.TreeC;
 Ch->Code.OwnC = (NPp->Code.OwnC * 2);
 if (Chnum == Rch_enum) Ch->Code.OwnC = Ch->Code.OwnC +1 ;
}
/*********/
PlacesT SearchChs(NodePtr ChNode)
{PlacesT CurrP = 0;
 Boolean EOFILE = false;
 struct Node_Type Node;
 PlacesT Result = -1;
 int RD = 0;

 do {RD = GetFromFile(CurrP, &Node);
     if (RD != 1) EOFILE = true;
     else 
      if ((CodeREL((void *) &Node, (void *) ChNode)) == EQL)
         {Result = CurrP ;
          EOFILE = true;}
     CurrP = CurrP + sizeof(struct Node_Type);
    } while (EOFILE != true);
 return Result;
}
/*********/
void FindChildrenOf(NodePtr Node, Ch_Ptr ChildrenPtr)
{PlacesT Ch1Pl, Ch2Pl;
 struct Node_Type ChNode;
 Ch1Pl = -1; Ch2Pl = -1;
 switch (Node->OTS) {
   case NEITHER_enum : ComputeChOf(Node, Lch_enum, &ChNode);
                       Ch1Pl = (SearchChs(&ChNode));
                       ComputeChOf(Node, Rch_enum, &ChNode);
                       Ch2Pl = SearchChs(&ChNode);
                       break;
   case ONLYLHS_enum : ComputeChOf(Node, Rch_enum, &ChNode);
                       Ch2Pl = SearchChs(&ChNode);
                       break;
   case ONLYRHS_enum : ComputeChOf(Node, Lch_enum, &ChNode);
                       Ch1Pl = SearchChs(&ChNode);
                       break;
   case BOTH_enum : break;
 }
 ChildrenPtr->LeftCh = Ch1Pl;
 ChildrenPtr->RightCh = Ch2Pl;
}
/*********/
ItemTree AllCodes[NumOfSubs];
/***********/
ItemTree TreeOfCodes = NULL;
/* FILE *fpCHS; */

PlacesT SearchForChs(ItemTree I, Child_Type ChT)
{struct ITEMS temp;
 ItemTree Chtemp = NULL;
 struct Node_Type ChNode;
 NodePtr Node = (NodePtr) I->Ptr; 

 ComputeChOf(Node, ChT, &ChNode);
 temp.Ptr = (void *) &ChNode;
 /* Show_Item(&temp) ; */
 Chtemp = FindTree(&temp, AllCodes[Node->Code.TreeC]);
 if (Chtemp !=NULL) 
   if ((RelateNodes(&ChNode, (NodePtr) Chtemp->Ptr)) == EQL)
      return (Chtemp->Address);
   else return -1;
 else return -1;
}
/*********/
void Find_Chs(ItemTree I)
{PlacesT Ch1Pl, Ch2Pl;
 struct Ch_Str Children;
 NodePtr Node = (NodePtr) I->Ptr; 
 Ch1Pl = -1; Ch2Pl = -1;
 
 switch (Node->OTS) {
   case NEITHER_enum : Ch1Pl = SearchForChs(I, Lch_enum);
                       Ch2Pl = SearchForChs(I, Rch_enum);
                       /* if ((Ch1Pl == -1) || (Ch2Pl == -1)) 
                           {printf("Ch Not Found "); Show_Item(I); }*/
                       break;
   case ONLYLHS_enum : Ch2Pl = SearchForChs(I, Rch_enum);
                       /* if (Ch2Pl == -1) 
                           {printf("Ch Not Found"); Show_Item(I); }*/
                       break;
   case ONLYRHS_enum : Ch1Pl = SearchForChs(I, Lch_enum);
                       /* if (Ch1Pl == -1) 
                           {printf("Ch Not Found"); Show_Item(I); }*/
                       break;
   case BOTH_enum : break;
 }
 /* Show_Item(I);*/
 Children.LeftCh = Ch1Pl;
 Children.RightCh = Ch2Pl;
 /* printf("%ld %ld \n", Ch1Pl, Ch2Pl); */
 /* printf("----------\n");*/
 fwrite((void *) &Children, sizeof(struct Ch_Str), 1, fpCHS);
}
/*********/
/*********/
ItemTree LastCode = NULL;
ItemTree FirstCode = NULL;
void FindAllChs()
{PlacesT CurrP = 0;
 Boolean EOFILE = false;
 NodePtr Node;
 ItemTree I;

 int RD = 0;
 /*
 if ((fpOUTCodes = fopen(".CodesList.bin", "r")) == NULL)
                {printf("Can't open %s\n", ".CodesList.bin"); exit(1);}
 else if ((fpCHS = fopen(".ChildPlace.bin", "w")) == NULL)
                {printf("Can't open %s\n", ".ChildPlace.bin"); exit(1);}
 else
 */
 do { /* Get the current code */
    /* printf(" Loading\n"); */
     Node = (NodePtr) AllocElem(sizeof(struct Node_Type));
     RD = GetFromFile(CurrP, Node);
    /* printf(" Inserting\n"); */
     if (RD != 1) EOFILE = true;
     else
        {I = FillItem((void *) Node, CurrP);
         /* Show_Item(I); */
         /* ENter the code to the list of codes at its tree place */
         TreeOfCodes = AllCodes[Node->Code.TreeC];
         AllCodes[Node->Code.TreeC] = EnterTree(I, TreeOfCodes);
         if (LastCode == NULL) {FirstCode = I; LastCode = I;}
         else {LastCode->Next = I; LastCode = I;}
         /* printf("%d ", CurrP);*/
        }
     CurrP = CurrP + sizeof(struct Node_Type);
    } while (EOFILE==false);
 /* fclose(fpOUTCodes); */
 printf("\n^^^^^^^^^\n");
 /* Now run through the codes and write for each its child place */
 TreeLMap(FirstCode, (void *) &Find_Chs); 
 /* fclose(fpCHS); */
}
