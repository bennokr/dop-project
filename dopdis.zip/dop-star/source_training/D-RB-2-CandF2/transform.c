#include "Universals.h"
#include "Constants.h"
#include "Aux.h"

static char VAL[SymLength];

char *TransLetter(char letter)
{VAL[0] = letter; VAL[1]='\0';
 switch (letter) {
   case ':': strcpy(VAL, "_a_"); break;
   case '+': strcpy(VAL, "_b_"); break;
   case '#': strcpy(VAL, "_c_"); break;
   case ';': strcpy(VAL, "_d_"); break;
   case '\'': strcpy(VAL, "_e_"); break;
   case '\"': strcpy(VAL, "_f_"); break;
   case ',': strcpy(VAL, "_g_"); break;
   case '`': strcpy(VAL, "_h_"); break;
   case '$': strcpy(VAL, "_i_"); break;
   case '!': strcpy(VAL, "_j_"); break;
   case '*': strcpy(VAL, "_l_"); break;
   case '&': strcpy(VAL, "_m_"); break;
   case '^': strcpy(VAL, "_n_"); break;
   case '\\': strcpy(VAL, "_o_"); break;
   case '=': strcpy(VAL, "_p_"); break;
   case '-': strcpy(VAL, "_q_"); break;
   case '\?': strcpy(VAL, "_r_"); break;
   case '>': strcpy(VAL, "_s_"); break;
   case '<': strcpy(VAL, "_t_"); break;
   case '/': strcpy(VAL, "_u_"); break;
   case '%': strcpy(VAL, "_v_"); break;
   case '~': strcpy(VAL, "_w_"); break;
   case '|': strcpy(VAL, "_x_"); break;
   case '{': strcpy(VAL, "_y_"); break;
   case '}': strcpy(VAL, "_z_"); break;
  otherwise: break;
 }
 return VAL;
}
/*--------------------------------------------*/
void TransformName(char *Name)
{char RESULT[SymLength]; int i; 

 strcpy(RESULT,"");
 {i = 0; while (Name[i] != '\0') {strcat(RESULT, TransLetter(Name[i])); i++;} }
 strcpy(Name, RESULT);
}
