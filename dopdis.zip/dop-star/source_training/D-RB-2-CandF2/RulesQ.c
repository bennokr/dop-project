#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"
#include "CodeL.h"
#include "NT_Lists.h"
#include "NT_Rules.h"
#include "NT_Sets.h"
#include "RulesQ.h"
#include "RnoCodes.h"   

/* Another queue implementation **/
/***************************************************/
/** A single production                         ****/
Prods CrProd() {return NULL;}
/****************************************************/
Prods FillProd(RDomain NUM, NTDomain lhs, TDomain rhs1, NTDomain rhs2)
{Prods prds = (Prods) AllocElem(sizeof(struct SProds));
       prds->NUM = NUM;
       prds->lhs = lhs;
       prds->rhs1 = rhs1;
       prds->rhs2 = rhs2;
       return prds;
}
/**************************************************************/
/*******        LIFOs of rules                         *******/
/*** NOTE : duplications in the lifo are not prohibited*******/
/***        take care yourself that that doesn't happen *******/
LIFO EnLifoUnit(Prods R)
{LIFO Lifo = (LIFO) AllocElem(sizeof(struct LifoUnit));
 Lifo->NUM = R->NUM;
 Lifo->lhs = R->lhs;
 Lifo->rhs1 = R->rhs1;
 Lifo->rhs2 = R->rhs2;
 Lifo->Next = NULL; 
 Lifo->Last = NULL; 
 return Lifo; 
}
/*****************************************/
LIFO CrLifo()
{return NULL;}
/*****************************************/
LIFO Enlifo(Prods R, LIFO Lifo)
{LIFO This = EnLifoUnit(R); LIFO Last;
 if (Lifo != NULL)
  {Last = Lifo->Last;
   Last->Next = This;
   Lifo->Last = This;
   return Lifo;
  }
 else {This->Last = This; return This;}
}
/*****************************************/
void LifoMap(LIFO Lifo, void (*func)())
{LIFO This = Lifo;
 while (This != NULL) 
   {(*func)(This->NUM, This->lhs, This->rhs1, This->rhs2, This->Next);
    This = This->Next; }
}
/**************************************************************/
/**** The rules of a non-terminal                      ********/
/**************************************************************/
ProdsPtr CrProds()
{ProdsPtr Ptr = (ProdsPtr) AllocElem(sizeof(struct ProdLists));
 Ptr->UProds = NULL; Ptr->TProds = NULL; Ptr->BProds = NULL;
 Ptr->EpsProds = NULL;
 Ptr->ULast = NULL; Ptr->TLast = NULL; Ptr->BLast = NULL; 
 Ptr->EpsLast = NULL;
 Ptr->UCount = 0; Ptr->TCount = 0; Ptr->BCount = 0; Ptr->EpsCount = 0;
 return Ptr;
}
/******************************************************/
/* PRE: ProdsPtr must exist                        ****/
void EnProd(ProdsPtr RPtr, Prods R, enum RType RT)
{if (RPtr == NULL) RPtr = CrProds(); /** First create the lifos **/
 switch (RT) {
   case Unary  : if (RPtr->UProds == NULL) {
                      RPtr->UProds = Enlifo(R, RPtr->UProds);
                       RPtr->ULast = RPtr->UProds; 
                      RPtr->UCount++;
                  }
                 else {RPtr->UProds = Enlifo(R, RPtr->ULast);
                      RPtr->ULast = RPtr->UProds; 
                      RPtr->UCount++;}
                 break;
   case Term  :  if (RPtr->TProds == NULL) {
                      RPtr->TProds = Enlifo(R, RPtr->TProds);
                       RPtr->TLast = RPtr->TProds; 
                      RPtr->TCount++;
                  }
                 else {RPtr->TProds = Enlifo(R, RPtr->TLast);
                      RPtr->TLast = RPtr->TProds; 
                      RPtr->TCount++;}
                 break;
   case Binary  :
                 if (RPtr->BProds == NULL) {
                      RPtr->BProds = Enlifo(R, RPtr->BProds);
                       RPtr->BLast = RPtr->BProds; 
                      RPtr->BCount++;
                  }
                 else {RPtr->BProds = Enlifo(R, RPtr->BLast);
                      RPtr->BLast = RPtr->BProds; 
                      RPtr->BCount++;}
                 break;
   case Eps     : if (RPtr->EpsProds == NULL) {
                      RPtr->EpsProds = Enlifo(R, RPtr->EpsProds);
                       RPtr->EpsLast = RPtr->EpsProds; 
                      RPtr->EpsCount++;
                  }
                 else {RPtr->EpsProds = Enlifo(R, RPtr->EpsLast);
                      RPtr->EpsLast = RPtr->EpsProds; 
                      RPtr->EpsCount++;}
                 break;
   default     : printf("%20s\n", "RuleType error");
                 break;
 }/* Switch */
}
/********************************************************/
void EmptyProds(ProdsPtr RPtr, enum RType RT)
{if (RPtr == NULL) RPtr = CrProds(); /** First create the lifos **/
 switch (RT) {
   case Unary  : RPtr->UProds = CrLifo();
                 break;
   case Binary : RPtr->BProds = CrLifo();
                 break;
   case Term   : RPtr->TProds = CrLifo();
                 break;
   case Eps    : RPtr->EpsProds = CrLifo();
                 break;
   default     : printf("%20s\n", "RuleType error");
                 break;
 }/* Switch */
}
/********************************************************/
void MapProds(ProdsPtr RPtr, enum RType RT, void (*func)())
{if (RPtr == NULL) printf("Error: no rules\n");
 else switch (RT) {
   case Unary  : LifoMap(RPtr->UProds, func); 
                 break;
   case Binary : LifoMap(RPtr->BProds, func); 
                 break;
   case Term   : LifoMap(RPtr->TProds, func); 
                 break;
   case Eps    : LifoMap(RPtr->EpsProds, func); 
                 break;
   default     : printf("%20s\n", "RuleType error");
                 break;
 }/* Switch */
}
/********************************************************/
RDomain ProdsSize(ProdsPtr RPtr, enum RType RT)
{switch (RT) {
      case Term   : return RPtr->TCount;
      case Unary  : return RPtr->UCount;
      case Binary : return RPtr->BCount;
      case Eps    : return RPtr->EpsCount;
      default: printf("Err: strange rule type");
               return 0;
 } /* switch */
}
