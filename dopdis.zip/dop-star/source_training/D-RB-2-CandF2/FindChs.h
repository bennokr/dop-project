FILE *fpOUT, *fpIN, *fpIN1;
FILE *fpOUTCodes, *fpCHS;

