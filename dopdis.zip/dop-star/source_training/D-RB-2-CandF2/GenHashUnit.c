#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "GenHashUnit.h"
    
extern char *NewStringOf(char *A);
/***********************************************************************/
UnitPtr NewUnit(char *String, UnitNumType N)
{UnitPtr new = (UnitPtr) AllocElem(sizeof(struct UnitType));
 if (new != NULL)
    if (String != NULL) {new->Rule = NewStringOf(String); }
    else new->Rule = NULL;
 else {fprintf(stderr,"Err: allocation failed in NewUnit\n"); exit(1);}
 new->UnitNum = N;
 new->UnitFreq = 1;
 return new;
}
UnitPtr FreeNewUP(UnitPtr UP)
{if (UP != NULL) 
    {if (UP->Rule != NULL) cfree((void *) UP->Rule); cfree((void *) UP); return NULL;}
 else return NULL;
}
/* EQ is true iff ua's Rule and ub's Rule are equal */
void EqUnitKey(void *ua, void *ub, Boolean *EQ)
  {UnitPtr UA = (UnitPtr) ua;   UnitPtr UB = (UnitPtr) ub;
   char *A = (char *) UA->Rule; char *B = (char *) UB->Rule;
   *EQ = (!strcmp(A,B)) ? true : false;}
/*********/
void EqUnitPtrs(void *A, void *B, Boolean *Found)
{if (((UnitPtr) A) == ((UnitPtr) B)) *Found = true;
 else *Found = false;
}
/*******/
void UnitNumOK(UnitNumType UN)
{if (UN < 0)
  {printf("Err: Unit number is < 0, i.e. key not found in HASHTABLE\n");exit(1);}
}
UnitNumType UnitNum(UnitPtr UN)
{return UN->UnitNum;
}
/********************************/
void MapOnUnitsKey(UnitPtr UP, void (*fp)())
{(*fp)(UP->Rule); }

FreqType UnitFreqOf(UnitPtr UP)
{return UP->UnitFreq;
}
/********************************/
/* Printing facilities          */
/********************************/
void ShowFreqOf(void *VUP)
{UnitPtr UP = (UnitPtr) VUP;
 PRI(UP->UnitFreq);PRS(UP->Rule);PRS("\n");
}
void ShowOUT(void *VUP)
{UnitPtr UP = (UnitPtr) VUP;
 fprintf(fpOUT, "%d  %s \n", UP->UnitFreq,UP->Rule);
}
/***********/
