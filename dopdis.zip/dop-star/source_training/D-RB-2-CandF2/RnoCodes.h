struct RuleStruct {
     RDomain Rno;
     PtrList CodesL;
     struct RuleStruct *Next;
};
typedef struct RuleStruct *RulesLPtr;
RulesLPtr Cr_CodesL();
RulesLPtr EnR_CodesL(RDomain, PtrList CL, RulesLPtr L);
void Map_CodesL(RulesLPtr L, void (* fp)());
RulesLPtr Reverse(RulesLPtr L);
