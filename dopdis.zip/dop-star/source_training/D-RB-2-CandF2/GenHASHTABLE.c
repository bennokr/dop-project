#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "PtrList.h"
#include "GenHashUnit.h"
#include "GenHASHTABLE.h"

/*********************/
/* global tables     */
HASHTABLE Word_Hash;    
HASHTABLE Bigram_Hash;
HASHTABLE Unigram_Hash;
HASHTABLE LexPairs_Hash;

void CrWord_Hash()
{ Word_Hash = NewHTable();   
}
void CrBigram_Hash()
{ Bigram_Hash = NewHTable();   
}
void CrUnigram_Hash()
{ Unigram_Hash = NewHTable();   
}
void CrLex_Hash()
{ LexPairs_Hash = NewHTable();   
}
/*************************************************************************/
extern PtrList RemoveIfNULL(PtrList PL);  

int String2Int(char *str)
{int sum = 0;
 int i =1;
 char *This = str;
 if (This == NULL) return -1;
 else if (This[0] == '\0') return -1;
      else
 do {
   sum = sum + ((int) This[0] * i); This = This+1;
 } while (This[0] != '\0');
 return sum;
} 
/******************************/
HASHTABLE AllocHashTable()
{HASHTABLE HT = (HASHTABLE) AllocElem(sizeof(struct HASHSTRUCT)); 
 HT->TheHT = (HASHLIST) MultAlloc((size_t) Maxvalue, sizeof(PtrList)); 
 HT->Num = 0;
 HT->SumFreq = 0;
 return HT;
}
/*****************************/
void InitHTable(HASHTABLE HTP)
{int i; HASHLIST HT = HTP->TheHT;
 for (i=0; i < Maxvalue; i++) HT[i] = NULL;}
/*****************************/
/* Allocates and initializes */
HASHTABLE NewHTable()
{HASHTABLE HT = AllocHashTable();
 InitHTable(HT);
 return HT;}
/*****************************/
int BucketOf(UnitPtr RU)
{int result;
 int R = String2Int(RU->Rule); 
 if (R < 0) {fprintf(stderr, "Err: BucketOf %s\n", R);exit(1);}
 else {result = (Mod(R, Maxvalue));
       return result;}
}
/***********************************************************************/
/*   Keeps the HASHTABLE as a set !!  */
UnitPtr ENT2HTable(HASHTABLE HTP,char *String)
{int place; UnitPtr New; HASHLIST HT = HTP->TheHT;
 if (String != NULL)
  {
 New = FindUnitInHT(HTP, String);
 if (New == NULL)
  {
   New = NewUnit(String,(HTP->Num+1)); place = BucketOf(New);
   if (place >= 0) {HT[place] = (PtrList) EnterPStack((void *) New, HT[place]); 
                    HTP->Num++;
                    return ((UnitPtr)(HT[place])->Ptr);}
   else {printf("place is < 0 in HASHTABLE\n"); PRS("\n string is:"); 
         PRS(String);PRS("\n"); exit(1);};
  } 
 else {New->UnitFreq++; HTP->SumFreq++; return New;}
 }
 else return NULL;
}
/****************************/
/* Find the UnitPtr of String in HT or otherwise return NULL;
*/
UnitPtr FindUnitInHT(HASHTABLE HTP, char *String)
{int place; UnitPtr UnitRes; PtrList This; HASHLIST HT; UnitPtr temp;

          void CMPRRule(PtrList R)
           {UnitPtr AR;
            if (R != NULL)
              {AR = (UnitPtr) R->Ptr; 
               if (AR != NULL) if (!strcmp(String, AR->Rule)) UnitRes = AR;
                               else;
               else {fprintf(stderr,"Err: NULL in CMPRule\n");exit(1);}  
              }
            else;
           }
 HT = HTP->TheHT; temp = NULL; UnitRes = NULL;
 if (String != NULL) {
  temp = NewUnit(String,0);
  place = BucketOf(temp); 
  if (temp != NULL) {temp = FreeNewUP(temp); }
  if ((place >= 0) && (place < Maxvalue))
   {/* do limited  PListMap(HT[place], (void *) &CMPRRule); */
    This = HT[place];
    while ((This != NULL) && (UnitRes == NULL)) {CMPRRule(This); This = This->Next;}
   }
  else {fprintf(stderr,"Err: place in HASH is %d  for %s...\n", place, String);exit(1);}  

 return UnitRes;
 }
 else {return NULL;}
}
/**********************/
void RemoveHEntryOf(HASHTABLE HTP, char *String)
{PtrList This; int place; UnitPtr New; HASHLIST HT = HTP->TheHT;
    void FreeIfEq(PtrList PL)
     {UnitPtr AR = (UnitPtr) PL->Ptr;
      if (!strcmp(String, AR->Rule)) PL->Ptr = (void *) FreeNewUP(AR); 
     }
 if (String != NULL)
  {New = NewUnit(String,1); place = BucketOf(New);
   if ((place >= 0) && (place < Maxvalue))
    {This = HT[place]; while (This != NULL) {FreeIfEq(This); This = This->Next;}
     HT[place] = RemoveIfNULL(HT[place]);
    }
   New = FreeNewUP(New);
  }
}
/**********************/
/* -1 not found otherwise a number >=0 */
UnitNumType UnitNumOf(HASHTABLE HTP, char *String)
{UnitPtr UP = FindUnitInHT(HTP, String);
 if (UP == NULL) return -1;
 else return UP->UnitNum;
}
UnitNumType UnitNumOfEn(HASHTABLE HTP, char *String)
{UnitPtr UP;
 UP = ENT2HTable(HTP,String);
 return UP->UnitNum;
}
/**************/
void MapOnHTableKey(HASHTABLE HTP, void (* fp)())
{ int i; HASHLIST HT;
        void MapOnUnitsKeyI(void *VUP)
          {UnitPtr UP = (UnitPtr) VUP;
           MapOnUnitsKey(UP, fp);
          }
  HT = HTP->TheHT;
  for (i=0; i < Maxvalue; i++) 
      if (HT[i] != NULL)
         PListMapV(((PtrList) HT[i]), (void *) &MapOnUnitsKeyI);
}
/**************/
void MapOnHTableUnits(HASHTABLE HTP, void (* fp)())
{ int i;HASHLIST HT;
        void MapOnUnit(void *VUP)
          {UnitPtr UP = (UnitPtr) VUP;
           (*fp)(UP);
          }
 HT = HTP->TheHT;
 if (HT !=NULL)
  for (i=0; i < Maxvalue; i++)
      if (HT[i] != NULL)
         PListMapV(((PtrList) HT[i]), (void *) &MapOnUnit);
}
/*************/
FreqType TotalFreqOf(HASHTABLE HTP)
{FreqType Tot;
     void AddHUP(UnitPtr UP)
      {Tot = Tot + UP->UnitFreq;
      }
 Tot = 0;
 MapOnHTableUnits(HTP, (void *) &AddHUP);
 return Tot;
}
/*************/
float AverageFreq(HASHTABLE HTP)
{if (HTP == NULL) return ((float) 0.0);
 else if (HTP->Num == 0) return ((float) 0.0);
      else return ((float) ((float) HTP->SumFreq)/((float) HTP->Num));
}
/*************/
float FreqStdDev(HASHTABLE HTP)
{float stddev; float Avg;
    void CStdDev(UnitPtr UP)
     {stddev = stddev + ((float) pow((double) (((float) UP->UnitFreq) - Avg), (double) 2.0));
     }
 stddev = 0.0;
 Avg = AverageFreq(HTP);
 MapOnHTableUnits(HTP, (void *) &CStdDev);
 stddev = (float) sqrt((double) (stddev /((float) HTP->Num)));
 return stddev;
}
/*************/
void FreeHTable(HASHTABLE HTP)
{ int i;HASHLIST HT = HTP->TheHT;
  for (i=0; i < Maxvalue; i++)
      if (HT[i] != NULL) {FreePListN(HT[i]);HT[i] = NULL;}
  HTP->Num = 0;
}
/*************/
extern FreqType UnitFreqOf(UnitPtr UP);

char *MaxFreqKeyOf(HASHTABLE HTP)
{FreqType MAX = 0; char *RES = NULL;
  void SelectMaxFreq(UnitPtr UP)
     {if (UP != NULL) if (UnitFreqOf(UP) > MAX) RES = UP->Rule;}

  if (HTP == NULL) return NULL;
  MapOnHTableUnits(HTP, (void *) &SelectMaxFreq);
  return RES;
}
/****************************************************************************************/
/* for making shorter names                                                             */
#define _WDS_PER_LET 1000

char *NameFromNum(int NUM)
{int LetterNum; int NumAfterLetter; char ModNUM[SymLength]; static char RES[SymLength];
 strcpy(RES,"x"); strcpy(ModNUM,"");
 LetterNum = (int) (((float) NUM)/((float) _WDS_PER_LET));
 NumAfterLetter = Mod(NUM, _WDS_PER_LET);
 RES[0] = (char) (LetterNum+'a'); RES[1] = '\0';
 sprintf(ModNUM,"%d", NumAfterLetter); strcat (RES,ModNUM);
 return (RES);
}
char *ShortRepresent(char *WORD)
{int Number; UnitPtr UP;
 if ((UP = FindUnitInHT(Word_Hash, WORD)) != NULL) Number = (int) UnitNum(UP);
 else Number = (int) UnitNum(ENT2HTable(Word_Hash, WORD));
 return (NameFromNum(Number));
}
