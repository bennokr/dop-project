/************************************/
/* For large tree-banks I decided to*/
/* move all codes from the main mem.*/
/* to the file .CodesList.bin       */
/* The file is a binary-file of Node_Type structures. */
/* The codes of a rule are on the file after each other
   in the order they appeared in the RBSTSG file.     */
/* The number of the codes of a rule and the place on */
/* of the first of these codes on the file are maintained */
/* in main the program in a Place_Struct.                 */
/************************************/
/************************************/
/************************************/
struct RCodeTStruct {
     TreeCodeT TreeC;
     InTreeCodeT OwnC;
};
typedef struct RCodeTStruct RCodeType;
typedef RCodeType *RCodePtr;


/*********************/
void WR_DECLARATIONS();
void WR_A_Code(PtrList P);
void WR_C(RulesLPtr R);
void WR_Codes();
