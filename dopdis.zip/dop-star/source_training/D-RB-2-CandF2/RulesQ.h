struct SProds {
    RDomain NUM;
    NTDomain lhs;
    TDomain rhs1;
    NTDomain rhs2;
};
typedef struct SProds *Prods;
Prods CrProd();
Prods FillProd(RDomain NUM, NTDomain lhs, TDomain rhs1, NTDomain rhs2);
/******************************************************************/
/*** The type Prods must be defined externally         ************/
/******************************************************************/
struct LifoUnit {
        /* Prods Rule;           the rule */
        RDomain NUM;
        NTDomain lhs;
        TDomain rhs1;
        NTDomain rhs2;
        struct LifoUnit *Next;
        struct LifoUnit *Last;
};
typedef struct LifoUnit *LIFO;  /* lists of rules */
/*****************************/
/* returns a Q with element R*/
LIFO EnLifoUnit(Prods R);
/*****************************/
LIFO CrLifo();
/*****************************/
/* Enqueues R in Q           */
LIFO Enlifo(Prods R, LIFO Lifo);
/*****************************/
/* Maps func on Q            */
void LifoMap(LIFO Lifo, void (*func)());

/******************************************************************/
/* rules are of three types: Unary, Binary or Trinary             */
struct ProdLists {
        LIFO UProds; /* Unary list of rules */
        RDomain  UCount;  /* their number        */
        LIFO ULast;  /* last element in the LIFO */
        LIFO TProds; 
        RDomain  TCount;
        LIFO TLast; 
        LIFO BProds;
        RDomain  BCount;
        LIFO BLast;
        LIFO EpsProds;
        RDomain  EpsCount;
        LIFO EpsLast;
};
typedef struct ProdLists *ProdsPtr;
/****************/
ProdsPtr CrProds();
/****************/
/* ENter R into rulestructure */
/*   RPtr under rules type RT */
void EnProd(ProdsPtr RPtr, Prods R, enum RType RT);
void EmptyProds(ProdsPtr RPtr, enum RType RT);
/*****************/
/* Maps func on all */
/* rules of type RT */
/* in RPtr.         */
void MapProds(ProdsPtr RPtr, enum RType RT, void (*func)());
/********************/
RDomain ProdsSize(ProdsPtr RPtr, enum RType RT);
