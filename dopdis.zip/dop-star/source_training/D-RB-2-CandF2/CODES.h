/* Number of chars in repres. of a code */
#define CdChars 50  

extern char CCode[CdChars]; 
extern PtrList CCodes; 
extern RulesLPtr T_List, U_List, B_List, Eps_List;
