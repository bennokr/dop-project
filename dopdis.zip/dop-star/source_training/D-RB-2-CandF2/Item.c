#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"
#include "NT_Lists.h"
#include "NT_Rules.h"
#include "NT_Sets.h"
#include "RulesQ.h"
/*** implementation files ***/
#include "CodeL.h"
#include "RnoCodes.h"
#include "Probabilities.h"
#include "GenFiles.h"
#include "FindChs.h"
#include "FindChild.h"
#include "Item.h"
#include "Trees.h"          


ItemTree FillItem(void *Ptr, PlacesT PL)
{ItemTree IDL = (ItemTree) AllocElem(sizeof(struct ITEMS));
 IDL->Right = (ItemTree) NULL; IDL->Left = (ItemTree) NULL; 
 IDL->Ptr = Ptr;
 IDL->Next = NULL;
 IDL->Address = PL;
 return IDL;}

void Show_Item(ItemTree I)
{NodePtr N = (NodePtr) I->Ptr;
 printf("%d %d \n", N->Code.TreeC, N->Code.OwnC);
 printf("%d \n", I->Address);
 printf("------\n");
}
