#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"
#include "CodeL.h"
#include "NT_Lists.h"                   
#include "Probabilities.h"

Boolean HasBeenC;
TreeCodeT TotalRsNum;    

/* #define ProbDomain float */
/* ProDomain TheProbOf[TotalRootsNum];*/
extern FILE *fpIN; 
extern FILE *fpOUT; 
void PRB(float A) {fprintf(fpOUT, "%f", A);}

Boolean FirstTime = true;
int Total = 1;

void R_W_ProbsI(char *X, Boolean LastTime)
{ProbDomain P; float temp;
 char *s; int i, j;

  if (LastTime == false) {P = (ProbDomain) strtod(X,NULL);}

  if (HasBeenC == true) 
   if ((FirstTime == true) && (LastTime == false)) {
    WRITE("ProbDomain IVTheProbOf");WGNum();
    WRITE("[IVTotalRootsNum");WGNum();WRITE("] = \n");
    WRITE("{ "); PRB((float) P); FirstTime = false;
   }
   else if (LastTime == false) 
           {if ((Total%5)==0) WRITE("\n"); WRITE(", ");PRB((float) P);} 
        else WRITE("\n};\n");
  else {WRITE("ProbDomain *IVTheProbOf");WGNum();WRITE(" = NULL;");}
  Total++; 
}
void R_W_Probs(FILE *fpIN)
{ProbDomain P; float temp;
 char *s; int i, j;

  j = 1;
  if (HasBeenC == true) {
    WRITE("ProbDomain IVTheProbOf");WGNum();
                          WRITE("[IVTotalRootsNum");WGNum();WRITE("] = \n");
    if (TotalRsNum >= 0)
     {WRITE("{ "); 
      do {
        i = fscanf(fpIN, "%f", (float *) &temp); 
        printf("%d\n",i);
        P = (ProbDomain) temp;
        if ((j != 1) && (i != EOF)) WRITE(", ");
        if (i != EOF) {fprintf(fpOUT, "%f", (float) P); 
                       j++;
                       if ((j%5)==0) WRITE("\n"); 
                      }
       } while (i !=EOF);
     WRITE("};\n");
     } else;
   }
  else {WRITE("ProbDomain *IVTheProbOf");WGNum();WRITE(" = NULL;");}
}
