#include "stdlib.h"
#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"
#include "CodeL.h"
#include "NT_Lists.h"
#include "NT_Rules.h"
#include "NT_Sets.h"
/******************************************/
/* Sets of Nonterminals and their rules  **/
/* This module assumes two modules:      **/
/*   Lists and Rules                     **/
/******************************************/
/* global arrays for this unit used for speed-up */
static List *NonTArray;
static List *TermArray;

extern List *AssignArray(Set S);


Set CreateSet()
{return NULL;}
/*****************************************/
Set InitSet()
{Set set;
 set = (Set) AllocElem(sizeof(struct SetType));
 set->Cont = NULL;
 set->Size = 0;
 set->Kind = NONS;
 set->Array = NULL;
 return set;
}
/************************/
Boolean Last(Set set)
{if (set == NULL) return true;
 else
 if (Next(set->Cont) == NULL) return true;
 else return false;
}
/************************/
/*Pre: set must exist   */
Set Add(KeyType key, Set set)
{Boolean b;
 Set set1 = (set == NULL) ? InitSet() : set;
 set1->Cont = Enter(key, set1->Cont, &b); 
 if (b) (set1->Size)++; /* else  no change in Size */
 return set1;
}
/****************/
Set AddNotSorted(KeyType key, Set set)
{Boolean b; Set set1 = ((set == NULL) ? InitSet() : set);
 set1->Cont = EnterNotSorted(key, set1->Cont); 
 (set1->Size)++; 
 return set1;
}
/************************/
/*Pre: set must exist   */
/************************/
extern List SeekArray(KeyType key, Set set, TDomain *C);

Set Seek(KeyType key, Set set)
{TDomain C; Set Nset ;
 Nset = InitSet();
 if (set->Array != NULL) {Nset->Cont = SeekArray(key, set, &C); C = C + 1;}
 else if (set == NULL) fprintf(stderr,"Err: empty set");
      else Nset->Cont = Search(key, set->Cont, &C); 

 Nset->Size = ((set->Size) - C) + 1;
 return Nset;
}
Set SubSetFrom(Set set, TDomain place )
{Set Nset = InitSet();
 Nset->Cont = set->Array[place];
 Nset->Size = set->Size - place;
 return Nset;
}
/************************/
Boolean Member(KeyType key, Set set)
{TDomain C;
 List L;
 if (set == NULL) return false;
 else return (InElm(key, L = Search(key, set->Cont, &C)));
}
/************************/
/* return a pointer to the subset of set that starts with key */
Set UpdateData(RDomain R, KeyType key, Set set, enum RType RT, TDomain place)
{TDomain C; Set Nset; List This; RulesPtr RPtr;
 if (place == -1) {Nset = Seek(key, set); C = Nset->Size; This = Nset->Cont;}
 else {This = set->Array[place]; C = place; Nset = InitSet(); Nset->Size = set->Size - place; Nset->Cont = This;}
 RPtr = (RulesPtr) This->Data;
 if (InElm(key, This) == true) {if (RPtr == NULL) {RPtr = CrRules(); This->Data = (void *) RPtr;}; (EnRule(RPtr, R, RT));} 
 else ; /* {fprintf(stderr, "%20s\n", "Err: strange key");exit(1);} */
 return Nset;
}
/*************************/
void SetsMap(Set set, void (* fp)(), enum PartT KR, enum RType RT)
{RulesPtr RPtr;
 List L;
 if (set == NULL) fprintf(stderr,"Err: empty set");
 else 
  {L = set->Cont; 
   if (L == NULL) fprintf(stderr,"Err: empty List");
   else
     switch (KR) {
      case RULE : RPtr = (RulesPtr) L->Data;
                  MapRules(RPtr, RT, fp);
                  break;
      case KEY : ListMap(L, fp);
                 break;
      default: break;
      } /* Switch */
  } /*. ELse */
}

void SetsMapExten(Set set, void (* fp)(), enum PartT KR, enum RType RT)
{RulesPtr RPtr;
 List L;
 if (set == NULL) fprintf(stderr,"Err: empty set");
 else 
  {L = set->Cont; 
   if (L == NULL) fprintf(stderr,"Err: empty List");
   else
     switch (KR) {
      case RULE : RPtr = (RulesPtr) L->Data;
                  MapRules(RPtr, RT, fp);
                  break;
      case KEY : MapOnList(L, fp);
                 break;
      default: break;
      } /* Switch */
  } /*. ELse */
}
/**********************************/
RDomain SetSize(Set set)
{if (set == NULL) return 0;
 else return (set->Size);} 
/**********************************/
RDomain DataSize(KeyType key, Set set, enum RType RT)
{Set S = Seek(key, set);
 if (Member(key, set)) return (RulesSize((RulesPtr) S->Cont->Data, RT));
 else return 0;
}
/***************************/
/* Assuming set if ordered */
void Print(List L) {fprintf(stderr,"%s\n", L->Key);} 

Set AssignSet(Set set)
{Set s = InitSet(); List Temp;  List Last = NULL; List FSTinLST = NULL;
 void CPY(KeyType Key, List Next)
  {Temp = EnterKey(Key);
   if (Last != NULL) Last->Next = Temp;
   else {Last = Temp; FSTinLST = Last;}
   Last = Temp;
  }
 
 SetsMap(set, (void *) &CPY, KEY, NONE);
 s->Cont = FSTinLST; s->Size = set->Size; s->Kind = set->Kind; s->Array = AssignArray(s);

 /* MapOnList(s->Cont, (void *) &Print); */
 return s;
}
/*******************************************************************************************************/
List *TempArray;

extern int CompareLists(List L1, List L2);
extern enum TorN StateOfReading;

int Compare(const void *VL1, const void *VL2)
{return ((int) CompareLists((List) VL1, (List) VL2));}

int CompareH(const void *VVL1, const void *VVL2)
{List *VL1 = (List *) VVL1; List *VL2 = (List *) VVL2; 
 return ((int) CompareLists((List) *VL1, (List) *VL2));
}

void SORT(List *Array, int size)
{int i, j; List Temp;
 for (j=0; j < size-1; j++)
  for (i=j+1; i < size; i++)
   if (CompareLists(Array[j], Array[i]) > 0) {Temp = Array[j]; Array[j] = Array[i]; Array[i] = Temp;}
}

/* searches for key in set and returns distance from beginning of set */
/* if not in set, then return first in set and *C is zero             */
List SeekArray(KeyType key, Set set, TDomain *C)
{List *HERE; List templist = EnterKey(key);

 HERE = (List *) bsearch((void *) &templist, (void *) &(set->Array[0]), (size_t) set->Size, sizeof(List), CompareH);

 if (HERE != NULL) *C = (TDomain) (HERE - (set->Array) );
 else {HERE = &set->Cont; *C = 0;}
 free(templist);
 return *HERE;
}

List *AssignArray(Set S)
{int counter =0 ; List *Array; void addToArray(List L) {Array[counter] = L; counter++;}

 Array = (List *) MultAlloc(S->Size,sizeof(List));
 MapOnList(S->Cont, (void *) &addToArray);
 if (counter < (S->Size -1)) {fprintf(stderr,"Error in copying to array\n"); exit(1);}
 return Array;
}

Set OrderSet(Set S)
{int counter = 0; List result;
 
 if (S->Size != 0) {
 TempArray = AssignArray(S);       /* make a copy of S */
 /* now sort the array and then reshuffle the list */
 qsort((void *) &(TempArray[0]),  S->Size, (sizeof(List)), CompareH); /* slow : SORT(TempArray, S->Size); */

 /* for (counter = 0; counter < (S->Size); counter++) {Print(TempArray[counter]);} fprintf(stderr,"-------\n"); */

 /* reshuffling the list of the set into the same order as in TempArray */
 result = TempArray[0];
 for (counter = 0; counter < (S->Size-1); counter++) {TempArray[counter]->Next =  TempArray[counter+1];}
 TempArray[S->Size-1]->Next = NULL;

 S->Cont = result;
 /* MapOnList(S->Cont, (void *) &Print); */
 if (StateOfReading == NONS) {NonTArray = TempArray; S->Kind = NONS; S->Array = TempArray;}
 else {TermArray = TempArray; S->Kind = TERMS;  S->Array = TempArray;}
 }
 else {S->Kind = StateOfReading; S->Array = NULL;}

 return S;
}
/*
       void qsort(void *base, size_t nmemb, size_t size, int (*compar)(const void *, const void *))

DESCRIPTION
       The  qsort()  function  sorts an array with nmemb elements of size size.  The base argument points to
       the start of the array.

       The contents of the array are sorted in ascending order according to a comparison function pointed to
       by compar, which is called with two arguments that point to the objects being compared.

       The comparison function must return an integer less than, equal to, or greater than zero if the first
       argument is considered to be respectively less than, equal to, or greater than the  second.   If  two
       members compare as equal, their order in the sorted array is undefined.

*/
