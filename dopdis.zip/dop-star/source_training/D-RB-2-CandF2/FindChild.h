/* #define NumOfSubs 130000 */
#define SEEK_SET 0
#define PlacesT long int
/*
struct Ch_Str {
      PlacesT LeftCh;
      PlacesT RightCh;
};
typedef struct Ch_Str *Ch_Ptr;
*/

enum Relate RelateNodes(NodePtr A, NodePtr B);

enum Relate CodeREL(const void *e1, const void *e2);
/******************/
