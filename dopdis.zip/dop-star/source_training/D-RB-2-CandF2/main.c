/* This program translates a CFG into a c file which includes */
/* declarations and definitions of variables and datastructures */
/* which can be used for a parser (CYK).                        */
/* Assumptions: Input file contains                                 
/*              1. a. A list of nonterminals, each an identifier 
                      as of prog. languages.
                   b. First nonterminals is the start symbol of
                      the CFG. 
                   c. This list of Nonterminals must end with ";".
                2. List of terminals (same req.s as for nonterminals
                   here above).
                3. A list of rules, each in CNF and ended with ";".
                4. The symbol "##" ends the input file. 
   Post conds: An output file is created which contains definitions
               and declarations of datastructures in c. The contents
               of this file represent the input CFG.  This maybe included 
               in a main program which also contains an
               implementation of a parsing algorithm, a procedure
               which implements an interface with the user. Such a
               program forms then a parser where the output file of
               the present program is in fact a representation of
               the CFG.
               For a figure of the representation see the figure
               Rep.ps in this directory.
*/
/***********************************/
/*
#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "sys/types.h"
#include "sys/times.h"
#include "math.h"
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <float.h>

/*** Decalrations files ***/
/****** External declarations *****/
FILE *fpOUT; FILE *fpIN; FILE *fpIN1; FILE *fpOUTCodes; FILE *fpCHS;
/*******************/
#include "Constants.h"
#include "Universals.h"
#include "Aux.h"
#include "CodeType.h"
#include "NT_Lists.h"
#include "NT_Rules.h"
#include "NT_Sets.h" 
#include "RulesQ.h" 
#include "CodeL.h"
#include "RnoCodes.h"
#include "CODES.h"
#include "Probabilities.h"
#include "GenFiles.h"
/**
#include ".D-ChildFinding/FindChild.h"
#include ".D-ChildFinding/Item.h"
#include ".D-ChildFinding/Trees.h"
#include ".D-ChildFinding/Item.c"
#include ".D-ChildFinding/Trees.c"
#include ".D-ChildFinding/FindChild.c" 
**/
/************* See last line in this file for more ****/
/* enum TorN {TERMS=1,NONS=0,RULES=2,CODES=3}; */
int GrammarNum = 0;
char CODESFNAME[100] = ".CodesList.bin";
/**********/
void USAGE()
{
 printf("Options: -i <inputfile>\n");
 printf("Options: -o <outputfile>\n");
 printf("Options: -N #    # is the grammar number\n");
}
extern void Trans();
extern void TandN_Decs(Set set, enum TorN TN);

/* extern int getopt( int argc, char* argv[], char* optstring ); */
extern char* optarg;
extern int optind, opterr;


int  main( int argc, char *argv[])
{int opt_ch; int error_flag = 0; char* options = "i:o:N:"; char Temp[20] = ""; 
 FILE *fopen(); clock_t start, finish; double duration ; int i;
 clock_t clock() {struct tms *buff; return 0;}

 start = clock(); fpOUT = stdout; fpIN = stdin;

 opt_ch = getopt( argc, argv, options );
 while ( opt_ch != -1 )
   {switch( opt_ch ) {
     case 'N' : GrammarNum = atoi(optarg); if  (GrammarNum > 0) strcpy(Temp,optarg);
                break;
     case 'i' : if ((fpIN = fopen(optarg, "r")) == NULL)
             printf("Can't open %s\n", *argv);
           break;
     case 'o' : if ((fpOUT = fopen(optarg, "w")) == NULL)
             printf("Can't open %s\n", *argv);
           break;
     case '?' : error_flag++; USAGE(); exit(1); break;
    }
    opt_ch = getopt( argc, argv, options );
  } /* while */
  /* -----------  file names problems ---------------*/
   if (( argc - optind > 0 ) && ( fpIN == stdin ))
      {if ((fpIN = fopen(argv[optind], "r")) == NULL) 
         fprintf(stderr, "Can't open %s\n", argv[optind]); 
       ++optind;
      }
   if (( argc - optind > 0 ) && ( fpOUT == stdout ))
     {if ((fpOUT = fopen(argv[optind], "w")) == NULL) 
         fprintf(stderr, "Can't open %s\n", argv[optind]); 
      ++optind;
     }
   if ( argc - optind > 0 ) {USAGE(); exit(1);}

   /* -----------  ---------------*/
  if (GrammarNum > 2) {fprintf(stderr,"Err: not legal ( -N<num>:  0<= <num> <= 2 )\n");exit(1);}
  if (GrammarNum >= 0) 
     {WRITE("#ifndef IVGrammarNumber\n");
      WRITE("#define IVGrammarNumber  ");WGNum();WRITE("\n");
      WRITE("#endif\n"); 
      WRITE("/*defines the names of the binary code files for the parser */\n");
      WRITE("char CodeBINName"); WGNum(); WRITE("[] = \".CodesList.bin");WRITE(Temp);WRITE("\";\n");
      WRITE("char ChPlBINName"); WGNum(); WRITE("[] = \".ChildPlace.bin");WRITE(Temp);WRITE("\";\n");
      WRITE("/*-----------------------------------*/\n");
     }
  else {fprintf(stderr,"Err: grammar number is not legal (choose > 0)\n");exit(1);}
  strcat(CODESFNAME,Temp); /* concat the supplied number to the file name */
  Trans();
  fclose(fpIN);
  fclose(fpOUT);
  fclose(fpOUTCodes); 
 finish = clock();
 duration = ((double) (finish - start)) / 60;
 /* printf("Duration is :%f secs\n", duration);*/
 return 0;
}
/*****************************************************************/
/*** The external variables to the next func.s  are hereunder ***/
enum TorN StateOfReading;
Set Tempset; 
Set Nonterminals, Rhs1Nons, Rhs2Nons;
Set Terminals;
KeyType StartNont;
List StartNonTPtr = NULL;
Boolean First = true;
TDomain current = 0;
ProdsPtr Productions;
Boolean InputIsASet = true;

extern void CrWord_Hash() ;
/*****************************************************************/
/****** The translation procedure                              ***/
/*** Fills Nonterminals and Terminals and declares then in the  **/
/** output ****/
int Tyylex();

void Trans()
{int i; long InFilePos; 
 StateOfReading = NONS; /*firstly nonterminals */
 Tempset = CreateSet(); 
 if ((fpOUTCodes = fopen(CODESFNAME, "w")) == NULL) {fprintf(stderr, "Can't open %s\n",CODESFNAME);exit(1);}



 Nonterminals = CreateSet(); 
 Rhs1Nons = CreateSet(); 
 Rhs2Nons = CreateSet(); 
 Terminals = CreateSet();
 Productions = CrProds();
 CrWord_Hash();

 Tyylex(); 

 free(Tempset); free(Nonterminals); free(Rhs1Nons); free(Rhs2Nons); free(Terminals); free(Productions);
 fclose(fpOUTCodes);
}
/****** what to do with each nonterminal/terminal ****/
/*** Generating a declaration of a  nonterminal/terminal   ***/
/*** checking whether to put an "," or ";" behind it.      ***/
void WRITES(char *a, void *Next)
{char Temp[10];
  if (current == 0) WRITE("{"); /** first element **/
  WRITE(a); 
  WRITE("=");
  sprintf(Temp, "%d", current++);
  WRITE(Temp); 
  if (Next == NULL) WRITE("};\n"); /** last element **/
  else WRITE(",");
  if (current == 9) WRITE("\n             ");
}

/** declaration for enumerated type NONTERMINALS ***/
/** and of the sizes of each of the sets        ***/
/**/
void TandN_Decs(Set set, enum TorN TN)
{char Temp[SymLength];
 char Temp1[SymLength]="\0";
 char Temp2[SymLength]="\0";
 TDomain size;
 TDomain Start;

 /** Size definition **/
 size = SetSize(set);
 switch (TN) {
    case TERMS : strcpy(Temp1, "IVTermsSize");
                 strcpy(Temp2, "Terminals");
                 break;
    case NONS  : WRITE("#define IVStartNonterminal");WGNum();WRITE(" ");
                 Start = size - SetSize(Seek(StartNont, set)); 
                 sprintf(Temp, "%d", Start); WRITE(Temp); WRITE("\n");
                 strcpy(Temp1, "IVNonTSize");
                 strcpy(Temp2, "Nonterminals");
                 break;
    default : printf("Err: not good"); break;
 } /* of case */
 WRITE("#define "); WRITE(Temp1);WGNum(); sprintf(Temp, "%d", size); 
 WRITE(" ");WRITE(Temp); WRITE("\n");
 WRITE("/* enum ");WRITE(Temp2);WRITE("  */\n");
}
/******************************************************/
/**** Other file ***/
#include "Proc.c"
#include "lex.yy.c"
/******************************************************/
/* ref1:
   The file names .CodesList.binX and .ChildPlace.binX may have any X>0
   but the internal numbers in GrammarX.c are either 1 or 2, where if
   the grammar number supplied is >=2 then these internal numbers are 2
*/
/*
 fprintf(stderr,"%d\n", KeyComp("aa1","aa11"));
 fprintf(stderr,"%d\n", KeyComp("aa1","aa10"));
 fprintf(stderr,"%d\n", KeyComp("ab","aa"));
 fprintf(stderr,"%d\n", KeyComp("ba","ab"));
 fprintf(stderr,"%d\n", KeyComp("ab","ba"));
 fprintf(stderr,"%d\n", KeyComp("ab@","ab"));
 fprintf(stderr,"%d\n", KeyComp("ab","ab@"));
exit(0);
*/
