/*********************************************************************/
/**** KeyType is a type defined outside this module together with ***/
/**** its relational operations: Less, Greater, Leq, Geq, Eq       ***/
/**** and KeyAssig.                                                ***/
/*********************************************************************/
struct ElemType {
        KeyType Key;
        struct ElemType *Next;
        void *Data;
};
/*** The type List ************/
typedef struct ElemType *List; 
/******************************/
/* Function declarations      */
/******************************/
/*   On Elements              */
/*----------------------------*/
List EnterKey(KeyType key);
Boolean InElm(KeyType key, List L);
/******************************/
/*  On LISTS                  */
/* initializes L to NULL */
List CreateList();                 
/************/
/* Given  a list it returns a pointer to the second element
   in the list. In case the list is empty it returns NULL       */
List Next(List L);
/************/
/*
 Precond: L is not NULL;
 returns a pointer to the last item smaller or eq than key in list
 otherwise: a pointer to the first item which is larger
*/
List Search(KeyType key, List L, TDomain *C);

/*********************************************************************/
/* Enters elem into list pointed to by L in the right place keeping  */
/* the lexicographic order in good shape.                            */
/* Pre: L is a lexicographically ordered list such that one of three */
/*      is true: 1. given-key is smaller than the first key          */
/*               2. given-key ranks between first and second  keys   */
/*               3. given-key is equal to first key                  */

List EnterElem(KeyType key, List L); 
/*********************************************************************/
/* Pre: list must exit i.e. at least must have value NULL.            */
/*      list must be ordered.
/* Post: an oredred list in which key also appears (an oredred set)  */
/*       Change indicates whether the item was added or not (already */
/*       was in the set).                                            */
List Enter(KeyType key, List list, enum boolean *Change);
/*********************************************************************/
void ListMap(List L, void (* fp)());
List EnterNotSorted(KeyType key, List list);
void MapOnList(List L, void (* fp)()) ;
int CompareLists(List L1, List L2) ;
