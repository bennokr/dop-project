#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"
#include "CodeL.h"
#include "NT_Lists.h"                   
#include "NT_Rules.h"
/**************************************************************/
/*******        Queues of rules                         *******/
/*** NOTE : duplications in the queue are not prohibited*******/
/***        take care yourself that that doesn't happen *******/
Queue EnQUnit(Rules R)
{Queue Q = (Queue) AllocElem(sizeof(struct QUnit));
 Q->Rule = R; Q->Next = NULL; return Q; }
/*****************************************/
Queue CrQ()
{return NULL;}
/*****************************************/
Queue Enqueue(Rules R, Queue Q)
{Queue This = EnQUnit(R);
 Queue Last = Q;
 if (Last != NULL) {while (Last->Next != NULL) Last = Last->Next;
                    Last->Next = This; 
                    return Q;}
 else return This;
}
/*****************************************/
void QMap(Queue Q, void (*func)())
{Queue This = Q;
 while (This != NULL) {(*func)(This->Rule, This->Next);
                       This = This->Next;
                      }
}
/**************************************************************/
/**** The rules of a non-terminal                      ********/
/**************************************************************/
RulesPtr CrRules()
{RulesPtr Ptr = (RulesPtr) AllocElem(sizeof(struct RLists));
 Ptr->URules = NULL; Ptr->TRules = NULL; Ptr->BRules = NULL;
 Ptr->UCount = 0; Ptr->TCount = 0; Ptr->BCount = 0; 
 Ptr->EpsRules = NULL; Ptr->EpsCount = 0;
 return Ptr;
}
/******************************************************/
/* PRE: RulesPtr must exist                        ****/
void EnRule(RulesPtr RPtr, Rules R, enum RType RT)
{if (RPtr == NULL) RPtr = CrRules(); /** First create the queues **/
 switch (RT) {
   case Unary  : RPtr->URules = Enqueue(R, RPtr->URules);
                 RPtr->UCount++;
                 break;
   case Binary : RPtr->BRules = Enqueue(R, RPtr->BRules);
                 RPtr->BCount++;
                 break;
   case Term   : RPtr->TRules = Enqueue(R, RPtr->TRules);
                 RPtr->TCount++; 
                 break;
   case Eps    : RPtr->EpsRules = Enqueue(R, RPtr->EpsRules);
                 RPtr->EpsCount++; 
                 break;
   default     : printf("%20s\n", "RuleType error");
                 break;
 }/* Switch */
}
/********************************************************/
void MapRules(RulesPtr RPtr, enum RType RT, void (*func)())
{if (RPtr == NULL) printf("Error: no rules\n");
 else switch (RT) {
   case Unary  : QMap(RPtr->URules, func); 
                 break;
   case Binary : QMap(RPtr->BRules, func); 
                 break;
   case Term   : QMap(RPtr->TRules, func); 
                 break;
   case Eps    : QMap(RPtr->EpsRules, func); 
                 break;
   default     : printf("%20s\n", "RuleType error");
                 break;
 }/* Switch */
}
/********************************************************/
RDomain RulesSize(RulesPtr RPtr, enum RType RT)
{if (RPtr != NULL)
 switch (RT) {
      case Term   : return RPtr->TCount;
                    break;
      case Unary  : return RPtr->UCount; break;
      case Binary : return RPtr->BCount; break;
      case  Eps   : return RPtr->EpsCount; break;
      default: printf("Err: strange rule type");
               return 0; break;
 } /* switch */
 else return 0;
}
