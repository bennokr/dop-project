extern Boolean HasBeenC; 
/* #define ProbDomain float */
extern TreeCodeT TotalRsNum;
void R_W_Probs();
