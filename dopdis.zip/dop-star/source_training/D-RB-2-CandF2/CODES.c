#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "CodeType.h"     
#include "CodeL.h"
#include "NT_Lists.h"
#include "NT_Rules.h"
#include "NT_Sets.h"
#include "RulesQ.h"
#include "RnoCodes.h"
#include "CODES.h"

RulesLPtr T_List, U_List, B_List, Eps_List;
/*
RulesLPtr T_Roots_List, U_Roots_List, B_Roots_List, Eps_Roots_List;
long int T_R_Size, U_R_Size, B_R_Size, Eps_R_Size;
long int T_Oth_Size, U_Oth_Size, B_Oth_Size, Eps_R_Size;
*/
char CCode[CdChars];
PtrList CCodes = NULL;
/**/
void InitCLists()
{T_List = Cr_CodesL(); U_List = Cr_CodesL(); 
 B_List = Cr_CodesL(); Eps_List = Cr_CodesL();
}
void UpdateCCode(char *STR)
{strcat(CCode, "/");
 strcat(CCode, STR);
 /* printf("%s\n", CCode);*/
}
void UpdateCodes()
{/*char *a;*/
 NodePtr CdP = NULL;
 /* a = (char *) AllocElem(50*sizeof(char)); */
 /* strcpy(a, CCode); if (a[0] != '\0') */
 if (CCode[0] != '\0') 
                   {CdP = FromStrToCode(CCode);
                    CCodes = EnterPO((void *) CdP, CCodes);
                   }
 CCode[0] = '\0';
}

void UpdateRCs(RDomain Rno, enum RType RT, PtrList Codes)
{
 switch (RT) {
    case Term  : T_List = EnR_CodesL(Rno, Codes, T_List);
                break;
    case Unary :
                U_List = EnR_CodesL(Rno, Codes, U_List);
                break;
    case Binary:
                B_List = EnR_CodesL(Rno, Codes, B_List);
                break;
    case Eps   :
                Eps_List = EnR_CodesL(Rno, Codes, Eps_List);
                break;
    default    :
                break;
 }
}
