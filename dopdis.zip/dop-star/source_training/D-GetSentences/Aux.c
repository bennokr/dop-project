#include "Constants.h"
void PRB(double a) { fprintf(fpOUT, "%e", a); }
void PRL(double a) { fprintf(fpOUT, "%lf", a); }
enum boolean {false = 0 , true = 1};
#define Boolean enum boolean
void *MultAlloc(unsigned long int count, int elemsize)
{void *ptr;
 unsigned int i = (unsigned int) count;
 ptr = NULL;
 ptr = (void *) calloc(i, elemsize);
 if (ptr == NULL) printf("%30s\n", "Unable to allocate");
 else;
 return ptr;
}
void PRS(char *a) { fputs(a, fpOUT);}
void *AllocElem(int size)
{void *ptr = NULL;
 ptr = (void *) malloc(size);
 if (ptr == NULL) printf("%30s\n", "Unable to allocate");
 else return ptr;
}
int Max(int a, int b)
{return ((a >= b) ? a : b);
}
int Min(int a, int b)
{return ((a <= b) ? a : b);
}
void yyerror(char *str)
{fprintf(stderr, str); exit(1);
} 
char *TOLOWER(char *a)
{char *new; int j = 0;
 int i = 0;

 new = (char *) AllocElem(SymLength*sizeof(char));
 new[0] = '\0';
 if (a != NULL)
  {while (a[i] != '\0')
    {if (isalpha(a[i])!= 0) {new[j] = (char) tolower((int) a[i]); i++;j++;}
     else {new[j] = a[i]; i++;j++;}}
   new[j] = '\0';
   return new;
  }
 else return NULL;
}
