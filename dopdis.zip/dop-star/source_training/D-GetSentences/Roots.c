/********************/
/* The General Part */
/********************/
void InitRPtr(RootPtr R)
{if (R == NULL) ;
 else {R->Children = NULL;
       R->ChNum = 0;
       strcpy(R->Name,"");
       R->Soort = OtherSym;
       R->depth = 0; 
      }
}
RootPtr FillRPtr(PtrList L, int Chnum, char *N, SoortType So)
{
/* RootPtr New = (RootPtr) AllocElem(sizeof(struct RootNode));*/
 RootPtr New = GetARoot();
 New->Children = L;
 New->ChNum = Chnum;
 strcpy(New->Name, N);
 New->Soort = So;
 New->depth = 0;
 New->allchsnnp = false;
 return New;
}
/*************************/
/* A generator of non-terminal names for ECNF */
int j = 0;
/*************************/
char *NewName(char *Name, int i)
{char *New = (char *) AllocElem(SymLength*sizeof(char));
 char *here = NULL;
 char J[10];

 strcpy(New, Name); 
 here = strchr(New, '_');
 if (here != NULL) {here[0] = '1'; /* in case of terminals */
                    here[1] = '\0';
                   }
 else {i++; sprintf(J, "%d", i); strcat(New, J);}
 return New;
}
/*************************/
/* This Part is for CFG-2-ECNF */
/*************************/
/*************************/
/*************************/
/*************************/
int TreeNum = 0;
int k = 0;
char ThisNonT[SymLength]; 
/***/
void TransPtrList(PtrList P, char *ParentName)
{
 RootPtr NewRP = NULL;
 RootPtr RP = (RootPtr) P->Ptr;
 PtrList NewCh = NULL;
 if (P->Next == NULL) ;
 else {TransPtrList(P->Next, ParentName);
       NewCh = EnStack(P->Next->Ptr, NewCh); 
       NewCh = EnStack(P->Ptr, NewCh);     
  /* NewCh = EnterP(P->Ptr, NewCh); NewCh = EnterP(P->Next->Ptr, NewCh); */
   /* For obtaining structures that allow various levels of
                Names such as S4 S3 S2 S1 to avoid S1->S1 
                if later one wants to cut the empty category 
       if (ThisNonT[0] == '\0') 
            {k++; strcpy(ThisNonT, ((RootPtr) P->Ptr)->Name);}
       else if (strcmp(ThisNonT, ((RootPtr) P->Ptr)->Name) != 0) 
              {k++; strcpy(ThisNonT, ((RootPtr) P->Ptr)->Name);}
            else ; */

       P->Ptr = (void *) FillRPtr(NewCh, 2, 
                                  (NewName(ParentName, k)), Nonterminal);
                                  /* (NewName(RP->Name, k)), Nonterminal);*/
       FreePListN(P->Next);
       P->Next = NULL;
      }
}
void TransBigRules(RootPtr RP, int i)
{ PtrList This = (RP->Children)->Next;
  k = i;
  ThisNonT[0] = '\0';
  TransPtrList(This, RP->Name); if (k > j) j = k-1;
  k = 0;
}
/*************************/
/*
void ShowChild(PtrList Child)
{RootPtr RP;
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       PRS(RP->Name);
      }
}
int count = 1;
void ShowUnder(PtrList Child)
{RootPtr RP;
 count++;
 if ((count % 5) == 0) PRS("\n");
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       ShowRPtrs(RP); if (Child->Next != NULL) PRS(",");
      }
}
void ShowRPtrs(RootPtr RP)
{if (RP == NULL) PRS("NULL\n");
 else {PRS("tree(");PRS(RP->Name);PRS(",");
       PRS("[");
       PListMap(RP->Children, (void *) &ShowUnder);
       PRS("])");
      }
}
*******************************/
void CountList(PtrList L)
{while (L != NULL) {TreeNum++; L=L->Next;}
} 
void CountRules(PtrList *AR)
{int i;
 for (i=0; i < 26; i++) PListMap(AR[i], (void *) &CountList);
}
/******************************/
