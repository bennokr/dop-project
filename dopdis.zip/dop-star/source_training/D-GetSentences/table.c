Boolean IsOriginal(char *Name)
{int i=0;
 while ((isdigit(Name[i])) == 0) 
   {i++; if (Name[i] == '\0') return true;}
   return false; 
}
Boolean IsOrigSym(RootPtr RP)
{if (RP->Soort == Terminal) return true;
 else return (IsOriginal(RP->Name));
}
