#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "ctype.h"
#include "math.h"
/*****************/                                                                                                                            
/*****************/
int Num_of_Unknowns = 0;
int NumOfWs = 0;
int NumOfTrees = 0;
FILE *fpOUT, *fpIN;
char *StartNonT;
int Depth = 1;
/*****************/
#include "Aux.c"
#include "Constants.h"
#include "PtrList.h"
#include "Roots.h"
#include "AllocRoots.h"
#include "Rules.h"
/* #include "HashTable.h" */
/****************/
#include "Rules.c"
#include "Freeing.c"
#include "AllocRoots.c"
/* #include "HashTable.c" */
#include "Roots.c"
#include "Show.c"
#include "y.tab.c"
#include "lex.yy.c"
extern void TRANS();
extern FILE *fopen();


Boolean _show_postag = false;

extern int optind, opterr;     
int main(argc, argv)
int argc;
char *argv[];
{char* options = "P"; /* set your choices here */
 char  opt_ch; int error_flag = 0;
 
 opt_ch = getopt( argc, argv, options );

 while ( opt_ch != -1 )
   {switch( opt_ch ) {                                                                                                                             
       case 'P': _show_postag = true; break;
    }
    opt_ch = getopt( argc, argv, options );      
   }

   fpOUT = stdout; fpIN = stdin;                        

        /* case file names without -i and -o */
   if ( argc - optind > 0 )
    if (fpIN == stdin)
     {if (argv[optind][0] != '-')
       {fpIN = fopen( argv[optind], "r" );
        if ( !fpIN )
         {fprintf( stderr, "File <%s> does not exist\n", argv[optind] ); exit( 1 );}
       }
      else error_flag++;
     }
    else /* input file read */
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
   if ( argc - ++optind > 0 )
    if (fpOUT == stdout)
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
    else error_flag++;
   else error_flag++;
 
         /* In case of error  */
   if ( error_flag )
   {char* basename = strrchr( argv[0], '/' );
 
    if ( basename ) basename++;
    else basename = argv[0];
    exit( 1 );
   }
 
  TRANS();
 
 return 0;
}
/**********************/
                  /* MaxDepth = i>0 means all subtrees*/
                  /* of depth 0 < j <= i              */
void TRANS()
{int i;
 AllocDMEM();
 yyparse(); 
 /* fprintf(stderr,"Total number of unknown words is: %d\n", Num_of_Unknowns);
 fprintf(stderr,"Total number of words is: %d\n", NumOfWs);
 fprintf(stderr,"Total number of sentences is: %d\n", NumOfTrees);
 */
}
