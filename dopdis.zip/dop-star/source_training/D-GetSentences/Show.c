extern Boolean _show_postag;

void ShowRPtr1(RootPtr RP);
void ShowChild(PtrList Child)
{RootPtr RP;
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       PRS(RP->Name);
      }
}
int count = 1;
void ShowUnder(PtrList Child)
{RootPtr RP;
 count++;
 RP = (RootPtr) Child->Ptr;
 ShowRPtr1(RP); 
}
void ShowRPtr1(RootPtr RP)
{
 if (RP == NULL) PRS("NULL\n");
 else 
 if (RP->Children == NULL) ; 
 else if (RP->Soort == POSTAG) 
         { if (_show_postag == true) {PRS("[ ");PRS(RP->Name); PRS(" "); } PRS(((RootPtr) RP->Children->Ptr)->Name); if (_show_postag == true)  PRS(" ]"); PRS(" ");}
      else PListMap(RP->Children, (void *) &ShowUnder);
}
void ShowRPtr(RootPtr RP)
{int i;
 fprintf(fpOUT, "SENTENCE: "); ShowRPtr1(RP);
}
/****************************************/
void ShowRPtrs(RootPtr RP);
void ShowUnder2(PtrList Child)
{RootPtr RP;
 count++;
 /* if ((count % 5) == 0) PRS("\n");*/
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       ShowRPtrs(RP); if (Child->Next != NULL) PRS(",");
      }
}
void ShowRPtrs(RootPtr RP)
{if (RP == NULL) PRS("NULL\n");
 else {PRS("(");PRS(RP->Name);PRS(",");
       PRS("[");
       PListMap(RP->Children, (void *) &ShowUnder2);
       PRS("])");
      }
}
void ShowRPtrss(RootPtr RP)
{ShowRPtrs(RP);PRS(".\n");
}
