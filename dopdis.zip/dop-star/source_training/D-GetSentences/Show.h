void ShowRPtrss(RootPtr RP) ;
