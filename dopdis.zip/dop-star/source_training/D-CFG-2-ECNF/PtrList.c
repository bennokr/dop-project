#include "Universals.h"
#include "Constants.h"
#include "Aux.h"
#include "PtrList.h"

PtrList CrPList()
{return NULL;}
/***********/
PtrList NewPtr(void *Ptr)
{PtrList IDL = (PtrList) AllocElem(sizeof(struct PtrLStr));
 IDL->Next = NULL;
 IDL->Ptr = Ptr;
 return IDL;
}
/***********/
void PListMap(PtrList L, void (* fp)())
{PtrList This = L;
 while(This != NULL) {(*fp)(This);
                       This = This->Next;
                     }
}
/***********/
void PListMapV(PtrList L, void (* fp)())
{PtrList This = L;
 while(This != NULL) {(*fp)(This->Ptr);
                       This = This->Next;
                     }
}
/***************************************/
void FreePListN(PtrList L)
{PtrList Head = L;
 PtrList Prev = L;
 while (Head != NULL) { Prev = Head; Head = Head->Next; free(Prev); }
}
void FreePList(PtrList L)
{PtrList Head = L;
 PtrList Prev;
 while (Head != NULL) { Prev = Head; Head = Head->Next; free(Prev->Ptr); free(Prev); }
}
/***********/
/* Queue */
PtrList EnterP(void *Ptra, PtrList L)
{PtrList this = L;
 PtrList Last = NULL;
 PtrList New = NewPtr(Ptra);
 
 while (this != NULL) {Last = this; this = this->Next;}
 if (Last != NULL) {Last->Next = New; return L;}
 else return New;
}
/***********/
PtrList EntList(PtrList S, PtrList T)
{PtrList Last = NULL; PtrList This = T;
 if (S == NULL) return T;
 else if (T == NULL) return S;
      else {while (This != NULL) {Last = This; This = This->Next;}
            Last->Next = S;
            return T;
           }
}
/****************/
PtrList EnStack(void *P, PtrList L)
{PtrList L1 = NewPtr(P);
 L1->Next = L;
 return L1;
}
/********************************************************/
/***********/
void EqTrees(void *a, void *b, Boolean *EQ)
{char *A = (char *) a;
 char *B = (char *) b;
 *EQ = (!strcmp(A,B)) ? true : false;
}
/******************
ST(P1,P2) returns true- If P2 is smaller than P1  Else false-.
StackOrdered adds PTC to List such that the largest element is first
and the smallest is last. 
**/
PtrList StackOrdered(void *PTC, PtrList List, Boolean (* ST)())
{PtrList This; PtrList temp = List; Boolean Stop = false; PtrList Prev = NULL;
 if (List == NULL) return (EnStack(PTC,List));
 else
   {while ((temp->Next != NULL) && (Stop == false))
     if (((* ST)(temp->Next->Ptr, PTC)) == true) {Prev = temp; temp = temp->Next;}
     else Stop = true;
    if (((* ST)(temp->Ptr, PTC)) == true) 
      {This = NewPtr(PTC);This->Next = temp->Next; temp->Next = This;}
    else if (Prev != NULL) {This = NewPtr(PTC); This->Next = Prev->Next; Prev->Next = This;}
         else {This = NewPtr(PTC); This->Next = temp; List = This;}
    return List;
   }
}
/************/
/* if not found then it is stacked */
PtrList EnterSet(void *Ptra, PtrList L, void (* Eq)())
{PtrList this = L;
 PtrList Last = NULL;
 PtrList New;
 Boolean Found = false;

 while ((this != NULL) && (Found != true))
       {Last = this;
        Eq(Ptra, Last->Ptr, &Found);
        this = this->Next;}
 if (Found == true) return L;
 else {New = NewPtr(Ptra);
       if (Last != NULL) {Last->Next = New; return L;}
       else return New;}
}
/***********/
PtrList FindPtr(void *Ptra, PtrList L, void (* Eq)())
{PtrList this = L;
 PtrList Last = NULL;
 Boolean Found = false;

 while ((this != NULL) && (Found != true))
       {Last = this;
        Eq(Ptra, Last->Ptr, &Found);
        this = this->Next;}
 if (Found == true) return Last;
 else return NULL;
}
/***********/
/* Unites two sets T and S */
/* If both are not empty then all items of T which are not in S
   are added into S (stacking) which is the result of the union */
/* THIS adds elements of STACK T on STACK S making set (STACK) */
PtrList EntSetLs(PtrList T, PtrList S, void (* Eq)())
{PtrList Last = NULL;
 PtrList This = T;
 PtrList Res = NULL;
 if (S == NULL) return T;
 else if (T == NULL) return S;
      else {Res = S;
            while (This != NULL) {Last = This; 
                                  Res = 
                                  EnterSet(Last->Ptr, Res, (void *) &EqTrees);
                                  This = This->Next;}
            return Res;
           }
}
/**************************/
PtrList RemoveIfNULL(PtrList PL)
{PtrList Next = PL;
 if (PL != NULL) 
   {PL->Next = RemoveIfNULL(PL->Next);
    if (PL->Ptr == NULL) {Next = PL->Next; free(PL);}
    return Next;
   }
 else return PL;
}
/******/
PtrList CopyList(PtrList Original)
{PtrList Copy = NULL;
   void CopyPtr(void *Ptr)
    {Copy = EnStack(Ptr, Copy);}

 if (Original != NULL) PListMapV(Original, (void *) CopyPtr);
 return Copy;
}
/*********/
PtrList MakeSetOfList(PtrList P, void (* Eq)())
{PtrList New = NULL;
  void EnterToNew(void *element)
   {New = EnterSet(element, New, Eq);}
 if (P == NULL) return P;
 PListMapV(P, (void *) &EnterToNew);
 return New;
}
