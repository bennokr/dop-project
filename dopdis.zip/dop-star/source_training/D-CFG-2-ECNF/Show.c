char PROB[15] = "";
void ShowChild(PtrList Child)
{RootPtr RP;
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       PRS(RP->Name);
      }
}
int count = 1;
void ShowRPtrs(RootPtr RP);
void ShowUnder(PtrList Child)
{RootPtr RP;
 count++;
 /* if ((count % 5) == 0) PRS("\n");*/
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       ShowRPtrs(RP); if (Child->Next != NULL) PRS(",");
      }
}
void ShowRPtrs(RootPtr RP)
{if (RP == NULL) PRS("NULL\n");
 else {PRS("(");PRS(RP->Name);PRS(",");
       PRS("[");
       PListMap(RP->Children, (void *) &ShowUnder);
       PRS("])");
      }
}
void ShowRPtrss(RootPtr RP)
{ShowRPtrs(RP);PRS(".\n");
}
void ShowRPtr(RootPtr RP)
{if (RP == NULL) ;/* PRS("NULL\n");*/
 else if (RP->ChNum != 0)
      {PRS("(");PRS(RP->Name);PRS(",");
       PRS("[");
       PListMap(RP->Children, (void *) &ShowUnder);
       if (ProbYes == true)
         {PRS("],");PRS(PROB);PRS(").\n");}
       else 
         {PRS("]");PRS(").\n");}
      }
}
/******************************/
