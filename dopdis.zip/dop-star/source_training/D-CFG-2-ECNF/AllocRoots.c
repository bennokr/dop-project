/***************************/
void FlushDMEMAll()
{int i;
 for (i=0; i < MaxMemUse; i++) {FreeRPtrThis((RootPtr) (DMEM->ThisPtr+i)); 
                                       InitRPtr((RootPtr) (DMEM->ThisPtr+i));    }
}
void InitDMEM()
{int i; for (i=0; i < MaxMemUse; i++) InitRPtr((RootPtr) (DMEM->ThisPtr+i));}
/****/
void AllocDMEM()
{DMEM = (struct DirectMem *) AllocElem(sizeof(struct DirectMem));
 DMEM->ThisPtr = (struct RootNode *) MultAlloc(MaxMemUse,sizeof(struct RootNode));
 DMEM->First = DMEM->ThisPtr;
 DMEM->numofav = MaxMemUse; 
 InitDMEM();
}
/********/
RootPtr GetARoot()
{if (DMEM == NULL) AllocDMEM();
 if (DMEM->numofav == 0) 
         {printf("Can't Allocate: Please Enlarge MaxMemUse value\n");
          exit(1);
         }
 else {DMEM->numofav = DMEM->numofav - 1; 
       DMEM->ThisPtr = DMEM->ThisPtr + 1;
       return ((RootPtr) (DMEM->ThisPtr));
      }
}
/*********/
void FreeAllRoots()
{DMEM->numofav = MaxMemUse; 
 DMEM->ThisPtr = DMEM->First; 
 FlushDMEMAll(); 
}
