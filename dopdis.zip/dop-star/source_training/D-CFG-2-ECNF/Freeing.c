/*
void FreeRPtr(RootPtr RP)
{ if (RP!=NULL) 
  {if (RP->ChNum >= 1) FreeRPtr((RootPtr) RP->Children->Ptr);
   if (RP->ChNum == 2) FreeRPtr((RootPtr) RP->Children->Next->Ptr);
   FreePListN((PtrList) RP->Children);
   * free(RP); look at MemUse*
  }
}
*/
void FreeRPtr(RootPtr RP)
{PtrList temp;
  if (RP!=NULL) 
    {temp = (PtrList) RP->Children;
     while (temp != NULL)
         {FreeRPtr((RootPtr) temp->Ptr); temp = temp->Next;}
     FreePListN((PtrList) RP->Children); RP->Children = NULL;
    }
}
void FreeRPtrThis(RootPtr RP)
{if (RP!=NULL)
    {FreePListN(RP->Children);
     RP->Children = NULL;
    }
}
