extern Boolean _global_diff ;
#define _continuous false

/********************/
/* The General Part */
/********************/
void InitRPtr(RootPtr R)
{if (R == NULL) ;
 else {R->Children = NULL;
       R->ChNum = 0;
       strcpy(R->Name,"");
       R->Soort = OtherSym;
       R->depth = 0; 
      }
}
RootPtr FillRPtr(PtrList L, int Chnum, char *N, SoortType So)
{
/* RootPtr New = (RootPtr) AllocElem(sizeof(struct RootNode));*/
 RootPtr New = GetARoot();
 New->Children = L;
 New->ChNum = Chnum;
 if (strlen(N) >= SymLength) 
      {fprintf(stderr, "Please enlarge SymLength in Constants.c to %d\n", (strlen(N))); exit(1);}
 strcpy(New->Name, N);
 New->Soort = So;
 New->depth = 0;
 New->allchsnnp = false;
 return New;
}
/*************************/
/* A generator of non-terminal names for ECNF */
int j = 0;
/*************************/
int counter =0;

Boolean ContainsECNFSym(char *Name)
{char *here = NULL;
 here = strchr(Name, _ECNF_SYM); if (here != NULL) return true; else return false;
}
char *NewNameOrig(char *Name)
{char TEMP[SymLength]; static char New[SymLength];
 /* = (char *) AllocElem(SymLength*sizeof(char)); */
 char *here = NULL;

 strcpy(New, Name); here = strchr(New, '_');
 if (here != NULL) {here[0] = _ECNF_SYM; /* in case of terminals */
                    here[1] = '\0';
                   }
 else {if (New[strlen(New) -1] == '@') New[strlen(New)-1] = '\0';
       TEMP[0] = _ECNF_SYM; TEMP[1] = '\0'; 
       strcat(New, TEMP);
      }
 return New;
}
char *NewName(char *Name)
{char *here; char TEMP[10]; static char *New;
 New = NewNameOrig(Name); 
 if (_global_diff==true) {
 counter++;
 sprintf(TEMP, "%d", counter); 
 
 here = strchr(New,_ECNF_SYM); here[0]='\0';
 strcat(New, TEMP); strcat(New,"@");
 }
 return New;
}
/*************************/
/* This Part is for CFG-2-ECNF */
/*************************/
/*************************/
/*************************/
/*************************/
/*-----------------------*/
void TransDBLRecRules(RootPtr RP)
{RootPtr FstCh; RootPtr SkndCh; PtrList temp; RootPtr NewSkndCh;
 if (RP->ChNum == 2) {
   FstCh = (RootPtr) RP->Children->Ptr;
   SkndCh = (RootPtr) RP->Children->Next->Ptr;
   if ((!strcmp(FstCh->Name, SkndCh->Name)) && (!strcmp(FstCh->Name, RP->Name))) 
     { /* found a rule XP -> XP XP : we make it XP-> XP (XP@->XP)  */
      temp = RP->Children->Next; /* hold the second child */
      NewSkndCh = FillRPtr(temp, 1, (NewName(RP->Name)), Nonterminal); /*make SkndCh only child of NewSkndCh*/
      RP->Children->Next = EnStack((void *) NewSkndCh, NULL);  /* add new second child to RPs children */
     }
 }
}
/*-----------------------*/
PtrList TransPtrList(PtrList P, char *ParentName)
{PtrList REST = NULL; RootPtr RP = NULL; PtrList NewChildren = NULL;
 if (P->Next == NULL) 
    {if (_continuous == true)
     {NewChildren = EnStack(P->Ptr, NewChildren);
      P->Ptr = (void *) FillRPtr(NewChildren, 1, (NewName(ParentName)), Nonterminal);
     }
     return P;
    }
 else {NewChildren = TransPtrList(P->Next, ParentName);
       NewChildren = EnStack((void *) P->Ptr, NewChildren); 
       P->Ptr = (void *) FillRPtr(NewChildren, 2, (NewName(ParentName)), Nonterminal);
       /* FreePListN(P->Next); */
       P->Next = NULL;
       return P;
      }
}
/*-----------------------*/
void TransBigRules(RootPtr RP)
{PtrList This = (RP->Children)->Next;
 /* if (RP->ChNum == 2) TransDBLRecRules(RP); else */
 if (RP->ChNum > 2) RP->Children->Next = TransPtrList(This, RP->Name); 
}
/*-----------------------*/
RootPtr TransRule(RootPtr RP)
{
         /* Rules A -> a B */
      void Terms2rules(PtrList Child)
	{RootPtr NewRP = NULL; PtrList NewCh = NULL;
 	 RootPtr RPi = (RootPtr) Child->Ptr;
 	 if (RPi->Soort == Terminal) 
  	  {NewCh = EnterP((void *) RPi, NewCh);
           NewRP = FillRPtr(NewCh, 1, (NewName(RPi->Name)), Nonterminal);
   	  FreeRPtr((RootPtr) Child->Ptr);
   	  Child->Ptr = (void *) NewRP;
         }
	}
 PListMap(RP->Children, (void *) &Terms2rules); /* dealing with Rules A -> a B */

 if (RP->ChNum >= 2) TransBigRules(RP);
 return RP;
}
/*-----------------------*/
void TransChild(PtrList Child)
{RootPtr RPi = (RootPtr) Child->Ptr;
 Child->Ptr = (void *) Transform2ECNF(RPi);
}
/*-----------------------*/
RootPtr Transform2ECNF(RootPtr RP)
{if (RP == NULL) return NULL;
 else {
       PListMap(RP->Children, (void *) &TransChild);
       if (RP->ChNum > 1)  RP = TransRule(RP);
       return RP; 
      }
}
/****************************************************************************************************/
/*
void ShowChild(PtrList Child)
{RootPtr RP;
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       PRS(RP->Name);
      }
}
int count = 1;
void ShowUnder(PtrList Child)
{RootPtr RP;
 count++;
 if ((count % 5) == 0) PRS("\n");
 if (Child == NULL) PRS("NULLCH ");
 else {RP = (RootPtr) Child->Ptr;
       ShowRPtrs(RP); if (Child->Next != NULL) PRS(",");
      }
}
void ShowRPtrs(RootPtr RP)
{if (RP == NULL) PRS("NULL\n");
 else {PRS("(");PRS(RP->Name);PRS(",");
       PRS("[");
       PListMap(RP->Children, (void *) &ShowUnder);
       PRS("])");
      }
}
*******************************/
void CountList(PtrList L)
{while (L != NULL) {L=L->Next;}
} 
void CountRules(PtrList *AR)
{int i;
 for (i=0; i < 26; i++) PListMap(AR[i], (void *) &CountList);
}
/******************************/
