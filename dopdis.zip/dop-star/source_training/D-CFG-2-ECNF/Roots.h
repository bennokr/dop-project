/* #define SymLength 30 */
enum SType {Terminal=0,Nonterminal=1,OtherSym=2};
#define SoortType enum SType
struct RootNode {
    PtrList Children;
    unsigned short ChNum;
    char Name[SymLength];
    SoortType Soort; 
    unsigned short int depth;
    Boolean allchsnnp;
};
typedef struct RootNode *RootPtr;
typedef struct RootNode ROOTNODE;
void InitRPtr(RootPtr R);
void ShowChild(PtrList Child);
void ShowUnder(PtrList Child);
void ShowRPtr(RootPtr RP);
RootPtr Transform2ECNF(RootPtr RP);
void TransChild(PtrList Child);
RootPtr TransRule(RootPtr RP);
