/* PtrList AllRules[26] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL}; */
struct RuleStr {
    char Rule[MaxRule];
    short int j;
};
typedef struct RuleStr *RulePtr;
/***********************/

