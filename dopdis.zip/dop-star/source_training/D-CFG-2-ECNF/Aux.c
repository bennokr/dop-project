void PRSNL() {/* printf("*"); fflush(BufStdout); */
              fputc('\n', fpOUT);
             } 
void PRS(char *a) {int x = fprintf(fpOUT, "%s", a);}
void STDERR(char *a) {int x = fprintf(stderr, "%s", a);}

void *AllocElem(int size)
{void *ptr = NULL;
 ptr = (void *) malloc(size);
 if (ptr == NULL) {fprintf(stderr,"%30s\n", "Unable to allocate");exit(1);}
 else return ptr;
}
void *MultAlloc(size_t count, size_t elemsize)
{void *ptr;
 ptr = NULL;
 ptr = (void *) calloc(count, elemsize);
 if (ptr == NULL) {STDERR("Unable to allocate");exit(1);}
 else return ptr;
}

void PRI(long int a) { fprintf(fpOUT, "%ld ", a); }
void PRC(char *a) { fprintf(fpOUT,"%s", a); }
void PRBF(float a) {fprintf(fpOUT, "%e ", a);}
void PRBS(double a) {fprintf(fpOUT, "%f ", (float) a);}
double POWER(double a)
{return ((double) pow((double) 10.0, (double) a));}
void PRB(ProbDomain a) {/* fprintf(fpOUT, "%12.16e ", ( a)); */
                        fprintf(fpOUT, "%6.6e ", (POWER((double) a))); 
                        }
void PRBM(float a) {fprintf(fpOUT, "%f\n", a);}
/**********/
/* writes out the log10 of a double */
void PRBLOGof(double a) {
  if (a>0) fprintf(fpOUT, "%e ",  log10(a));
  else {printf("Log problem "); printf("%e\n", a);}
}                                                        
/***********/
/*void WRITE(char *a) {fputs(a, fpOUT);}*/
void WRITE(char *a) {PRS(a);}

char *TOLOWER(char *a)
{char *new; int j = 0; int i = 0;

 new = (char *) AllocElem(SymLength*sizeof(char));
 new[0] = '\0';
 if (a != NULL)
  {while (a[i] != '\0')
    {if (isalpha(a[i])!= 0) {new[j] = (char) tolower((int) a[i]); i++;j++;}
     else {new[j] = a[i]; i++;j++;}
    }
   new[j] = '\0';
   return new;
  }
 else return NULL;
}

void yyerror(char *str)
{fprintf(stderr, str); exit(1);
}
Boolean EQ_Strings(char *str1, char *str2)
{if ((str1 == NULL) && (str2 == NULL)) return true;
	 if (!strcmp(str1, str2)) return true;
	  return false;
}

