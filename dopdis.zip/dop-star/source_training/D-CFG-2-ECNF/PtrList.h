struct PtrLStr {
       void  *Ptr;
       struct PtrLStr *Next;
};
typedef struct PtrLStr *PtrList;
/********************/
PtrList NewPtr(void *Ptr);
/************************** The observed functions are ***/
PtrList CrPList();
PtrList EnterP(void *Ptr, PtrList L);
void PListMap(PtrList L, void (* fp)());
/*************/
void PListMapV(PtrList L, void (* fp)());
/***************************************/
void FreePListN(PtrList L);
void FreePList(PtrList L);
/***********/
/* Queue */
PtrList EnterP(void *Ptra, PtrList L);
/***********/
PtrList EntList(PtrList S, PtrList T);
/****************/
PtrList EnStack(void *P, PtrList L);
/********************************************************/
PtrList EnterSet(void *Ptra, PtrList L, void (* Eq)());
PtrList FindPtr(void *Ptra, PtrList L, void (* Eq)());
/***********/
/* Unites two sets T and S */
/* If both are not empty then all items of T which are not in S
   are added into S (stacking) which is the result of the union */
/* THIS adds elements of STACK T on STACK S making set (STACK) */
PtrList EntSetLs(PtrList T, PtrList S, void (* Eq)());
/**************************/
PtrList RemoveIfNULL(PtrList PL);
PtrList StackOrdered(void *PTC, PtrList List, Boolean (* ST)());

#define  PDListMap( A, B )     PListMapV(A,B)

#ifndef EnterPStack
#define EnterPStack EnStack
#endif

#ifndef EnterQueue
#define EnterQueue EnterP
#endif
