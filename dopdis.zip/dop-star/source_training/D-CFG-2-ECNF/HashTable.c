int Mod(int x, int y)
{return ((int) (fmod((double) x,(double) y)));
}
/******************************/
void InitHT()
{int i; for (i=0; i < Maxvalue; i++) AllRules[i] = NULL; }
/****************************/
int BucketOf(RulePtr RU)
{int R = Rule2Int(RU->Rule);
 if (R < 0) return -1;
 else return (Mod(R, Maxvalue));}
/****************************/
void ENTRule(RootPtr RP, int j)
{int place;
 RulePtr New = RPtr2Rule(RP, j);
 place = BucketOf(New);
 if (place >= 0) AllRules[place] = EnterP((void *) New, AllRules[place]);
}
/****************************/
int FindRule(RootPtr RP)
{int place;
 int result;
 RulePtr ThisR;
          void CMPRRule(PtrList R)
           {RulePtr AR = (RulePtr) R->Ptr;
            if (!strcmp(ThisR->Rule, AR->Rule)) result = AR->j;
           }
 result = -1;
 ThisR = RPtr2Rule(RP, 0);
 place = BucketOf(ThisR);
 if (place >= 0) PListMap(AllRules[place], (void *) &CMPRRule);
 FreeRule(ThisR);
 return result;
}
/**************/
