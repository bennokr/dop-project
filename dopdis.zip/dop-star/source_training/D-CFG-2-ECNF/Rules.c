/*********************/
/* free the unnecessary like you did in SUB-2-RBSTSG case*/
/* consider FindRule, RPtr2Rule and such. */
/*********************/
void FreeRule(RulePtr RP)
{if (RP != NULL) free(RP);
}
RulePtr NewRule(char *Contents, short int j)
{RulePtr New = (RulePtr) AllocElem(sizeof(struct RuleStr));
 strcpy(New->Rule, Contents);
 New->j = j;
 return New;
}

RulePtr RPtr2Rule(RootPtr RP, short int j)
{RulePtr New;
 char ThisCh[SymLength];
    void CpyChName(PtrList CH)
       {RootPtr Rch = (RootPtr) CH->Ptr;
        /* if (ThisCh[0] == '\0') strcpy(ThisCh, Rch->Name); REC 
        else if (!strcmp(ThisCh,Rch->Name));                 REC 
             else {*/
         strcat(New->Rule, "-");
         strcat(New->Rule, Rch->Name);      
        /* strcpy(ThisCh, Rch->Name);}             REC */
                  
       }
 ThisCh[0] = '\0';
 New = NewRule(RP->Name, j);
 PListMap(RP->Children, (void *) &CpyChName);
 return New;
}
/****************************
void ENTRule(RootPtr RP, short int j)
{int place = RP->Name[0]-'a';
 RulePtr New = RPtr2Rule(RP, j);
 AllRules[place] = EnterP((void *) New, AllRules[place]);
}
****************************
int FindRule(RootPtr RP)
{int place;
 short int result;
 RulePtr ThisR;
          void CMPRRule(PtrList R)
           {RulePtr AR = (RulePtr) R->Ptr;
            if (!strcmp(ThisR->Rule, AR->Rule)) result = AR->j;
           }
 result = -1;
 place = RP->Name[0]-'a';
 ThisR = RPtr2Rule(RP, 0);
 PListMap(AllRules[place], (void *) &CMPRRule);
 return result;
}
*****/
int Rule2Int(char *str)
{int sum = 0;
 int i =1;
 char *This = str;
 if (This == NULL) return -1;
 else if (This[0] == '\0') return -1;
      else
 do {
   sum = sum + ((int) This[0] * i); This = This+1;
 } while (This[0] != '\0');
 return sum;
}
