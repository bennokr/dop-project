#define Maxvalue 10001
PtrList AllRules[Maxvalue];
/***********************/
