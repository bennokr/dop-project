#include <ctype.h>
#define MaxMemUse 3000
struct DirectMem {
  struct RootNode *ThisPtr;
  struct RootNode *First;
  long int numofav; 
};
struct DirectMem *DMEM;
void InitDMEM();
void AllocDMEM();
RootPtr GetARoot();
void FreeAllRoots();
