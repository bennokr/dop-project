#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"
/*****************/
FILE *fpOUT, *fpIN;
char BufStdout[1];
#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "PtrList.h"
#include "Aux.c"
/****************/
int Num_of_Unknowns = 0;
Boolean ProbYes;
#include "Roots.h"
#include "AllocRoots.h"
#include "Rules.h"
#include "Freeing.c"
#include "Rules.c"
#include "HashTable.h"
#include "HashTable.c"
#include "Show.c"
#include "AllocRoots.c"
#include "Roots.c"
#include "y.tab.c"
#include "lex.yy.c"

#define SUBTRANSFORM_ECNF "SubCFG2ECNF"
#define TRANSFORM_ECNF "TreeCFG2ECNF"
#define REMOVE_UNARIES "Remove_Unaries"

extern void TRANS();
extern void USAGE();
Boolean _global_diff = false;
Boolean _remove_unaries = false;

int main(argc, argv, envp)
int argc;
char **argv, **envp;
{char* options = "Ui:o:"; /* set your choices here */
 char  opt_ch; int error_flag = 0;
 FILE *fopen();

 fpOUT = stdout; fpIN = stdin;

 opt_ch = getopt( argc, argv, options );
 while ( opt_ch != -1 )
   {switch( opt_ch ) {
     case 'U' : _global_diff = true; break;
     case 'i' : if ((fpIN = fopen(optarg, "r")) == NULL) printf("Can't open %s\n", *argv); break;
     case 'o' : if ((fpOUT = fopen(optarg, "w")) == NULL) printf("Can't open %s\n", *argv); break;
     case '?' : error_flag++; break;
    }
    opt_ch = getopt( argc, argv, options );
   }
        /* case file names without -i and -o */
   if ( argc - optind > 0 )
    if (fpIN == stdin)
     {if (argv[optind][0] != '-')
       {fpIN = fopen( argv[optind], "r" );
        if ( !fpIN )
         {fprintf( stderr, "File <%s> does not exist\n", argv[optind] ); exit( 1 );}
       }
      else error_flag++;
     }
    else /* input file read */
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
   if ( argc - ++optind > 0 )
    if (fpOUT == stdout)
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
    else error_flag++;
   else error_flag++;

         /* In case of error  */
   {char* basename = strrchr( argv[0], '/' );

    if ( basename ) basename++;
    else basename = argv[0];

    if (EQ_Strings(basename,TRANSFORM_ECNF)==true)  _remove_unaries =false; 
     else if (EQ_Strings(basename,SUBTRANSFORM_ECNF)==true)  _remove_unaries =false; 
          else if (EQ_Strings(basename,REMOVE_UNARIES)==true)  _remove_unaries =true; 

   if ( error_flag ) {USAGE(); exit( 1 );}
   }
 TRANS();
}
/**********************/
void TRANS()
{
 InitHT();
 AllocDMEM();
/*  BufStdout[0] = '\0'; setbuf(stdout, BufStdout);*/ /* fclose(stdout);*/
 yyparse();
}
void USAGE()
{
}

