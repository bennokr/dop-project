enum boolean {false = 0 , true = 1};
#define Boolean enum boolean

void *AllocElem(int size);
void *MultAlloc(size_t count, size_t elemsize);
void yyerror(char *str);
