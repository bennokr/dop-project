/*
   cfgtree.h: created October 17, 1995 15:44:42
   Wilco van Hoogstraeten.

   $Id$
 */

#ifndef CFGTREE_H
#define CFGTREE_H

#include <stdio.h>

#define MAX_CHILDREN	50
#define MAX_TAG_LEN	256

struct cfgnode
{
   char*            tag;
   unsigned short   no_of_children;
   struct cfgnode** children;
};

typedef struct cfgnode  CFGNODE;

struct cfgtree
{
   CFGNODE* root;
   double   freq;
};

typedef struct cfgtree  CFGTREE;

double	read_cfg( FILE* stream, CFGTREE *tree );
void	write_cfg( FILE* stream, CFGTREE *tree );
void	decode_cfg( FILE* stream, CFGTREE *tree );
void	code_cfg( FILE* stream, CFGTREE *tree, double prob );
void	write_cfg_with_freq( FILE* stream, CFGTREE* tree );
void	decode_cfg_with_freq( FILE* stream, CFGTREE *tree );

#endif  
