/*
   cfgtree.c: created October 17, 1995 15:44:42
   Wilco van Hoogstraeten.
 */

static const char rcsid[] =
   "$Id$";

#include <assert.h>
#include <ctype.h>
#include <string.h>
#include "tnew.h"
#include "Constants.h"
#include "cfgtree.h"

Boolean CharInSymbol(char ch)
{if (isalnum(ch) || (ch == '%') || (ch == '_') || (ch == '-') || (ch == _ECNF_SYM)) return true;
 else return false;
}  

char* tstrdup( const char* s )
{
   char* d;

   d = tnewn( strlen(s) + 1, char );
   strcpy( d, s );
   return( d );
}

CFGNODE* read_cfgnodes( FILE* stream )
{
   CFGNODE* node = NULL, *children[MAX_CHILDREN];
   char ch, buf[MAX_TAG_LEN+1];
   int i = 0; Boolean R_TREE = false; Boolean ENTER = true;

   ch = getc( stream );
   if ( ch == 't' ) R_TREE = true;
   else if (ch == '(') R_TREE = false;
        else ENTER = false;

   if (ENTER == true)
   {int FOUND = 0; CFGNODE* child;

      if (R_TREE) fscanf( stream, "ree(" );
 
      ch = getc( stream );
     while ( ch != ',' )
      {
	 buf[i++] = ch;
	 ch = getc( stream );
      }
      buf[i] = '\0';
      assert( getc(stream) == '[' );
      node = tnew( CFGNODE );
      node->no_of_children = 0;
      node->tag = tstrdup( buf );
      child = read_cfgnodes( stream );
      i = 0;
      while ( child )
      {
	 node->no_of_children++;
	 children[i++] = child;
	 ch = getc( stream );
	 if ( ch == ',' )
	    child = read_cfgnodes( stream );
	 else
	 {
	    ungetc( ch, stream );
	    child = NULL;
	 }
      }
      if ( i )
      {
	 int j;

	 node->children = tnewn( node->no_of_children, CFGNODE* );
	 for ( j = 0; j < i; j++ )
	    node->children[j] = children[j];
      }
      assert( getc(stream) == ']' );
      if ((ch = getc(stream)) != ')' ) ungetc(ch, stream);
   }
   else
      ungetc( ch, stream );
   return( node );
}

void write_cfgnodes( FILE* stream, CFGNODE* node )
{
   if ( node )
   {
      char* s= "";
      int i;

      fprintf( stream, "(%s,[", node->tag );
      for ( i = 0; i < node->no_of_children; i++ )
      {
	 fprintf( stream, "%s", s );
	 write_cfgnodes( stream, node->children[i] );
	 s = ",";
      }
      fprintf( stream, "])" );
   }
}

double read_cfg( FILE* stream, CFGTREE* tree )
{
   char ch; double freq = -1;

   tree->root = read_cfgnodes( stream );
   if ( tree->root )
     {ch = getc( stream );
      if ( ch == ',' ) 
        {fscanf( stream, "%le", &freq ); assert(freq >= 0); 
         tree->freq = freq; ch = getc( stream); assert( ch == ')');
        }
      else ungetc( ch, stream);
      fscanf( stream, ".\n" );
      return freq;
     }
  return 1.0;
}

void write_cfg( FILE* stream, CFGTREE* tree )
{
   write_cfgnodes( stream, tree->root );
   fprintf( stream, ".\n" );
}

void write_cfg_with_freq( FILE* stream, CFGTREE* tree )
{
   CFGNODE* node = tree->root;

   if ( node )
   {
      char* s= "";
      int i;

      fprintf( stream, "(%s,[", node->tag );
      for ( i = 0; i < node->no_of_children; i++ )
      {
	 fprintf( stream, "%s", s );
	 write_cfgnodes( stream, node->children[i] );
	 s = ",";
      }
      if (tree->freq >=0 ) fprintf( stream, "],%le).\n", tree->freq );
      else fprintf( stream, "]).\n");
   }
}
      
CFGNODE* decode_cfgnodes( FILE* stream )
{
   CFGNODE* node;
   char ch, buf[MAX_TAG_LEN];
   int  i = 0;

   ch = getc( stream );
   while ( CharInSymbol(ch) == true)
   {
      buf[i++] = ch;
      ch = getc( stream );
   }
   buf[i] = '\0';
   node = tnew( CFGNODE );
   node->tag = tstrdup( buf );
   if ( ch == '(' )
   {
      int num;

      fscanf( stream, "%u", &num );
      node->no_of_children = num;
      node->children = tnewn( num, CFGNODE* );
      for ( i = 0; i < num; i++ )
      {
	 ch = getc( stream );
	 node->children[i] = decode_cfgnodes( stream );
      }
      assert( getc(stream) == ')' );
   }
   else
   {
      ungetc( ch, stream );
      node->no_of_children = 0;
      node->children = NULL;
   }
   return( node );
}

void code_cfgnodes( FILE* stream, CFGNODE* node )
{
   if ( node )
   {
      fprintf( stream, "%s", node->tag );
      if ( node->no_of_children )
      {
	 char delim = ':';
	 int i;

	 fprintf( stream, "(%d", node->no_of_children );
	 for ( i = 0; i < node->no_of_children; i++ )
	 {
	    fprintf( stream, "%c", delim );
	    code_cfgnodes( stream, node->children[i] );
	    delim = ',';
	 }
	 fprintf( stream, ")" );
      }
   }
}

void code_cfg( FILE* stream, CFGTREE* tree, double prob )
{
   if (prob == -1.0) ;/* fprintf( stream, "\n"); */
   else fprintf( stream, "%le ", prob );

   code_cfgnodes( stream, tree->root );
   fprintf(stream, "\n");
  /*
   if (prob == -1.0) fprintf( stream, "\n"); 
   else fprintf( stream, " %le\n", prob );
  */
}
/*--------------------------------------*/
void decode_cfg( FILE* stream, CFGTREE* tree )
{
   char ch;

   ch = getc( stream );
   if ( CharInSymbol(ch) == true )
   {
      ungetc( ch, stream );
      tree->root = decode_cfgnodes( stream );
      fscanf( stream, "\n" );
   }
   else
      tree->root = NULL;
}

void decode_cfg_with_freq( FILE* stream, CFGTREE* tree )
{
   char ch;
   double freq = -1;

   ch = getc( stream );
   if (isdigit(ch) != 0)
    { ungetc( ch, stream );
      fscanf( stream, "%le ", &freq );
      tree->freq = freq;
      ch = getc( stream );
    }
   else tree->freq = 0.0;

   if ( CharInSymbol(ch) == true )
   {
      ungetc( ch, stream );
      tree->root = decode_cfgnodes( stream );

      ch = getc( stream );
      if (isdigit(ch) != 0)
       { ungetc( ch, stream );
         fscanf( stream, "%le", &freq );
         tree->freq = freq;
       }
      else ungetc( ch, stream );
      fscanf( stream, "\n" );
   }
   else
      tree->root = NULL;
}

