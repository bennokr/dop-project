
static const char rcsid[] =
   "$Id$";

#include <assert.h>
#include <ctype.h>
#include <string.h>
#include "tnew.h"
#include "Constants.h"
#include "cfgtree.h"

extern char* tstrdup( const char* s );

char *StrudelOf(char *text)
{static char NAME[SymLength];
 strcpy(NAME, text); 
 if (strchr(text, _ECNF_SYM)==NULL) {NAME[strlen(text)] = _ECNF_SYM; NAME[strlen(text)+1] = '\0';}
 return NAME;
}

Boolean EQ_Strings(char *str1, char *str2)
{if ((str1 == NULL) && (str2 == NULL)) return true;
	 if (!strcmp(str1, str2)) return true;
	  return false;
}

Boolean HasStrudel(char *text)
{if (strchr(text,_ECNF_SYM)!=NULL) return true;
 else return false;
}

/**************************************************************************************************/
#define  CO_RD_ARRAYLEN  1
static char *CO_ORD_ARRAY[ CO_RD_ARRAYLEN ] = {"KON"};
#define  PUNCT_ARR_LEN    4
static char *PUNCT_ARRAY[ PUNCT_ARR_LEN ] = {"ZCM","ZCL","ZSCL","KON"};

Boolean InPUNCT_ARRAY(char *TEXT)
{int i;
 for (i=0; i < PUNCT_ARR_LEN; i++) if (strstr(TEXT, PUNCT_ARRAY[i]) != NULL) return true;
 return false;
}

Boolean InCO_ORDINATION_ARRAY(char *TEXT)
{int i;
  if (CO_ORD_ARRAY != NULL)
   {for (i=0; i< CO_RD_ARRAYLEN; i++) if (strstr(TEXT, CO_ORD_ARRAY[i]) != NULL) return true;
   }
 return false;
}
/************************************************************************************************/


int NumberOfCOMMA_Chs(CFGNODE *NP)
{int i; int result = 0; 
 for (i=0; i<NP->no_of_children; i++) if (InPUNCT_ARRAY(NP->children[i]->tag) == true) result++;
 return result;
}
/* Has a C beginning of label and has more than 3 children? of which at least two are ZCM or so */
Boolean TransformRightLinearQ(CFGNODE *NP)
{Boolean RESULT=true;
 if (strchr(NP->tag,'_') != NULL) RESULT = false;
 if (NP->tag[0] != 'C')           RESULT = false;
 if (NP->no_of_children <=3)      RESULT = false;
 if (NumberOfCOMMA_Chs(NP)<2)     RESULT = false; 
 
 return RESULT;
}
/************************************************************************************************/
/* A recursive phrase consists of a list of CS-->PH ZCM PH ZCM.... KON/CC PH                    */
/*             										        */
/* A mother node which label starts with C e.g. CNP, and has mother than 3 children:            */
/* transform into (CS--> PH ZCM (PH@ PH ZCM (PH@ ....)  )  )                                    */
/************************************************************************************************/
/**/
/* all children of node after the comma fall under new node labeled node->tag@ */
void RightLinearAfter_ChNum(CFGNODE *node, int comma, char *NEWTAG)
{/* catch the first COMMA and transform what's after it into recursive structure */
 int i; 

 /* all children after the comma fall under node->tag@ name */
 /* comma is not last child and there is a child left after the comma */
 if ( (comma != node->no_of_children) && ((node->no_of_children-comma-1)>1) )
  {int j; CFGNODE **charray; 
   CFGNODE **temparray=node->children; int temp_no_ch = node->no_of_children;
   {/* put the children up to including the comma as new children of node */
    charray = tnewn( comma+2, CFGNODE* ); /* build a new array  comma + 2 size (one extra for XP@) */
    for ( j = 0; j <= comma; j++ ) charray[j] = node->children[j]; /* move the children up to the comma */
    node->children = charray; node->no_of_children = comma+2;
   }

   {/* add a new child with XP@ as label and chnum = temp_no_ch - comma */
    CFGNODE *rec_node = tnew( CFGNODE ); rec_node->tag = tstrdup(StrudelOf(NEWTAG));
    rec_node->no_of_children = temp_no_ch - comma -1;
    rec_node->children = tnewn( temp_no_ch - comma, CFGNODE* );
    for (j=comma+1; j< temp_no_ch; j++)  rec_node->children[j-comma-1] = temparray[j];
    charray[comma+1] = rec_node;
   }

   /* empty the array to avoid double free later on */
   for (j=0; j< temp_no_ch; j++) temparray[j]=NULL;
  }
}
/****************************************************/
void TransThisNodeCommas(CFGNODE *node)
{/* catch the first COMMA and transform what's after it into recursive structure */
 int i; int comma=0;

 if (TransformRightLinearQ(node) == true)
  {for ( i = 0; ((i < node->no_of_children) && (comma==0)); i++ ) 
     if (InPUNCT_ARRAY(node->children[i]->tag)==true) comma = i; /* we cought a COMMA */
 
   if (comma!=0) RightLinearAfter_ChNum(node, comma, node->tag);
  }
}

/*node with at least 2 children and repetition of one node: repetitions are treated */
void TransThisNodeRepitition(CFGNODE *node)
{int i; int repetition = -1; int tot_cons_rep=0;

 if (node->no_of_children>=2)
 {for ( i = 1; (i < node->no_of_children) ; i++ ) 
     if (EQ_Strings(node->children[i-1]->tag,node->children[i]->tag)==true) tot_cons_rep++;

  if (tot_cons_rep>=3)
   for ( i = 1; ((i < node->no_of_children) && (repetition==-1)); i++ ) 
     if (EQ_Strings(node->children[i-1]->tag,node->children[i]->tag)==true) repetition=i-1;
 }

 if (repetition>0) repetition=repetition-1; /* when XP NP NP NP trans to XP NP@... */

 if (repetition!=-1) RightLinearAfter_ChNum(node, repetition, node->children[repetition+1]->tag);
}
void TransThisNodeRepititionII(CFGNODE *node)
{static char NAME[SymLength]; int i; int repetition = -1;

 if (node->no_of_children>=4)
  for ( i = 2; ((i < (node->no_of_children -1)) && (repetition==-1)); i++ ) 
     if ( (EQ_Strings(node->children[i-2]->tag,node->children[i]->tag)==true) &&
          (EQ_Strings(node->children[i-1]->tag,node->children[i+1]->tag)==true)      )  repetition=i-1;

 if ((HasStrudel(node->tag)==false) && (repetition!=-1))
    {strcpy(NAME,node->children[repetition]->tag); strcat(NAME,node->children[repetition-1]->tag);}
 else strcpy(NAME,node->tag);

 if (repetition>1) repetition=repetition-2; /* when YP XP NP XP NP trans to YP XPNP@... */

 if (repetition!=-1) RightLinearAfter_ChNum(node, repetition, NAME);
}
/****************************************************/
void TransThisNode(CFGNODE *node)
{TransThisNodeCommas(node);     /* treat enumerations seperated by commas */
	 if (1==0)
	 {
 TransThisNodeRepitition(node); /* treat repetitions */
 TransThisNodeRepititionII(node); /* treat repetitions */
	 }
}

int treenumber=1;
Boolean TransformTree(CFGNODE* node, Boolean Root)
{int i; Boolean result = true; Boolean result_ch=true;

 if ( node )
  {if ( node->no_of_children > 1) TransThisNode(node);/* at least one child */ 

   if (node->no_of_children>16)
    {fprintf(stderr,"excluding tree-number: %d, node %s with %d children\n", treenumber, node->tag, node->no_of_children); 
     /* write_cfgnodes( stderr, node ); fprintf(stderr,"\n"); */ fflush(stderr);
     result=false;
    }

   for ( i = 0; i < node->no_of_children; i++ )
     {result_ch = TransformTree( node->children[i] , false); result = ((result==true) ? result_ch : result);}

   if (Root==true) treenumber++;
  }

 return result;
}
