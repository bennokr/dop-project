/*
   treeconvert.c: created October %0d, 1995 16:03:33
   Wilco van Hoogstraeten.

   Converts trees from prolog style notation to a shorter form or vice
   versa.
 */

static const char rcsid[] =
   "$Id$";

#include <string.h>
#include "tnew.h"
#include "cfgtree.h"
#include "ExtraTrans.h"

#define PRO_2_SHORT "pro2shf"
#define SHORT_2_PRO "shf2pro"
#define TRANS_RIGHT_LINEAR "to_right_linear"
#define REMOVE_UNARIES "remove_unary_prods"

Boolean OUTPUT_TREE = true;

int main( int argc, char* argv[] )
{
   FILE* in_file = stdin, *out_file = stdout;
   CFGTREE tree;
   char* basename;

   if ( argc >= 2 )
   {
      in_file = fopen( argv[1], "r" );
      if ( !in_file )
      {
	 fprintf( stderr, "File <%s> does not exist\n", argv[1] );
	 exit( 1 );
      }
   }
   if ( argc >= 3 )
   {
      out_file = fopen( argv[2], "w" );
      if ( !out_file )
      {
	 fprintf( stderr, "File <%s> cannot be opened\n", argv[2] );
	 fclose( in_file );
	 exit( 1 );
      }
   }
   basename = strrchr( argv[0], '/' );
   if ( basename )
      basename++;
   else
      basename = argv[0];

   if ( !strcmp(basename, PRO_2_SHORT) )
   {double prob;

      prob = read_cfg( in_file, &tree );
      while ( tree.root )
      {
	 code_cfg( out_file, &tree , prob);
	 tfree( );
	 prob = read_cfg( in_file, &tree );
      }
   }
   else if ( !strcmp(basename, SHORT_2_PRO) )
   {
      decode_cfg_with_freq( in_file, &tree );
      while ( tree.root )
      {
	 write_cfg_with_freq( out_file, &tree );
	 tfree( );
	 decode_cfg_with_freq( in_file, &tree );
      }
   }
   else if ( !strcmp(basename, TRANS_RIGHT_LINEAR) )
   {double prob;

      prob = read_cfg( in_file, &tree );
      while ( tree.root )
      {  OUTPUT_TREE=true; OUTPUT_TREE = TransformTree(tree.root, true); /* might set OUTPUT_TREE false */
	 if (OUTPUT_TREE == true) write_cfg( out_file, &tree );
	 tfree( );
	 prob = read_cfg( in_file, &tree );
      }
   }

   return( 0 );
}
