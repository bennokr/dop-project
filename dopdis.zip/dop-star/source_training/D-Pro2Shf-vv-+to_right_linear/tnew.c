/*
   tnew.c: created October 17, 1995 16:33:28
   Wilco van Hoogstraeten.
 */

static const char rcsid[] =
   "$Id$";

#include <assert.h>
#include <stdio.h>
#include "tnew.h"

#define BLOCK_SIZE	4096

static void* base = NULL;

void* talloc( size_t size )
{
   static void* current, *curr_base;
   static size_t mem_left;
   void *p;

   size = size + (4 - size % 4);
   if ( base == NULL )
   {
      base = curr_base = malloc( BLOCK_SIZE );
      *((char**) base) = NULL;
      current = (void*) ((char*) base + sizeof(char*));
      mem_left = BLOCK_SIZE - sizeof( char* );
   }
   if ( size > mem_left )
   {
      assert( size <= BLOCK_SIZE );
      p = malloc( BLOCK_SIZE );
      *((char**) curr_base ) = p;
      curr_base = p;
      *((char**) curr_base) = NULL;
      current = (void*) ((char*) curr_base + sizeof(char*));
      mem_left = BLOCK_SIZE - sizeof( char* );
   }
   mem_left -= size;
   p = current;
   current = (void*) ((char*) current + size );
   return( p );
}

void tfree( )
{
   void* p, *old;

   p = base;
   while ( p )
   {
      old = p;
      p = (void*) *((char**) p);
      free( old );
   }
   base = NULL;
}
