extern Boolean TransformTree(CFGNODE* node, Boolean Root);
