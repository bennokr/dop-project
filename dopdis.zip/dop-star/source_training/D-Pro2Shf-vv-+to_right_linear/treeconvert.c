/*
   treeconvert.c: created October %0d, 1995 16:03:33
   Wilco van Hoogstraeten.

   Converts trees from prolog style notation to a shorter form or vice
   versa.
 */

static const char rcsid[] =
   "$Id$";

#include <string.h>
#include "cfgtree.h"
#include "tnew.h"

#define PRO_2_SHORT "pro2sh"
#define SHORT_2_PRO "sh2pro"

int main( int argc, char* argv[] )
{
   FILE* in_file = stdin, *out_file = stdout;
   CFGTREE tree;
   char* basename;

   if ( argc >= 2 )
   {
      in_file = fopen( argv[1], "r" );
      if ( !in_file )
      {
	 fprintf( stderr, "File <%s> does not exist\n", argv[1] );
	 exit( 1 );
      }
   }
   if ( argc >= 3 )
   {
      out_file = fopen( argv[2], "w" );
      if ( !out_file )
      {
	 fprintf( stderr, "File <%s> cannot be opened\n", argv[2] );
	 fclose( in_file );
	 exit( 1 );
      }
   }
   basename = strrchr( argv[0], '/' );
   if ( basename )
      basename++;
   else
      basename = argv[0];
   if ( !strcmp(basename, PRO_2_SHORT) )
   {double prob = -1.0;
      prob = read_cfg( in_file, &tree );
      while ( tree.root )
      {
	 code_cfg( out_file, &tree, prob );
	 tfree( );
	 prob = read_cfg( in_file, &tree );
      }
   }
   else if ( !strcmp(basename, SHORT_2_PRO) )
   {
      decode_cfg( in_file, &tree );
      while ( tree.root )
      {
	 write_cfg( out_file, &tree );
	 tfree( );
	 decode_cfg( in_file, &tree );
      }
   }
   return( 0 );
}
