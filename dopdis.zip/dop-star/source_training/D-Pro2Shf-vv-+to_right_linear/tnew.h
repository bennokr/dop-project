/*
   tnew.h: created October 17, 1995 16:33:28
   Wilco van Hoogstraeten.

   $Id$
 */

#ifndef TNEW_H
#define TNEW_H

#include <stdlib.h>

extern void* talloc( size_t size );
extern void  tfree( );

#define tnew( type )		(type*) talloc( sizeof(type) )
#define tnewn( n, type )	(type*) talloc( (n)*sizeof(type) )

#ifndef false
#define false 0
#endif
#ifndef true
#define true 1
#endif
#ifndef Boolean
#define Boolean char
#endif  

#endif  /* TNEW_H */
