/*
 * Created on May 29, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 *
 * Class Treekey stores data of root tree node:
 * root tree name
 * whether the root node is terminal
 * sequence in its parents subtree (start from 1)
 * node tree address 
 * @author tlnguyen
 */

import java.util.*;
public class TreeKey implements Comparator {
	public String treename;
	public boolean terminal;
	public int treeaddress;
	public int siblingseq;
	public int parentaddress;	 
	
	public TreeKey(){
		terminal = false;
	}
	public TreeKey(String treestr){
		this.treename = treestr;
		if (treestr.charAt(this.treename.length()-1)=='_')
		{		
			this.terminal = true;
			this.treename = this.treename.substring(0, this.treename.length()-1);
		}
		else
			this.terminal = false;
				
	}
	
	public boolean equals(TreeKey tree){
		if (tree.parentaddress == this.parentaddress && tree.siblingseq == this.siblingseq && tree.treename.equals(this.treename))
			return true;
		else
			return false;
		
	}
		
	public boolean equalskeyname(TreeKey tree){
		if (tree.treename.equals(this.treename))
			return true;
		else return false;
	}

//	public int compare(TreeKey tree1,
//					   TreeKey tree2){
	public int compare(Object obj1,
					   Object obj2){
		TreeKey tree1 = new TreeKey();
		TreeKey tree2= new TreeKey();
		tree1 = (TreeKey)obj1;
		tree2 = (TreeKey)obj2;
		
		if (tree1.siblingseq < tree2.siblingseq)
			return -1;
		if (tree1.siblingseq == tree2.siblingseq)
			return 0;
		if (tree1.siblingseq > tree2.siblingseq)
			return 1;
		return 0;  	
	}	
}
