
/*
 * Created on Jan 9, 2004
 *
 */

/**
 * @author Andreas Zollmann
 *
 */
public class FilteredParserOutput extends ParserOutput
{

	public String basicTree;

	public FilteredParserOutput(String bT)
	{
		basicTree = "sss,[(" + bT + ")]";
	}

	public boolean addTreeCondition(String treeStr)
	{
		return (Tree.nonStrictEqualsStr(basicTree, treeStr));		
	}

}
