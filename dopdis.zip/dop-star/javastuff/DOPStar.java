/*
 * Created on Jun 5, 2003
 * 
 * renice 19 -u azollman
 * ps -exfl (nice tree)
 * top -d1
 * converttreebank < tmp | viewtree
 * dopdis -K100 | grep '^[^*]*\*[^*]*\*[^*]*$'
 * cat corpus | tr '[A-Z]' '[a-z]' > ovis.complete.lowercase
 * sh: for a in *; do echo $a; done
 * tcsh: foreach a (*) [ENTER] echo $a [ENTER] end
 * /usr/local/mysql/bin/safe_mysqld --datadir=. --tmpdir=.
 * /opt/arch/mysql/libexec/mysqld --basedir=/opt/arch/mysql --datadir=.
 * 
 * 
 * time needed for atc size 5000, -n5 (on den, weekend):
 * gen-t-grams: 524 sec, 3.9 mio fragments
 * read in fragments: 30269 sec (8.4 h)
 * 
 * tell khalil about viterbi-format problems (marked as !!!)
 * rev_conv_wsj has problems with sss->a,b rules
 * why in dop1 more correct parses derivable? 
 * 
 * other advantage: very high precision possible (dopstar parses only when it's confident)
 * 
 * --big-tables
 * 
 */

//import java.sql.*;
import java.util.*;
import java.io.*;


//import jdbm.*;

/**
 * 
 * Main class.
 * 
 * @author Andreas Zollmann
 *
*/
public class DOPStar extends U
{

    //        /**
    //         * whether an ovis training corpus is used
    //         */
    //        public static boolean ovis = false;
    //    
    //        public static boolean onlyCreateSplittings = false;
    //        public static boolean useGivenSplittings = true;
    //        public static boolean heldOutCheating = false;
    //        public static boolean heldOutUseLexicon = false;
    //        public static boolean includeDop1 = true;
    //  	    public static boolean includeDopstarDop1 = false;
    //        public static boolean includeDopstar = true;
    //        public static boolean includeDop1Purest = false;
    //        public static boolean unknownExtraction = true;
    //        public static double unknownFactor = 1E-2;
    //    
    //        /**
    //         * n.o. beta levels
    //         */
    //        public static int betaLevelsCount = 2;
    //        public static double betaSmoothingFactor = 1E-0;
    //
    //    
    //        /** 
    //         * gen-t-grams options concerning the fragments created from
    //         * unknown parse trees during the 
    //         * DOP* training procedure (concerns getBetas). If null
    //         * then this parameter is set automatically in the `main' method.
    //         * 
    //         */
    //        public static String dopStarUnknownExtractionFragmentOptions = null;
    //        //"-d3";
    //    
    //        //public static boolean interpolateDop1 = false;
    //    
    //        /**
    //         * Montecarlo sampling size during testing in case testingType.equals(   
    //         */
    //        public static int monteCarloSamplingSizeTesting = 2000;
    //    
    //        /**
    //         * Montecarlo sampling size during beta-estimation  
    //         */
    //        public static int monteCarloSamplingSizeBeta = 6000;
    //    
    //        public static String[] testParsers = {
    //            //"dopone", "dopstar_dopone", "dopstar_purest", "dopstar_pcfg" };
    //            "pcfg", "dopone", "dopstar_purest", "dopstar_pcfg" };
    //        //"dopstar_purest", "dopstar_pcfg" };
    //        // "dopone" };
    //    
    //        public static String[] backOffParsers =
    //            //{ "dopstar_d3", "dopstar_d2", "dopone" };
    //            //{ "dopstar_d3", "dopone_d3" };
    //        { "dopone" };
    //    
    //        public static boolean showNonSingleWordSentencesResults = false;
    //    
    //        /**
    //         * size of corpus (approx.)
    //         */
    //        public static int corpusSize = 577;
    //    
    //        /**
    //         * size of testing corpus to be split off from corpus
    //         */
    //        public static int testingCorpusSize = 100;
    //    
    //    
    //        /**
    //         * corpus file (including training and testing data) used
    //         */
    //        //public static String corpusFile = scriptPath + "ovis.complete";
    //        //public static String corpusFile = "/home/azollman/download/cnv.atis";
    //        public static String corpusFile =
    //            "/scratch/andreas/dopstar/cnv.atis.no_features.lowercase";
    //
    
    
    /**
     * The following are parameters that you might want to adapt
     */

    /**
     * whether an ovis training corpus is used
     */
    public static boolean ovis = true;

    public static boolean onlyCreateSplittings = false;
    public static boolean useGivenSplittings = false;
    public static boolean heldOutCheating = false;
    public static boolean heldOutUseLexicon = false;
    public static boolean includeDop1 = false;
    public static boolean includeDop1Purest = false;
    public static boolean includeDopstarDop1 = false;
    public static boolean includeDopstar = true;
    public static boolean leavingOneOut = false;
    public static boolean unknownExtraction = true;
    public static double unknownFactor = 1E-2;

    /**
     * n.o. beta levels
     */
    public static int betaLevelsCount = 2;
    public static double betaSmoothingFactor = 1E-0;

    /** 
     * gen-t-grams options concerning the fragments created from
     * unknown parse trees during the 
     * DOP* training procedure (concerns getBetas). If null
     * then this parameter is set automatically in the `main' method.
     * 
     */
    public static String dopStarUnknownExtractionFragmentOptions = null;
    //"-d3";

    //public static boolean interpolateDop1 = false;

    /**
     * Montecarlo sampling size during testing in case 
     * testingMode == ALLMPP or testingMode == MPP   
     */
    public static int monteCarloSamplingSizeTesting = 2000;

    /**
     * Montecarlo sampling size during beta-estimation  
     */
    public static int monteCarloSamplingSizeBeta = 6000; //6000

    public static String[] testParsers = {
        //"dopone", "dopstar_dopone", "dopstar_purest", "dopstar_pcfg" };
        "dopstar_pcfg" };
    //  "dopstar_purest", "dopstar_pcfg" };
    //  "dopone" };
    //};

    public static String[] backOffParsers =
        //{ "dopstar_d3", "dopstar_d2", "dopone" };
        //{ "dopstar_d3", "dopone_d3" };
        //{ "dopone" };
    {
    };

    public static boolean showNonSingleWordSentencesResults = true;

	/*
	 * 
	 *
	 * 
	 * 
	 * 
	 * 
	 *  
	 * 
	 * 
	 * --------------------------------------------------------------------------------
	 * 
	 * 
	 */

    /**
     * The following parameters are initialized during the program runtime.
     */

    /**
     * corpus file (including training and testing data), used
     * for the splitting process in method `train'.
     * Set in the `main' method.
     */
    public static String corpusFile = null;

    /**
     * Size of corpus, used for the splitting process in method `train'.
     * Set in the `main' method.
     */
    public static int corpusSize = -1;

    /**
     * Size of testing corpus to be split off from corpus, used 
     *  for the splitting process in method `train'.
     * Set in the `main' method.
     */
    public static int testingCorpusSize = -1;

    /** 
     * gen-t-grams options concerning the fragments created during the 
     * DOP* training procedure (concerns getATCFragments and getBetas).
     * Initialized in `main' method
     */
    public static String dopStarFragmentOptions = null; //"-Co";

    /** 
     * gen-t-grams options concerning the fragments created during the 
     * DOP1 training procedure. 
     * Initialized in `main' method
     */
    public static String dop1FragmentOptions = null;
    //"-L3 -Co";

    /**
     * dopdis testing options 
     */
    public static String dopdisTestOptions = "-C"; //"-P -s"; //"-P";

    /** 
     * the next three are constants for the test mode	  
     */
    public static final int ALLMPP = 1;
    public static final int MPP = 2;
    public static final int MPD = 3;
    public static final int MRP = 4;
    /**
     * the testing mode: 
     * Most probable parse (MPP)
     * Most probable parse, but return all sampled parses for statistical purposes (ALLMPP)
     * Most probable derivation (MPD)
     * Maximum Recall Rate Parse (MRP)
     * 
     * Initialized in main method
     */
    public static int testingMode = -1;

    /**
     * Total number of experiments to perform.
     * Initialized in `main' method.
     */
    public static int totalExperimentsCount = 1;
    /**
     * Experiment number to start with. 
     * Initialized in `main' method.
     */
    public static int startWithExperiment = 1;

    /** 
     * in case of ovis: the fragment corpus containing the lexical items.
     * Will be extracted during the training process. 
     */
    public static FragmentCorpus ovisLexicon = null;

    /**
     * directories used - caution! always use "/" at the end. Initialized in init and main methods.
     */
    public static String tmpPath = null;
    // set by init method   // "/scratch/andreas/exp/temp/";
    public static String dopstarPath = null;
    // set by init method   // "/scratch/andreas/exp/";
    public static String trainPath = null; // "/scratch/andreas/exp/train/";
    public static String testPath = null;
    // "/scratch/andreas/exp/train/test/";

    /**
     *  for statistical purposes only
     */
    public static long infoCountShortestDerivations = 0;
    /**
     * for statistical purposes only
     */
    public static long infoCountHeldOutTestedSentences = 0;

    //public static int cnt_nonterminalnodes = 0; //for statistics purpose only
    //  

    /*
     * 
     *
     * 
     * 
     * 
     * 
     *  
     * 
     * 
     * --------------------------------------------------------------------------------
     * 
     * 
     */

    public static void init(String[] args) throws Exception
    {
        /**
         * set to `true' for verbose output mode
         */
        verbose = true;

        /**
         * the unix output device / file used when running shell commands
         * typically either /dev/tty or /dev/null or a filename
         */
        unixOutputDevice = "/dev/tty";

        dopstarPath = (new File(args[0]).getAbsoluteFile()).getPath();
        if (dopstarPath.charAt(dopstarPath.length() - 1) != '/')
            dopstarPath += "/";

        if (tmpPath == null)
            tmpPath = dopstarPath + "../temp/";
        //tmpPath = System.getProperty("java.io.tmpdir") + "/dopstar_temp/";
        run("mkdir -p " + tmpPath);

        // does tmp directory really exist?
        File file = new File(tmpPath + ".");
        if (!file.exists())
        {
            System.out.println(
                "Error! Temporary directory '"
                    + tmpPath
                    + "' does not exist although just created!");
            System.exit(1);
        }
    }

    public static void shutDown() throws Exception
    {
        //        run(
        //            "rm -rf "
        //                + System.getProperty("java.io.tmpdir")
        //                + "/dopstar_temp/");
    }

    public static void main(String[] args) throws Exception
    {
        if ((args.length < 4) || args.length > 7)
        {
            System.out.println(
                "Syntax error! Use the shell script 'dopstar' to execute this program.");
        } else
        {
            try
            {
                init(args);

                //System.setOut(p_out);

                trainPath =
                    (new File(args[1]).getAbsoluteFile()).getPath() + "/";
                testPath = trainPath + "test/";
                if (args.length <= 5)
                {

                    // testing mode only

                    totalExperimentsCount = Integer.parseInt(args[3]);
                    startWithExperiment =
                        args.length == 5 ? Integer.parseInt(args[4]) : 1;
                    if (args[2].equals("testmrp"))
                    {
                        testingMode = MRP;
                        test();
                    } else if (args[2].equals("testmpp"))
                    {
                        testingMode = ALLMPP;
                        test();
                    } else if (args[2].equals("testmpd"))
                    {
                        testingMode = MPD;
                        test();
                    } else
                    {
                        System.out.println("Syntax error: Command line argument '"
                         + args[2] + "' is not a valid testing action!");
                    }
                } else
                {

                    //training and testing

                    totalExperimentsCount = Integer.parseInt(args[5]);
                    startWithExperiment =
                        args.length == 7 ? Integer.parseInt(args[6]) : 1;

                    corpusFile = (new File(args[2]).getAbsoluteFile()).getPath();
                    corpusSize = getTextFileLinesCount(corpusFile);
                    testingCorpusSize = Integer.parseInt(args[3]);

                    dopStarFragmentOptions = dop1FragmentOptions = args[4];
                    if (dopStarUnknownExtractionFragmentOptions == null)
                        dopStarUnknownExtractionFragmentOptions =
                            args[4].length() == 3
                                && args[4].startsWith("-d")
                                && args[4].charAt(2) >= '4' ? "-d3" : args[4];

                    train();
                    if (!onlyCreateSplittings)
  					   testingMode = ALLMPP;
                       test();
                }
            } catch (Exception e)
            {
                e.printStackTrace();
            }
            shutDown();
        }
    }

    public static void train() throws Exception
    {
        long startTimeTrain = System.currentTimeMillis();
        run("mkdir -p " + trainPath);

        {
            File file = new File(trainPath + "log_dopstar.txt");
            if (file.exists())
                run("cp -p log_dopstar.txt log_dopstar.txt.bak", trainPath);
            log = new LogPrintWriter(trainPath + "log_dopstar.txt");
        }
        run("echo $HOST >" + tmpPath + "hostname");
        log.print2("Host used for experiment: ");
        log.printFile2(tmpPath + "hostname");
        log.println2("trainPath = " + trainPath);
        log.println2("corpusFile = " + corpusFile);
        log.println2("corpusSize=" + corpusSize);
        log.println2("testingCorpusSize=" + testingCorpusSize);
        log.println2("totalExperimentsCount=" + totalExperimentsCount);
        log.println2("startWithExperiment=" + startWithExperiment);
        log.println2(
            "monteCarloSamplingSizeBeta=" + monteCarloSamplingSizeBeta);
        if (includeDopstar)
        {
            log.println2(
                "Using "
                    + (heldOutCheating ? "" : "NO ")
                    + "held-out cheating.\n"
                    + (heldOutUseLexicon ? "Add " : "DON'T add ")
                    + "lexicon to Actual Training Corpus during held-out training."
                    + (leavingOneOut
                        ? "\nUsing the Leaving-One-Out method"
                        : "")
                    + (unknownExtraction
                        ? "\nDoing unknownExtraction with unknownFactor="
                            + unknownFactor
                        : "\nNO unknown extraction.")
                    + (betaLevelsCount != 1
                        ? "\nUtilizing also non-shortest derivations during held-out training (betaLevelsCount="
                            + betaLevelsCount
                            + ", smoothing factor=p_unkn*"
                            + betaSmoothingFactor
                            + ")"
                        : "\nDON'T smooth in longer derivations"));
        } else
            log.println2("NO DOP* training.");
        log.println2(
            includeDop1
                ? "Include DOP1 training."
                : "DON'T include DOP1 training.");
        log.println2(
            "Properties of extracted fragments (depth1-fragments are always used): "
                + dopStarFragmentOptions
                + " (DOP*), "
                + dopStarUnknownExtractionFragmentOptions
                + " (DOP* unknown extraction), "
                + dop1FragmentOptions
                + " (DOP1)"
                + "\n  -d = Max. depth of fragments"
                + "\n  -n = Max. n. o. nonterminal leaves ('open nodes')"
                + "\n  -l = Max. n. o. terminal leaves ('lexical items')"
                + "");

        // create files needed for temporary compiling
        run(
            "echo DIR = "
                + dopstarPath
                + "../objects >"
                + tmpPath
                + "Make_DOPDIS");
        run(
            "cat Make_DOPDIS_parameters >>" + tmpPath + "Make_DOPDIS",
            dopstarPath);
        run("cp -p parameters.c " + tmpPath, dopstarPath);

        // build the lexicon
        if (ovis)
            buildLexicon();

        // copy the corpus to the training directory
        run("cp -p " + corpusFile + " " + trainPath + "corpus");

        for (int expNum = startWithExperiment;
            expNum <= totalExperimentsCount;
            expNum++)
        {
            log.println2(
                "\n========================================================\n");
            log.println2("STARTING EXPERIMENT " + expNum);

            long starttime = System.currentTimeMillis();

            if (!useGivenSplittings || onlyCreateSplittings)
            {
                System.out.println("Splitting corpus ...");

                // split corpus randomly into training and testing part
                split(
                    trainPath,
                    "corpus",
                    testingCorpusSize,
                    "corpus.train." + expNum,
                    "corpus.test." + expNum);
            }

            String fileTC = trainPath + "corpus.train." + expNum;
            FragmentCorpus fragDOP1 = null;
            FragmentCorpus fragPCFG = null;
            if (!onlyCreateSplittings)
            {
                if (includeDop1)
                {
                    //                    boolean verboseBak = verbose;
                    //                    verbose = true;
                    fragDOP1 =
                        ovis
                            ? dop1Train(fileTC, ovisLexicon)
                            : dop1Train(fileTC, null);
                    compileFragmentCorpus(
                        fragDOP1,
                        trainPath + "dopone." + expNum + "/",
                        true);
                    //                    verbose = verboseBak;
                }

                // create dopone parser without lexicon
                if (includeDop1Purest)
                {
                    FragmentCorpus fragDOP1purest = dop1Train(fileTC, null);
                    compileFragmentCorpus(
                        fragDOP1purest,
                        trainPath + "dopone_purest." + expNum + "/");
                }

                // create PCFG parser
                fragPCFG = pcfgTrain(fileTC);
                compileFragmentCorpus(
                    fragPCFG,
                    trainPath + "pcfg." + expNum + "/");
            }
            if (includeDopstar || onlyCreateSplittings)
            {
                if (!leavingOneOut
                    && (!useGivenSplittings || onlyCreateSplittings))
                {
                    // now divide the training corpus up
                    String source = "corpus.train." + expNum;
                    long splitCount = (corpusSize - testingCorpusSize) / 10;
                    //long splitCount = (10-expNum)*100;                  
                    // the following loop first splits off a piece from corpus.train.expNum,
                    // storing the rest in corpus.tc10.expNum, and
                    // then successively splits off pieces from that file
                    for (int i = 1; i <= 9; i++)
                    {
                        split(
                            trainPath,
                            source,
                            splitCount,
                            "corpus.tc10." + expNum,
                            "corpus.tc" + i + "." + expNum);
                        // set source for the next iteration	
                        source = "corpus.tc10." + expNum;
                    }
                }

                if (!onlyCreateSplittings)
                {
                    // the beta DOP* fragment corpora containing the beta-fragments
                    // extracted from the 10 different held-out testings
                    FragmentCorpus[] fragBetas =
                        new FragmentCorpus[betaLevelsCount];
                    for (int i = 0; i < betaLevelsCount; i++)
                    {
                        fragBetas[i] = new FragmentCorpus();
                    }

                    double p_unkn;

                    if (leavingOneOut)
                    {
                        //String fileTC =
                        //	trainPath + "corpus.train" + "." + expNum;
                        log.println2("DOP* training on ...");

                        // do DOP* training
                        if (heldOutCheating)
                        {
                            p_unkn =
                                getBetas(fileTC, fragPCFG, fileTC, fragBetas);
                        } else if (heldOutUseLexicon)
                        {
                            p_unkn =
                                getBetas(
                                    fileTC,
                                    ovisLexicon,
                                    fileTC,
                                    fragBetas);
                        } else
                        {
                            p_unkn =
                                getBetas(
                                    fileTC,
                                    new FragmentCorpus(),
                                    fileTC,
                                    fragBetas);
                        }
                    } else
                    {
                        // sum of the p_unkn values returned by the different splittings
                        double sum_p_unkn = 0;

                        // iterate over each TC piece to use that TC piece as held-out corpus 
                        // with the other TC pieces as actual training corpus
                        for (int i = 1; i <= 10; i++)
                        {
                            log.println2(
                                "DOP* training on split " + i + " ...");

                            String fileHOC =
                                trainPath + "corpus.tc" + i + "." + expNum;

                            // assemble the ATC file tmp_atc
                            String fileATC = tmpPath + "tmp_atc";
                            run("rm -f " + fileATC);
                            for (int j = 1; j <= 10; j++)
                            {
                                if (j != i)
                                    run(
                                        "cat "
                                            + trainPath
                                            + "corpus.tc"
                                            + j
                                            + "."
                                            + expNum
                                            + " >>"
                                            + fileATC);
                            }

                            // do DOP* training
                            if (heldOutCheating)
                            {
                                sum_p_unkn
                                    += getBetas(
                                        fileATC,
                                        fragPCFG,
                                        fileHOC,
                                        fragBetas);
                            } else if (heldOutUseLexicon)
                            {
                                sum_p_unkn
                                    += getBetas(
                                        fileATC,
                                        ovisLexicon,
                                        fileHOC,
                                        fragBetas);
                            } else
                            {
                                sum_p_unkn
                                    += getBetas(
                                        fileATC,
                                        new FragmentCorpus(),
                                        fileHOC,
                                        fragBetas);
                            }

                        }

                        // calculate avg. p_unkn in order to interpolate DOP1 or PCFG into the beta-weight corpus
                        p_unkn = sum_p_unkn / 10.0;
                    } // if (leavingOneOut) else branch

                    if (!heldOutCheating)
                    {
                        log.println2(
                            "Average p_unkn used for interpolation in the following: "
                                + p_unkn);
                    } else
                    {
                        p_unkn = .01;
                    }

                    /* write out the relatively small Beta Corpora for debugging and 
                     * analyzing purposes
                     */
                    System.out.println(
                        "Writing out Beta corpora to "
                            + trainPath
                            + "dopstar."
                            + expNum
                            + "/");
                    run("mkdir -p " + trainPath + "dopstar." + expNum + "/");
                    for (int i = 0; i < betaLevelsCount; i++)
                    {
                        long countFragBeta =
                            fragBetas[i].printFragments(
                                trainPath
                                    + "dopstar."
                                    + expNum
                                    + "/"
                                    + "beta_corpus_"
                                    + i);
                        log.println2(
                            "The DOP* Beta fragment corpus "
                                + i
                                + " contains "
                                + countFragBeta
                                + " fragments.");
                    }

                    FragmentCorpus fragDOPStar =
                        interpolateBetas(
                            fragBetas,
                            p_unkn * betaSmoothingFactor);

                    // compile the pure DOP* Corpus
                    compileFragmentCorpus(
                        fragDOPStar,
                        trainPath + "dopstar_purest." + expNum + "/",
                        true);

                    if (includeDopstarDop1)
                    {
                        // interpolate final beta-weight corpus with DOP1 
                        // for performance reasons, add (small) beta corpus to (big) DOP1 corpus
                        // this is ok, as long as p_unkn is not too small (cf. FragmentCorpus.weightedSum)			
                        {
                            log.println2(
                                "  CALCULATING DOP* CORPUS AS WEIGHTED SUM OF BETA AND DOP1 WEIGHTS ...");
                            long starttime2 = System.currentTimeMillis();
                            fragDOP1.weightedSum(
                                fragDOPStar,
                                p_unkn,
                                1 - p_unkn);
                            log.println2(
                                "  Time spent: " + timeSpendStr(starttime2));
                        }

                        //                if (ovis)
                        //                {
                        //                    // theoretically not necessary since lexicon is already contained 
                        //                    // in the DOP1 / PCFG portion
                        //                    log.println2(
                        //                        "  CALCULATING WEIGHTED SUM OF DOP* FRAGMENT CORPUS AND LEXICON ...");
                        //                    long starttime2 = System.currentTimeMillis();
                        //                    fragDOP1.weightedSum(ovisLexicon, 1 - 1.0E-10, 1.0E-10);
                        //                    log.println2("Time spent: " + timeSpendStr(starttime2));
                        //                }

                        // compile the DOP* corpus
                        compileFragmentCorpus(
                            fragDOP1,
                            trainPath + "dopstar_dopone." + expNum + "/",
                            true);
                    }

                    //FragmentCorpus fragBetaCopy = new FragmentCorpus();
                    //fragBetaCopy.add(fragBeta);

                    //            if (ovis)
                    //            {
                    //                // compile a DOP* version containing of the Beta corpus plus the lexicon
                    //                log.println2(
                    //                    "  CALCULATING WEIGHTED SUM OF DOP* FRAGMENT CORPUS AND LEXICON ...");
                    //                long starttime2 = System.currentTimeMillis();
                    //                fragBeta.weightedSum(ovisLexicon, 1 - 1.0E-10, 1.0E-10);
                    //                log.println2("Time spent: " + timeSpendStr(starttime2));
                    //
                    //                // compile the DOP* corpus
                    //                compileFragmentCorpus(
                    //                    fragBeta,
                    //                    trainPath + "dopstar_lexicon." + expNum + "/");
                    //            }

                    // interpolate final beta-weight corpus with PCFG 
                    {
                        log.println2(
                            "  CALCULATING DOP* CORPUS AS WEIGHTED SUM OF BETA AND PCFG WEIGHTS ...");
                        long starttime2 = System.currentTimeMillis();
                        fragDOPStar.weightedSum(
                            fragPCFG,
                            1 - 1.0E-20 * p_unkn,
                            1.0E-20 * p_unkn);
                        // the multiplication with p_unkn is a joke of course and serves merely
                        // to solve the ultra-extremist theoretician's worries of really 
                        // keeping the estimator consistent
                        log.println2(
                            "  Time spent: " + timeSpendStr(starttime2));
                    }

                    // compile the DOP*-PCFG corpus
                    compileFragmentCorpus(
                        fragDOPStar,
                        trainPath + "dopstar_pcfg." + expNum + "/",
                        true);
                } // end if (!onlyCreateSplittings)
            } // end includeDopstar

            log.println2(
                "TOTAL TIME SPENT FOR THIS TRAINING EXPERIMENT:  "
                    + timeSpendStr(starttime));

            run("ls -laht", tmpPath + ".");
        } // for loop expNum

        log.println2(
            "TOTAL TIME SPENT FOR ALL TRAINING EXPERIMENTS:  "
                + timeSpendStr(startTimeTrain)
                + "\nAverage n. o. shortest derivations encountered per held-out parse: "
                + (double) infoCountShortestDerivations
                    / (double) infoCountHeldOutTestedSentences);
    }

    /**
     * 
     * Test the given dopdis parsers for the different experiments.
     * @throws Exception
     */
    public static void test() throws Exception
    {
        test(null, startWithExperiment, totalExperimentsCount);
    }

    /**
     * specificTestCorpus == null: Test the given dopdis parsers for the different experiments startWithExperiment,...,totalExperimentsCount;
     * specificTestingCorpus != null: Test the given dopdis parsers on a specific testing corpus (in that case startWithExperiment and totalExperimentsCount should both equal one).
     * @throws Exception
     */
    public static void test(
        String specificTestCorpus,
        int startWithExperiment,
        int totalExperimentsCount)
        throws Exception
    {
        run("mkdir -p " + testPath);
        tmpPath = testPath;

        //if training procedure has not yet been called, make own test log
        if (log == null)
        {
            File file = new File(testPath + "test_log.txt");
            if (file.exists())
                run("cp -p test_log.txt test_log.txt.bak", testPath);

            log = new LogPrintWriter(testPath + "test_log.txt");
        }
        log.println2(
            "\n\n\n\n\n\n\n\n\n\n\n\n\n\ntestingMode=" + testingMode);
        if (specificTestCorpus == null)
        {
            log.print2("backOffParsers=");
            for (int i = 0; i < backOffParsers.length; i++)
                log.print2(backOffParsers[i] + " ");
        }
        log.println2("");
        log.println2("dopdisTestOptions=" + dopdisTestOptions);
        if (specificTestCorpus == null)
        {
            log.println2("totalExperimentsCount=" + totalExperimentsCount);
            log.println2("startWithExperiment=" + startWithExperiment);
            log.println2("trainPath=" + trainPath);
        }
        log.println2("testPath=" + testPath);
        log.println2(
            "monteCarloSamplingSizeTesting=" + monteCarloSamplingSizeTesting);

        //  long[] results = new long[experimentsCount * 4];

        int totalSubExpCount = testParsers.length;

        /*
         * contains the sum of all exact matches results of the different dopdis versions
         */
        double[] sumEM = new double[totalSubExpCount];

        /*
         * contains the sum of all non-single-word-sentence exact matches results of the various dopdis versions
         */
        double[] sumEMNonSingleWordSentences = new double[totalSubExpCount];

        //String[][] resultFiles = new String[experimentsCount][subExpCount];
        //String[][] resultFilesNonSingleWordSentences = new String[experimentsCount][subExpCount];

        for (int expNum = startWithExperiment;
            expNum <= totalExperimentsCount;
            expNum++)
        {
            Set existingParsesSet = new HashSet();
            long countSentences = 0;
            run("rm -f " + testPath + "gold" + "_nsws." + expNum);
            for (int subExpNum = 0;
                subExpNum < totalSubExpCount;
                subExpNum++)
            {
                long startTimeExp = System.currentTimeMillis();
                log.println2(
                    "\nSTART TESTING FOR EXPERIMENT "
                        + (specificTestCorpus == null ? (expNum + " - ") : "")
                        + testParsers[subExpNum]);

                long countUnkn = 0; // gonna be returned
                long countUnknBecauseUnknWord = 0;
                long countBackoffSentences = 0;
                long countSuccessfulBackoffs = 0;
                countSentences = 0;
                long countExactMatch = 0;
                long countExactMatchFirstTrial = 0;
                long countExactMatchFirstTrialNonSingleWordSentences = 0;
                long countExactMatchNonSingleWordSentences = 0;
                long countNonSingleWordSentences = 0;
                long countUnknNonSingleWordSentences = 0;
                long countCorrectParseExists = 0;
                long countCorrectParseExistsNonSingleWordSentences = 0;

                run(
                    "rm -f "
                        + testPath
                        + (specificTestCorpus != null
                            ? (subExpNum + "")
                            : testParsers[subExpNum])
                        + "."
                        + expNum);
                run(
                    "rm -f "
                        + testPath
                        + (specificTestCorpus != null
                            ? (subExpNum + "")
                            : testParsers[subExpNum])
                        + "_nsws."
                        + expNum);

                FileReader fr =
                    new FileReader(
                        specificTestCorpus != null
                            ? specificTestCorpus
                            : (trainPath + "corpus.test." + expNum));
                BufferedReader br = new BufferedReader(fr);

                String record = new String();

                for (long treeCnt = 1;
                    (record = br.readLine()) != null;
                    treeCnt++)
                {

                    StringTokenizer stTok =
                        new StringTokenizer(record, ".", false);

                    while (stTok.hasMoreTokens())
                    {
                        countSentences++;

                        // get next tree
                        String goldTreeStrWithoutSSS = stTok.nextToken();
                        goldTreeStrWithoutSSS = goldTreeStrWithoutSSS.trim();
                        goldTreeStrWithoutSSS =
                            goldTreeStrWithoutSSS.substring(
                                1,
                                goldTreeStrWithoutSSS.length() - 1);
                        Tree goldTreeWithoutSSS =
                            new Tree(goldTreeStrWithoutSSS);
                        String testSentenceString =
                            (goldTreeWithoutSSS).getYieldString();
                        Vector testSentenceVector =
                            (goldTreeWithoutSSS).getYield();

                        // store its described sentence in tmpFile
                        String tmpFileSentence =
                            tmpPath + "tmpTestSentence.tmp";
                        {
                            PrintWriter p; // declare a print stream object
                            p =
                                new PrintWriter(
                                    new BufferedWriter(
                                        new FileWriter(tmpFileSentence)));
                            //Tree tree = new Tree(treeStr);
                            p.println(testSentenceString + ".");
                            p.close();
                        }

                        //                        //	store current testing tree in tmpFile
                        //                        String tmpFileTree = tmpPath + "tmpTestTree.tmp";
                        //                        {
                        //                            PrintWriter p; // declare a print stream object
                        //                            p =
                        //                                new PrintWriter(
                        //                                    new BufferedWriter(
                        //                                        new FileWriter(tmpFileTree)));
                        //                            p.println("(" + goldTreeStr + ").");
                        //                            p.close();
                        //                        }

                        if (U.verbose)
                            System.out.println(
                                "PROCESSING TREE "
                                    + treeCnt
                                    + ": "
                                    + goldTreeStrWithoutSSS
                                    + "'.");
                        if (U.verbose)
                            System.out.println(
                                "Corresponding sentence: "
                                    + testSentenceString);
                        boolean singleWordSentence =
                            (testSentenceString.indexOf(' ') == -1);
                        if (singleWordSentence)
                        {
                            if (U.verbose)
                                System.out.println(
                                    "This sentence only consists of a single word.");
                        } else
                        {
                            countNonSingleWordSentences++;
                        }

                        /* This variable is set to true if we are testing on dopstar and
                         * no parse can be found (then we are backing off to
                         * `backOffParser').
                         */
                        boolean backingOff = false;

                        // the parse suggested by dopdis        
                        String dopdisPreferredParse = null;
                        // the correct parse
                        String goldTreeStr =
                            "sss,[(" + goldTreeStrWithoutSSS + ")]";

                        ParserOutput dopdisOutput = new ParserOutput();

                        if (specificTestCorpus == null)
                        {
                            /* 
                             * for efficiency, first check whether the parse is at all
                             * derivable from the trained grammar using the fast PCFG MPD parser
                             */
                            boolean tmpUnknBecauseUnknWord =
                                testSub(
                                    trainPath + "pcfg" + "." + expNum + "/",
                                    MPD,
                                    tmpFileSentence,
                                    goldTreeStrWithoutSSS,
                                    dopdisOutput);
                            if (tmpUnknBecauseUnknWord)
                            {
                                countUnknBecauseUnknWord++;
                                if (U.verbose)
                                    System.out.println(
                                        "Increased Unknown-because-of-an-unknown-word count.");
                            }
                        }
                        if (specificTestCorpus == null
                            && dopdisOutput.isEmpty())
                        {
                            // no parse has been found - no need to try the real parsers
                            countUnkn++;
                            if (!singleWordSentence)
                                countUnknNonSingleWordSentences++;
                            if (U.verbose)
                                System.out.println(
                                    "Increased Unknown count.");
                        } else
                        {
                            /* 
                             * call the dopdis parser and analyse its output, inserting it 
                             * in the ParserOutput TreeMap
                             */
                            dopdisOutput = new ParserOutput();
                            boolean unknBecauseUnknWord =
                                testSub(
                                    (specificTestCorpus != null
                                        ? testParsers[subExpNum]
                                        : (trainPath
                                            + testParsers[subExpNum]
                                            + "."
                                            + expNum))
                                        + "/",
                                    testingMode,
                                    tmpFileSentence,
                                    goldTreeStrWithoutSSS,
                                    dopdisOutput);

                            // determine dopdis's suggested parse
                            if (unknBecauseUnknWord)
                            {
                                countUnknBecauseUnknWord++;
                                if (U.verbose)
                                    System.out.println(
                                        "Increased Unknown-because-of-an-unknown-word count.");
                            }
                            if (dopdisOutput.isEmpty())
                            {
                                // on first trial, no parse has been found

                                countUnkn++;
                                if (!singleWordSentence)
                                    countUnknNonSingleWordSentences++;
                                if (U.verbose)
                                    System.out.println(
                                        "Increased Unknown count.");
                                if (testParsers[subExpNum]
                                    .startsWith("dopstar"))
                                {
                                    // try to back-off to other parsers and see if a parse can
                                    // be found this way	
                                    backingOff = true;
                                    countBackoffSentences++;
                                    for (int i = 0;
                                        i < backOffParsers.length
                                            && dopdisOutput.isEmpty();
                                        i++)
                                    {
                                        if (U.verbose)
                                            System.out.println(
                                                "Backing off to "
                                                    + backOffParsers[i]
                                                    + " ...");
                                        testSub(
                                            trainPath
                                                + backOffParsers[i]
                                                + "."
                                                + expNum
                                                + "/",
                                            testingMode,
                                            tmpFileSentence,
                                            goldTreeStrWithoutSSS,
                                            dopdisOutput);
                                    }
                                }
                            }
                        }
                        if (dopdisOutput.isEmpty())
                        {
                            // still, no parse has been found
                            dopdisPreferredParse =
                                Tree.sentenceToUnknTree(testSentenceVector);
                        } else
                        {
                            // get parse from the dopdis output that had the highest probability
                            Set mostProbableParses =
                                (Set) dopdisOutput.get(
                                    dopdisOutput.lastKey());

                            int shDSize = mostProbableParses.size();
                            ensure(
                                shDSize != 0,
                                "dopdis did output parses but there are no best ones");

                            // if there are several parses with highest probability, just take
                            // the first one according to the (unknown) Set ordering
                            Iterator i = mostProbableParses.iterator();
                            dopdisPreferredParse =
                                Tree.derivationToParse((String) i.next());
                        }

                        // evaluate dopdis's suggested parse
                        if (dopdisPreferredParse.equals(goldTreeStr))
                        {
                            countExactMatch++;
                            if (!singleWordSentence)
                                countExactMatchNonSingleWordSentences++;
                            if (backingOff)
                            {
                                countSuccessfulBackoffs++;
                            } else
                            {
                                countExactMatchFirstTrial++;
                                if (!singleWordSentence)
                                    countExactMatchFirstTrialNonSingleWordSentences++;
                            }
                            if (U.verbose)
                                System.out.println(
                                    "\ndopdis parsed CORRECTLY.\n");
                        } else
                        {
                            if (U.verbose)
                                System.out.println(
                                    "\ndopdis parsed FALSELY.\n");
                        }

                        if (dopdisOutput.containsTree(goldTreeStr))
                        {
                            /* the correct parse existed in the output of dopdis, i.e.,
                             * could have in principle found by the fragment weight 
                             * estimation method
                             */
                            countCorrectParseExists++;
                            if (!singleWordSentence)
                                countCorrectParseExistsNonSingleWordSentences++;
                            existingParsesSet.add(new Long(treeCnt));
                        }

                        // store the gold and dopdis parses for evalb evaluation
                        run(
                            "echo '("
                                + dopdisPreferredParse
                                + ").' >>"
                                + testPath
                                + (specificTestCorpus != null
                                    ? (subExpNum + "")
                                    : testParsers[subExpNum])
                                + "."
                                + expNum);
                        if (!singleWordSentence)
                        {
                            run(
                                "echo '("
                                    + dopdisPreferredParse
                                    + ").' >>"
                                    + testPath
                                    + (specificTestCorpus != null
                                        ? (subExpNum + "")
                                        : testParsers[subExpNum])
                                    + "_nsws."
                                    + expNum);
                            if (subExpNum == 0)
                                run(
                                    "echo '("
                                        + goldTreeWithoutSSS
                                        + ").' >>"
                                        + testPath
                                        + "gold"
                                        + "_nsws."
                                        + expNum);
                        }
                        if (U.verbose)
                            System.out.println();
                        if (U.verbose)
                            System.out.println();
                        if (U.verbose)
                            System.out.println();
                        if (U.verbose)
                            System.out.println();
                        if (U.verbose)
                            System.out.println();
                        if (U.verbose)
                            System.out.println();
                        if (U.verbose)
                            System.out.println();
                        if (U.verbose)
                            System.out.println();
                    }
                }
                br.close();

                long countSingleWordSentences =
                    countSentences - countNonSingleWordSentences;
                log.println2(
                    "TOTAL TESTING TIME SPENT FOR THIS SUBEXPERIMENT:  "
                        + timeSpendStr(startTimeExp));

                log.println2("Size of the testing corpus: " + countSentences);
                log.println2(
                    "N. o. single-word sentences: "
                        + countSingleWordSentences
                        + " (proportion: "
                        + 100.0
                            * (double) countSingleWordSentences
                            / (double) countSentences
                        + ")");
                log.println2(
                    "---------------------------------------------------------------\nALL SENTENCES:\n-----------");
                log.println2(
                    "Exact match rate: "
                        + 100.0
                            * (double) countExactMatch
                            / (double) countSentences
                        + " %");
                log.println2(
                    "Proportion of sentences for which no parse could be found on first trial: "
                        + 100.0 * (double) countUnkn / (double) countSentences
                        + " %");
                log.println2(
                    "Proportion of sentences for which no parse could be found (on first trial) because they contained unknown words: "
                        + 100.0
                            * (double) countUnknBecauseUnknWord
                            / (double) countSentences
                        + " %");
                log.println2(
                    "Proportion of sentences for which back-offs were performed: "
                        + 100.0
                            * (double) countBackoffSentences
                            / (double) countSentences
                        + " %");
                log.println2(
                    "Proportion of sentences with *successful* back-offs performed: "
                        + 100.0
                            * (double) countSuccessfulBackoffs
                            / (double) countSentences
                        + " %");
                log.println2(
                    "Proportion of exact matches amongst sentences for which a parse was found on first trial: "
                        + 100.0
                            * (double) countExactMatchFirstTrial
                            / (double) (countSentences - countUnkn)
                        + " %");
                if (testingMode == ALLMPP)
                    log.println2(
                        "Proportion of sentences for which the correct parse was derivable from the training data: "
                            + 100.0
                                * (double) countCorrectParseExists
                                / (double) countSentences
                            + " %");
                evalb(
                    (specificTestCorpus != null
                        ? specificTestCorpus
                        : (trainPath + "corpus.test." + expNum)),
                    testPath
                        + (specificTestCorpus != null
                            ? (subExpNum + "")
                            : testParsers[subExpNum])
                        + "."
                        + expNum);

                if (showNonSingleWordSentencesResults)
                {
                    log.println2(
                        "---------------------------------------------------------------\nNON-SINGLE-WORD SENTENCES\n-------------------------");
                    log.println2(
                        "Exact match rate: "
                            + 100.0
                                * (double) countExactMatchNonSingleWordSentences
                                / (double) countNonSingleWordSentences
                            + " %");
                    log.println2(
                        "Proportion of sentences for which no parse could be found (on first trial): "
                            + 100.0
                                * (double) countUnknNonSingleWordSentences
                                / (double) countNonSingleWordSentences
                            + " %");
                    log.println2(
                        "Proportion of exact matches amongst sentences for which a parse was found on first trial: "
                            + 100.0
                                * (double) countExactMatchFirstTrialNonSingleWordSentences
                                / (double) (countNonSingleWordSentences
                                    - countUnknNonSingleWordSentences)
                            + " %");
                    if (testingMode == ALLMPP)
                        log.println2(
                            "Proportion of sentences for which the correct parse was derivable from the training data: "
                                + 100.0
                                    * (double) countCorrectParseExistsNonSingleWordSentences
                                    / (double) countNonSingleWordSentences
                                + " %");
                    evalb(
                        testPath + "gold" + "_nsws." + expNum,
                        testPath
                            + (specificTestCorpus != null
                                ? (subExpNum + "")
                                : testParsers[subExpNum])
                            + "_nsws."
                            + expNum);
                }

                log.println2(
                    "---------------------------------------------------------------\nSINGLE-WORD SENTENCES:");
                log.println2(
                    "Exact match rate: "
                        + 100.0
                            * (double) (countExactMatch
                                - countExactMatchNonSingleWordSentences)
                            / (double) countSingleWordSentences
                        + " %");
                log.println2(
                    "Proportion of sentences for which no parse could be found (on first trial): "
                        + 100.0
                            * (double) (countUnkn
                                - countUnknNonSingleWordSentences)
                            / (double) countSingleWordSentences
                        + " %");
                log.println2("==================================\n");

                sumEM[subExpNum] += (double) countExactMatch
                    / (double) countSentences;
                sumEMNonSingleWordSentences[subExpNum]
                    += (double) countExactMatchNonSingleWordSentences
                    / countNonSingleWordSentences;
            }
            if (testingMode == ALLMPP)
                log.println2(
                    "Proportion of sentences for which the correct parse was derivable from the training data from at least one of the dopdis programs: "
                        + 100.0
                            * (double) existingParsesSet.size()
                            / (double) countSentences
                        + " %"
                        + "\n====================================\n\n");
        }

        if (specificTestCorpus == null)
        {
            log.println2(
                "\n================================================\n");
            log.println2(
                "Parser\tAverage exact match\tAvg. EM non-single-w.");

            for (int subExpNum = 0;
                subExpNum < totalSubExpCount;
                subExpNum++)
            {
                log.println2(
                    testParsers[subExpNum]
                        + "\t"
                        + 100.0
                            * sumEM[subExpNum]
                            / (double) (totalExperimentsCount
                                + 1
                                - startWithExperiment)
                        + " %"
                        + "\t"
                        + 100.0
                            * sumEMNonSingleWordSentences[subExpNum]
                            / (double) (totalExperimentsCount
                                + 1
                                - startWithExperiment)
                        + " %");
            }
            for (int subExpNum = 0;
                subExpNum < totalSubExpCount;
                subExpNum++)
            {
                String goldFileList = "";
                String goldFileListNSWS = "";
                String resultFileList = "";
                String resultFileListNSWS = "";
                for (int i = startWithExperiment;
                    i <= totalExperimentsCount;
                    i++)
                {
                    goldFileList += trainPath + "corpus.test." + i + " ";
                    goldFileListNSWS += testPath
                        + "gold"
                        + "_nsws."
                        + i
                        + " ";
                    resultFileList += testPath
                        + testParsers[subExpNum]
                        + "."
                        + i
                        + " ";
                    resultFileListNSWS += testPath
                        + testParsers[subExpNum]
                        + "_nsws."
                        + i
                        + " ";
                }

                log.println2(
                    "\n================================================"
                        + "\n"
                        + testParsers[subExpNum]);
                log.println2(
                    "---------------------------------------------------------------\nALL SENTENCES:\n-----------");
                evalb(goldFileList, resultFileList);

                if (showNonSingleWordSentencesResults)
                {
                    log.println2(
                        "---------------------------------------------------------------\nNON-SINGLE-WORD SENTENCES\n-------------------------");
                    evalb(goldFileListNSWS, resultFileListNSWS);
                }
            }
        }
    }

    /**
     * Runs the dopdis parser on a test sentence. Called by `test()'. Returns `true' iff a parse
     * could not be found because of an unknown word in the sentence. 
     */
    private static boolean testSub(
        String dopdisPath,
        int myTestingMode,
        String inputSentenceFile,
        String goldTreeStrWithoutSSS,
        ParserOutput dopdisOutput)
        throws IOException
    {
        String dopdis = dopdisPath + "dopdis " + dopdisTestOptions + " ";
        dopdis += myTestingMode == MPP
            ? "-m" + monteCarloSamplingSizeTesting
            : (myTestingMode == ALLMPP
                ? "-M" + monteCarloSamplingSizeTesting
                : (myTestingMode == MPD
                    ? ""
                    : (myTestingMode == MRP ? "-d" : "(syntax error)")));

        if (U.verbose)
            System.out.println("Running " + dopdis + " ...");

        int exitVal =
            run(
                dopdis
                    + " <"
                    + inputSentenceFile
                    + " >"
                    + testPath
                    + ".dopdisStdOut",
                dopdisPath,
                testPath + ".dopdisErrOut");

        //if (U.verbose) System.out.println(
        //    "Extracting the fragments involved in a shortest derivation to the beta-corpus ...");

        ensure(exitVal == 0, "dopdis exited with error code " + exitVal);
        boolean onlyPreferredParseReturned = myTestingMode != ALLMPP;
        boolean unknBecauseUnknWord = false;
        try
        {
            unknBecauseUnknWord =
                dopdisOutput.parseOutput(
                    testPath + ".dopdisStdOut",
                    testPath + ".dopdisErrOut",
                    onlyPreferredParseReturned);
        } catch (IOException e)
        {
            /* 
             * some problem occurred - probably went out of memory
             * go on anyway (treat parse as unknown), but
             * report to log file
             */
            log.println2(
                "The following exception occurred when getting dopdis' output! Processed tree was: "
                    + goldTreeStrWithoutSSS);
            e.printStackTrace();
            e.printStackTrace(log);
        }
        return unknBecauseUnknWord;
    }

    /**
     * Runs Collin's `evalb' program to evaluate the parses in the files testFileList 
     * against the parses in the files goldFileList.
     * @param goldFileList A space-separated list of the files containing the 
     * correct parses. White space at the beginning or end of the list will
     * be trimmed.
     * @param testFileList As above for the parses to test.
     */
    public static void evalb(String goldFileList, String testFileList)
        throws IOException
    {
        /*
         * First create the test sentences from the gold parse trees:
         * The call of GetSentences returns the sentences line by line preceded by
         * the string 'SENTENCE: '. Use perl regexp substitution to
         * remove those strings from each line.
         */
        runDirectly(
            "cat "
                + goldFileList
                + " 2>"
                + U.unixOutputDevice
                + " | "
                + "GetSentences 2>"
                + U.unixOutputDevice
                + " | "
                + "perl -p -e 's/SENTENCE: //g;' 2>"
                + U.unixOutputDevice
                + " >"
                + "tmp_evalb_sentences",
            tmpPath);
        /*
         * now convert the gold and test parse trees into WSJ format using
         * rev_conv_wsj. The parameter -s specifies the file with the sentences.
         * They are used to create some "unknown"-parse in the case that dopdis
         * returned a line like "(sss,[(XXXnonOemptydf,[])])." (therefore this
         * option is actually only necessary for the conversion of `testFileList').
         */
        runDirectly(
            "cat "
                + goldFileList
                + " 2>"
                + U.unixOutputDevice
                + " | rev_conv_wsj -s tmp_evalb_sentences 2>"
                + U.unixOutputDevice
                + " >"
                + "tmp_evalb_gold",
            tmpPath);
        runDirectly(
            "cat "
                + testFileList
                + " 2>"
                + U.unixOutputDevice
                + " | rev_conv_wsj -s tmp_evalb_sentences 2>"
                + U.unixOutputDevice
                + " >"
                + "tmp_evalb_test",
            tmpPath);

        /*
         * finally, we are ready to run `evalb'
         */
        runDirectly(
            "evalb -p "
                + dopstarPath
                + "COLLINS.prm"
                + " tmp_evalb_gold tmp_evalb_test 2>"
                + U.unixOutputDevice
                + " |tail -25 2>"
                + U.unixOutputDevice
                + " >tmp_evalb_out",
            tmpPath);

        /*
         * print `evalb''s output to the log file and to the screen
         */
        log.printFile2(tmpPath + "tmp_evalb_out");
    }

    /**
     * Randomly splits off `splitCount' lines from file `source' 
     * (only file name without path!) in directory `dir'. The target files are allowed 
     * to exist already (will then be overwritten) and one of them may even be
     * identical to the source file (in which case the source file is overwritten).
     * @param dir
     * @param source
     * @param splitCount
     * @param target1 File to be created that contains the lines that were NOT split off. May include a path (if not, `dir' is assumed).
     * @param target2 File to be created that contains the lines that were split off. May include a path (if not, `dir' is assumed).
     */
    public static void split(
        String dir,
        String source,
        long splitCount,
        String target1,
        String target2)
        throws IOException
    {
        /* split it:
          * -f inFile 
          * -d directory (only local name possible) 
          * -n numOfLinesToSplitOff 
          * -e extension to append to the resulting files inFile.train and inFile.test 
          * 
          */
        run(
            "python2.2 "
                + dopstarPath
                + "splitrandom.py -f "
                + source
                + " -d . -n "
                + splitCount
                + " -e .tmp_split",
            dir);
        run("mv " + source + ".train.tmp_split " + target1, dir);
        run("mv " + source + ".test.tmp_split " + target2, dir);
    }

    public static FragmentCorpus dop1Train(
        String corpusFile,
        FragmentCorpus interpolant)
        throws Exception
    {
        long startTimeExp = System.currentTimeMillis();

        log.println2(
            "TRAINING AND COMPILING DOP1 ON CORPUS " + corpusFile + ".");

        System.out.println(
            "Getting rid of words leaving unknown only, then get rid of ");
        System.out.println(
            "unary productions - transforming into short form (.atc_stsg1shf) ...");
        run("pro2shf " + corpusFile + ">.atc_stsg1shf", tmpPath + ".");
        System.out.println(
            "Extracting the rules (into file .atc_stsg2dop1) ...");
        // lugiano: "-d3 -l7 -n2 -L3"
        run(
            "gen-t-grams -1 "
                + dop1FragmentOptions
                + "  -i .atc_stsg1shf -o .atc_stsg2dop1",
            tmpPath + ".");

        FragmentCorpus fc = new FragmentCorpus();
        System.out.println("Reading .atc_stsg2dop1 into FragmentCorpus ...");
        {
            long starttime = System.currentTimeMillis();
            long cnt = fc.addOfflineCorpus(tmpPath + ".atc_stsg2dop1");
            log.println2(cnt + " fragments.");
            printTimeSpentMsg(starttime);
        }

        if (interpolant != null)
        {
            log.println2(
                "CALCULATING WEIGHTED SUM OF DOP1 FRAGMENT CORPUS AND INTERPOLANT...");
            long starttime2 = System.currentTimeMillis();
            fc.weightedSum(interpolant, 1 - 1.0E-10, 1.0E-10);
            log.println2("Time spent: " + timeSpendStr(starttime2));
        }

        log.println2(
            "Total time spent for DOP1 training: "
                + timeSpendStr(startTimeExp));
        return fc;
    }

    public static FragmentCorpus pcfgTrain(String corpusFile) //, String destPath)
    throws Exception
    {
        long startTimeExp = System.currentTimeMillis();

        log.println2(
            "TRAINING AND COMPILING PCFG-PARSER ON CORPUS "
                + corpusFile
                + ".");

        if (U.verbose)
            System.out.println(
                "Getting rid of words leaving unknown only, then get rid of ");
        if (U.verbose)
            System.out.println(
                "unary productions - transforming into short form (.atc_stsg1shf) ...");
        run("pro2shf " + corpusFile + ">.atc_stsg1shf", tmpPath + ".");
        if (U.verbose)
            System.out.println(
                "Extracting the rules (into file .atc_stsg2dop1) ...");
        // max. depth 200 (-d200), max. n.o. nonterminal leaves 5 (-n5)
        run(
            "gen-t-grams  -d1" + "  -i .atc_stsg1shf -o .atc_stsg2dop1",
            tmpPath + ".");

        FragmentCorpus fc = new FragmentCorpus();
        if (U.verbose)
            System.out.println(
                "Reading .atc_stsg2dop1 into FragmentCorpus ...");
        {
            long starttime = System.currentTimeMillis();
            long cnt = fc.addOfflineCorpus(tmpPath + ".atc_stsg2dop1");
            log.println2(cnt + " fragments.");
            printTimeSpentMsg(starttime);
        }

        if (ovis)
        {
            log.println2(
                "CALCULATING WEIGHTED SUM OF PCFG FRAGMENT CORPUS AND LEXICON...");
            long starttime2 = System.currentTimeMillis();
            fc.weightedSum(ovisLexicon, 1 - 1.0E-10, 1.0E-10);
            log.println2("Time spent: " + timeSpendStr(starttime2));
        }

        log.println2(
            "Total time spent for PCFG training: "
                + timeSpendStr(startTimeExp));
        return fc;
    }

    public static void compileFragmentCorpus(
        FragmentCorpus fc,
        String destPath)
        throws Exception
    {
        compileFragmentCorpus(fc, destPath, verbose);
    }

    public static void compileFragmentCorpus(
        FragmentCorpus fc,
        String destPath,
        boolean verboseMode)
        throws Exception
    {
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        log.println2("COMPILING " + destPath + "dopdis ...");
        long startCompileTime = System.currentTimeMillis();

        run("mkdir -p " + destPath);
        //		create files needed for temporary compiling
        run(
            "echo DIR = "
                + dopstarPath
                + "../objects >"
                + destPath
                + "Make_DOPDIS");
        run(
            "cat Make_DOPDIS_parameters >>" + destPath + "Make_DOPDIS",
            dopstarPath);
        run("cp -p parameters.c " + destPath, dopstarPath);

        System.out.println("Writing fragment corpus to tmp_stsg3 ...");
        {
            long starttime = System.currentTimeMillis();
            long cnt = fc.printFragments(destPath + "tmp_stsg3");
            log.println2(cnt + " fragments.");
            printTimeSpentMsg(starttime);
        }

        boolean verboseBak = verbose;
        verbose = verboseMode;
        System.out.println(
            "Transforming rules into Extended Chomsky Normal Form (tmp_stsg4ecnf) ...");
        run("SubCFG2ECNF tmp_stsg3 > tmp_stsg4ecnf", destPath + ".");

        System.out.println(
            "Transforming grammar into a convenient representation (tmp_stsg5rb) ...");
        run("SUB-2-RBSTSG tmp_stsg4ecnf tmp_stsg5rb", destPath + ".");
        System.out.println(
            "Transforming grammar again into C data-structures and extra binary files (GrammarSingle.c) ...");
        run("RB-2-CandF -i tmp_stsg5rb -o GrammarSingle.c", destPath + ".");
        run("FindChs", destPath + ".");

        run(
            "rm -f dopdis unary_bamboo_functions.o TheGramInitSingle.o",
            destPath + ".");

        System.out.println("Compiling the parser (dopdis) ...");
        run("make dopdis -f Make_DOPDIS >.DEBUGmake", destPath + ".");

        //the following three files are the only ones needed for running dopdis - everything
        // else can be deleted after the training session:
        // run("cp -p dopdis " + destPath, destPath);
        // run("cp -p .ChildPlace.bin " + destPath, destPath);
        // run("cp -p .CodesList.bin " + destPath, destPath);
        log.println2(
            "Total time spent for compiling: "
                + timeSpendStr(startCompileTime));
        verbose = verboseBak;
    }

    public static void getATCFragments(
        String atcFile,
        FragmentCorpus fragATCInterpolant,
        FragmentCorpus fragATC)
        throws Exception
    {
        long startTimeExp = System.currentTimeMillis();

        log.println2("  GETTING ATC-FRAGMENTS FROM CORPUS " + atcFile + ".");

        System.out.println(
            "Getting rid of words leaving unknown only, then get rid of ");
        System.out.println(
            "unary productions - transforming into short form (.atc_stsg1shf) ...");
        run("pro2shf " + atcFile + ">.atc_stsg1shf", tmpPath + ".");
        System.out.println(
            "Extracting the rules (into file .atc_stsg2dop1) ...");
        // max. depth 200 (-d200), max. n.o. nonterminal leaves 5 (-n5)
        run(
            "gen-t-grams -1 "
                + dopStarFragmentOptions
                + "  -i .atc_stsg1shf -o .atc_stsg2dop1",
            tmpPath + ".");

        System.out.println(
            "Reading .atc_stsg2dop1 into ATC-FragmentCorpus ...");
        {
            long starttime = System.currentTimeMillis();
            long cnt = fragATC.addOfflineCorpus(tmpPath + ".atc_stsg2dop1");
            log.println2(cnt + " fragments.");
            printTimeSpentMsg(starttime);
        }

        if (fragATCInterpolant != null)
        {
            System.out.println("Adding the ATC interpolant ...");
            /* After the call of add, our fragment corpus will not be normalized anymore.
             * That does not matter since we don't care about the fragments' weights.
             */
            fragATC.add(fragATCInterpolant);
        }

        log.println2(
            "  Total time spent for getting ATC fragments: "
                + timeSpendStr(startTimeExp));
    }

    public static double getBetas(
        String fileATC,
        FragmentCorpus fragATCInterpolant,
        String fileHOC,
        FragmentCorpus[] betas)
        throws Exception
    {
        // create the ATC fragments from the ATC file
        FragmentCorpus fragATC = new FragmentCorpus();
        getATCFragments(fileATC, fragATCInterpolant, fragATC);

        log.println2(
            "  GETTING BETA-WEIGHTS using held-out corpus " + fileHOC + ".");

        long countUnkn = 0; // gonna be returned
        long countUnknBecauseUnknWord = 0;
        long sizeHOC = 0;
        long startTimeExp = System.currentTimeMillis();

        FileReader fr = new FileReader(fileHOC);
        BufferedReader br = new BufferedReader(fr);

        String record = new String();

        for (long treeCnt = 1;(record = br.readLine()) != null; treeCnt++)
        {

            StringTokenizer stTok = new StringTokenizer(record, ".", false);

            while (stTok.hasMoreTokens())
            {
                sizeHOC++;
                infoCountHeldOutTestedSentences++;

                // get next tree from HOC
                String treeStr = stTok.nextToken();
                treeStr = treeStr.trim();
                treeStr = treeStr.substring(1, treeStr.length() - 1);
                String treeYield = (new Tree(treeStr)).getYieldString();

                // store its Viterbi Format represenation in tmpFile
                String tmpFileViterbi = tmpPath + "tmpBetaViterbi.tmp";
                {
                    PrintWriter p; // declare a print stream object
                    p =
                        new PrintWriter(
                            new BufferedWriter(
                                new FileWriter(tmpFileViterbi)));
                    //!!!Tree tree = new Tree(treeStr);
                    //!!!p.println(tree.toViterbiFormatString() + ".");
                    p.println(treeYield + ".");
                    p.close();
                }

                //	store current HOC tree in tmpFile
                String tmpFileTree = tmpPath + "tmpBetaTree.tmp";
                {
                    PrintWriter p; // declare a print stream object
                    p =
                        new PrintWriter(
                            new BufferedWriter(new FileWriter(tmpFileTree)));
                    p.println("(" + treeStr + ").");
                    p.close();
                }

                if (U.verbose)
                    System.out.println(
                        "PROCESSING TREE " + treeCnt + ": " + treeStr + "'.");
                if (U.verbose)
                    System.out.println(
                        "Getting rid of words leaving unknown only, then get rid of ");
                if (U.verbose)
                    System.out.println(
                        "unary productions - transforming into short form (.stsg1shf) ...");

                run("pro2shf " + tmpFileTree + ">.stsg1shf", tmpPath + ".");

                if (U.verbose)
                    System.out.println(
                        "Extracting the fragments (into file .stsg2dop1) ...");
                // max. depth 200
                run(
                    "gen-t-grams -1 "
                        + dopStarFragmentOptions
                        + "  -i .stsg1shf -o .stsg2dop1",
                    tmpPath + ".");

                if (U.verbose)
                    System.out.println(
                        "Intersecting fragments with Frag(ATC) (.stsg3shortest) ...");
                FragmentCorpus fc = new FragmentCorpus();
                if (U.verbose)
                    System.out.println(
                        "              Reading in .stsg2dop1 ...");
                {
                    long starttime = System.currentTimeMillis();
                    fc.addOfflineCorpus(tmpPath + ".stsg2dop1");
                    if (U.verbose)
                        printTimeSpentMsg(starttime);
                }
                // if (U.verbose) System.out.println("              creating copy ...");                
                // FragmentCorpus fcCopy = fc.getCopy();
                if (U.verbose)
                    System.out.println(
                        "              Computing intersection ...");
                //fc.printFragments(tmpPath + "tmptest_dop1");
                //fragATC.printFragments(tmpPath + "tmptest_atc");
                boolean somethingDeleted;
                {
                    long starttime = System.currentTimeMillis();
                    somethingDeleted = fc.intersection(fragATC);
                    if (U.verbose)
                        printTimeSpentMsg(starttime);
                }
                if (U.verbose)
                    System.out.println(
                        "              Writing to .stsg3shortest ...");
                {
                    long starttime = System.currentTimeMillis();
                    fc.printFragments(tmpPath + ".stsg3shortest", true);
                    if (U.verbose)
                        printTimeSpentMsg(starttime);
                }

                fc.dispose();

                //System.out.println("Contents of .stsg3shortest: ");
                //run("cat " + ".stsg3shortest", tmpPath + ".");

                if (U.verbose)
                    System.out.println(
                        "Transforming rules into Extended Chomsky Normal Form (.stsg4ecnf) ...");
                run("SubCFG2ECNF .stsg3shortest > .stsg4ecnf", tmpPath + ".");
                //catch nonlexical problem: no problem anymore since there is always
                //the terminal xxxphrase_ in the grammar
                if (U.verbose)
                    System.out.println(
                        "Transforming grammar into a convenient representation (.stsg5rb) ...");
                run("SUB-2-RBSTSG .stsg4ecnf .stsg5rb", tmpPath + ".");

                if (U.verbose)
                    System.out.println(
                        "Transforming grammar again into C data-structures and extra binary files (GrammarSingle.c) ...");
                run(
                    "RB-2-CandF -i .stsg5rb -o GrammarSingle.c",
                    tmpPath + ".");
                run("FindChs", tmpPath + ".");

                if (U.verbose)
                    System.out.println("Compiling the parser (dopdis) ...");
                run(
                    "rm -f dopdis unary_bamboo_functions.o TheGramInitSingle.o",
                    tmpPath + ".");
                run("make dopdis -f Make_DOPDIS >.DEBUGmake", tmpPath + ".");

                if (U.verbose)
                    System.out.println("Running dopdis ...");
                //run("cat " + tmpFileViterbi, tmpPath + ".");
                int exitVal = run(
                    //!!! "dopdis -f1
    "./dopdis -C -K"
        + monteCarloSamplingSizeBeta
        + " <"
        + tmpFileViterbi
        + " >.dopdisStdOut",
        tmpPath + ".",
                    //tmpPath + ".dopdisStdOut",
    tmpPath + ".dopdisErrOut");

                if (U.verbose)
                    System.out.println(
                        "Extracting the fragments involved in a shortest derivation to the beta-corpus ...");

                FilteredParserOutput dopdisOutput =
                    new FilteredParserOutput(treeStr);

                // parse the output of dopdis                
                if (exitVal != 0)
                {
                    // dopdis exited with error - probably because training treebank file 
                    // tmpFileTree is empty
                    // that means that everything from the current held-out corpus tree
                    // is unknown, even the nonterminals

                    // -> increase countUnknBecauseUnknWord 
                    countUnknBecauseUnknWord++;
                    if (U.verbose)
                        System.out.println(
                            "Increased Unknown-because-of-an-unknown-word count.");

                    // also leave dopdisOutput empty -> later countUnkn will be increased

                } else
                {
                    boolean unknBecauseUnknWord = false;
                    try
                    {
                        unknBecauseUnknWord =
                            dopdisOutput.parseOutput(
                                tmpPath + ".dopdisStdOut",
                                tmpPath + ".dopdisErrOut");
                    } catch (IOException e)
                    {
                        /* 
                         * some problem occurred - probably went out of memory
                         * go on anyway (treat parse as unknown), but
                         * report to log file
                         */
                        log.println2(
                            "The following exception occurred when getting dopdis' output! Processed tree was: "
                                + treeStr);
                        e.printStackTrace();
                        e.printStackTrace(log);
                    }
                    if (unknBecauseUnknWord)
                    {
                        countUnknBecauseUnknWord++;
                        if (U.verbose)
                            System.out.println(
                                "Increased Unknown-because-of-an-unknown-word count.");
                    }
                }

                if (dopdisOutput.isEmpty())
                {
                    countUnkn++;
                    if (U.verbose)
                        System.out.println("Increased Unknown count.");
                    ensure(
                        somethingDeleted,
                        "dopdis didn't find parse although no fragment of hoc tree was deleted. Concerned tree: "
                            + treeStr);
                    if (unknownExtraction)
                    {
                        if (U.verbose)
                            System.out.println(
                                "Adding frags of this parse to beta corpus:");
                        if (U.verbose)
                            System.out.println(
                                "		Extracting the fragments (into file .stsg2dop1) ...");
                        run(
                            "gen-t-grams -1 "
                                + dopStarUnknownExtractionFragmentOptions
                                + "  -i .stsg1shf -o .stsg2dop1",
                            tmpPath + ".");
                        if (U.verbose)
                            System.out.println(
                                "		Reading in fragments of .stsg2dop1 ...");
                        betas[0].addOfflineCorpus(
                            tmpPath + ".stsg2dop1",
                            unknownFactor);
                    }
                } else
                {
                    for (int i_betas = 0;
                        i_betas < betas.length && !dopdisOutput.isEmpty();
                        i_betas++)
                    {
                        /* if i_betas = 0: get shortest derivations (i.e., derivations from the dopdis output
                         *  which had the highest probability)
                         * if i_betas > 0: get derivations of length shortest_deriv_length + i_betas
                         */

                        //                        SortedMap sortedMap = dopdisOutput;
                        //                        for (int ii = 0; ii < i_betas; ii++) {
                        //                        	sortedMap = sortedMap.headMap(sortedMap.lastKey());
                        //                        }

                        Set shortestDerivations =
                            (Set) dopdisOutput.get(dopdisOutput.lastKey());

                        // delete current set of shortest derivations
                        // -> make way for second-shortest derivations used in next round
                        dopdisOutput.remove(dopdisOutput.lastKey());

                        // now add currently shortest derivations to respective beta corpus

                        int shDSize = shortestDerivations.size();
                        if (i_betas == 0)
                        {
                            // we are really talking about the shortest derivations

                            infoCountShortestDerivations += shDSize;

                            //                            if (!somethingDeleted)
                            //                            {
                            //                                ensure(
                            //                                    shDSize
                            //                                        == 1
                            //                                            & shortestDerivations.contains(
                            //                                                "*sss,[(*" + treeStr + ")]"),
                            //                                    "no fragment of hoc tree was deleted but dopdis's output contains more than one parse or does not contain a length-one derivation of that very tree.  Concerned tree: "
                            //                                        + treeStr);
                            //                            }
                        }
                        double normalizationFactor = 1.0 / shDSize;
                        for (Iterator i = shortestDerivations.iterator();
                            i.hasNext();
                            )
                        {
                            String ss = (String) i.next();
                            betas[i_betas].addDerivationFragments(
                                ss,
                                normalizationFactor);
                        }
                    }
                }
                if (U.verbose)
                    System.out.println();
                if (U.verbose)
                    System.out.println();
                if (U.verbose)
                    System.out.println();
                if (U.verbose)
                    System.out.println();
                if (U.verbose)
                    System.out.println();
                if (U.verbose)
                    System.out.println();
                if (U.verbose)
                    System.out.println();
                if (U.verbose)
                    System.out.println();
            }
        }
        run("ls -laht", tmpPath + ".");
        System.gc();

        br.close();

        log.println2(
            "  Time spent for obtaining beta corpus:  "
                + timeSpendStr(startTimeExp));

        log.println2("  Size of the held-out corpus used: " + sizeHOC);
        log.println2(
            "  Proportion of sentences for which no parse could be found: "
                + (double) countUnkn / (double) sizeHOC);
        log.println2(
            "  Proportion of sentences for which no parse could be found because they contained unknown words: "
                + (double) countUnknBecauseUnknWord / (double) sizeHOC);
        return (double) countUnkn / (double) sizeHOC;
    }

    /**
     * Interpolates the Beta Corpora together and saves the result in fragBetas[0] 
     * (all elements of the fragBetas array are modified except the last one!).
     * FragmentCorpus fragBetas[i] gets the interpolation weight
     * (1-factor)*factor^i if 0 <= i <= fragBetas.length-2 resp.
     * factor^i if i=fragBetas.length-1
     * @param fragBetas
     * @param factor
     * @return reference to the resulting fragment corpus fragBetas[0]
     * @throws IOException
     */
    public static FragmentCorpus interpolateBetas(
        FragmentCorpus[] fragBetas,
        double factor)
        throws Exception
    {
        log.print2("Interpolating Betas together ... ");
        long starttime = System.currentTimeMillis();
        for (int i = fragBetas.length - 2; i >= 0; i--)
        {
            fragBetas[i].weightedSum(fragBetas[i + 1], 1 - factor, factor);
        }
        log.println2(timeSpendStr(starttime));
        return fragBetas[0];
    }

    //    /**
    //     * Creates depth1 fragments from the training corpora in FileList. 
    //     * @param FileList space-separated list of file names of the training corpora
    //     * @return the resulting depth1 fragment corpus
    //     * @throws Exception
    //     */
    //    public static FragmentCorpus getGammas(String fileList) throws Exception
    //    {
    //        log.print2("GETTING GAMMA-WEIGHTS: ");
    //        long startTimeGamma = System.currentTimeMillis();
    //        FragmentCorpus gammas = new FragmentCorpus();
    //        log.println2(
    //            "CREATING DEPTH-1-FRAGMENTS FROM TRAINING CORPORA ["
    //                + fileList
    //                + "]");
    //        System.out.println(
    //            "Getting rid of words leaving unknown only, then get rid of ");
    //        System.out.println(
    //            "unary productions - transforming into short form (.depth1_stsg1shf) ...");
    //        runDirectly(
    //            "2>"+U.unixOutputDevice+" cat "
    //                + fileList
    //                + "| pro2shf >.depth1_stsg1shf 2>"+U.unixOutputDevice+"",
    //            tmpPath + ".");
    //        System.out.println(
    //            "Extracting the rules (into file .depth1_stsg2dop1) ...");
    //        run(
    //            "gen-t-grams  -d1  -i .depth1_stsg1shf -o .depth1_stsg2dop1",
    //            tmpPath + ".");
    //
    //        System.out.println(
    //            "Reading .depth1_stsg2dop1 into Gamma-FragmentCorpus ...");
    //        {
    //            long starttime = System.currentTimeMillis();
    //            long cnt = gammas.addOfflineCorpus(tmpPath + ".depth1_stsg2dop1");
    //            log.println2(cnt + " fragments in Gamma corpus.");
    //            printTimeSpent(starttime);
    //        }
    //        log.println2(
    //            "Time spent for getting Gamma weights: "
    //                + timeSpent(startTimeGamma));
    //        return gammas;
    //    }

    public static void buildLexicon() throws Exception
    {
        System.out.println("EXTRACTING LEXICAL ITEMS FROM OVIS ...");
        {
            run("pro2shf " + corpusFile + " corpus.shf", tmpPath);
            run(
                "gen-t-grams.old -Co -p -q -d1 -l1 -n0 -F -i corpus.shf -o corpus.lexicon.tmp",
                tmpPath);
            run(
                "python2.2 "
                    + dopstarPath
                    + "getLexicon.py -f corpus.lexicon.tmp -L corpus.lexicon.unnormalized -F corpus.nolex.tmp",
                tmpPath);

            run("cat sss.out >> corpus.lexicon.unnormalized", tmpPath);
            run(
                "python2.2 "
                    + dopstarPath
                    + "normalize.py -f corpus.lexicon.unnormalized -F corpus.lexicon.normalized",
                tmpPath);
        }
        System.out.println();
        ovisLexicon = new FragmentCorpus();
        System.out.println(
            "READING IN LEXICON corpus.lexicon.normalized ...");
        long starttime = System.currentTimeMillis();
        long cnt =
            ovisLexicon.addOfflineCorpus(
                tmpPath + "corpus.lexicon.normalized");
        System.out.println(cnt + " fragments read.");
        printTimeSpentMsg(starttime);
    }

    /**
     * Adds file treebankFileName to tree bank `treebank'. 
     * For each each sentence in the file it creates a new tree in vector treebank 
     * 
     * @param treebankFileName Name of the tree bank file
     * @param treebank Each element of the vector is one tree 
     * in the corpus (an element of type Tree)
     * @throws IOException
     */
    public static void Readtreebank(String treebankFileName, Vector treebank)
        throws Exception
    {

        FileReader fr = new FileReader(treebankFileName);
        BufferedReader br = new BufferedReader(fr);

        String record = new String();

        System.out.print("  (Lines processed: ");
        for (long cnt = 0;(record = br.readLine()) != null; cnt++)
        {
            if (cnt % 1000 == 0 && cnt != 0)
            {
                System.out.print(cnt + ", ");
            }

            StringTokenizer stTok = new StringTokenizer(record, ".", false);

            while (stTok.hasMoreTokens())
            {
                String s = stTok.nextToken();
                s = s.trim();
                s = s.substring(1, s.length() - 1);
                Tree tree = new Tree(s);
                treebank.add(tree);
            }
        }
        System.out.println(")");
        br.close();
    }

    //    public static void linh_dop1test(String[] args) throws Exception
    //    {
    //        String DOP_file = tmpPath + "dopout.txt";
    //        if (args.length == 2)
    //        {
    //            corpusFile = args[0];
    //            DOP_file = args[1];
    //        } else if (args.length == 1)
    //            corpusFile = args[0];
    //        else
    //        {
    //            //showUsage();
    //            //return;
    //        }
    //
    //        long starttime = System.currentTimeMillis();
    //        System.out.println("Reading in the corpus...");
    //        Tree.Nodestatistics = new HashMap();
    //        // in order to count the nonterminal labels
    //
    //        Vector treebank = new Vector();
    //        //     Each element of the vector is one tree in the corpus
    //        //     (an element of type Tree)    
    //        Readtreebank(corpusFile, treebank);
    //        System.out.println(
    //            "Number of trees in the treebank:  " + treebank.size());
    //        //      System.out.println("Number of PCFG rules:  " + cnt_PCFGrules);
    //        System.out.println(
    //            "Number of nonterminal labels:  " + Tree.Nodestatistics.size());
    //        //        System.out.println(
    //        //            "Number of nonterminal occurrences:  " + cnt_nonterminalnodes);
    //        System.out.println(
    //            "Greatest depth of all full-parse trees: " + Tree.greatestDepth);
    //
    //        System.out.println("Generating the fragments...");
    //
    //        //FragmentCorpus fc = new FragmentCorpus(tmpPath + "tmp_dop1corpus");
    //        FragmentCorpus fc = new FragmentCorpus();
    //        generateDOP1Fragments(treebank, fc);
    //        System.out.println("Printing the fragments...");
    //        fc.printFragments(DOP_file);
    //
    //        long endtime = System.currentTimeMillis();
    //        long timespend = Math.round((float) (endtime - starttime) / 1000);
    //
    //        ///
    //
    //        System.out.println("Time spent:  " + timespend + " seconds");
    //        System.out.println("Finish generate DOP trees!");
    //
    //        //      DOPdepthonestatistics = null;
    //        //      System.out.println("Finish generate DOP trees!");
    //
    //    }
    //
    //    /**
    //     * Generate fragments for each tree in the treebank `tb' assigning DOP1 weights
    //     * (i.e., assigning the fragments' numbers of occurrences)
    //     * and store those (in string representation) in the fragment corpus `fc'.
    //     */
    //    public static void generateDOP1Fragments(Vector tb, FragmentCorpus fc)
    //        throws Exception
    //    {
    //        /** 
    //        * maximal depth fragments of which are extracted when in dop1 mode
    //        * 
    //        */
    //        int max_fragmentdepth = 5;
    //
    //        int i = 0;
    //        int tmp1 = tb.size();
    //        while (i < tmp1)
    //        {
    //            //            Tree tree = new Tree();
    //            Tree tree = (Tree) tb.get(i); // get next full-parse tree 
    //
    //            // first add an sss-(tree.rootname) fragment
    //            Tree f2 = new Tree("sss,[(" + tree.rootname + ",[])]");
    //            fc.add(f2, 1.0);
    //
    //            // now, add all fragments contained in 'tree'
    //            Vector treeFrags = tree.generateFragments(max_fragmentdepth);
    //            //generateFragments does not work correctly!!
    //            //             list of DOP trees generated by one tree(i) in the corpus
    //
    //            int j = 0;
    //            int tmp = treeFrags.size();
    //            while (j < tmp)
    //            {
    //                Tree v_DOPtree = (Tree) treeFrags.get(j);
    //                fc.add(v_DOPtree, 1.0);
    //                j++;
    //            }
    //            i++;
    //        }
    //    }
    //
    //    /**
    //     * Perform DOP1 equivalent PCFG rule generation from tree bank.
    //     * @param treeBankFileName Name of the tree bank file
    //     * @param outputFileName Name of the output file in which the PCFG rules are stored
    //     */
    //    public static void PCFGTest(
    //        String treeBankFileName,
    //        String outputFileName)
    //        throws Exception
    //    {
    //        Hashtable DOPdepthonestatistics = new Hashtable();
    //        //map String Dopdepthone rule
    //        //to its Statistics: one occurence probability and the number of occurence
    //
    //        Tree.Nodestatistics = new HashMap();
    //        // initialize Nodestatistics
    //
    //        System.out.println("Start reading the corpus...");
    //
    //        // read in treebank from file
    //        System.out.println("Start reading the corpus...");
    //        Vector treebank = new Vector();
    //        Readtreebank(treeBankFileName, treebank);
    //        System.out.println("Finish reading the corpus!");
    //
    //        System.out.println(
    //            "Greatest depth of all full-parse trees: " + Tree.greatestDepth);
    //
    //        System.out.println(
    //            "Start assign address to each node of tree bank...");
    //        AssignAddress(treebank);
    //        System.out.println(
    //            "Finish assign address to each node of tree bank!");
    //
    //        System.out.println("Start generate PCFG rules ...");
    //        long starttime = System.currentTimeMillis();
    //
    //        //        File f;
    //        //        FileOutputStream out; // declare a file output object
    //        //        PrintStream p; // declare a print stream object
    //        //        f = new File(PCFG_file);
    //        //        // Create a new file output stream
    //        //        // connected to filename
    //        //        out = new FileOutputStream(f);
    //        //        // Connect print stream to the output stream
    //        PrintWriter p =
    //            new PrintWriter(
    //                new BufferedWriter(new FileWriter(outputFileName)));
    //
    //        long cnt_PCFGrules = 0;
    //        for (int i = 0; i < treebank.size(); i++)
    //        {
    //            Tree tree = (Tree) treebank.get(i);
    //            Vector PCFGstatistics =
    //                GeneratePCFGrule(tree, DOPdepthonestatistics);
    //            PrintPCFGrule(PCFGstatistics, p);
    //            cnt_PCFGrules += PCFGstatistics.size();
    //        }
    //
    //        Enumeration e = DOPdepthonestatistics.keys();
    //        cnt_PCFGrules += DOPdepthonestatistics.size();
    //        for (; e.hasMoreElements();)
    //        {
    //
    //            String DOPstrtree = (String) e.nextElement();
    //            Statistics sta =
    //                (Statistics) DOPdepthonestatistics.get(DOPstrtree);
    //            float prob = sta.count * sta.Prob;
    //            p.println("(" + DOPstrtree + ")   Prob:" + prob);
    //        }
    //
    //        long endtime = System.currentTimeMillis();
    //        long timespend = Math.round((float) (endtime - starttime) / 1000);
    //        ///
    //        p.close();
    //        System.out.println(
    //            "Number of trees in the treebank:  " + treebank.size());
    //        System.out.println("Number of PCFG rules:  " + cnt_PCFGrules);
    //        System.out.println(
    //            "Number of nonterminal labels:  " + Tree.Nodestatistics.size());
    //        //        System.out.println(
    //        //            "Number of nonterminal occurrences:  " + cnt_nonterminalnodes);
    //
    //        System.out.println("Time spends:  " + timespend + " seconds");
    //    }
    //
    //    /**
    //     * AssignAddress() assign address for each nonterminal node in the trees of treebank vector
    //     * The address of each node is a unique integer. 
    //     */
    //    public static void AssignAddress(Vector treebank)
    //    {
    //        int i = 0;
    //        int startaddress = 1;
    //        while (i < treebank.size())
    //        {
    //            Tree tree = (Tree) treebank.get(i);
    //            startaddress = tree.assignAddress(startaddress, 0) + 1;
    //            i++;
    //        }
    //    }
    //
    //    /**
    //     * GeneratePCFGrule(Tree tree) has input parameter is one tree 
    //     * and output all PCFG for that tree a Vector which elements is a string contains 
    //     * PCFG rule and its probability 
    //     */
    //    public static Vector GeneratePCFGrule(
    //        Tree tree,
    //        Hashtable DOPdepthonestatistics)
    //    {
    //        Vector PCFGstatistics = new Vector(); //return Vector
    //        int k = tree.subtrees.size();
    //        if (k == 0)
    //            return PCFGstatistics;
    //
    //        int i;
    //
    //        for (i = 0; i < k; i++) //generate PCFG rules for all subtrees
    //            PCFGstatistics.addAll(
    //                GeneratePCFGrule(
    //                    (Tree) tree.subtrees.get(i),
    //                    DOPdepthonestatistics));
    //
    //        //Start to generate PCFG rules that have left side of the rule is root of tree...
    //        int[] terminal_with_address = new int[100];
    //        /*an array indicate for one rule one node is with or without address 
    //        terminal_with_address[0] :for the root
    //        terminal_with_address[1...k]: for all the subnode of the root
    //        terminal_with_address = 0 : without address
    //        terminal_with_address = 1 : with address */
    //
    //        for (i = 0; i < k + 1; i++)
    //            terminal_with_address[i] = 1;
    //
    //        for (i = 0; i < k; i++)
    //            if (((Tree) tree.subtrees.get(i)).terminal)
    //                terminal_with_address[i + 1] = 0;
    //
    //        while (terminal_with_address[0] >= 0)
    //        {
    //            String strrule = new String();
    //            float number1 = 1; //prob =number1/number2
    //            float number2;
    //            if (terminal_with_address[0] == 0) //no address         
    //                number2 =
    //                    ((Float) Tree.Nodestatistics.get(tree.rootname))
    //                        .floatValue();
    //            else
    //                number2 = tree.cnt_DOPsubtrees;
    //
    //            /* update strrule = (root_withorwithoutaddress, [(subnode1, subnode2,..., subnodek)] Prob=..
    //             * Probability of the rule = number1/number2              
    //             */ ///
    //            strrule =
    //                "("
    //                    + getterminalwithaddress(tree, terminal_with_address[0])
    //                    + ", [";
    //            int j = 0;
    //            while (j < k)
    //            {
    //                Tree subtree = (Tree) tree.subtrees.get(j);
    //                strrule =
    //                    strrule
    //                        + getterminalwithaddress(
    //                            subtree,
    //                            terminal_with_address[j + 1]);
    //                if (j < k - 1)
    //                    strrule += ", ";
    //                else
    //                    strrule += "])";
    //                if (terminal_with_address[j + 1] == 1
    //                    && subtree.cnt_DOPsubtrees != 0) //address
    //                    number1 = number1 * subtree.cnt_DOPsubtrees;
    //                j++;
    //            }
    //
    //            String DOPstrrule = new String();
    //            DOPstrrule = strrule;
    //            strrule =
    //                strrule
    //                    + "  Prob="
    //                    + (new Float(number1 / number2)).toString();
    //            ///
    //
    //            PCFGstatistics.add(strrule);
    //
    //            j = k;
    //            while (((Tree) tree.subtrees.get(j - 1)).terminal)
    //            {
    //                j--;
    //                if (j == 0)
    //                    break;
    //            }
    //            terminal_with_address[j]--;
    //            while (terminal_with_address[j] < 0) //at first j==k
    //            {
    //                if (j == 0)
    //                {
    //                    PCFGstatistics.remove(strrule);
    //                    Statistics sta = new Statistics();
    //                    if (DOPdepthonestatistics.containsKey(DOPstrrule))
    //                    {
    //                        sta = (Statistics) DOPdepthonestatistics.get(strrule);
    //                        sta.increasecount();
    //                        DOPdepthonestatistics.remove(DOPstrrule);
    //                        DOPdepthonestatistics.put(DOPstrrule, sta);
    //                    } else
    //                    {
    //                        sta = new Statistics(number1 / number2, 1); ///
    //                        DOPdepthonestatistics.put(DOPstrrule, sta);
    //                    }
    //                    return PCFGstatistics;
    //                }
    //                terminal_with_address[j] = 1;
    //                j--;
    //                if (j >= 1)
    //                {
    //                    while (((Tree) tree.subtrees.get(j - 1)).terminal)
    //                    {
    //                        j--;
    //                        if (j == 0)
    //                            break;
    //                    }
    //                }
    //                terminal_with_address[j]--;
    //            }
    //        }
    //        return PCFGstatistics;
    //    }
    //
    //    /**
    //     * getterminalwithaddress(Tree tree, int address) return String of rootname for PCFG rule
    //     * if the rootname also the terminal then return: rootname_
    //     * if the rootname and address = 0 then return: rootname (rootname with out address)
    //     * if the rootname and address = 1 then return: rootname_rootaddress (rootname with its address)
    //     */
    //    private static String getterminalwithaddress(Tree tree, int address)
    //    {
    //        if (tree.subtrees.size() == 0)
    //            return tree.rootname; // + "_";
    //        if (address == 0) //no address
    //            return tree.rootname;
    //        else
    //            return tree.rootname // + "_" 
    //            +tree.rootaddress;
    //    }
    //
    //    /**
    //     * PrintPCFGrule( Vector PCFGstatistics ,PrintStream p) prints all the rule 
    //     * in PCFGstatistics to PrintStream p 
    //     */
    //    public static void PrintPCFGrule(Vector PCFGstatistics, PrintWriter p)
    //        throws Exception
    //    {
    //        int i = 0;
    //        int k = PCFGstatistics.size();
    //        while (i < k)
    //        {
    //            String rule = (String) PCFGstatistics.get(i);
    //            p.println(rule);
    //            i++;
    //        }
    //    }

}
