import java.io.File;

/*
 * Created on Apr 13, 2004
 *
from Khalil:
get current documentation latex code (until April 30)
get GUI training program (if possible until April 30)
get source code with makefiles (until May 15)

- till 15th of April:
chose representative portion from OVIS corpus
make corpus splitting prog simple to use
program an evaluation program [also evaluate and compare multiple parsers; option to ignore 1-word sentences]

-till 30th of April
create documented sample training and testing scripts
make treebank conversion scripts
simplify usage of tree- and fragmentviewer scripts
complete documentation of dopdis, GUI interface, above-mentioned scripts, evaluation program [don't forget proper definitions of LR,LP,EM,FM]

-till 15th of May
bug-test and possibly fix Linh's PCFG reduction and document it in a section of the dopdis documentation [only its usage; include Linh's report elsewhere and also refer to Goodman]
include DOP* into the package:
    give overview document usage in a section of the dopdis documentation
    make separate JavaDoc file about purpose of all its classes

-till 31st of May
put links to relevant DOP literature on the website
make dopdis website
put links to relevant DOP literature on it
obtain info about how to do a Gnu Public License
add license files to package
make a test installation
migrate website to khalil's account
find more NLP-related resource sites on the web
register dopdis site with all of those sites

 */

/**
 * @author Andreas Zollmann
 *
 */
public class CorpusSplitter extends DOPStar
{

    public static void main(String[] args) throws Exception
    {
    	init(args);

		/**
		 * set to `true' for verbose output mode
		 */
		verbose = true;
	
		/**
		 * the unix output device / file used when running shell commands
		 * typically either /dev/tty or /dev/null or a filename
		 */
		unixOutputDevice = "/dev/tty";


		 File source = new File(args[1]).getAbsoluteFile();
		 File target1 = new File(args[3]).getAbsoluteFile();
		 File target2 = new File(args[4]).getAbsoluteFile();
		 // System.out.println(source);
		 split(source.getParent(), source.getName(), Long.parseLong(args[2]), target1.getPath(), target2.getPath());
		 
		 shutDown();
    }
}
