import java.io.IOException;
import java.sql.SQLException;

/*
 * Created on Jan 18, 2004
 *
 */

/**
 * @author Andreas Zollmann
 *
 */
public interface FragmentIterator
{
   	public Fragment next()  throws IOException, SQLException;
   	public boolean hasNext()  throws IOException;
}
