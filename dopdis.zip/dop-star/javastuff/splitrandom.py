import sys,re,os,string,getopt,random

def sr(argv):
    """
    @return: given a treebank file with M trees, returns a training and test file,
             <treebank_file>1 and treebank_file>2 resp., with 'M-n' sentences in file 1
             and 'n' sentences in file 2.
    """
    (f,d,n,e) = parseInput(argv)

    #File manipulation.    
    #1.Create files to output in directory d.   
    (f1,f2) = ("%s%s%s" % (f.name,'.train',e),"%s%s%s" % (f.name,'.test',e))
    (d1,d2) = ("%s%s" % (d,f1),"%s%s" % (d,f2))
    if f1 in os.listdir(d): os.remove(d1)
    if f2 in os.listdir(d): os.remove(d2)
    (f1,f2) = (open(d1,'a'),open(d2,'a'))

    print "Choosing sentences and splitting..."
    #Input file processing.    
    slist = f.readlines()
    m = len(slist)
    seqnumbers = range(1,m+1)
    randomseq = []
    i = 1
    while i <= n:
        x = random.choice(seqnumbers)
        randomseq.append(x)
        seqnumbers.remove(x)
        i += 1

    i = 1
    for sentence in slist:
        sentence = sentence.strip()
        if i in randomseq:
            f2.write(sentence+"\n")
            f2.flush()
            randomseq.remove(i)
        else:
            f1.write(sentence+"\n")
            f1.flush()
        i += 1
     
    #Close files    
    f.close()    
    f1.close()
    f2.close()
    print "Done.\n"
    
def parseInput(argv):
    """
    return: File object for input file and string representing path
            to directory where node files will be stored.
    rtype f: C{file}
    rtype d: C{string}
    """
    try:
        opts,args = getopt.getopt(argv,"hf:d:n:e:")        
    except getopt.GetoptError:
        usage()            
        sys.exit(2)

    infile = outdir = n = e = 0    
    for o,a in opts:
        if o in ["-h"]: usage(), sys.exit(2)
        elif o in ["-f"]: infile = a
        elif o in ["-d"]: outdir = a
        elif o in ["-n"]: n = string.atoi(a)
        elif o in ["-e"]: e = a


    if (not infile or not outdir or not n or not e):
        usage(), sys.exit(2)
    else:
        try:
            f = open(infile,'r')            
        except:
            print "File %s not found" % infile
            sys.exit(2)
        try:
            d = "%s/%s/" % (os.getcwd(),outdir)
            os.listdir(d)
        except:            
            print "Directory %s not found" % outdir
            sys.exit(2)
                
    return (f,d,n,e) 
            
def usage():  
    print "function: Create training (1) and test (2) files from a treebank file."
    print "usage: python splitrandom.py -f <treebank file>"
    print "                             -d <directory_to_output_files>"
    print "                             -n <number_of_sentences_in_test_file>"
    print "                             -e <extension, e.g. '.exp1'>"    
    
#--------------------------------------------------------------------------------------------------
sr(sys.argv[1:])    


