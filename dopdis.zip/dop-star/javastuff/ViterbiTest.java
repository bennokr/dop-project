import java.io.*;
import java.util.StringTokenizer;

/*
 * Created on Nov 19, 2003
 *
 */

/**
 * @author Andreas Zollmann, email: zollmann@gmx.de
 * 
 * Test class
 *
 */
public class ViterbiTest
{

	// print line by line the labeled-constituent Viterbi format of the trees fed in
	// line by line through the standard input
	public static void main(String[] args) throws Exception
	{
		BufferedReader br = new  BufferedReader(new InputStreamReader(System.in));
		//BufferedReader br = new  BufferedReader(new FileReader("fragmentin.txt"));
		String record = new String();

		Runtime rt = Runtime.getRuntime();
		Process proc = rt.exec("java -verbose");
		int exitVal = proc.waitFor();
		System.out.println("Process exitValue: " + exitVal);


 	
		System.out.println(br.read());
		System.out.println(br.ready());
		//while (br.ready() &&) {
			
		//}

		while ((record = br.readLine()) != null)
		{

			StringTokenizer stTok = new StringTokenizer(record, ".", false);

			while (stTok.hasMoreTokens())
			{
				String s = stTok.nextToken();
				s = s.trim();
				s = s.substring(1, s.length() - 1);
				Tree tree = new Tree(s);
				
				System.out.println(tree.toViterbiFormatString());
			}
		}

	}
}
