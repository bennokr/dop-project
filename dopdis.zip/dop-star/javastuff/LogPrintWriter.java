import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * Created on Jan 10, 2004
 *
 */

/**
 * @author Andreas Zollmann
 *
 */
public class LogPrintWriter extends PrintWriter
{
    // public String logFile;

    public LogPrintWriter(String logFileName) throws IOException
    {
        super(new BufferedWriter(new FileWriter(logFileName)), true);
        // logFile = logFileName;
    }

    /**
     * Prints to the log and at the same time to System.out
     * @param s
     */
    public void print2(String s)
    {
        System.out.print(s);
        print(s);
    }

    /**
    	 * "Println"s to the log and at the same time to System.out
    	 * @param s
    	 */
    public void println2(String s)
    {
        System.out.println(s);
        println(s);
    }

	/**
	 * print file `fileName' to the log file
	 */
	public void printFile(String fileName) throws IOException
	{
		BufferedReader br =
			new BufferedReader(new FileReader(fileName));
		for (String record;(record = br.readLine()) != null;)
		{
			println(record);
		}
		br.close();
	}

	/**
	 * print file `fileName' to the log file and to the screen
	 */
	public void printFile2(String fileName) throws IOException
	{
		BufferedReader br =
			new BufferedReader(new FileReader(fileName));
		for (String record;(record = br.readLine()) != null;)
		{
			println2(record);
		}
		br.close();
	}
}
