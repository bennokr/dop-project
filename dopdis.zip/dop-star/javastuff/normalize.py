import os,re,string,sys,getopt

def normalize(argv):
    """
    @return: Takes trees with counts and print out
    to standard output the same trees with probabilities.
    """
    (f,F) = parseInput(argv)
        
    Sum = {}
    p = re.compile(r',[0-9e+-.]+\)')
    q = re.compile(r'\([A-Za-z-@]+,')

    #For each distribution, sum all counts.
    s = f.readline()   
    while s != "":
        c = string.atof(p.search(s).group()[1:-1])
        n = q.search(s).group()[1:-1]
        Sum[n] = Sum.get(n,0.0) + c
        s = f.readline()

    #Calculate the probability of each tree for each distribution.
    f.seek(0)
    s = f.readline()   
    while s != "":
        c = string.atof(p.search(s).group()[1:-1])
        n = q.search(s).group()[1:-1]
        prob = float(c)/Sum[n]
        s = p.sub(",%e)" % prob,s)
        F.write(s)
        s = f.readline()
        
    #Close files
    f.close()
    F.close()


def parseInput(argv):
    try:
        opts,args = getopt.getopt(argv,"hf:F:")        
    except getopt.GetoptError:
        usage()            
        sys.exit(2)

    infile = outfile = 0
    
    for o,a in opts:
        if o in ["-h"]: usage(), sys.exit(2)
        elif o in ["-f"]: infile = a
        elif o in ["-F"]: outfile = a
        
    if not infile or not outfile:
        usage(), sys.exit(2)
    else:
        try:
            f = open(infile,'r')            
        except:
            print "File %s not found" % infile
            sys.exit(2)
        try:
            if outfile in os.listdir(os.getcwd()):
                os.remove(os.getcwd()+"/"+outfile)
            F = open(outfile,'a',0)
        except:
            print "Cannot open %s" % outfile
            sys.exit(2)
            
    return (f,F) 
            
def usage():  
    print "function: Normalize tree counts."    
    print "usage: python normalize.py -f <file_with_fragments_and_counts>"
    print "                           -F <output_file_with_probabilities>"
    
#--------------------------------------------------------------------------------------------------
normalize(sys.argv[1:])    


