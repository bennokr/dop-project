/*
 * Created on Jun 5, 2003.
 *
 * @author Thuy Linh Nguyen and Andreas Zollmann
 *
*/

//import java.util.*;
import java.io.*;
//import java.sql.*;

import jdbm.*;
//import com.braju.format.*; //the printf stuff
import java.sql.SQLException;
import java.text.DecimalFormat;

/**
 * Object of type FragmentDistribution contains a weight distribution of 
 * fragments of the same root. Caution! This class is highly unsynchronized.
 * 
 * @author Thuy Linh Nguyen and Andreas Zollmann
 *
 */
public class FragmentDistribution
{
    /**
     * The root label of the fragments in this distribution
     */
    public String root;

    /**
     * Sum of fragment's weights (could also be the total 
     * number of occurrences of that fragment)
     */
    public double weightSum;

    /**
     * Map each fragment to its weight (could also be 
     * the number of occurrences).
     * 
     * Implemented as a persistent Hashtable, i.e., sourced out
     * to the file system.
     */
    private JDBMHashtable fragments;

    /**
     * The record manager underlying the persistent Hashtable `fragments'.
     */
    private JDBMRecordManager recordManager;

    /**
     * "FD" + Number of current instance of FragmentDistribution
     */
    protected String id;

    /**
     * number of instances of FragmentDistribution that have been created so far
     */
    protected static long idCount = 0;

    /**
     *  our connnection to the db - persists for life of program
     */
    //private static Connection connection = null;

    private class FragmentIteratorImplementation implements FragmentIterator
    {
        JDBMEnumeration en;
        //Statement dbStatement;
        //private ResultSet rs;
        //private boolean hasNext;
        //        FragmentIteratorImplementation(String id) throws IOException
        //        {
        //            // create communication means
        //            dbStatement = connection.createStatement();
        //            rs = dbStatement.executeQuery("SELECT * FROM " + id);
        //
        //            // in SQL, the pointer of a ResultSet points _before_ the first row
        //            // in the beginning
        //            // -> call next() immediately
        //            hasNext = rs.next();
        //        }

        FragmentIteratorImplementation(JDBMEnumeration en)
        {
            this.en = en;
        }

        public Fragment next() throws IOException, SQLException
        {
            Fragment f = new Fragment();
            f.tree = (String) en.nextElement();
            f.weight = getWeight(f.tree);
            //            f.tree = rs.getString("key");
            //            f.weight = rs.getDouble("value");
            //            hasNext = rs.next();
            return f;
        }
        public boolean hasNext() throws IOException
        {
            //return hasNext;
            return en.hasMoreElements();
        }
    }

//    private static void init() throws IOException, IOException
//    {
//        connection = DOPStar.dbConnection;
//    }

	protected FragmentDistribution(String root) {
		
		// increment the Instances counter
		idCount++;

		// initialize fields
		this.root = root;
		weightSum = 0;
		this.id = "FD" + idCount;
	}

    /**
     * Constructs new FragmentDistribution.
     * @param root The root label of the fragment distribution
     * @param rm The handle for the temporary file which the persistent
     *           hash tables use.
     * @throws Exception
     */
    public FragmentDistribution(String root, JDBMRecordManager rm) throws IOException
    {
		// increment the Instances counter
		idCount++;

		// initialize fields
		this.root = root;
		weightSum = 0;
		this.id = "FD" + idCount;

//        if (connection == null)
//        {
//            // first time a FragmentDistribution instance is created
//            init();
//        }


//        // create communication means
//        Statement dbStatement = connection.createStatement();
//        // create table in the database
//        dbStatement.executeQuery(
//            "CREATE CACHED TABLE "
//                + id
//                + " (key CHAR PRIMARY KEY, value DOUBLE)");
//        dbStatement.close();
//    

	  fragments = rm.getHashtable(id);
	  recordManager = rm;
}

	public FragmentDistribution getNewFragmentDistribution(String root) throws IOException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		return new FragmentDistribution(root, recordManager); 
	}

    /**
     * Returns a FragmentIterator of the non-zero weight fragments of the 
     * fragment distribution.
     * @return
     * @throws IOException
     */
    public FragmentIterator getFragmentIterator() throws IOException, SQLException
    {
        // return new FragmentIteratorImplementation(id);
        return new FragmentIteratorImplementation(fragments.keys());
    }

    public void makeEmpty() throws IOException, SQLException
    {
//        // create communication means
//        Statement dbStatement = connection.createStatement();
//        int i = dbStatement.executeUpdate("DELETE FROM " + id);
//        // run the query
//
//        if (i == -1)
//        {
//            throw new IOException("DB error when deleting table " + id);
//        }
//        dbStatement.close();

		fragments.dispose();
		fragments = null;
		//NOT NICE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
		id += "_me";
		fragments = recordManager.getHashtable(id);
		weightSum = 0.0;

    }

    /**
     * returns `true' if this fragment distribution is empty 
     * @return
     * @throws IOException
     */
    public boolean empty() throws IOException, SQLException
    {
        // ResultSet rs = dbStatement.executeQuery("SELECT key FROM " + id);
        // return !rs.next();
        FragmentIterator it = getFragmentIterator();
        return !it.hasNext();
    }

    /**
     * Add the Fragment occurrence `tree' (as String representation) 
     * with weight 1, adapting its `weightSum' variable
     * accordingly. If the weight
     * becomes zero, the fragment is removed in case it already existed.
     * Just calls add(tree, 1.0).
     *  
     */
    public void add(String tree) throws IOException, SQLException
    {
        add(tree, 1.0);
    }

    /**
     * Adds the fragment `frag' to the distribution, adapting its `weightSum' variable
     * accordingly. If the weight
     * becomes zero, the fragment is removed in case it already existed.
     * @param frag
     * @throws IOException
     */
    public void add(Fragment frag) throws IOException, SQLException
    {
        add(frag.tree, frag.weight);
    }

    /**
     * Add the Fragment occurrence `tree' with weight `w', adapting its 
     * `weightSum' variable
     * accordingly. If the weight
     * becomes zero, the fragment is removed in case it already existed.
     *  
     */
    public void add(String tree, double w) throws IOException, SQLException
    {
        weightSum += w;
        setWeight(tree, w + getWeight(tree));
    }

    public void add(FragmentDistribution fd) throws IOException, SQLException
    {
        //if (U.verbose) System.out.print("weightSum=" + weightSum + " ... ");
        U.ensure(
            root.equals(fd.root),
            "Supposed to add fragment distribution with root "
                + fd.root
                + " to this fragment distribution with root "
                + root);
        FragmentIterator it = fd.getFragmentIterator();
        for (long cnt = 0; it.hasNext(); cnt++)
        {
            if (cnt % 10000 == 0 && cnt != 0)
            {
                if (U.verbose) System.out.print(cnt + ", ");
            }

            Fragment frag = it.next();
            add(frag.tree, fd.getWeight(frag.tree));
        }
    }

    /**
    	* Adds all the fragments in the fragment distribution `fd' (of the same root)
    	* to this fragment
    	* distribution in such a way that
    	* for each fragment f that exists in both distributions, the resulting quotient 
    	* this.getWeight(f) / this.weightSum equals
    	* fd.getWeight(f) / fd.weightSum * fdWeight +
    	* this.getWeight(f) / this.weightSum * myWeight
    	* (if one of the weightSums is zero, i.e., one of the two fragment distributions
    	* is empty, then the quotient will equal the
    	* quotient of the other fragment distribution). Note that this means that
    	* myWeight and fcWeight should add up to one for usual purposes.
    	* 
    	* Performance hint: `fd' should be the smaller fragment distribution of the two.
    	* 
    	* Possible problem: If myWeight gets very small, the current implementation
    	* might be problematic (division by myWeight).
    	*  
    	*/
    public void weightedSum(
        FragmentDistribution fd,
        double myWeight,
        double fdWeight)
        throws IOException, SQLException
    {
        if (U.verbose) System.out.print(
            "category "+root+": this.weightSum="
                + weightSum
                + ", fd.weightSum="
                + fd.weightSum
                + " ... ");
        if (!(fd.weightSum == 0.0))
            // if fd.weightSum == 0, nothing is to be done  
        {
            if (this.weightSum == 0.0 || myWeight == 0.0)
            {
                // no fragments in this distribution or myWeight == 0 
                // --> just copy over the other distribution
                makeEmpty();
                add(fd);
                this.weightSum = fd.weightSum;
            } else
            {
                // we choose the new this.weightSum in such a way that we can keep
                // this.getWeight(f) for fragments f that are not in fd:
                // new_this.weightsum := this.weightSum / myWeight (see below)
                FragmentIterator it = fd.getFragmentIterator();
                for (long cnt = 0; it.hasNext(); cnt++)
                {
                    if (cnt % 50000 == 0 && cnt != 0)
                    {
                        if (U.verbose) System.out.print(cnt + ", ");
                    }

                    Fragment frag = it.next();
                    setWeight(
                        frag.tree,
                        this.getWeight(frag.tree)
                            + frag.weight
                                / fd.weightSum
                                * this.weightSum
                                * fdWeight
                                / myWeight);
                }
                if (U.verbose) System.out.println(")");
                this.weightSum = this.weightSum / myWeight;
            }

        }
    }

    /**
     * Deletes all the fragments that do not occur in the fragment distribution `fd'
     * (i.e., that are assigned weight zero in `fd')
     * from this fragment distribution.  Does not adjust the `weightSum' variable.
     * 
     * @param fd
     * @return true iff some fragment has been deleted
     * @throws Exception
    */
    public boolean intersection(FragmentDistribution fd)
        throws IOException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
    {
        if (U.verbose) System.out.print(
            "    (Intersecting fragments of category " + root + " ... ");
        boolean somethingDeleted = false;
        if (fd == null)
        {
            somethingDeleted = !empty();
            makeEmpty();
        } else
        {
            if (!root.equals(fd.root))
            {
                throw new RuntimeException(
                    "Consistency error in this fragment distribution: this root '"
                        + root
                        + "' is different to the intersect-argument's root ("
                        + fd.root
                        + ")!");
            }
            FragmentDistribution deletionDistribution =
                getNewFragmentDistribution(root);
            {
                long cnt = 0;
                for (FragmentIterator it = getFragmentIterator();
                    it.hasNext();
                    cnt++)
                {
                    if (cnt % 10000 == 0 && cnt != 0)
                    {
                        if (U.verbose) System.out.print(cnt + " ");
                    }
                    Fragment frag = it.next();
                    if (fd.getWeight(frag.tree) == 0.0)
                    {
                        // Actually, we just want to remove the fragment; however, this
                        // should not be done while iterating over it. Therefore, we
                        // have to temporarily save it in the deletionDistribution
                        deletionDistribution.add(frag);
                        somethingDeleted = true;
                    }
                }
            }
            if (U.verbose) System.out.println(")");
            U.ensure(
                !somethingDeleted == deletionDistribution.empty(),
                "!somethingDeleted == deletionDistribution.empty()");
            if (somethingDeleted)
            {
                if (U.verbose) System.out.print(
                    "      (Deleting superfluous fragments ... ");
                long cnt = 0;
                for (FragmentIterator it =
                    deletionDistribution.getFragmentIterator();
                    it.hasNext();
                    cnt++)
                {
                    if (cnt % 10000 == 0 && cnt != 0)
                    {
                        if (U.verbose) System.out.print(cnt + " ");
                    }
                    Fragment frag = it.next();
                    setWeight(frag.tree, 0.0);
                }
                if (U.verbose) System.out.println(")");
            }
        }
        return somethingDeleted;
    }

    /**
     * Gets the weight this distribution assigns to fragment `tree'.
     * @param tree
     * @return
     * @throws Exception
     */
    public double getWeight(String tree) throws IOException, SQLException
    {
//        double ret;
//        // create communication means
//        Statement dbStatement = connection.createStatement();
//        ResultSet rs =
//            dbStatement.executeQuery(
//                "SELECT value FROM " + id + " WHERE key='" + tree + "'");
//        boolean nonempty = rs.next();
//        if (nonempty)
//        {
//            ret = rs.getDouble("value");
//        } else
//        {
//            ret = 0.0;
//        }
//        dbStatement.close();
//        return ret;

		Double value = (Double) fragments.get(tree);
		if (value != null)
		{
			return value.doubleValue();
		} else
		{
			return 0.0;
		}

    }

    /**
     * Sets the weight of Fragment `tree' to `w' without changing `weightSum'.
     * If `w'==0 then the `tree' is removed from the fragment distribution
     * in case it exists.
     * @param tree String representation of the fragment
     * @param w The weight to set
     * @throws IOException
     */
    public void setWeight(String tree, double w) throws IOException, SQLException
    {
//        // create communication means
//        Statement dbStatement = connection.createStatement();
//        dbStatement.executeUpdate(
//            "DELETE FROM " + id + " WHERE key='" + tree + "'");
//        if (w != 0)
//        {
//            dbStatement.executeUpdate(
//                "INSERT INTO "
//                    + id
//                    + " (key,value) VALUES('"
//                    + tree
//                    + "', "
//                    + w
//                    + ")");
//        }
//        dbStatement.close();

		if (w == 0)
		{
			fragments.remove(tree);
		} else
		{
			fragments.put(tree, new Double(w));
		}
    }

    /**
     * Prints list of fragments with their weights if weightSum != 0.
     * 
     * @return The number of fragments printed.
     */
    public long printFragments(PrintWriter p) throws Exception
    {
        return printFragments(p, false);
    }

    /**
     * Prints list of fragments with their weights if weightSum != 0.0.
     * If weightOneHalf is true, print fragments using weight 0.5 and
     * ignoring the actual weights.
     * 
     * @return The number of fragments printed.
     */
    public long printFragments(PrintWriter p, boolean weightOneHalf)
        throws IOException, SQLException
    {
        long fragCount = 0;
        if (U.verbose) System.out.print("weightSum=" + weightSum + " ... ");
        if (weightSum != 0.0)
        {
            FragmentIterator it = getFragmentIterator();
            for (long cnt = 0; it.hasNext(); cnt++)
            {
                if (cnt % 10000 == 0 && cnt != 0)
                {
                    if (U.verbose) System.out.print(cnt + ", ");
                }

                Fragment frag = it.next();
                String strtree = frag.tree;
                if (!root.equals(Tree.getRoot(strtree)))
                {
                    throw new RuntimeException(
                        "Consistency error in this fragment distribution: fragment '"
                            + strtree
                            + "' has different root ("
                            + Tree.getRoot(strtree)
                            + ") than this fragment distribution has ("
                            + root
                            + ")!");
                }
                double prob = .5;
                if (!weightOneHalf)
                {
                    double cntDOPtree = frag.weight;
                    prob = cntDOPtree / weightSum; ///
                }
                DecimalFormat df = new DecimalFormat("0.000000E00");
                String probStr = df.format(prob);
                if (!(probStr.charAt(9) == '-'))
                {
                    probStr =
                        probStr.substring(0, 9)
                            + '+'
                            + probStr.substring(9, 11);
                }
                p.println(
                    "(" + strtree + ", " + probStr.toLowerCase() + " ).");
                //            toLowerCase in order to change the 'E' to an 'e'

                fragCount++;
            }
            if (U.verbose) System.out.println(")");
            p.flush();
        }
        return fragCount;
    }

    /**
     * Clean up the data base from the fragment distribution, thus freeing disk space.
     * Automatically called by the garbage collection.
     * @throws IOException
     */
    public void dispose() throws IOException, SQLException
    {
//        // create communication means
//        Statement dbStatement = connection.createStatement();
//        // delete the table corresponding to this fragment distribution
//        dbStatement.executeUpdate("DROP TABLE " + id);
//        dbStatement.close();

		fragments.dispose();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#finalize()
     */
    protected void finalize() throws Throwable
    {
        dispose();
        super.finalize();
    }

}
