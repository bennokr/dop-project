/*
 * Created on Jan 18, 2004
 *
 */

/**
 * @author Andreas Zollmann
 *
 */
public class Fragment
{
	public String tree;
	public double weight;
}
