/*
 * Created on Nov 9, 2003
 *
 */

//import java.sql.SQLException;
import java.sql.SQLException;
import java.util.*;
import java.io.*;

import jdbm.*;

/**
 * @author Thuy Linh Nguyen and Andreas Zollmann
 *
 */
public class FragmentCorpus
{
    /**
     * determines whether running with mysql or with jdbm
     */
    public static boolean sqlMode = false;

    /**	
     * Key (String): non-terminal node label which is the root of all contained fragments 
     * Value (FragmentDistribution): the FragmentDistribution for the fragments
     * headed by the key non-terminal node   
     * 
     */
    public Map fragmentDistributions = new HashMap();

    /**
     * Will be the handle of the persistent hash tables used.
     */
    private JDBMRecordManager recordManager;

    /**
     * number of current instance of FragmentCorpus using the temp file
     */
    private long id;

    /**
     * temp file name for temporary corpora
     */
    private String tempFileName = null;
    //private static String tempFileName = null;

    /**
     * number of instances of FragmentCorpus that have used the temp file so far
     */
    private static long idCount = 0;

    /**
     * Will be the handle of the persistent hash tables used.
     */
    private static JDBMRecordManager staticRecordManager;

    //    /**
    //     * Create empty fragment fragmentDistributions, using files `fileName'.db and 
    //     * `fileName'.log as storage file
    //     * for the persistent hash tables used, where those files will be deleted
    //     * in case they already exist.
    //     * @param fileName
    //     * @throws IOException If trouble creating the storage file.
    //     */
    //    public FragmentCorpus(String fileName) throws IOException
    //    {
    //        // delete the files files in case they already exist
    //        File file = new File(fileName + ".db");
    //        if (file.exists())
    //            file.delete();
    //        file = new File(fileName + ".lg");
    //        if (file.exists())
    //            file.delete();
    //
    //        recordManager = new JDBMRecordManager(fileName);
    //        recordManager.disableTransactions();
    //        // don't log transactions - no safety needed
    //
    //        id = 0; //means that no temp file is used
    //    }

    /**
     * Create empty fragment fragmentDistributions, using two self-created tmp files as storage and log file
     * for the persistent hash tables used, where the tmp files will be deleted
     * when dispose() or finalize() is called and automatically
     * on exit of the program.
     * @param tmpFileName
     * @throws IOException If trouble with the tmp files.
     */
    public FragmentCorpus() throws IOException
    {
        // next FragmentCorpus instance working with our temp files has been started
        idCount++;

        id = idCount;

        if (!sqlMode)
        {
            //if (tempFileName == null)
            //{ // first use of this constructor during this java session

            //            File file =
            //                File.createTempFile(
            //                    "tmp_dopstar",
            //                    "",
            //                    new File(DOPStar.tmpPath + "."));
            //            recordManagerFileName = file.getName();
            //			  if (file.exists()) file.delete();

            tempFileName = DOPStar.tmpPath + "tmp_dopstar" + id;

            // delete the temporary files in case they already exist and also
            // mark them for deletion when exiting the program
            File file = new File(tempFileName + ".db");
            if (file.exists())
                file.delete();
            file.deleteOnExit();
            file = new File(tempFileName + ".lg");
            if (file.exists())
                file.delete();
            file.deleteOnExit();

            staticRecordManager = new JDBMRecordManager(tempFileName);
            staticRecordManager.disableTransactions();
            // don't log transactions - no safety needed
            //}
            recordManager = staticRecordManager;
        }
    }
    
    public FragmentCorpus getCopy() throws IOException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    	FragmentCorpus fc = new FragmentCorpus();
    	fc.add(this);
    	return fc;
    }
    
    protected FragmentDistribution getNewFragmentDistribution(String root) throws IOException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    	if (sqlMode) {
    		return new SQLFragmentDistribution(root);
    	}
    	else {
    		return new FragmentDistribution(root, recordManager);
    	}
    }

    /**
     * Returns the number of root labels and thus fragment distributions in the 
     * fragment fragmentDistributions. 
     * @return
     */
    public int rootLabelCount()
    {
        return fragmentDistributions.size();
    }

	/**
	 * Adds fragments from file `fileName'
	 * @return The number of fragments added.
	 */
	public long addOfflineCorpus(String fileName) throws Exception
	{
		return addOfflineCorpus(fileName, 1.0);		
	}
	
    /**
     * Adds fragments from file `fileName', where each fragment's weight
     * is determined by multiplying the weight
     * stated in the file with `scalingFactor'. 
     * @return The number of fragments added.
     */
    public long addOfflineCorpus(String fileName, double scalingFactor) throws Exception 
    {
        long fragCount = 0;

        FileReader fr = new FileReader(fileName);
        BufferedReader br = new BufferedReader(fr);

        String s;

        for (long cnt = 0;(s = br.readLine()) != null; cnt++)
        {
            if (cnt % 10000 == 0 && cnt != 0)
            {
                //if (U.verbose) 
				if (cnt == 10000) 
				System.out.print("  Lines processed: ");
                System.out.print(cnt + ", ");
            }

            //   e.g., s="(sss,[(mpxA,[])], 7.476636e-02 )."

            s = s.trim();
            String ss = s.substring(s.indexOf('(') + 1, s.lastIndexOf(','));
            //     e.g., "sss,[(mpxA,[])]"

            if (!ss.substring(0, 5).equals("ssss,")
                && !ss.substring(0, 10).equals("xxxphrase,"))
                // ignore special symbols "ssss" and "xxxphrase"
            {
                String sProb =
                    s.substring(s.lastIndexOf(',') + 1, s.lastIndexOf(')'));
                //     e.g., " 2.336449e-01 "   

                double d = Double.parseDouble(sProb);

                //Tree f2 = new Tree(ss);
                add(ss, scalingFactor * d);
                fragCount++;
            }
        }
        br.close();
        return fragCount;
    }

    /**
     * Adds all the fragments in the FragmentDistribution `fd' to this fragment
     * corpus, adding fragment weights in case a distribution with this
     * root already exists in this fragment corpus.
     */
    public void addFragmentDistribution(FragmentDistribution fd)
        throws IOException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
    {
        if (U.verbose) System.out.print(
            "  (Processing fragments of category " + fd.root + ": ");

        FragmentDistribution fd1 =
            (FragmentDistribution) fragmentDistributions.get(fd.root);
        if (fd1 == null)
        {
            fd1 = getNewFragmentDistribution(fd.root);
            fragmentDistributions.put(fd1.root, fd1);
        }
        fd1.add(fd);
    }

    /**
     * Adds all the fragments in the FragmentCorpus `fc' to this fragment
     * corpus, inserting them into the appropriate fragment distributions,
     * if needed, creating new fragment distributions,  
     * and adding fragment weights in case fragments already exist in the
     * corpus.
     * 
     * @param fc
     * @throws IOException
     */
    public void add(FragmentCorpus fc) throws IOException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
    {
        Iterator e = fc.fragmentDistributions.entrySet().iterator();
        while (e.hasNext())
        {
            Map.Entry entry = (Map.Entry) e.next();
            addFragmentDistribution((FragmentDistribution) entry.getValue());
        }
    }

    /**
    	* Adds all the fragments in the FragmentCorpus `fc' to this fragment
    	* corpus, (inserting them into the appropriate fragment distributions and,
    	* if needed, creating new fragment distributions) in such a way that
    	* for each fragment f that exists in both corpora, the resulting quotient 
    	* weight(f)/"f's distribution".weightSum equals
    	* weight_fc(f)/"f's distribution in `fc'".weightSum * fcWeight +
    	* weight_this(f)/"f's distribution in `this'".weightSum * myWeight
    	* (if one of the weightSums is zero, i.e., one of the two fragment distributions
    	* for f is empty, then the quotient will equal the
    	* quotient of the other fragment distribution). Note that this means that
    	* myWeight and fcWeight should add up to one for usual purposes.
    	* 
    	* See also: FragmentDistribution.weightedSum
    	* 
    	* Performance hint: `fc' should be the smaller fragment corpus of the two.
    	* 
    	* Possible problem: If myWeight gets very small, the current implementation
    	* might be problematic (division by myWeight). Only start to worry about that
    	* if myWeight gets smaller than 1.0E-4.
    	*  
    	*/
    public void weightedSum(
        FragmentCorpus fc,
        double myWeight,
        double fcWeight)
        throws IOException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
    {
        //    	try
        //        {
        //            printFragments("tmpTestWSMy");
        //			fc.printFragments("tmpTestWSFC");
        //        } catch (Exception e1)
        //        {
        //            e1.printStackTrace();
        //        }

        Iterator e = fc.fragmentDistributions.entrySet().iterator();
        while (e.hasNext())
        {
            Map.Entry entry = (Map.Entry) e.next();
            FragmentDistribution fd = (FragmentDistribution) entry.getValue();
            FragmentDistribution my_fd =
                (FragmentDistribution) fragmentDistributions.get(fd.root);
            if (my_fd == null)
            {
                my_fd = getNewFragmentDistribution(fd.root);
                fragmentDistributions.put(my_fd.root, my_fd);
            }
            my_fd.weightedSum(fd, myWeight, fcWeight);
        }
    }

    /**
     * Add fragment `f' with weight `w' to the fragment fragmentDistributions, automatically finding the entry with
     * the appropriate root. 
     */
    public void add(Tree f, double w) throws Exception
    {
        if (fragmentDistributions.containsKey(f.rootname))
        {
            FragmentDistribution v_doptreemap =
                (FragmentDistribution) fragmentDistributions.get(f.rootname);
            v_doptreemap.add(f.toString(), w);

            //fc.remove(f.rootname);
            //fc.put(f.rootname, v_doptreemap);
        } else
        {
            FragmentDistribution v_doptreemap =
                getNewFragmentDistribution(f.rootname);
            v_doptreemap.add(f.toString(), w);
            fragmentDistributions.put(f.rootname, v_doptreemap);
        }
    }

    /**
     * Add fragment `f' (as String representation) with weight `w' to the fragment fragmentDistributions, 
     * automatically finding the entry with
     * the appropriate root. 
     */
    public void add(String f, double w) throws Exception
    {
        String rootname = Tree.getRoot(f);
        if (fragmentDistributions.containsKey(rootname))
        {
            FragmentDistribution v_doptreemap =
                (FragmentDistribution) fragmentDistributions.get(rootname);
            v_doptreemap.add(f, w);

            //fc.remove(f.rootname);
            //fc.put(f.rootname, v_doptreemap);
        } else
        {
            FragmentDistribution v_doptreemap =
                getNewFragmentDistribution(rootname);
            v_doptreemap.add(f, w);
            fragmentDistributions.put(rootname, v_doptreemap);
        }
    }

    /**
     * Deletes all the fragments that do not occur in the fragment corpus `fc'
     * (i.e., that are assigned weight zero in `fc')
     * from this fragment corpus. deletes fragment distributions
     * in the map fragmentDistributions that become empty.
     * 
     * @param fc
     * @return true iff any fragment has been deleted
     * @throws IOException
     */
    public boolean intersection(FragmentCorpus fc) throws Exception
    {
        boolean somethingDeleted = false;
        List deleteList = new LinkedList();
        Iterator e = fragmentDistributions.entrySet().iterator();
        while (e.hasNext())
        {
            Map.Entry entry = (Map.Entry) e.next();
            FragmentDistribution fd1 =
                (FragmentDistribution) entry.getValue();

            FragmentDistribution fd2 =
                (FragmentDistribution) fc.fragmentDistributions.get(fd1.root);
            somethingDeleted |= fd1.intersection(fd2);
            if (fd1.empty())
            {
                deleteList.add(fd1.root);
            }
        }
        for (Iterator it = deleteList.iterator(); it.hasNext();)
        {
            fragmentDistributions.remove(it.next());
        }
        return somethingDeleted;
    }

    /**
     * Adds the fragments of the derivation `der' to this fragment corpus.
     * @param der The derivation in string representation
     * @param weight The weight with which each fragment is added to this fragment corpus 
     * @throws Exception
     */
    public void addDerivationFragments(String der, double weight)
        throws Exception
    {
        Tree t = new Tree(der);
        Vector v = t.expandDerivation();
        for (int i = 0; i < v.size(); i++)
        {
            Tree frag = (Tree) v.get(i);
            add(frag, weight);

            //if (U.verbose) System.out.println(frag);
        }
    }

    /**
     * Prints fragments 
     * in this fragment corpus to filename.
     * @return The number of fragments printed.
     */
    public long printFragments(String filename) throws Exception
    {
        return printFragments(filename, false);
    }

    /**
    * Prints fragments 
    * in this fragment corpus to PrintWriter p.
    * @return The number of fragments printed.
    */
    public long printFragments(PrintWriter p) throws Exception
    {
        return printFragments(p, false);
    }

    /**
     * Prints fragments 
     * in fragmentCorpus HashMap to filename all with weights 0.5
     * if weightOneHalf = true (used by shortestderivation analysis).
     *
     * @return The number of fragments printed.
     * 
     */
    public long printFragments(String filename, boolean weightOneHalf)
        throws Exception
    {
        PrintWriter p =
            new PrintWriter(new BufferedWriter(new FileWriter(filename)));
        long ret = printFragments(p, weightOneHalf);
        p.close();
        return ret;
    }

    /**
      * Prints fragments 
      * in fragmentCorpus HashMap to p all with weights 0.5
      * if weightOneHalf = true (used by shortestderivation analysis).
      *
      * @return The number of fragments printed.
      * 
      */
    public long printFragments(PrintWriter p, boolean weightOneHalf)
        throws Exception
    {
        long fragCount = 0;

        p.println("(ssss,[(sss,[])], 1.000000e+00 ).");
        p.println("(ssss,[(xxxprior,[])], 1.000000e+00 ).");
        p.println("(xxxphrase,[(xxxphrase_,[])], 1.000000e+00 ).");
        Iterator e = fragmentDistributions.keySet().iterator();
        for (; e.hasNext();)
        {
            String rootname = (String) e.next();

            if (U.verbose) System.out.print(
                "  (Processing fragments of category " + rootname + ": ");

            FragmentDistribution v_doptree =
                (FragmentDistribution) fragmentDistributions.get(rootname);
            fragCount += v_doptree.printFragments(p, weightOneHalf);
        }
        return fragCount;
    }

    public void dispose() throws IOException, SQLException
    {
        if (!sqlMode)
        {
            Iterator e = fragmentDistributions.entrySet().iterator();
            while (e.hasNext())
            {
                Map.Entry entry = (Map.Entry) e.next();
                FragmentDistribution fd =
                    (FragmentDistribution) entry.getValue();
                fd.dispose();
            }
            recordManager.close();
            // close the file handle if it is not our temp file
            //if (id == 0)	recordManager.close();

            // if FragmentCorpus was constructed without specifying a file name,
            // then delete the temp files
            if (id != 0)
            {
                // delete the temporary files
                File file = new File(tempFileName + ".db");
                //if (file.exists())
                file.delete();
                file = new File(tempFileName + ".lg");
                //if (file.exists())
                file.delete();
                //file = new File(recordManagerFileName);
                //if (file.exists()) file.delete();
            }
        }
    }

    /* (non-Javadoc)
     * @see java.lang.Object#finalize()
     */
    protected void finalize() throws Throwable
    {
        dispose();
        super.finalize();
    }

}
