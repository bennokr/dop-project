/*
 * Created on Nov 17, 2003
 *
 */

/**
 * @author Andreas Zollmann, email: zollmann@gmx.de
 * 
 * Labeled-constituent Viterbi tuple representing a node of a tree. If the node
 * is a terminal, `cat' is its POS tag; otherwise, `cat' is "xxxphrase_".
 *
 */
public class ViterbiTuple
{
	public int start;
	public int end;
	public String cat;
	public String word;

	/**
	 * 
	 */
	public ViterbiTuple(int start1, int end1, String cat1, String word1)
	{
		start = start1;
		end = end1;
		cat = cat1;
		word = word1;
	}

	public void inc(int i)
	{
		start += i;
		end += i;
	}

}
