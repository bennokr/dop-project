/*
 * Created on Jun 5, 2003.
 *
 * @author Thuy Linh Nguyen and Andreas Zollmann
 *
*/

//import java.util.*;
import java.io.*;
import java.sql.*;

//import jdbm.*;

/**
 * Object of type FragmentDistribution contains a weight distribution of 
 * fragments of the same root. Caution! This class is highly unsynchronized.
 * 
 * @author Thuy Linh Nguyen and Andreas Zollmann
 *
 */
public class SQLFragmentDistribution extends FragmentDistribution
{
	/** 
	 * max. number of fragments in the buffer when iterating
	 * over all fragments of a distribution
	 */
	public static int fragmentBufferSize = 1000;
	
    /**
     * JDBC URL, initialized from com.mysql.jdbc.testsuite.url
     * system property, or defaults to jdbc:mysql:///test
     */
    public static String dbUrlGeneral =
        "jdbc:mysql://localhost:3307/?user=root&autoReconnect=true";
    public static String dbUrlDopstar =
        "jdbc:mysql://localhost:3307/dopstar?user=root&autoReconnect=true";

    public static String dbPath = "/scratch/andreas/mysql/";

    /**
     *  our connnection to the db - persists for life of program
     */
    private static Connection connection = null;

    private class FragmentIteratorImplementation implements FragmentIterator
    {
        //        JDBMEnumeration en;
        Statement dbStatement;
        private ResultSet rs;
        private long fragmentCounter = 0;
        private int bufferCounter = 0;
        private boolean hasNext;
        FragmentIteratorImplementation(String id)
            throws IOException, SQLException
        {
            // create communication means
            dbStatement = connection.createStatement();
            /*
             * we have to use the following hack since the current mysql-connector
             * implementation otherwise retrieves resultsets completely into 
             * memory. There might be problems if not all fragments are iterated over
             * (see  http://www.mysql.com/documentation/connector-j/index.html#id2800171)
             */
			//dbStatement = connection.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY, java.sql.ResultSet.CONCUR_READ_ONLY);
			//dbStatement.setFetchSize(Integer.MIN_VALUE);
			fetchNextBuffer();

			// in SQL, the pointer of a ResultSet points _before_ the first row
			// in the beginning
			// -> call next() immediately
			hasNext = rs.next();
			fragmentCounter++;
			bufferCounter++; 
        }
        
        private void fetchNextBuffer() throws SQLException {
			rs = dbStatement.executeQuery("SELECT SQL_BIG_RESULT * FROM " + id
			+ " LIMIT "+fragmentCounter+","+fragmentBufferSize);
			bufferCounter = 0;
       }

        public Fragment next() throws IOException, SQLException
        {
            Fragment f = new Fragment();
            //f.tree = (String) en.nextElement();
            f.tree = rs.getString("mykey");
            //f.weight = getWeight(f.tree);
            f.weight = rs.getDouble("myvalue");
            if (bufferCounter >= fragmentBufferSize) fetchNextBuffer();
            hasNext = rs.next();
			fragmentCounter++;
			bufferCounter++; 
            return f;
        }
        public boolean hasNext() throws IOException
        {
            return hasNext;
            //return en.hasMoreElements();
        }
    }

    private static void init()
        throws
            IOException,
            SQLException,
            InstantiationException,
            IllegalAccessException,
            ClassNotFoundException
    {
        //U.run("rm -fr "+dbPath+"test");
        //U.run("mkdir "+dbPath+"test");
        //connection = DOPStar.dbConnection;
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        //Properties prop = new Properties();
        //prop.setProperty("user", "php-azollman");
        //prop.setProperty("password", "XIvR?Dy7");
        //prop.setProperty("password", "2mkL/Pox");
        //conn = DriverManager.getConnection(dbUrl, prop);
        connection = DriverManager.getConnection(dbUrlGeneral);
        Statement dbStatement = connection.createStatement();
        dbStatement.executeUpdate("DROP DATABASE IF EXISTS dopstar");
        dbStatement.executeUpdate("CREATE DATABASE dopstar");
        dbStatement.close();
        connection = DriverManager.getConnection(dbUrlDopstar);

    }

    /**
     * Constructs new FragmentDistribution.
     * @param root The root label of the fragment distribution
     * @throws Exception
     */
    public SQLFragmentDistribution(String root)
        throws
            IOException,
            SQLException,
            InstantiationException,
            IllegalAccessException,
            ClassNotFoundException
    {
        super(root);

        if (connection == null)
        {
            // first time a FragmentDistribution instance is created
            init();
        }

        // create communication means
        Statement dbStatement = connection.createStatement();
        // create table in the database
        //		dbStatement.executeQuery(
        //			"CREATE CACHED TABLE "
        //				+ id
        //				+ " (mykey CHAR PRIMARY KEY, myvalue DOUBLE)");
        dbStatement.executeUpdate("CREATE  TABLE " + id
        //		+ " (id BIGINT NOT NULL AUTO_INCREMENT UNIQUE, mykey BLOB, INDEX(mykey(2)), myvalue DOUBLE)");
        +" (hash INT NOT NULL, INDEX(hash), mykey BLOB NOT NULL, myvalue DOUBLE NOT NULL)");
        //		+ " (mykey BLOB, myvalue DOUBLE, INDEX(mykey(10000)))");
        dbStatement.close();
    }

    public FragmentDistribution getNewFragmentDistribution(String root)
        throws
            IOException,
            SQLException,
            InstantiationException,
            IllegalAccessException,
            ClassNotFoundException
    {
        return new SQLFragmentDistribution(root);
    }

    /**
     * Returns a FragmentIterator of the non-zero weight fragments of the 
     * fragment distribution.
     * @return
     * @throws IOException
     */
    public FragmentIterator getFragmentIterator()
        throws IOException, SQLException
    {
        return new FragmentIteratorImplementation(id);
        //  return new FragmentIteratorImplementation(fragments.mykeys());
    }

    public void makeEmpty() throws IOException, SQLException
    {
        // create communication means
        Statement dbStatement = connection.createStatement();
        int i = dbStatement.executeUpdate("DELETE FROM " + id);
        // run the query

        if (i == -1)
        {
            throw new IOException("DB error when deleting table " + id);
        }
        dbStatement.close();

        //		fragments.dispose();
        //		fragments = null;
        //		//NOT NICE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
        //		id += "_me";
        //		fragments = recordManager.getHashtable(id);
        //		weightSum = 0.0;

    }

    /**
     * Gets the weight this distribution assigns to fragment `tree'.
     * @param tree
     * @return
     * @throws Exception
     */
    public double getWeight(String tree) throws IOException, SQLException
    {
        double ret;
        // create communication means
        Statement dbStatement = connection.createStatement();
        ResultSet rs =
            dbStatement.executeQuery(
                "SELECT myvalue FROM "
                    + id
                    + " WHERE hash="
                    + tree.hashCode()
                    + " AND mykey='"
                    + tree
                    + "'");
        boolean nonempty = rs.next();
        if (nonempty)
        {
            ret = rs.getDouble("myvalue");
        } else
        {
            ret = 0.0;
        }
        dbStatement.close();
        return ret;
    }

    /**
     * Sets the weight of Fragment `tree' to `w' without changing `weightSum'.
     * If `w'==0 then the `tree' is removed from the fragment distribution
     * in case it exists.
     * @param tree String representation of the fragment
     * @param w The weight to set
     * @throws IOException
     */
    public void setWeight(String tree, double w)
        throws IOException, SQLException
    {
        // create communication means
        Statement dbStatement = connection.createStatement();
        dbStatement.executeUpdate(
            "DELETE FROM "
                + id
                + " WHERE hash="
                + tree.hashCode()
                + " AND mykey='"
                + tree
                + "'");
        if (w != 0)
        {
            //        	System.out.println("hi");
            dbStatement.executeUpdate(
                "INSERT INTO "
                    + id
                    + " (hash,mykey,myvalue) VALUES("
                    + tree.hashCode()
                    + ", '"
                    + tree
                    + "', "
                    + w
                    + ")");
        }
        dbStatement.close();
    }

    /**
     * Clean up the data base from the fragment distribution, thus freeing disk space.
     * Automatically called by the garbage collection.
     * @throws IOException
     */
    public void dispose() throws IOException, SQLException
    {
        // create communication means
        Statement dbStatement = connection.createStatement();
        // delete the table corresponding to this fragment distribution
        dbStatement.executeUpdate("DROP TABLE " + id);
        dbStatement.close();
    }

}
