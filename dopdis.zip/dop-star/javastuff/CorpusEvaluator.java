import java.io.File;

/*
 * Created on Apr 13, 2004
 *
 */

/**
 * @author Andreas Zollmann
 *
 */
public class CorpusEvaluator extends DOPStar
{





    
	public static boolean showNonSingleWordSentencesResults = false;
    

    public static void main(String[] args) throws Exception
    {
		init(args);

		/**
		 * set to `true' for verbose output mode
		 */
		verbose = true;
	
		/**
		 * the unix output device / file used when running shell commands
		 * typically either /dev/tty or /dev/null or a filename
		 */
		unixOutputDevice = "/dev/tty";

		String[] tmpBackOffParsers = {};
		backOffParsers = tmpBackOffParsers;

//		System.out.println(System.getenv());
	    testingMode = args[2].equals("mpp")? ALLMPP :
					  args[2].equals("mpd")? MPD :
		              args[2].equals("mrp")? MRP :
		              -1;
		if (testingMode == -1) {
			throw new Exception("Syntax error!");
		}
		else {
			testParsers = new String[args.length - 4];
			for (int i = 0; i < testParsers.length; i++) {
				testParsers[i] = (new File(args[i+4]).getAbsoluteFile()).getPath();
				// if (testParsers[i].indexOf('/') != -1) throw new Exception("Error: none of the dopdis locations may contain a \"'\"!");
			}
			// trainPath = args[3]; 
			// if (!trainPath.endsWith("/")) trainPath += "/"; 
			testPath = (new File(args[1]).getAbsoluteFile()).getPath() + "/";
			test((new File(args[3]).getAbsoluteFile()).getPath(), 1, 1);
		}
		shutDown();
   }
}
