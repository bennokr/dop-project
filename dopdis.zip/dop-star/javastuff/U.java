import java.io.*;

/*
 * Created on Jan 10, 2004
 *
 */

/**
 * @author Andreas Zollmann
 *
 */
public class U
{
    /**
     * set to `true' for verbose output mode
     */
    public static boolean verbose = true;

    /**
     * the unix output device / file used when running shell commands
     * typically either /dev/tty or /dev/null or a filename
     */
    public static String unixOutputDevice = "/dev/tty";

    /** 
     * Stream logging important statistics etc.
     */
    public static LogPrintWriter log = null;

    /**
     * Similar to the assert command: if `cond' fails, a `RunTimeException' is thrown with
     * the error message "Failed sanity test! " + err.
     * @param cond
     * @param err
     */
    public static void ensure(boolean cond, String err)
    {
        if (!cond)
        {
            String msg = "Failed sanity test: " + err;
            Exception e = new RuntimeException(msg);
            //if (verbose) System.out.println(msg);
            e.printStackTrace();
            if (log != null)
                e.printStackTrace(log);
        }
    }

    /**
     * Prints a message with the number of seconds, minutes, hours (precision: 1/1000) that have 
     * passed since System.currentTimeMillis() was equal to starttime. 
     * @param starttime
     */
    public static void printTimeSpentMsg(long starttime)
    {
        System.out.println(
            "               Time spent: " + timeSpendStr(starttime));
    }

    /**
     * Returns a string with the number of seconds, minutes, hours (precision: 1/1000) that have 
     * passed since System.currentTimeMillis() was equal to starttime. 
     * @param starttime
     */
    public static String timeSpendStr(long starttime)
    {
        long endtime = System.currentTimeMillis();
        double timespend =
            (Math.round((double) (endtime - starttime)) / 1000.0);
        double timespend_min =
            Math.round(((double) (endtime - starttime)) / 60.0) / 1000.0;
        double timespend_h =
            (Math.round(((double) (endtime - starttime)) / 3600.0) / 1000.0);
        return timespend
            + " sec = "
            + timespend_min
            + " min = "
            + timespend_h
            + " h";
    }

    /**
     * Returns the number of seconds (precision: 1/1000) that have 
     * passed since System.currentTimeMillis() was equal to starttime. 
     * @param starttime
     */
    public static double timeSpent(long starttime)
    {
        long endtime = System.currentTimeMillis();
        return (Math.round((double) (endtime - starttime)) / 1000.0);
    }

    /**
     * Same as `run(command, null)'.
    */
    public static int run(String command) throws IOException
    {
        return run(command, null, null);
    }

    /**
     * Run a command in the `sh' shell, redirecting all standard and error 
     * output that is not redirected via `>' or `2>' to the console.
     * @param command Command (may include redirection and other sh-specific features
     * but no piping - for pipes use `runDirectly')
     * @param workingDir Directory in which the command is executed. If `null', 
     * there is no predefined working 
     * directory in which the command is executed.
     * @return Exit code
     * @throws IOException
     * @throws InterruptedException
     */
    public static int run(String command, String workingDir)
        throws IOException
    {
        return run(command, workingDir, null);
    }

    /**
     * Run a command in the `sh' shell, redirecting all standard and error 
     * output that is not redirected via `>' or `2>' to the console
     * and at the same time logging the error output in `errLogFile'. 
     * @param command Command (may include redirection and other sh-specific features
     * but no piping - for pipes use `runDirectly')
     * @param workingDir Directory in which the command is executed. If `null', 
     * there is no predefined working 
     * directory in which the command is executed.
     * @param errLogFile
     * @return Exit code
     * @throws IOException
     * @throws InterruptedException
     */
    public static int run(String command, String workingDir,
    // String stdLogFile,
    String errLogFile) throws IOException
    {
        command = errLogFile == null ?
        /* display standard and error output on console 
         * (if they haven't been redirected in 'command')
         */
        ">" + unixOutputDevice + " 2>" + unixOutputDevice + " " + command
        /* Error output to handle one, exec. command, then log 
         * handle one stream to errLogFile and also output it to console.
         * 
         * If std output is redirected in 'command', it won't be displayed
         * on console, otherwise, err and std output will both appear
         * on console.
         */
        : "2>&1 "
            + command
            + " |tee "
            + errLogFile
            + " 2>"
            + unixOutputDevice
            + " >"
            + unixOutputDevice
            + "";
        return runDirectly(command, workingDir);
    }

    /**
     * Run a command in the `sh' shell -
     * CAUTION! if the program has output, that output must be redirected; otherwise,
     * the stdout/errout buffers (which is not emptied) might get filled and cause
     * a deadlock.
     * @param command Command (may include redirection, pipes, and other sh-specific features)
     * @param workingDir Directory in which the command is executed
     * @param errLogFile
     * @return Exit code
     * @throws IOException
     * @throws InterruptedException
     */
    public static int runDirectly(String command, String workingDir)
        throws IOException
    {
        long starttime = System.currentTimeMillis();

        //        PrintWriter sysOut =
        //            new PrintWriter(
        //                new BufferedWriter(new OutputStreamWriter(System.out)));
        //
        //        PrintWriter stdOut =
        //            (stdLogFile == null)
        //                ? sysOut
        //                : new PrintWriter(
        //                    new BufferedWriter(new FileWriter(stdLogFile)));
        //        PrintWriter errOut =
        //            (errLogFile == null)
        //                ? sysOut
        //                : new PrintWriter(
        //                    new BufferedWriter(new FileWriter(errLogFile)));

        Runtime rt = Runtime.getRuntime();
        //Process process;

        if (verbose)
            System.out.println("RUN> " + command);
        if (workingDir != null)
            command = "cd " + workingDir + "; " + command;
        String[] strArray = { "/bin/bash", "-c", command };

        /* the commented line below does not work reliably 
         * (bug in Java upto at least 1.4.1)
         * therefore the workaround above using `cd'
         */
        //Process process = rt.exec(strArray, null, new File(workingDir));

        Process process = rt.exec(strArray, null, null);

        // do not pass any input
        process.getOutputStream().close();

        //        PrintStream stdOut =
        //            (stdLogFile == null)
        //                ? null
        //                : new PrintStream(
        //                    new BufferedOutputStream(
        //                        new FileOutputStream(stdLogFile)));
        //        PrintStream errOut =
        //            (errLogFile == null)
        //                ? null
        //                : new PrintStream(
        //                    new BufferedOutputStream(
        //                        new FileOutputStream(errLogFile)));
        //
        //        SimpleProcess process =
        //            new SimpleProcess(
        //                rt.exec(strArray, null, new File(workingDir)),
        //                System.in,
        //                stdOut,
        //                errOut);

        //		//process = rt.exec(command, null, new File(workingDir));
        //        //process = rt.exec("/usr/local/bin/tcsh -xfs", null, new File(workingDir));
        //            
        //        //pass input
        //        //PrintWriter pout = new PrintWriter(process.getOutputStream());
        //        //pout.println(command);
        //        //pout.close();
        //
        //		if (verbose) System.out.print("      started process - ");
        //
        //        //handle the output
        //        StreamGobbler outputGobbler =
        //            new StreamGobbler(process.getInputStream(), "Std", stdLogFile);
        //        StreamGobbler errorGobbler =
        //            new StreamGobbler(process.getErrorStream(), "Err", errLogFile);
        //        errorGobbler.start();
        //        outputGobbler.start();
        //		if (verbose) System.out.println("started output gobblers - ");
        //        errorGobbler.join();
        //        outputGobbler.join();
        //		if (verbose) System.out.print("     - waited for o.g.'s to finish - ");
        //

        ////        // process the standard output of the application
        ////        // error output is always redirected to the terminal using 2>/dev/tty resp. 2>&1
        ////        // if you want to process both std and err output, threads are needed in order 
        ////        // to ensure simultanious processing and thus to avoid deadlock	
        ////        {
        ////            BufferedReader std =
        ////                new BufferedReader(
        ////                    new InputStreamReader(process.getInputStream()));
        ////            //                    BufferedReader err =
        ////            //                        new BufferedReader(
        ////            //                            new InputStreamReader(process.getErrorStream()));
        ////            //        
        ////            for (String line1 = std.readLine();
        ////                line1 != null;
        ////                line1 = std.readLine())
        ////            {
        ////                if (verbose) System.out.println("STD>" + line1);
        ////                //                        if (errLogFile != null)
        ////                //                            sysOut.println(line1);
        ////            }
        ////            //            for (String line = br.readLine();
        ////            //                line != null;
        ////            //                line = br.readLine())
        ////            //            {
        ////            //                stdOut.println(line);
        ////            //                if (stdLogFile != null)
        ////            //                    sysOut.println(line);
        ////            //            }
        ////            //
        ////            //            sysOut.flush();
        ////            //            if (stdLogFile != null)
        ////            //                stdOut.close();
        ////            //            if (errLogFile != null)
        ////            //                errOut.close();
        ////        }

        //        {
        //            BufferedReader in =
        //                new BufferedReader(
        //                    new InputStreamReader(process.getInputStream()));
        //            BufferedReader err =
        //                new BufferedReader(
        //                    new InputStreamReader(process.getErrorStream()));
        //
        //            boolean alive = true;
        //            for (int errChk = 2, inChk = 2;
        //                err.ready() || in.ready() || alive;
        //                )
        //            {
        //                try
        //                {
        //                    process.exitValue();
        //                    alive = false;
        //                } catch (IllegalThreadStateException e)
        //                {
        //                    //try {Thread.sleep(0,1);} catch (InterruptedException ie) {};
        //                    if (verbose) System.out.print("L");
        //                }
        //                while (err.ready() && errChk != -1)
        //                {
        //                    errChk = err.read();
        //                    if (errChk != -1)
        //                    {
        //                        out.write(errChk);
        //                        if (logFile != null)
        //                            sysOut.write(errChk);
        //                    }
        //                }
        //                while (in.ready() && inChk != -1)
        //                {
        //                    inChk = in.read();
        //                    if (inChk != -1)
        //                    {
        //                        out.write(inChk);
        //                        if (logFile != null)
        //                            sysOut.write(inChk);
        //                    }
        //                }
        //                out.flush();
        //            }
        //        }

        //if (verbose) System.out.print("           (waiting for process thread to finish... ");
        int exitVal = 1;
        try
        {
            exitVal = process.waitFor();
        } catch (InterruptedException e)
        {
            e.printStackTrace();
            System.exit(1);
        }
        //if (verbose) System.out.println("finished)");

        ////process.getInputStream().close();
        ////process.getErrorStream().close();

        //process.destroy();

        if (verbose)
            printTimeSpentMsg(starttime);
        if (exitVal != 0)
        {
            System.out.println(
                "ERROR EXIT " + exitVal + " when running command " + command);

            if (log != null)
                log.println(
                    "ERROR EXIT "
                        + exitVal
                        + " when running command "
                        + command);
        }
        return exitVal;
    }

    /**
     * Returns the number of lines contained in text file `textFile'.
     * @param textFile
     * @return
     * @throws IOException
     */
    public static int getTextFileLinesCount(String textFile) throws IOException
    {
        int linesCount = 0;
        File f = new File(textFile);
        BufferedReader br = new BufferedReader(new FileReader(f));
        while ((br.readLine()) != null)
        {
            linesCount++;
        }
        return linesCount;
    }

}
