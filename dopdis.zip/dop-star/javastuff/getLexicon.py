import os,re,string,sys,getopt

def getLexicon(argv):
    """
    @return: Create lexicon file from file with trees and counts (STSG).
    """
    (f,L,F) = parseInput(argv)
    ssss = re.compile(r'\(ssss,')
    sss = re.compile(r'\(sss,')
    xxx = re.compile(r'xxx')
    lex = re.compile(r'[A-Za-z-@]+,\[\([a-z]+_,\[\]\)\],[0-9e+-.]+')

    if 'ssss.out' in os.listdir(os.getcwd()):
        os.remove(os.getcwd()+"/"+'ssss.out')
    fssss = open('ssss.out','a',0)        
    if 'sss.out' in os.listdir(os.getcwd()):
        os.remove(os.getcwd()+"/"+'sss.out')
    fsss = open('sss.out','a',0)
                
    s = f.readline()
    while s != "":
        if lex.search(s):
            L.write(s)
        elif ssss.search(s):
            fssss.write(s)
        elif sss.search(s):
            if not xxx.search(s):
               fsss.write(s)
            else:
                F.write(s)
        else:
            F.write(s)
        s = f.readline()

    f.close()
    L.close()
    fssss.close()
    fsss.close()
    F.close()  
      
def parseInput(argv):
    """
    return: File object for input file and file for output.
    rtype f: C{file}
    rtype F: C{file}
    """
    try:
        opts,args = getopt.getopt(argv,"hf:L:F:")        
    except getopt.GetoptError:
        usage()            
        sys.exit(2)

    infile = outfile1 = outfile2 = 0
    for o,a in opts:
        if o in ["-h"]: usage(), sys.exit(2)
        elif o in ["-f"]: infile = a
        elif o in ["-L"]: outfile1 = a       
        elif o in ["-F"]: outfile2 = a        

    if not infile or not outfile1 or not outfile2:
        usage(), sys.exit(2)
    else:
        try:
            f = open(infile,'r')                
        except:
            print "File %s not found" % infile
            sys.exit(2)
        try:
            if outfile1 in os.listdir(os.getcwd()):
                os.remove(os.getcwd()+"/"+outfile1)
            L = open(outfile1,'a',0)
        except: 
            print "Cannot open %s" % outfile1
            sys.exit(2)
        try:
            if outfile2 in os.listdir(os.getcwd()):
                os.remove(os.getcwd()+"/"+outfile2)
            F = open(outfile2,'a',0)
        except: 
            print "Cannot open %s" % outfile2
            sys.exit(2)

            
    return (f,L,F) 
            
def usage():  
    print "function: Create lexicon file (creates files for ssss and sss rules)."
    print "usage: python getLexicon.py -f <file_with_trees_and_counts>"
    print "                            -L <output_file_with_lexicon>"
    print "                            -F <output_file_without_lexicon>"
#--------------------------------------------------------------------------------------------------
getLexicon(sys.argv[1:])    
