/*
 * Created on May 29, 2003
 *
 */

import java.util.*;
//import jdbm.*;

/**
 * @author Thuy Linh Nguyen and Andreas Zollmann
 * 
 * 
 */
public class Tree
{
    /**
     *  The greatest depth over all of the trees that have been constructed so far.
     */
    public static int greatestDepth = 0;

    /**
    Important for PCFG rule creation - has to be initialized before use.
    Nodestatistics has element's key is
    String type contains nonterminal node
    its data is a Float that contains the number of nonterminal's 
    DOP trees in theory (this number is an integer number but to 
             avoid overflow, program store it as a float number)  
    Nodestatisticsdata is updated when create new tree from the tree bank
     */
    public static HashMap Nodestatistics = null;

    public String rootname;

    /**
     * If terminal == true, the tree is just a single terminal node
     */
    public boolean terminal;

    /**
     * address of tree's root
     */
    public int rootaddress;

    //public int siblingseq; //tree's child sequence in its mother tree, incase tree has no mother tree siblingseq = 0

    /**
     * tree's parents address, incase the tree have no parent tree parentaddress=0
     */
    public int parentaddress;

    /**
     * Number of DOP trees (fragments) contained current tree 
     * that have the same root as this tree ( i.e., rootname)
     */
    public float cnt_DOPsubtrees;

    /**
     * Tree 's depth (i.e., n.o. nodes along longest path - 1): 0, 1, 2,...
     * -1 if undefined.
     */
    public int treedepth;

    /**
     * Vector of this tree's subtrees -- should never be `null'. If there are no subtrees (i.e., if this
     * tree is a leaf) then the vector has size 0.
     */
    public Vector subtrees;

    private Tree()
    {
        subtrees = new Vector();
        this.cnt_DOPsubtrees = 0;
        this.treedepth = 0;
    }

    /*
     * Constructor Tree from String treestr, which represent that tree
     */
    public Tree(String treestr)
    {
        String rootstr;
        rootstr = treestr.substring(0, treestr.indexOf(','));
        //assign root tree data     
        //this.siblingseq=0;
        this.treedepth = 0;
        this.rootname = rootstr;

        if (rootstr.charAt(rootstr.length() - 1) == '_')
        {
            this.terminal = true;
            //            this.rootname = this.rootname.substring(0, this.rootname.length() - 1);
            //            this.cnt_DOPsubtrees = 0;
            //            subtrees = new Vector();
            //            return;
        } else
        {
            this.terminal = false;
        }
        //DOPStar.cnt_nonterminalnodes++; //for statistics purpose only           

        String subtrees_str =
            treestr.substring(
                treestr.indexOf('[') + 1,
                treestr.lastIndexOf(']'));
        //         example of substrees_str = (tvxA,[(nee_,[])
        if (terminal && subtrees_str.length() != 0)
            throw new IllegalArgumentException(
                "Error creating tree "
                    + treestr
                    + "! Terminal node '"
                    + rootstr
                    + "' has subtrees!");

        // assign subtrees data:

        subtrees = new Vector();

        if (subtrees_str.length() == 0)
        {
            cnt_DOPsubtrees = 0;
            return;
        }

        int cnt_openbracket = 0;
        int cnt_closebracket = 0;
        int cnt = 0;
        int ind_openbracket;
        int ind_closebracket;
        int subtree_index = 0;
        String working_str = subtrees_str;
        String one_subtreestr; //String for one subtree

        ind_openbracket = working_str.indexOf('(');
        int max_subtreedepth = -1;
        //max_subtreedepth contains the maximum depth of all the subtrees.

        this.cnt_DOPsubtrees = 1;

        while (ind_openbracket >= 0)
        {
            subtree_index++;
            cnt_openbracket++;
            int current_index = 0;
            //get string for one subtree
            while (cnt_openbracket > cnt_closebracket)
            {
                ind_closebracket =
                    working_str.indexOf(')', current_index + 1);
                ind_openbracket = working_str.indexOf('(', current_index + 1);
                if (ind_closebracket > ind_openbracket
                    && ind_openbracket >= 0)
                {
                    cnt_openbracket++;
                    current_index = ind_openbracket + 1;
                } else
                {
                    cnt_closebracket++;
                    current_index = ind_closebracket + 1;
                }
            }
            one_subtreestr =
                working_str.substring(
                    working_str.indexOf('(') + 1,
                    current_index - 1);

            //Create a new subtree;
            Tree one_subtree = new Tree(one_subtreestr);

            //one_subtree.siblingseq = subtree_index;
            if (max_subtreedepth < one_subtree.treedepth)
                max_subtreedepth = one_subtree.treedepth;
            boolean b;
            b = subtrees.add(one_subtree);
            //update number of its subtree headed by tree's root:
            this.cnt_DOPsubtrees =
                this.cnt_DOPsubtrees * (one_subtree.cnt_DOPsubtrees + 1);

            ind_openbracket = working_str.indexOf('(', current_index);
            if (ind_openbracket >= 0)
                working_str =
                    working_str
                        .substring(working_str.indexOf('(', current_index))
                        .trim();

            cnt_openbracket = 0;
            cnt_closebracket = 0;

        }
        treedepth = max_subtreedepth + 1;
        if (treedepth > greatestDepth)
            greatestDepth = treedepth;

        // for PCFG use:
        if (Nodestatistics != null)
        {
            //update number of fragments in the whole corpus headed by tree's root
            if (Nodestatistics.containsKey(this.rootname))
            {
                float node_cntfragments =
                    ((Float) Nodestatistics.get(this.rootname)).floatValue();
                node_cntfragments += this.cnt_DOPsubtrees;
                Nodestatistics.remove(this.rootname);
                Nodestatistics.put(
                    this.rootname,
                    new Float(node_cntfragments));
            } else
                Nodestatistics.put(
                    this.rootname,
                    new Float(this.cnt_DOPsubtrees));
        }
    }

    /*  public boolean equalsTree(Tree tree){
            if (this.terminal && tree.terminal && this.rootname.equals(tree.rootname))
                return true;
            if (this.terminal != tree.terminal)
                return false;
            if (!this.rootname.equals( tree.rootname))
                return false;           
            if (this.subtrees.size()!=tree.subtrees.size())
                return false;
            int i=0;
            
            while (i < this.subtrees.size())
            {
                Tree subtree1 = (Tree)this.subtrees.get(i);
                Tree subtree2 = (Tree)tree.subtrees.get(i);
                if (subtree1.equalsTree(subtree2))
                    i++;
                else
                    return false;   
            }
            
            return true;        
        }
    */

    /**
     * Returns the derivation represented by this tree (where nodes at which composition
     * occurred are prefixed by a `*') in the form of a vector of string-represented 
     * fragments. 
     */
    public Vector expandDerivation() throws Exception
    {
        Vector v = new Vector(); // will be returned

        // create deep copy and remove the `*' symbols
        Tree firstFragment = new Tree(this.toString().replaceAll("\\*", ""));

        // note that the treedepth variable in the firstFragment tree and subtrees
        // will be undefined

        int k = this.subtrees.size();
        for (int i = 0; i < k; i++)
        {
            Tree t_sub = (Tree) this.subtrees.get(i);
            Vector v1 = t_sub.expandDerivation();
            if (t_sub.rootname.startsWith("*"))
            {
                Tree t1 = (Tree) firstFragment.subtrees.get(i);

                // make node a leaf
                t1.subtrees = new Vector();
            } else
            {
                // insert first fragment of this subtree's derivation sequence
                // into the respective node
                firstFragment.subtrees.set(i, v1.get(0));

                // delete first fragment of this subtree's derivation sequence
                v1.remove(0);
            }
            v.addAll(v1);
        }
        v.add(0, firstFragment);
        return v;
    }

    /**
     * Compare this tree with tree t, where no difference is made between actual
     * parse trees and short-forms of derivations; i.e., the "*" character in the
     * labels is simply ignored.
     *  
     * @param t
     * @return
     */
    public boolean nonStrictEquals(Tree t)
    {
        return nonStrictEqualsStr(toString(), t.toString());
    }

    /**
     * 
     * Compare tree t1 (in String representation) with tree t2 
     * (also in String representation),
     * where no difference is made between actual
     * parse trees and short-forms of derivations; i.e., the "*" character in the
     * labels is simply ignored.
     *  
     * @param t1
     * @param t2
     * @return
     */
    public static boolean nonStrictEqualsStr(String t1, String t2)
    {
        //System.out.println(t1); System.out.println(t2);

        String s1 = t1.replaceAll("\\*", "");
        String s2 = t2.replaceAll("\\*", "");

        //System.out.println(s1); System.out.println(s2);

        return s1.equals(s2);
    }
    
    /**
     * Converts a `derivation' (in String-representation) into a
     * parse tree. Simply replaces all "*"s by nothing.
     * @param derivation
     * @return
     */
    public static String derivationToParse(String derivation) {
    	return derivation.replaceAll("\\*", "");
    }

    public static String dopdisLineToTree(String dopdisLine)
    {
        String s = dopdisLine.replaceAll(" ", "");

        // delete leading '(' and trailing ")."
        s = s.substring(1, s.length() - 2);

        return s;
    }

    public static String sentenceToUnknTree(Vector sentence)
    {
//        String res = "sss,[(UNKNOWNPARSE,[";
//        boolean writeComma = false;
//        for (Iterator it = sentence.iterator(); it.hasNext();)
//        {
//            if (writeComma)
//                res += ",";
//            String word = (String) it.next();
//            res += "(UNKNOWN,[(" + word + ",[])])";
//            writeComma = true;
//        }
//        res += "])]";
//        return res;
		return "sss,[(XXXnonOemptydf,[])]";
    }

    /**
     * Returns the string representing this tree.
     */
    public String toString()
    {

        //        if (this.terminal)
        //            return this.rootname + "_, []";
        if (this.subtrees.size() == 0)
            return this.rootname + ",[]";

        String treeString = new String();
        int i = 0;
        treeString = this.rootname + ",[";

        int k = this.subtrees.size();
        while (i < k)
        {
            if (i < k - 1)
                treeString =
                    treeString
                        + "("
                        + ((Tree) this.subtrees.get(i)).toString()
                        + "),";

            else
                treeString =
                    treeString
                        + "("
                        + ((Tree) this.subtrees.get(i)).toString()
                        + ")";

            i++;
        }
        treeString = treeString + "]";

        return treeString;
    }

    /**
     * Returns the yield (Vector of String objects)
     * of this tree.
     */
    public Vector getYield() throws Exception
    {
        return getYieldSub();
    }

    /**
     * Returns a string-representation of the yield
     * of this tree.
     */
    public String getYieldString() throws Exception
    {
        Vector v = getYieldSub();
        String res = "";
        for (Iterator it = v.iterator(); it.hasNext();)
        {
            String vt = (String) it.next();
            res += res.equals("") ? vt : " " + vt;
        }
        return res;
    }

    private Vector getYieldSub() throws Exception
    {
        Vector res = new Vector();

        if (this.subtrees.size() == 0)
        {
            res.add(this.rootname);
        } else
        {
            for (int i = 0; i < this.subtrees.size(); i++)
            {
                Vector v = ((Tree) this.subtrees.get(i)).getYieldSub();

                for (Iterator it = v.iterator(); it.hasNext();)
                {
                    String vt = (String) it.next();
                    res.add(vt);
                }
            }
        }
        return res;
    }

    /**
     * Returns the labeled-constituent Viterbi format (Vector of ViterbiTuple objects)
     * of this tree in post-fix order.
     */
    public Vector toViterbiFormat() throws Exception
    {
        return toViterbiFormatSub("");
    }

    /**
     * Returns a string-representation of the labeled-constituent Viterbi format (Vector of ViterbiTuple objects)
     * of this tree in post-fix order.
     */
    public String toViterbiFormatString() throws Exception
    {
        Vector v = toViterbiFormatSub("");
        String res = "";
        for (Iterator it = v.iterator(); it.hasNext();)
        {
            ViterbiTuple vt = (ViterbiTuple) it.next();
            res += vt.start
                + " "
                + vt.end
                + " "
                + vt.cat
                + "/"
                + vt.word
                + "    ";
        }
        return res;
    }

    private Vector toViterbiFormatSub(String parentNode) throws Exception
    {
        Vector res = new Vector();

        if (this.terminal)
        {
            res.add(new ViterbiTuple(1, 2, parentNode, this.rootname));
        } else
        {
            if (this.subtrees.size() == 0)
                throw new IllegalArgumentException("Tree contains a nonterminal leaf!");

            int terminalCount = 0;
            for (int i = 0; i < this.subtrees.size(); i++)
            {
                Vector v =
                    ((Tree) this.subtrees.get(i)).toViterbiFormatSub(
                        rootname);

                for (Iterator it = v.iterator(); it.hasNext();)
                {
                    ViterbiTuple vt = (ViterbiTuple) it.next();

                    // adjust offsets `start' and `end' of each Viterbi Tuple vt
                    // returned by the current subtree i by the number of leaves
                    // spanned by the subtrees 0,...,i-1 left to it
                    vt.inc(terminalCount);

                    res.add(vt);

                    // the last element of the vector is the Viterbi Tuple of
                    // the whole subtree i
                    // --> add n.o. leaves spanned by this subtree to terminalCount
                    if (!it.hasNext())
                        terminalCount = vt.end - 1;
                }

            }
            if (subtrees.size() == 1 && ((Tree) subtrees.get(0)).terminal)
            { // we are talking about a POS category (only a terminal under it)
            } else
            { // we are not talking about a POS category (only a terminal under it)
                //!!!!currently commented out because khalil's parser does not work properly
                //                res.add(
                //                    new ViterbiTuple(
                //                        1,
                //                        terminalCount + 1,
                //                        this.rootname,
                //                        "xxxphrase_"));
            }
        }
        return res;
    }

    /*  public String getStringwithAddress(){
            
                if (this.terminal)
                    return this.rootname +"_, []";
            
                String treeString = new String();
                int i = 0;
                treeString = this.rootname + "@_"+this.rootaddress+ ", [";
            
                int k =this.subtrees.size();
                while (i<k)
                {
                    if (i < k-1)
                        treeString = treeString + "("+((Tree)this.subtrees.get(i)).getStringwithAddress()+"),";
                    
                    else
                        treeString = treeString + "("+((Tree)this.subtrees.get(i)).getStringwithAddress()+")";
                
                    i++;
                }
                treeString = treeString +"]";
            
                return treeString;      
            }
            */

    /**
     * assignAddress(int startaddr, int parentaddr) method assign the address for each node in the
     * tree start from the root with startaddr then each its subtrees, 
     * method return the last address of the tree
     */
    public int assignAddress(int startaddr, int parentaddr)
    {
        int startnumber = startaddr;
        this.parentaddress = parentaddr;
        if (this.subtrees.size() == 0)
            return startnumber;
        this.rootaddress = startnumber;
        startnumber++;
        int k = this.subtrees.size();
        int i = 0;
        while (i < k)
        {
            Tree subtree = (Tree) this.subtrees.get(i);
            startnumber =
                subtree.assignAddress(startnumber, this.rootaddress);
            i++;
        }
        return startnumber;
    }

    /**
     * concattrees method concate list of trees that have the same root and return the new tree.
     * It is used when generate DOP trees
     */
    public static Tree concattrees(Vector trees)
    {
        int i = 0;
        int cnt_trees = trees.size();
        Tree tree1 = (Tree) trees.get(0);

        Tree bigtree = new Tree();
        bigtree.parentaddress = tree1.parentaddress;
        bigtree.rootaddress = tree1.rootaddress;
        bigtree.rootname = tree1.rootname;
        bigtree.subtrees = new Vector();
        bigtree.treedepth = -1;
        while (i < cnt_trees)
        {
            Tree tmp = (Tree) ((Tree) trees.get(i)).subtrees.get(0);
            bigtree.subtrees.add(tmp);
            i++;
            if (bigtree.treedepth < tmp.treedepth)
                bigtree.treedepth = tmp.treedepth;
        }
        bigtree.treedepth++;
        return bigtree;
    }

    /**
     * concateroot() method concate root of input tree with new root 
     * that has rootname,rootaddress, parentaddress and return the new tree  
     */
    public static Tree concateroot(
        Tree tree,
        String rootname,
        int rootaddress,
        int parentaddress)
    {
        Tree returntree = new Tree();
        returntree.rootname = rootname;
        returntree.subtrees = new Vector();
        returntree.rootaddress = rootaddress;
        returntree.parentaddress = parentaddress;
        returntree.subtrees.add(tree);
        returntree.treedepth = tree.treedepth + 1;
        return returntree;
    }

    /**
     * Does not work correctly!!
     * method generatefragments generate list of DOP trees
     */
    public Vector generateFragments(int max_allowed_treedepth)
    {
        Vector fragments = new Vector();
        //fragments Vector stores list of FragmentCorpus (one for each root label)
        // this Vector is  returned by the method
        if (this.subtrees.size() == 0)
            return fragments;
        int k = this.subtrees.size();
        if (k == 0)
            return fragments;

        ArrayList subfragments = new ArrayList();

        int i = 0;

        //generate list of DOP trees headed by subtrees
        //primarytree is tree depth= 1 with root as this.tree.rootname and leaves is its subnode
        //subfragments vector store list of DOP trees for each subnodes with depth <= max_depth-1 
        while (i < k)
        {
            boolean b;
            Vector v = new Vector();
            v =
                ((Tree) this.subtrees.get(i)).generateFragments(
                    max_allowed_treedepth);
            if (v.size() != 0)
                b = fragments.addAll(v);

            Tree subtree = new Tree();
            Tree primarytree = new Tree();
            subtree = (Tree) this.subtrees.get(i);
            primarytree.rootname = subtree.rootname;
            primarytree.terminal = subtree.terminal;
            primarytree.parentaddress = this.rootaddress;
            primarytree.treedepth = 0;

            v.add(primarytree);
            int j = 0;
            Vector v_1 = new Vector();
            while (j < v.size())
            {
                Tree rootsubtree = new Tree();
                rootsubtree = (Tree) v.get(j);
                if (rootsubtree.parentaddress == this.rootaddress
                    && rootsubtree.treedepth <= max_allowed_treedepth - 1)
                {
                    v_1.add(rootsubtree);
                }
                j++;
            }

            subfragments.add(v_1);
            i++;
        }

        //generate DOP trees that have root is this.rootname:       
        i = 0;
        Vector newDOPtree = new Vector();
        int[] fragmentsindex = new int[100];
        int[] Maxfragmentsindex = new int[100];
        for (i = 0; i < k; i++)
        {
            fragmentsindex[i] = 0;
            Maxfragmentsindex[i] = ((Vector) subfragments.get(i)).size();
        }
        i = 0;
        Vector new_tree = new Vector();
        while (fragmentsindex[0] < Maxfragmentsindex[0])
        {
            i = 0;
            new_tree = new Vector();
            while (i < k)
            {
                Vector vtmp = (Vector) subfragments.get(i);
                Tree treetmp = (Tree) vtmp.get(fragmentsindex[i]);
                new_tree.add(
                    concateroot(
                        treetmp,
                        this.rootname,
                        this.rootaddress,
                        this.parentaddress));
                i++;
            }
            Tree DOPnew_tree = new Tree();
            DOPnew_tree = Tree.concattrees(new_tree);
            fragments.add(DOPnew_tree);
            fragmentsindex[k - 1]++;

            int j = k - 1;

            while (fragmentsindex[j] >= Maxfragmentsindex[j])
            {
                fragmentsindex[j] = 0;
                j--;
                if (j >= 0)
                    fragmentsindex[j]++;
                else
                    return fragments;
            }
        }
        return fragments;
    }

    //    /**
    //     * generates FragmentCorpus (outsourced to the file system) 
    //     * of the fragments of this tree
    //	 * @param max_allowed_treedepth Maximum depth of which fragments are extracted
    //     * @return The fragment corpus
    //     */
    //    public FragmentCorpus generateFragments(int max_allowed_treedepth)
    //    {
    //        FragmentCorpus fragments = new FragmentCorpus ();
    //        //fragments is mapping from root labels to `FragmentDistribution's
    //        // fragments is returned by the method
    //        
    //        int k = subtrees.size();
    //        if (k == 0)
    //            return fragments;
    //
    //        ArrayList subfragments = new ArrayList();
    //
    //        int i = 0;
    //
    //        //generate list of DOP trees (=fragments) headed by subtrees
    //        //primarytree is tree depth= 1 with root as this.tree.rootname and leaves is its subnode
    //        //subfragments vector store list of DOP trees for each subnodes with depth <= max_depth-1 
    //        while (i < k)
    //        {
    //            //before: Vector v!
    //            FragmentCorpus v = 
    //                ((Tree) this.subtrees.get(i)).generateFragments(
    //                    max_allowed_treedepth);
    //            if (v.rootLabelCount() != 0)
    //                fragments.add(v);
    //
    //            Tree subtree = (Tree) this.subtrees.get(i);
    //
    //            Tree primarytree = new Tree();
    //            primarytree.rootname = subtree.rootname;
    //            primarytree.terminal = subtree.terminal;
    //            primarytree.parentaddress = this.rootaddress;
    //            primarytree.treedepth = 0;
    //
    //            v.add(primarytree, 1.0);
    //           
    //            int j = 0;
    //            Vector v_1 = new Vector();
    //            while (j < v.size())
    //            {
    //                Tree rootsubtree =  (Tree) v.get(j);
    //                if (rootsubtree.parentaddress == this.rootaddress
    //                    && rootsubtree.treedepth <= max_allowed_treedepth - 1)
    //                {
    //                    v_1.add(rootsubtree);
    //                }
    //                j++;
    //            }
    //
    //            subfragments.add(v_1);
    //            i++;
    //        }
    //
    //        //generate DOP trees that have root is this.rootname:       
    //        i = 0;
    //        Vector newDOPtree = new Vector();
    //        int[] fragmentsindex = new int[100];
    //        int[] Maxfragmentsindex = new int[100];
    //        for (i = 0; i < k; i++)
    //        {
    //            fragmentsindex[i] = 0;
    //            Maxfragmentsindex[i] = ((Vector) subfragments.get(i)).size();
    //        }
    //        i = 0;
    //        Vector new_tree = new Vector();
    //        while (fragmentsindex[0] < Maxfragmentsindex[0])
    //        {
    //            i = 0;
    //            new_tree = new Vector();
    //            while (i < k)
    //            {
    //                Vector vtmp = (Vector) subfragments.get(i);
    //                Tree treetmp = (Tree) vtmp.get(fragmentsindex[i]);
    //                new_tree.add(
    //                    concateroot(
    //                        treetmp,
    //                        this.rootname,
    //                        this.rootaddress,
    //                        this.parentaddress));
    //                i++;
    //            }
    //            Tree DOPnew_tree = new Tree();
    //            DOPnew_tree = Tree.concattrees(new_tree);
    //            fragments.add(DOPnew_tree);
    //            fragmentsindex[k - 1]++;
    //
    //            int j = k - 1;
    //
    //            while (fragmentsindex[j] >= Maxfragmentsindex[j])
    //            {
    //                fragmentsindex[j] = 0;
    //                j--;
    //                if (j >= 0)
    //                    fragmentsindex[j]++;
    //                else
    //                    return fragments;
    //            }
    //        }
    //        return fragments;
    //    }

    /**
     * Returns the root of the tree whose string representation is `treestr'. 
     * @param treestr
     * @return
     */
    public static String getRoot(String treestr)
    {
        return treestr.substring(0, treestr.indexOf(','));
    }

}
