import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/*
 * Created on Nov 20, 2003
 *
 */

/**
 * @author Andreas Zollmann, email: zollmann@gmx.de
 *
 */
public class ParserOutput extends TreeMap
{

    public void addOutputLine(double prob, String stdOutLine)
    {

        //s = s.substring(s.indexOf(' ') + 1);
        String s = stdOutLine.trim();
        // delete leading '(' and trailing ")."
        s = s.substring(1, s.length() - 2);

        if (addTreeCondition(s))
        {
            //System.out.println("adding "+s);
            Double key = new Double(prob);
            Set value = (Set) this.get(key);
            if (value == null)
            {
                value = new HashSet();
                this.put(key, value);
            }
            value.add(s);
        }
    }

    public boolean addTreeCondition(String treeStr)
    {
        return true;
    }

    public boolean containsTree(String treeStr)
    {
        boolean found = false;
        for (Iterator i = entrySet().iterator(); !found && i.hasNext();)
        {
            Map.Entry entry = (Map.Entry) i.next();
            Set set = (Set) entry.getValue();
            found = set.contains(treeStr);
        }
        return found;
    }

    /**
     *  Parses the (probability,tree) pairs from the output of dopdis, storing them
     * as (key, value) pairs in the inherited TreeMap. Simply runs
     * `parseOutput(dopdisStdOut, dopdisErrOut, false)'.
     * 
     * @author Andreas Zollmann
     * @param dopdisStdOut name of file containing dopdis standard output 
     * @param dopdisErrOut name of file containing dopdis error output
     * @return true iff the dopdis considered the input unknown because of an unknown lexical item. 
     *
     */
    public boolean parseOutput(String dopdisStdOut, String dopdisErrOut)
        throws IOException
    {
        return parseOutput(dopdisStdOut, dopdisErrOut, false);
    }

    /**
     *  Parses the (probability,tree) pairs from the output of dopdis
     *  started with parameters -Mxxx or -Kxxx 
     * (onlyPrefParse == false) or the preferred parse tree returned by dopdis
     * started with parameters -mxxx, -d, or no parameters (onlyPrefParse == true).
     * 
     * @author Andreas Zollmann
     * @param dopdisStdOut name of file containing dopdis standard output 
     * @param dopdisErrOut name of file containing dopdis error output
     * @return true iff the dopdis considered the input unknown because of an unknown lexical item. 
     *
     */
    public boolean parseOutput(
        String dopdisStdOut,
        String dopdisErrOut,
        boolean onlyPrefParse)
        throws IOException
    {
        boolean unknBecauseUnknWord = false; // gonna be returned later

        BufferedReader std = new BufferedReader(new FileReader(dopdisStdOut));
        BufferedReader err = new BufferedReader(new FileReader(dopdisErrOut));
        String stdStr = std.readLine();
        if (stdStr == null)
        {
            std.close();
            err.close();
            throw new IOException(
                "No standard output from program `dopdis' found in file "
                    + dopdisStdOut);
        }
        if (stdStr.startsWith("Error"))
        {
            std.close();
            err.close();
            throw new IOException(
                "Error running `dopdis': output file "
                    + dopdisStdOut
                    + " contains : "
                    + stdStr);
        }
        String errStr = err.readLine();
        if (errStr == null)
        {
            std.close();
            err.close();
            throw new IOException(
                "No error-output from program `dopdis' found in file "
                    + dopdisErrOut);
        }
//		U.run("cat "+dopdisStdOut);
//		U.run("cat "+dopdisErrOut);
//		System.out.println(!stdStr.startsWith("S: ")+" "+!stdStr.startsWith("(")+" "+
//		stdStr.equals("(sss,[(XXXnonword,[(UNKNOWN_,[])])])."));
//		System.in.read();
        if (errStr.startsWith("Error"))
        {
            std.close();
            err.close();
            throw new IOException(
                "Error running `dopdis': output file "
                    + dopdisErrOut
                    + " contains : "
                    + errStr);
        }
        if (stdStr.equals(""))
        {
            // reason for being here must be no parse / derivation found
            // either "(sss,[(XXXnonOemptydf,[])])." or "(sss,[(XXXnonOemptypf,[])])." 
            if (!std.readLine().startsWith("(sss,[(XXXnonOempty"))
            {
                std.close();
                err.close();
                throw new IOException(
                    "Something wrong with standard output from program `dopdis' found in file "
                        + dopdisStdOut);
            }

            // getting here means no derivation was found -> dopdisOutput remains
            // empty

        } else if (
            !stdStr.startsWith("S: ")
                && (!stdStr.startsWith("(")
                    || stdStr.equals("(sss,[(XXXnonword,[(UNKNOWN_,[])])]).")))
        {
            // a word is unknown or the parser has an unacceptable output
            boolean somethingWrong = false;
            for (boolean go_on = true; go_on; stdStr = std.readLine())
            {
                if (stdStr == null)
                {
                    somethingWrong = true;
                    go_on = false;
                } else
                {
                    go_on =
                        (!stdStr
                            .equals("(sss,[(XXXnonword,[(UNKNOWN_,[])])])."));
                }
            }
            if (somethingWrong)
            {
                std.close();
                err.close();
                throw new IOException(
                    "Something wrong with standard output from program `dopdis' found in file "
                        + dopdisStdOut);
            } else
            {
                // getting here means a word was unknown

                unknBecauseUnknWord = true;
            }
        } else
        {
            // store all output derivations matching the parse treeStr in dopdisOutput

            /* first look for a line like "2.500000e-01 1.250000e-01 ..." in
             * the error output
             */
            // if there is no such entry, that means, dopdis was run to only return
            // the preferred parse/derivation (onlyPrefParse == true)
            while (errStr != null
                && (errStr.length() == 0
                    || errStr.charAt(0) < '0'
                    || errStr.charAt(0) > '9'))
            {
                errStr = err.readLine();
            }
            if (errStr == null)
                U.ensure(
                    onlyPrefParse,
                    "dopdis was called to return all sampled derivations/parses, but no probabilities were returned in the Err output");

            /* in the next steps, we run the perl script RevECNFOut on all lines		
             * of dopdis' std output that start with "(". This script converts
             * the trees returned by dopdis - still in a binary representation -
             * back to their original representation. Since the script cannot
             * deal with "*"s in the trees, we use star_substitution to
             * temporarily translate the "*" character into "TempStarReplacement"
             * and star_resubstitution to translate back. 
             */
            String fileRevECNFOut =
                DOPStar.tmpPath + "tmpParserOutput_RevECNFOut";
            U.runDirectly(
                "grep '^(.*' <"
                    + dopdisStdOut
                    + " 2>"+U.unixOutputDevice+" |star_substitution"
                    + " 2>"+U.unixOutputDevice+" |RevECNF"
                    + " 2>"+U.unixOutputDevice+" |star_resubstitution >"
                    + fileRevECNFOut
                    + " 2>"+U.unixOutputDevice+"",
                null);

            /*
             * now, store those trees
             */
            BufferedReader brParses =
                new BufferedReader(new FileReader(fileRevECNFOut));
            String parsesStr = brParses.readLine();
            if (onlyPrefParse)
            {
                // only one parse tree to store
                addOutputLine(-1.0, parsesStr);
            } else
            {
                // save the (probability, tree) pairs from err / std output
                int errIndex = 0;
                for (; parsesStr != null; parsesStr = brParses.readLine())
                {
                    int newErrIndex = errStr.indexOf(' ', errIndex) + 1;
                    double prob =
                        Double.parseDouble(
                            errStr.substring(errIndex, newErrIndex - 1));
                    errIndex = newErrIndex;
                    addOutputLine(prob, parsesStr);
                    //System.out.println(dopdisOutput);
                }
                if (errIndex == 0)
                {
                    // for loop hasn't been executed at all
                    brParses.close();
                    std.close();
                    err.close();
                    throw new IOException(
                        "Something wrong with standard output from program `dopdis' found in file "
                            + dopdisStdOut);
                }
            }
            brParses.close();
        }
        std.close();
        err.close();

        return unknBecauseUnknWord;
    }
}
