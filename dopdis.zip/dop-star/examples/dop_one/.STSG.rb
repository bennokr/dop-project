ssss sss mp errorp errornp errormp adv 
a adj aan a@ error con bosch alphen 
ale amsterdam beek avp anna as as@ avp@ 
bergen berkel bloemwijk center capelle castricum centrum den 
de cornelis det drie dolder en elsloo driebergen 
erroradv errorinf errordet errornum errorv errorper errors errorpro 
infp inf helder haag gilze imps hollands holland 
hoek het hollandsche ijssel hout indie imps@ int 
infp@ klomp leyens laan koog kogerveld leidschendam lage 
lelylaan loo mierlo np n mp@ naar n@ 
noi nieuw noord p num np@ op oedelrode 
num@ oost oever oud s per part paulowna 
pro polder ptp rijen riet qs ptp@ rading 
qs@ rijn rodenrijs so schiedamrotterdam s@ schollevaar sint 
spoor so@ xxxprior xxxphrase tv ts t trade 
ts@ v uithof vp van vink vennep veen 
vechtwijk voorburg west vp@ wtc world zuid zaandam 
zoom zeist zee zwaluwe ;
aalten_ aan_ aangevraagd_ aankomen_ 
aankomende_ aankomst_ aansluitende_ aanstaande_ aanwezig_ aardig_ abcoude_ accoord_ 
acht_ achtendertig_ achtentwintig_ achterhoek_ achttien_ aerdenhout_ af_ afstand_ 
aken_ akkrum_ al_ ale_ alkmaar_ alleen_ allemaal_ allerlaatste_ 
allervroegste_ alles_ almelo_ almere_ alphen_ als_ alsjeblieft_ alsnog_ 
alstublieft_ america_ amersfoort_ amstel_ amsterdam_ andere_ anna_ antwerpen_ 
antwoord_ apeldoorn_ appelscha_ appingedam_ april_ arkel_ arnemuiden_ arnhem_ 
arriveren_ assen_ augustus_ avond_ baarn_ badbentheim_ barendrecht_ bargeres_ 
barneveld_ bedankt_ bedum_ beeindigen_ beek_ beekelsloo_ begin_ begrepen_ 
begrijpen_ begrijpt_ behoefte_ beilen_ bekend_ ben_ bent_ bergambacht_ 
bergen_ bergweg_ bericht_ berkel_ best_ bestemming_ beter_ betreffende_ 
beukenlaan_ beverwijk_ bij_ bijlmer_ bijvoorbeeld_ bilthoven_ blaak_ blerick_ 
blijven_ bloemendaal_ bloemwijk_ bo_ bodegraven_ boekel_ bolsward_ borne_ 
bosch_ boskoop_ bovenkarspel_ brabant_ breda_ bredaprinsenbeek_ breukelen_ brummen_ 
brunssum_ brussel_ buiten_ buitenpost_ bunde_ bunnik_ bussum_ buytenwegh_ 
camminghaburen_ capelle_ castricum_ center_ centraal_ centrum_ chevremont_ circa_ 
coevorden_ colmschate_ cornelis_ correct_ correcte_ correctie_ corrigeer_ cs_ 
culemborg_ cuyk_ daar_ daarlerveen_ daarvan_ daarvoor_ dacht_ dag_ 
dagen_ dalen_ dan_ dank_ dankuwel_ dat_ datum_ de_ 
december_ delden_ delft_ delftsewal_ delfzijl_ den_ denk_ dertien_ 
dertiende_ dertienhonderd_ dertig_ deurne_ deventer_ deze_ dezelfde_ didam_ 
die_ diemen_ dinsdag_ dinsdagmorgen_ dinsdagochtend_ dinsdags_ direkt_ dit_ 
doe_ doen_ doesburg_ doet_ doetichem_ doetinchem_ dokkum_ dolder_ 
dolgraag_ domburg_ donderdag_ donderdagavond_ doof_ door_ doorgaande_ doorgedrongen_ 
dordrecht_ drenthe_ drie_ driebergen_ driebergenrijsenburg_ driebergenzeist_ drieentwintig_ drieentwintigste_ 
drieenveertig_ driemanspolder_ duidelijk_ duiven_ duivendrecht_ dus_ e_ echt_ 
ede_ edewageningen_ een_ eenendertig_ eenendertigste_ eenentwintig_ eenentwintigste_ eens_ 
eentje_ eerder_ eerdere_ eerste_ eerstvolgende_ eigenlijk_ eindhoven_ eindpunt_ 
eindstation_ elf_ elsloo_ elst_ emmeloord_ emmen_ en_ enkhuizen_ 
enschede_ enter_ er_ ermelo_ ervan_ ervoor_ ettenleur_ even_ 
eygelshoven_ eysden_ februari_ fiets_ fijn_ flora_ fout_ foutief_ 
franeker_ friesland_ ga_ gaan_ gaat_ gebruik_ geen_ geerdijk_ 
gegeven_ gehoord_ geinformeerd_ gelderland_ geldermalsen_ geldrop_ gelegenheid_ genoeg_ 
genoemd_ genoteerd_ gesprek_ geval_ geven_ gevraagd_ geweten_ gezegd_ 
gilze_ gisteren_ goed_ goedemiddag_ goedenavond_ goeiendag_ goes_ goor_ 
gorinchem_ gouda_ graag_ grijpskerk_ groningen_ grouw_ haag_ haarlem_ 
had_ half_ hallo_ hardegarijp_ hardenberg_ harderwijk_ hardin_ haren_ 
harlingen_ hartelijk_ haven_ he_ heb_ hebben_ hebt_ heden_ 
heeft_ heel_ heemstede_ heemstedeaerdenhout_ heen_ heerenveen_ heerhugowaard_ heerlen_ 
heiloo_ heino_ helder_ hele_ helemaal_ hellendoorn_ helmond_ hem_ 
hengelo_ herhaald_ herhaalt_ herhalen_ herstel_ het_ hetzelfde_ heusden_ 
heyendaal_ hier_ hilversum_ hoe_ hoef_ hoeft_ hoek_ hoeveel_ 
hofplein_ holland_ hollands_ hollandsche_ honderd_ hoofddorp_ hoofdstad_ hoogcatharijne_ 
hoogeveen_ hoogezand_ hooghalen_ hoop_ hoor_ hoorn_ horen_ horst_ 
horstsevenum_ hout_ houten_ houtwijk_ hs_ huis_ hulst_ ieder_ 
iets_ ijlst_ ijssel_ ik_ in_ inderdaad_ indie_ informatie_ 
ingegeven_ ingelicht_ inlichtingen_ inmiddels_ intercity_ is_ ja_ jadatklopt_ 
januari_ jawel_ jazeker_ je_ juist_ juli_ juni_ kaart_ 
kampen_ kan_ keer_ ken_ kerkrade_ kersenboogerd_ kerst_ kerstdag_ 
kerstmis_ klimmen_ klok_ klomp_ klopt_ kogerveld_ kom_ komen_ 
komende_ komt_ koog_ koogbloemwijk_ koogzaandijk_ kosten_ krabbendijke_ krijg_ 
krommenie_ krommenieassendelft_ kruiningenyerseke_ kunnen_ kunt_ kwart_ laan_ laat_ 
laatste_ lage_ lammenschans_ landgraaf_ lang_ later_ latere_ leerdam_ 
leeuwarden_ leiden_ leidschendam_ leidschendamvoorburg_ lelylaan_ lelystad_ lemmer_ leyens_ 
lichtenvoorde_ liefst_ liever_ ligt_ lijkt_ limburg_ lisse_ ljouwert_ 
lochem_ lombardijen_ loo_ loop_ loosduinen_ loppersum_ lunetten_ lunteren_ 
maak_ maakt_ maand_ maandag_ maandagmiddag_ maandagmorgen_ maar_ maarn_ 
maarssen_ maart_ maassluis_ maastricht_ mag_ mariahoeve_ marienberg_ marienheem_ 
me_ medemblik_ medewerking_ meenemen_ meer_ meerssen_ mei_ meppel_ 
merci_ met_ meteen_ mevrouw_ middag_ middelburg_ middernacht_ mierlo_ 
mierlohout_ mij_ mijn_ minuten_ minuutjes_ misschien_ moest_ moet_ 
mogelijk_ mogelijke_ molkwerum_ moment_ morgen_ morgenavond_ morgenmiddag_ morgenochtend_ 
morgenvroeg_ muiden_ muiderpoort_ muziekwijk_ na_ naar_ naarden_ naardenbussum_ 
nacht_ namelijk_ napoleonlaan_ nee_ needanku_ neem_ neen_ negen_ 
negende_ negenentwintig_ negenenvijftig_ negentien_ negentienhonderd_ negentienhonderdzesennegentig_ negentienvijfennegentig_ negentienzesennegentig_ 
negentienzevenennegentig_ nemen_ niet_ niets_ nieuw_ nieuwe_ nieuweschans_ nijkerk_ 
nijmegen_ nijverdal_ nob_ nodig_ nog_ nogmaals_ noi_ noodzakelijk_ 
nooit_ noord_ nord_ noteren_ nou_ november_ ns_ nu_ 
nul_ nummer_ nunspeet_ nuth_ obdam_ ochtend_ oedelrode_ oeteldonk_ 
oever_ of_ ogenblik_ oisterwijk_ ok_ okay_ oktober_ oldenzaal_ 
olst_ om_ ommen_ omstreeks_ onbekend_ ongeveer_ ontvangen_ ook_ 
oorschot_ oost_ oosterhout_ oosterwijk_ oostsouburg_ op_ opdam_ opgegeven_ 
opgeschreven_ opgeven_ opnieuw_ opstap_ orde_ oss_ oud_ oudejaarsdag_ 
over_ overdag_ overmorgen_ overstappen_ overvecht_ overveen_ overwhere_ paar_ 
paasdag_ palenstein_ papendrecht_ pardon_ parijs_ paris_ parkwijk_ paulowna_ 
perron_ pijnacker_ plaats_ plan_ plusminus_ polder_ precies_ presikhaaf_ 
prima_ prinsenbeek_ punt_ purmerend_ putten_ rading_ rai_ randwijk_ 
ravenstein_ rechtstreeks_ rechtstreekse_ reis_ reisgelegenheid_ reizen_ retour_ retourreis_ 
reuver_ rheden_ rhenen_ richting_ riet_ rijden_ rijen_ rijn_ 
rijsbergen_ rijssen_ rijswijk_ rodenrijs_ roermond_ rond_ roodeschool_ roosendaal_ 
rosmalen_ rotterdam_ route_ ruurlo_ santpoort_ savonds_ schagen_ scheveningen_ 
schiedam_ schiedamrotterdam_ schijndel_ schinnen_ schiphol_ schollevaar_ schothorst_ seghwaert_ 
senioren_ sgravenhage_ shertogenbosch_ sint_ sinterklaas_ sittard_ sliedrecht_ sloterdijk_ 
slotervaart_ smiddags_ smorgens_ snachts_ sneek_ snel_ sneltrein_ sochtends_ 
soest_ soestdijk_ soestduinen_ sorry_ souburg_ spijt_ spoedig_ spoor_ 
sportpark_ sprinter_ stad_ stadskanaal_ station_ stavoren_ steeds_ steenwijk_ 
stop_ stopzetten_ straks_ swalmen_ t_ te_ tegelen_ tegen_ 
terapel_ terneuzen_ terug_ terugreis_ terugweg_ tevreden_ tharde_ tiel_ 
tien_ tijd_ tijden_ tijdstip_ tilburg_ toch_ toe_ tot_ 
trade_ trein_ treinen_ treinkosten_ treinverbinding_ tussen_ twaalf_ twee_ 
tweede_ tweeen_ tweeendertig_ tweeentwintig_ tweeentwintigste_ tweeenvijftig_ twintig_ twintigste_ 
u_ uden_ uit_ uiteraard_ uitgeest_ uithof_ uithuizen_ urk_ 
usquert_ utrecht_ uur_ uw_ valkenburg_ van_ vanaf_ vanavond_ 
vandaag_ vandaan_ vanmiddag_ vanmorgen_ vannacht_ vanochtend_ vanuit_ varsseveld_ 
vast_ vechtwijk_ veen_ veendam_ veenendaal_ veenwouden_ veertien_ veertienhonderd_ 
veertig_ velp_ velperpoort_ venlo_ vennep_ venray_ ver_ verband_ 
verbinding_ verbindingen_ verbroken_ verder_ verdere_ verkeerd_ verstaan_ verstond_ 
verstreken_ verteld_ vertrek_ vertrekken_ vertrekplaats_ vertrekt_ vertrektijd_ via_ 
vier_ vierde_ vieren_ vierendertig_ vierentwintig_ vierentwintigste_ vierlingsbeek_ vijf_ 
vijfendertig_ vijfentwintig_ vijfenveertig_ vijfenvijftig_ vijftien_ vijftiende_ vijftienhonderd_ vijftig_ 
vink_ vlaardingen_ vleuten_ vlissingen_ vlugtlaan_ voerendaal_ voldoende_ volgende_ 
volgens_ volledig_ voor_ voorburg_ voorhout_ voorkeur_ voorlopig_ voormiddag_ 
voorschoten_ voorweg_ voorwegh_ vriendelijk_ vriezenveen_ vrij_ vrijdag_ vrijdagavond_ 
vrijdagmiddag_ vrijdagmorgen_ vrijdagochtend_ vroeg_ vroeger_ vroegere_ vroegste_ vught_ 
waar_ waarmee_ wageningen_ wanneer_ want_ waren_ was_ wassenaar_ 
wat_ we_ wederom_ week_ weekend_ weer_ weert_ weesp_ 
weet_ weg_ weggaan_ wehl_ weichen_ weken_ wel_ welke_ 
werkdag_ west_ weten_ wiechen_ wierden_ wij_ wijhe_ wil_ 
wilde_ willen_ wilt_ winschoten_ winsum_ winterswijk_ woensdag_ woensdagmorgen_ 
woerden_ wolfheze_ worden_ wordt_ world_ wormer_ wormerveer_ wou_ 
wtc_ wychen_ xxxphrase_ zaandam_ zaltbommel_ zandvoort_ zaterdag_ zaterdagavond_ 
zaterdagmorgen_ zaterdagochtend_ zaterdags_ ze_ zee_ zeeland_ zeer_ zeg_ 
zeggen_ zegt_ zei_ zeist_ zelfs_ zes_ zesde_ zesennegentig_ 
zesentwintig_ zesentwintigste_ zestien_ zestienhonderd_ zetten_ zettenandelst_ zeuven_ zeuvende_ 
zeuvenentwintig_ zeuventien_ zeven_ zevenaar_ zevenbergen_ zevenendertig_ zevenentwintig_ zevenenveertig_ 
zeventien_ ziens_ zierikzee_ zijn_ zinvol_ zitten_ zo_ zoetermeer_ 
zoiets_ zondag_ zoom_ zou_ zuid_ zuidbroek_ zuidhorn_ zutphen_ 
zwaagwesteinde_ zwaluwe_ zwijndrecht_ zwolle_ ;
t t_ [279  1  0 ];
a p n [856  1  3 ];
a n s [1101  1  3 ];
a p s [1056  1  3 ];
a s s [1149  1  3 ];
a p v [897  1  3 ];
n n n [913  1  3 ];
p p p [683  1  3 ];
s s s [1145  1  3 ];
a s a@ [1355  1  1 , 1347  1  1 ];
p af_ [1080  1  0 ];
v ga_ [984  1  0 ];
p na_ [710  1  0 ];
a@ s n [1321  3  3 ];
a@ p s [1316  3  3 ];
p in_ [774  1  0 ];
a@ s s [1485  7  3 , 1467  7  3 , 1452  3  3 , 1355  3  3 , 1345  3  3 ];
n n n@ [1410  1  1 , 1272  1  1 ];
p om_ [36  1  0 ];
p op_ [97  1  0 ];
v is_ [64  1  0 ];
s n s@ [1430  1  1 ];
s s s@ [1482  1  1 , 1470  1  1 , 1444  1  1 , 1404  1  1 ];
sss a [23  1  1 ];
s v s@ [1323  1  1 ];
sss n [7  1  1 ];
sss p [5  1  1 ];
a n mp [779  1  3 ];
sss s [14  1  1 ];
a n np [800  1  3 ];
a np p [711  1  3 ];
sss v [8  1  1 ];
a mp s [1030  1  3 ];
a s mp [962  1  3 ];
a np s [1039  1  3 ];
a s np [976  1  3 ];
a@ s a@ [1495  7  1 , 1463  3  1 ];
a tv n [923  1  3 ];
n n mp [744  1  3 ];
a vp s [1116  1  3 ];
a s vp [1108  1  3 ];
np n n [905  1  3 ];
a ts s [1247  1  3 ];
a tv p [809  1  3 ];
mp p n [802  1  3 ];
a tv s [1092  1  3 ];
a s tv [1065  1  3 ];
a tv v [949  1  3 ];
s s mp [946  1  3 ];
s np s [1028  1  3 ];
s np v [849  1  3 ];
s s qs [1304  1  3 ];
vp v n [938  1  3 ];
vp v p [833  1  3 ];
de de_ [244  1  0 ];
vp v v [967  1  3 ];
a as a@ [1451  1  1 ];
n dag_ [259  1  0 ];
a mp a@ [1407  1  1 , 1312  1  1 ];
adv e_ [1102  1  0 ];
p aan_ [338  1  0 ];
a np a@ [1307  1  1 ];
v had_ [271  1  0 ];
p bij_ [1035  1  0 ];
v heb_ [108  1  0 ];
en en_ [238  1  0 ];
a vp a@ [1309  1  1 ];
n mei_ [123  1  0 ];
v mag_ [248  1  0 ];
v ben_ [201  1  0 ];
a tv a@ [1502  1  1 , 1497  1  1 , 1495  1  1 , 1485  1  1 , 1467  1  1 , 
1463  1  1 , 1459  1  1 , 1458  1  1 , 1449  1  1 , 1438  1  1 , 
1437  1  1 , 1429  1  1 , 1424  1  1 , 1421  1  1 , 1409  1  1 , 
1406  1  1 , 1396  1  1 , 1394  1  1 , 1391  1  1 , 1389  1  1 , 
1371  1  1 , 1365  1  1 , 1360  1  1 , 1351  1  1 , 1345  1  1 , 
1343  1  1 , 1338  1  1 , 1334  1  1 , 1328  1  1 , 1321  1  1 , 
1317  1  1 , 1316  1  1 , 1314  1  1 , 1306  1  1 , 1303  1  1 , 
1302  1  1 , 1300  1  1 , 1291  1  1 , 1289  1  1 , 1288  1  1 , 
1282  1  1 , 1281  1  1 , 1271  1  1 ];
v doe_ [343  1  0 ];
np bo_ [250  1  0 ];
p via_ [654  1  0 ];
v kan_ [559  1  0 ];
det t_ [229  1  0 ];
a@ mp s [1306  3  3 ];
a@ s mp [1302  3  3 ];
a@ s np [1303  3  3 ];
v ken_ [999  1  0 ];
mp er_ [415  1  0 ];
np cs_ [134  1  0 ];
tv ja_ [26  1  0 ];
p van_ [21  1  0 ];
p met_ [430  1  0 ];
a@ ts p [1497  7  3 ];
np hs_ [1060  1  0 ];
n wat_ [178  1  0 ];
np@ n n [1405  3  3 ];
a@ vp s [1334  3  3 ];
a@ s vp [1463  7  3 , 1350  3  3 , 1347  3  3 , 1328  3  3 ];
a@ s ts [1438  3  3 ];
a@ ts s [1437  3  3 ];
mp@ p n [1278  3  3 ];
n@ p mp [1272  3  3 ];
per u_ [40  1  0 ];
np@ p n [1506  15  3 ];
v kom_ [931  1  0 ];
op op_ [375  1  0 ];
v zei_ [240  1  0 ];
a@ s tv [1317  3  3 ];
a@ tv s [1434  3  3 , 1312  3  3 ];
np ns_ [555  1  0 ];
v was_ [422  1  0 ];
p uit_ [315  1  0 ];
v wil_ [28  1  0 ];
v ver_ [922  1  0 ];
s mp s@ [1417  1  1 ];
p tot_ [211  1  0 ];
n uur_ [31  1  0 ];
n n adj [1214  1  3 ];
n adj n [1212  1  3 ];
s vp s@ [1433  1  1 ];
s ts s@ [1469  1  1 ];
a con n [1222  1  3 ];
a adv s [1163  1  3 ];
s tv s@ [1427  1  1 ];
v wou_ [197  1  0 ];
v zou_ [754  1  0 ];
sss mp [3  1  1 ];
n adv n [1089  1  3 ];
sss np [4  1  1 ];
a per s [1136  1  3 ];
sss so [465  1  1 ];
a p int [1270  1  3 ];
a mp np [653  1  3 ];
a np mp [649  1  3 ];
sss qs [752  1  1 ];
a np np [671  1  3 ];
sss vp [9  1  1 ];
sss ts [214  1  1 ];
s adv s [1158  1  3 ];
sss tv [6  1  1 ];
a mp vp [891  1  3 ];
a mp ts [1223  1  3 ];
a ts mp [1215  1  3 ];
s con s [1242  1  3 ];
n n int [1277  1  3 ];
n int n [1255  1  3 ];
v v adv [1117  1  3 ];
a@ vp a@ [1495  3  1 ];
a s ptp [1235  1  3 ];
a mp tv [780  1  3 ];
mp mp n [761  1  3 ];
a tv mp [758  1  3 ];
mp n mp [729  1  3 ];
a qs qs [1443  1  3 ];
a tv np [767  1  3 ];
np np n [771  1  3 ];
np n np [746  1  3 ];
mp mp p [633  1  3 ];
mp p mp [621  1  3 ];
mp np p [643  1  3 ];
mp p np [640  1  3 ];
s int n [1259  1  3 ];
a tv so [1252  1  3 ];
a vp vp [1043  1  3 ];
mp mp s [987  1  3 ];
a tv qs [1287  1  3 ];
s per v [1053  1  3 ];
mp v mp [757  1  3 ];
s int s [1283  1  3 ];
a tv vp [983  1  3 ];
a vp tv [961  1  3 ];
so so n [1274  1  3 ];
a tv ts [1231  1  3 ];
a ts tv [1226  1  3 ];
so so p [1260  1  3 ];
a tv tv [900  1  3 ];
so v np [1077  1  3 ];
s mp vp [867  1  3 ];
ts n so [1280  1  3 ];
s pro s [1200  1  3 ];
ts mp s [1133  1  3 ];
s np vp [887  1  3 ];
vp v mp [775  1  3 ];
s pro v [1189  1  3 ];
vp np v [834  1  3 ];
vp v np [795  1  3 ];
ts s so [1295  1  3 ];
a adv a@ [1353  1  1 , 1350  1  1 ];
a det a@ [1411  1  1 ];
tv tv n [886  1  3 ];
det de_ [185  1  0 ];
vp v tv [911  1  3 ];
adv al_ [302  1  0 ];
np ede_ [904  1  0 ];
n dank_ [41  1  0 ];
a int a@ [1452  1  1 ];
a@ adv s [1351  3  3 ];
adj ns_ [824  1  0 ];
v maak_ [804  1  0 ];
mp dan_ [370  1  0 ];
np ale_ [85  1  0 ];
a@ con p [1394  3  3 ];
adv er_ [459  1  0 ];
n paar_ [138  1  0 ];
p naar_ [12  1  0 ];
v gaat_ [366  1  0 ];
con en_ [223  1  0 ];
adv te_ [831  1  0 ];
v dank_ [42  1  0 ];
a@ con s [1429  3  3 ];
con of_ [855  1  0 ];
n keer_ [660  1  0 ];
adv ok_ [323  1  0 ];
per je_ [303  1  0 ];
adv we_ [993  1  0 ];
adv om_ [38  1  0 ];
int he_ [1177  1  0 ];
v hoef_ [841  1  0 ];
v denk_ [675  1  0 ];
v laat_ [402  1  0 ];
n orde_ [161  1  0 ];
n plan_ [709  1  0 ];
v hebt_ [610  1  0 ];
n tijd_ [471  1  0 ];
per me_ [461  1  0 ];
np rai_ [682  1  0 ];
n week_ [376  1  0 ];
n stad_ [172  1  0 ];
v neem_ [725  1  0 ];
per ik_ [24  1  0 ];
a@ s per [1343  3  3 ];
v doen_ [449  1  0 ];
np nob_ [1022  1  0 ];
a@ np np [1271  3  3 ];
adv nu_ [275  1  0 ];
n klok_ [495  1  0 ];
v bent_ [448  1  0 ];
n reis_ [365  1  0 ];
n juli_ [892  1  0 ];
v doet_ [890  1  0 ];
tv nee_ [17  1  0 ];
per we_ [981  1  0 ];
n iets_ [869  1  0 ];
p rond_ [154  1  0 ];
n juni_ [541  1  0 ];
p door_ [351  1  0 ];
adv zo_ [205  1  0 ];
a@ mp vp [1291  3  3 ];
a@ vp mp [1288  3  3 ];
a@ ts mp [1396  3  3 ];
a@ vp np [1289  3  3 ];
v ligt_ [462  1  0 ];
s@ con s [1469  3  3 , 1444  3  3 , 1433  3  3 , 1430  3  3 , 1427  3  3 , 
1417  3  3 ];
n huis_ [334  1  0 ];
pro er_ [502  1  0 ];
n loop_ [381  1  0 ];
a@ ptp s [1421  3  3 ];
a@ mp tv [1281  3  3 ];
det uw_ [547  1  0 ];
v reis_ [368  1  0 ];
sss adj [89  1  1 ];
a@ np tv [1282  3  3 ];
np n np@ [1506  1  1 ];
mp p mp@ [1483  1  1 , 1478  1  1 , 1475  1  1 , 1474  1  1 , 1471  1  1 , 
1372  1  1 , 1278  1  1 , 1261  1  1 ];
v weet_ [389  1  0 ];
v moet_ [80  1  0 ];
mp@ np p [1292  3  3 , 1261  3  3 ];
np wtc_ [662  1  0 ];
v hoop_ [398  1  0 ];
p over_ [221  1  0 ];
np@ p np [1258  3  3 ];
s per s@ [1473  1  1 ];
avp@ p v [1344  3  3 ];
a@ vp vp [1314  3  3 ];
v zegt_ [1024  1  0 ];
np urk_ [898  1  0 ];
pro ze_ [386  1  0 ];
v komt_ [324  1  0 ];
v zijn_ [231  1  0 ];
a@ tv vp [1495  15  3 , 1411  3  3 , 1309  3  3 ];
a@ vp tv [1300  3  3 ];
vp@ mp n [1285  3  3 ];
a@ ts tv [1409  3  3 ];
a@ tv ts [1407  3  3 ];
np oss_ [230  1  0 ];
vp@ p mp [1275  3  3 ];
n punt_ [202  1  0 ];
sss adv [19  1  1 ];
v wilt_ [364  1  0 ];
p voor_ [208  1  0 ];
sss inf [34  1  1 ];
v kunt_ [843  1  0 ];
a mp adv [1069  1  3 ];
sss con [142  1  1 ];
so v so@ [1362  1  1 , 1327  1  1 ];
a tv adj [1216  1  3 ];
error p [25  1  1 ];
np adj n [1211  1  3 ];
v stop_ [992  1  0 ];
a@ adv a@ [1467  3  1 ];
qs v qs@ [1378  1  1 , 1348  1  1 ];
a p infp [1167  1  3 ];
a adv qs [1310  1  3 ];
a@ con a@ [1497  3  1 , 1485  3  1 ];
vp v vp@ [1479  1  1 , 1462  1  1 , 1455  1  1 , 1373  1  1 , 1367  1  1 , 
1352  1  1 , 1325  1  1 , 1320  1  1 , 1318  1  1 , 1285  1  1 , 
1275  1  1 ];
sss int [630  1  1 ];
a per mp [906  1  3 ];
a tv adv [1112  1  3 ];
a adv tv [1091  1  3 ];
np adv n [1082  1  3 ];
a tv inf [1181  1  3 ];
a inf tv [1156  1  3 ];
mp p adv [1064  1  3 ];
mp adv p [1001  1  3 ];
np det n [1227  1  3 ];
sss num [10  1  1 ];
vp v adj [1217  1  3 ];
np per n [1000  1  3 ];
mp p per [942  1  3 ];
a@ ptp a@ [1502  3  1 ];
s det vp [1234  1  3 ];
vp v adv [1121  1  3 ];
vp adv v [1103  1  3 ];
s per mp [896  1  3 ];
mp mp mp [583  1  3 ];
mp mp np [602  1  3 ];
mp np mp [596  1  3 ];
vp v det [1239  1  3 ];
vp v inf [1185  1  3 ];
np np mp [599  1  3 ];
avp mp v [1076  1  3 ];
np np np [613  1  3 ];
np t loo [1384  1  3 ];
np n num [968  1  3 ];
np num n [956  1  3 ];
np pro n [1178  1  3 ];
mp p num [893  1  3 ];
mp p pro [1187  1  3 ];
np num p [848  1  3 ];
a tv ptp [1219  1  3 ];
so v per [1164  1  3 ];
aan aan_ [585  1  0 ];
s per vp [1074  1  3 ];
so so mp [1253  1  3 ];
so so np [1254  1  3 ];
vp v per [1057  1  3 ];
ale ale_ [432  1  0 ];
qs np so [1279  1  3 ];
ts mp so [1266  1  3 ];
ts np so [1268  1  3 ];
ts np qs [1297  1  3 ];
so v pro [1207  1  3 ];
vp vp mp [807  1  3 ];
np@ n np@ [1510  7  1 , 1501  3  1 , 1493  3  1 , 1453  3  1 ];
s pro vp [1190  1  3 ];
n breda_ [220  1  0 ];
np@ p np@ [1506  3  1 , 1481  3  1 ];
vp v num [1013  1  3 ];
n dagen_ [910  1  0 ];
vp v pro [1196  1  3 ];
adv dan_ [427  1  0 ];
den den_ [164  1  0 ];
n maand_ [1111  1  0 ];
vp v ptp [1221  1  3 ];
con die_ [1088  1  0 ];
n heden_ [776  1  0 ];
p circa_ [148  1  0 ];
det den_ [209  1  0 ];
adv dat_ [44  1  0 ];
np beek_ [212  1  0 ];
det een_ [195  1  0 ];
adv hoe_ [278  1  0 ];
con dat_ [65  1  0 ];
v dacht_ [1055  1  0 ];
a@ np adv [1307  3  3 ];
n negen_ [681  1  0 ];
adv als_ [264  1  0 ];
n nacht_ [988  1  0 ];
p vanaf_ [48  1  0 ];
n geval_ [1044  1  0 ];
np aken_ [447  1  0 ];
det het_ [920  1  0 ];
det dit_ [605  1  0 ];
adv weg_ [261  1  0 ];
a@ con mp [1389  3  3 ];
tv tv tv [850  1  3 ];
adv nog_ [272  1  0 ];
a@ con np [1391  3  3 ];
con als_ [475  1  0 ];
a@ adv qs [1459  3  3 ];
n kaart_ [801  1  0 ];
a@ s infp [1365  3  3 ];
het het_ [1029  1  0 ];
v heeft_ [866  1  0 ];
a@ adv vp [1338  3  3 ];
pro die_ [963  1  0 ];
p tegen_ [722  1  0 ];
adv wel_ [553  1  0 ];
n maart_ [413  1  0 ];
v maakt_ [972  1  0 ];
adv ook_ [157  1  0 ];
n avond_ [811  1  0 ];
n april_ [720  1  0 ];
a@ tv adv [1451  3  3 , 1353  3  3 ];
num elf_ [293  1  0 ];
per mij_ [265  1  0 ];
adv wat_ [199  1  0 ];
s@ con as [1482  3  3 ];
np@ adv n [1315  3  3 ];
zee zee_ [1171  1  0 ];
n weken_ [996  1  0 ];
num een_ [60  1  0 ];
n fiets_ [652  1  0 ];
n datum_ [615  1  0 ];
np uden_ [669  1  0 ];
np week_ [355  1  0 ];
pro dat_ [46  1  0 ];
van van_ [35  1  0 ];
pro hem_ [1062  1  0 ];
v wilde_ [739  1  0 ];
con dus_ [1066  1  0 ];
noi noi_ [417  1  0 ];
np goes_ [329  1  0 ];
np tiel_ [213  1  0 ];
np best_ [120  1  0 ];
v hoeft_ [72  1  0 ];
np@ n con [1465  3  3 ];
s@ np adv [1323  3  3 ];
v krijg_ [1036  1  0 ];
np wehl_ [155  1  0 ];
so@ inf p [1454  3  3 ];
oud oud_ [1160  1  0 ];
part te_ [997  1  0 ];
tv neen_ [306  1  0 ];
n trein_ [66  1  0 ];
s@ con mp [1404  3  3 ];
int zeg_ [1138  1  0 ];
per wij_ [985  1  0 ];
np nord_ [522  1  0 ];
vp@ adv p [1462  7  3 ];
vp@ p adv [1325  3  3 ];
pro het_ [717  1  0 ];
pro dit_ [414  1  0 ];
v waren_ [932  1  0 ];
v lijkt_ [955  1  0 ];
loo loo_ [703  1  0 ];
np@ con v [1397  3  3 ];
np velp_ [396  1  0 ];
np goor_ [109  1  0 ];
np elst_ [629  1  0 ];
np vink_ [113  1  0 ];
int dus_ [1115  1  0 ];
mp mp mp@ [1425  1  1 , 1375  1  1 ];
mp np mp@ [1376  1  1 ];
a@ pro vp [1360  3  3 ];
v vroeg_ [830  1  0 ];
np cuyk_ [634  1  0 ];
np zuid_ [342  1  0 ];
s@ con ts [1470  3  3 ];
avp@ v mp [1296  3  3 ];
np np np@ [1477  1  1 , 1468  1  1 , 1397  1  1 , 1379  1  1 , 1377  1  1 , 
1315  1  1 , 1265  1  1 , 1258  1  1 ];
a@ vp ptp [1406  3  3 ];
wtc wtc_ [941  1  0 ];
np@ n num [1313  3  3 ];
np@ num n [1510  31  3 , 1494  15  3 , 1493  15  3 , 1460  7  3 , 1308  3  3 ];
int nou_ [687  1  0 ];
n route_ [637  1  0 ];
np nuth_ [592  1  0 ];
tv okay_ [1009  1  0 ];
v moest_ [537  1  0 ];
np@ p num [1453  7  3 , 1299  3  3 ];
v ziens_ [678  1  0 ];
num nul_ [215  1  0 ];
np olst_ [958  1  0 ];
v spijt_ [628  1  0 ];
v klopt_ [54  1  0 ];
np west_ [198  1  0 ];
num zes_ [708  1  0 ];
ptp@ p np [1390  3  3 ];
np oost_ [623  1  0 ];
v wordt_ [597  1  0 ];
so so so@ [1476  1  1 , 1454  1  1 ];
np@ tv np [1265  3  3 ];
sss infp [30  1  1 ];
tv fout_ [322  1  0 ];
as con as [1420  1  3 ];
errorp n [16  1  1 ];
qs so qs@ [1507  1  1 ];
errorp p [11  1  1 ];
np np adj [1209  1  3 ];
a infp np [1124  1  3 ];
errors s [32  1  1 ];
errorp v [20  1  1 ];
vp vp vp@ [1480  1  1 ];
sss imps [222  1  1 ];
as int as [1447  1  3 ];
ts ts ts@ [1491  1  1 ];
mp mp adv [1037  1  3 ];
mp adv mp [959  1  3 ];
mp adv np [971  1  3 ];
errorv v [22  1  1 ];
s per inf [1193  1  3 ];
np np adv [1047  1  3 ];
np adv np [979  1  3 ];
a tv infp [1176  1  3 ];
avp adv v [1174  1  3 ];
np det np [1213  1  3 ];
avp inf v [1198  1  3 ];
so so adv [1301  1  3 ];
so so inf [1336  1  3 ];
qs adv so [1311  1  3 ];
ts adv so [1298  1  3 ];
a tv imps [1232  1  3 ];
mp int mp [1244  1  3 ];
ssss sss [0  1  1 ];
np int np [1246  1  3 ];
vp vp adv [1127  1  3 ];
vp v infp [1183  1  3 ];
adj half_ [434  1  0 ];
avp mp vp [1094  1  3 ];
mp num mp [794  1  3 ];
avp np vp [1099  1  3 ];
adj hele_ [1007  1  0 ];
np np num [858  1  3 ];
so so int [1432  1  3 ];
adv daar_ [266  1  0 ];
inf gaan_ [232  1  0 ];
n middag_ [75  1  0 ];
so so pro [1349  1  3 ];
ptp n ptp [1240  1  3 ];
adj doof_ [871  1  0 ];
np@ aan de [1496  3  3 ];
mp@ mp mp@ [1474  3  1 , 1471  3  1 ];
mp@ np mp@ [1475  3  1 ];
so so ptp [1374  1  3 ];
np blaak_ [571  1  0 ];
adv heel_ [95  1  0 ];
adv goed_ [483  1  0 ];
ts pro so [1339  1  3 ];
adv heen_ [765  1  0 ];
det geen_ [721  1  0 ];
adv maar_ [224  1  0 ];
np breda_ [207  1  0 ];
adv lang_ [782  1  0 ];
adv laat_ [437  1  0 ];
np didam_ [131  1  0 ];
adv echt_ [549  1  0 ];
tv tv int [1273  1  3 ];
tv int tv [1251  1  3 ];
np obdam_ [777  1  0 ];
con maar_ [440  1  0 ];
np dalen_ [881  1  0 ];
adv fijn_ [607  1  0 ];
np baarn_ [180  1  0 ];
con naar_ [27  1  0 ];
inf doen_ [496  1  0 ];
adv hier_ [151  1  0 ];
adv meer_ [318  1  0 ];
det deze_ [705  1  0 ];
qs@ mp qs@ [1507  3  1 ];
adv waar_ [691  1  0 ];
adv eens_ [255  1  0 ];
part aan_ [550  1  0 ];
adv toch_ [174  1  0 ];
adv even_ [165  1  0 ];
det mijn_ [399  1  0 ];
np bedum_ [112  1  0 ];
adv niet_ [57  1  0 ];
n tijden_ [1100  1  0 ];
np haren_ [995  1  0 ];
np bunde_ [59  1  0 ];
np aan np@ [1492  1  1 ];
np delft_ [728  1  0 ];
adv snel_ [384  1  0 ];
np maarn_ [296  1  0 ];
np arkel_ [93  1  0 ];
a@ pro adv [1371  3  3 ];
adv weer_ [530  1  0 ];
np gouda_ [252  1  0 ];
np opdam_ [735  1  0 ];
as per as@ [1464  1  1 ];
np haven_ [944  1  0 ];
np emmen_ [411  1  0 ];
num acht_ [382  1  0 ];
a@ adv ptp [1502  7  3 , 1424  3  3 ];
np heino_ [847  1  0 ];
adv zeer_ [137  1  0 ];
n zondag_ [91  1  0 ];
np flora_ [702  1  0 ];
np@ con as [1477  3  3 ];
n plaats_ [835  1  0 ];
np den np@ [1487  1  1 ];
np sneek_ [311  1  0 ];
np borne_ [169  1  0 ];
num paar_ [145  1  0 ];
num drie_ [52  1  0 ];
mp later_ [974  1  0 ];
np wijhe_ [749  1  0 ];
a@ ts infp [1449  3  3 ];
mp@ mp adv [1342  3  3 ];
mp adv mp@ [1363  1  1 , 1342  1  1 , 1292  1  1 ];
adv vrij_ [511  1  0 ];
n morgen_ [505  1  0 ];
np rijen_ [121  1  0 ];
n vieren_ [921  1  0 ];
inf zijn_ [284  1  0 ];
np assen_ [263  1  0 ];
adv vast_ [1141  1  0 ];
np gilze_ [952  1  0 ];
pro deze_ [498  1  0 ];
int toch_ [489  1  0 ];
adv fout_ [347  1  0 ];
pro hier_ [186  1  0 ];
np det np@ [1501  1  1 , 1465  1  1 , 1405  1  1 ];
np ommen_ [773  1  0 ];
con want_ [639  1  0 ];
vp@ con as [1480  3  3 , 1479  3  3 ];
mp@ con mp [1474  7  3 , 1376  3  3 , 1375  3  3 ];
int niet_ [254  1  0 ];
mp@ con np [1478  7  3 , 1475  7  3 ];
np@ con mp [1377  3  3 ];
np enter_ [645  1  0 ];
np@ con np [1379  3  3 ];
tv jawel_ [755  1  0 ];
np paris_ [674  1  0 ];
qs@ adv np [1348  3  3 ];
np lisse_ [964  1  0 ];
n moment_ [184  1  0 ];
n@ con num [1410  3  3 ];
vp@ mp adv [1318  3  3 ];
part toe_ [727  1  0 ];
num vijf_ [570  1  0 ];
vp@ np adv [1320  3  3 ];
mp vroeg_ [810  1  0 ];
np noord_ [723  1  0 ];
num tien_ [150  1  0 ];
v willen_ [241  1  0 ];
n nummer_ [576  1  0 ];
n kosten_ [487  1  0 ];
np weesp_ [319  1  0 ];
np venlo_ [312  1  0 ];
int hoor_ [372  1  0 ];
tv prima_ [331  1  0 ];
np ijlst_ [514  1  0 ];
np hoorn_ [513  1  0 ];
n perron_ [350  1  0 ];
mp terug_ [177  1  0 ];
np oud np@ [1504  1  1 ];
num twee_ [446  1  0 ];
np weert_ [260  1  0 ];
mp@ mp int [1456  3  3 ];
mp@ int mp [1425  3  3 ];
pro iets_ [939  1  0 ];
num vier_ [49  1  0 ];
so@ per mp [1327  3  3 ];
np kerst_ [499  1  0 ];
p vanuit_ [304  1  0 ];
mp adv adj [1230  1  3 ];
mp num mp@ [1413  1  1 ];
np det adj [1346  1  3 ];
mp pro mp@ [1456  1  1 ];
np vught_ [851  1  0 ];
np soest_ [543  1  0 ];
qs@ int mp [1507  7  3 ];
np num np@ [1510  1  1 , 1494  1  1 , 1493  1  1 , 1481  1  1 , 1461  1  1 , 
1460  1  1 , 1453  1  1 , 1319  1  1 , 1313  1  1 , 1308  1  1 , 
1299  1  1 ];
np zeist_ [914  1  0 ];
v opstap_ [551  1  0 ];
np hulst_ [486  1  0 ];
np horst_ [458  1  0 ];
ts@ con ts [1491  3  3 ];
np grouw_ [412  1  0 ];
p tussen_ [160  1  0 ];
v zitten_ [321  1  0 ];
vp@ pro mp [1352  3  3 ];
errormp p [18  1  1 ];
ptp p ptp@ [1423  1  1 , 1402  1  1 ];
infp n inf [1188  1  3 ];
infp inf p [1143  1  3 ];
np de riet [1382  1  3 ];
np adj num [1218  1  3 ];
infp inf s [1195  1  3 ];
np pro adj [1256  1  3 ];
np de vink [1388  1  3 ];
haag haag_ [745  1  0 ];
as per avp [1293  1  3 ];
mp adv int [1294  1  3 ];
s per infp [1192  1  3 ];
np het loo [1414  1  3 ];
imps v adv [1179  1  3 ];
avp mp avp [1262  1  3 ];
np@ aan np@ [1512  3  1 , 1511  3  1 ];
beek beek_ [587  1  0 ];
so so infp [1332  1  3 ];
lage lage_ [986  1  0 ];
qs so infp [1340  1  3 ];
adj begin_ [1148  1  0 ];
imps v per [1147  1  3 ];
n maandag_ [140  1  0 ];
laan laan_ [732  1  0 ];
p errorp p [1204  1  3 ];
anna anna_ [1095  1  0 ];
np@ con np@ [1506  7  1 ];
adv circa_ [179  1  0 ];
adv graag_ [94  1  0 ];
avp pro vp [1203  1  3 ];
np num num [1025  1  3 ];
n paasdag_ [973  1  0 ];
adv heden_ [812  1  0 ];
np@ van np@ [1514  3  1 ];
s s errors [1249  1  3 ];
s errors s [1248  1  3 ];
naar naar_ [37  1  0 ];
ptp mp ptp [1225  1  3 ];
ptp ptp mp [1220  1  3 ];
det ieder_ [1157  1  0 ];
ptp np ptp [1228  1  3 ];
adj welke_ [1153  1  0 ];
adj later_ [1119  1  0 ];
drie drie_ [235  1  0 ];
n dinsdag_ [126  1  0 ];
p vandaan_ [933  1  0 ];
adj zesde_ [1159  1  0 ];
np delden_ [677  1  0 ];
mp@ num mp@ [1483  3  1 , 1478  3  1 ];
adv nodig_ [419  1  0 ];
np@ num np@ [1510  15  1 , 1510  3  1 , 1494  7  1 , 1494  3  1 , 1493  7  1 , 
1461  3  1 , 1460  3  1 ];
v errorv v [1243  1  3 ];
adv beter_ [859  1  0 ];
np beilen_ [748  1  0 ];
hoek hoek_ [578  1  0 ];
n afstand_ [563  1  0 ];
np leiden_ [452  1  0 ];
n bericht_ [325  1  0 ];
np boekel_ [1105  1  0 ];
inf nemen_ [1061  1  0 ];
n verband_ [883  1  0 ];
np diemen_ [219  1  0 ];
np bergen_ [565  1  0 ];
n weekend_ [190  1  0 ];
inf geven_ [957  1  0 ];
np@ aan zee [1509  3  3 ];
np aalten_ [989  1  0 ];
n werkdag_ [903  1  0 ];
n ochtend_ [618  1  0 ];
np berkel_ [575  1  0 ];
vp@ per vp@ [1462  3  1 ];
mp@ adv adv [1363  3  3 ];
np rheden_ [1125  1  0 ];
mp eerder_ [935  1  0 ];
np almere_ [740  1  0 ];
adv prima_ [361  1  0 ];
np hardin_ [79  1  0 ];
n vrijdag_ [262  1  0 ];
adj terug_ [400  1  0 ];
np tharde_ [247  1  0 ];
np lochem_ [237  1  0 ];
np alphen_ [98  1  0 ];
n gebruik_ [1097  1  0 ];
inf komen_ [969  1  0 ];
adv ervan_ [875  1  0 ];
n januari_ [760  1  0 ];
np almelo_ [124  1  0 ];
np laan np@ [1514  1  1 , 1489  1  1 ];
np eentje_ [1045  1  0 ];
inf horen_ [882  1  0 ];
np arnhem_ [51  1  0 ];
np kampen_ [206  1  0 ];
infp@ inf p [1337  3  3 ];
int merci_ [1184  1  0 ];
int hallo_ [1110  1  0 ];
infp@ adv s [1370  3  3 ];
veen veen_ [1003  1  0 ];
num negen_ [693  1  0 ];
np@ adj num [1481  7  3 ];
np rhenen_ [954  1  0 ];
np heiloo_ [825  1  0 ];
adv niets_ [638  1  0 ];
n gesprek_ [1072  1  0 ];
adv zelfs_ [816  1  0 ];
a errors a@ [1434  1  1 ];
koog koog_ [925  1  0 ];
np lemmer_ [878  1  0 ];
np muiden_ [595  1  0 ];
inf weten_ [349  1  0 ];
np deurne_ [770  1  0 ];
np meppel_ [552  1  0 ];
np ermelo_ [928  1  0 ];
pro alles_ [143  1  0 ];
n treinen_ [316  1  0 ];
np hoek np@ [1490  1  1 ];
n oktober_ [966  1  0 ];
adv nooit_ [616  1  0 ];
np amstel_ [218  1  0 ];
so@ per adv [1362  3  3 ];
np bunnik_ [862  1  0 ];
mp morgen_ [490  1  0 ];
np buiten_ [153  1  0 ];
np@ con avp [1468  3  3 ];
adv adv adj [1238  1  3 ];
rijn rijn_ [1098  1  0 ];
np eysden_ [789  1  0 ];
np den haag [1356  1  3 ];
np parijs_ [916  1  0 ];
riet riet_ [626  1  0 ];
ptp@ con as [1498  3  3 ];
np duiven_ [713  1  0 ];
np akkrum_ [484  1  0 ];
np dokkum_ [416  1  0 ];
np@ van noi [1489  3  3 ];
adv juist_ [408  1  0 ];
avp mp avp@ [1296  1  1 ];
np wychen_ [821  1  0 ];
n centrum_ [612  1  0 ];
as@ pro avp [1464  3  3 ];
vp@ adv int [1455  3  3 ];
mp@ con num [1483  7  3 , 1413  3  3 ];
p volgens_ [937  1  0 ];
n minuten_ [136  1  0 ];
np@ con num [1501  7  3 ];
vink vink_ [397  1  0 ];
n station_ [276  1  0 ];
n vertrek_ [539  1  0 ];
np houten_ [460  1  0 ];
adv adv adv [1172  1  3 ];
vp@ pro adv [1373  3  3 ];
mp@ np part [1372  3  3 ];
np venray_ [162  1  0 ];
errorp om_ [43  1  0 ];
np reuver_ [438  1  0 ];
zuid zuid_ [593  1  0 ];
np zetten_ [523  1  0 ];
errorp det [436  1  1 ];
num zeven_ [181  1  0 ];
v vertrek_ [542  1  0 ];
num kwart_ [107  1  0 ];
np wormer_ [435  1  0 ];
np zwolle_ [340  1  0 ];
sint sint_ [1123  1  0 ];
np bussum_ [540  1  0 ];
so@ per ptp [1476  3  3 ];
np putten_ [194  1  0 ];
np@ num num [1461  7  3 , 1319  3  3 ];
hout hout_ [1191  1  0 ];
np winsum_ [183  1  0 ];
adv int adv [1290  1  3 ];
np@ op zoom [1500  3  3 ];
n mevrouw_ [584  1  0 ];
errormp mp [15  1  1 ];
west west_ [535  1  0 ];
ptp@ np ptp [1402  3  3 ];
np ruurlo_ [171  1  0 ];
errornp np [13  1  1 ];
infp mp inf [1166  1  3 ];
infp inf mp [1132  1  3 ];
infp n infp [1186  1  3 ];
infp np inf [1169  1  3 ];
infp inf np [1135  1  3 ];
oost oost_ [1017  1  0 ];
int sorry_ [788  1  0 ];
zoom zoom_ [699  1  0 ];
np de klomp [1380  1  3 ];
np het veen [1448  1  3 ];
a xxxprior [1515  1  1 ];
adj aardig_ [531  1  0 ];
num det num [1236  1  3 ];
adj andere_ [756  1  0 ];
np@ naar np@ [1513  3  1 ];
inf hebben_ [556  1  0 ];
int int int [1446  1  3 ];
n xxxprior [1516  1  1 ];
ptp adv ptp [1250  1  3 ];
adv bekend_ [346  1  0 ];
p xxxprior [1517  1  1 ];
n december_ [450  1  0 ];
adj eerder_ [1107  1  0 ];
np@ den haag [1487  3  3 ];
n allemaal_ [139  1  0 ];
s xxxprior [1518  1  1 ];
t xxxprior [1519  1  1 ];
np zuid wtc [1358  1  3 ];
a tv errors [1241  1  3 ];
v xxxprior [1520  1  1 ];
adj latere_ [817  1  0 ];
adv alleen_ [572  1  0 ];
adj tweede_ [885  1  0 ];
adj vierde_ [1175  1  0 ];
mp vandaag_ [525  1  0 ];
v herhaald_ [99  1  0 ];
ptp per ptp [1245  1  3 ];
np america_ [947  1  0 ];
n behoefte_ [341  1  0 ];
adv genoeg_ [273  1  0 ];
np abcoude_ [117  1  0 ];
np schagen_ [715  1  0 ];
np alkmaar_ [627  1  0 ];
adj eerste_ [589  1  0 ];
np naarden_ [168  1  0 ];
np leerdam_ [786  1  0 ];
np haarlem_ [743  1  0 ];
np brabant_ [473  1  0 ];
adv meteen_ [1081  1  0 ];
n ogenblik_ [1015  1  0 ];
inf rijden_ [712  1  0 ];
ptp pro ptp [1284  1  3 ];
np zaandam_ [330  1  0 ];
np blerick_ [313  1  0 ];
n dinsdags_ [1084  1  0 ];
adj nieuwe_ [901  1  0 ];
infp@ adv as [1466  3  3 ];
inf zeggen_ [694  1  0 ];
np veendam_ [819  1  0 ];
adv direkt_ [726  1  0 ];
n februari_ [601  1  0 ];
adv alsnog_ [902  1  0 ];
v herhaalt_ [277  1  0 ];
np hengelo_ [591  1  0 ];
n zaterdag_ [63  1  0 ];
np zeeland_ [836  1  0 ];
np weichen_ [696  1  0 ];
np bergweg_ [439  1  0 ];
np wiechen_ [127  1  0 ];
np heerlen_ [104  1  0 ];
infp@ con as [1484  3  3 ];
adv liefst_ [594  1  0 ];
adv liever_ [536  1  0 ];
np tegelen_ [149  1  0 ];
adv steeds_ [1014  1  0 ];
np bijlmer_ [680  1  0 ];
adv verder_ [560  1  0 ];
n kerstdag_ [133  1  0 ];
mp overdag_ [805  1  0 ];
np helmond_ [797  1  0 ];
n woensdag_ [524  1  0 ];
infp@ inf mp [1488  7  3 , 1354  3  3 , 1330  3  3 , 1329  3  3 ];
p richting_ [1041  1  0 ];
np drenthe_ [1031  1  0 ];
inf willen_ [291  1  0 ];
n schiphol_ [88  1  0 ];
np@ den rijn [1513  7  3 , 1511  7  3 ];
infp n infp@ [1368  1  1 ];
infp@ inf np [1333  3  3 , 1331  3  3 ];
avp adv avp@ [1344  1  1 ];
np heusden_ [994  1  0 ];
ptp gezegd_ [707  1  0 ];
inf reizen_ [55  1  0 ];
infp@ con mp [1428  3  3 ];
np terapel_ [1042  1  0 ];
np klimmen_ [289  1  0 ];
np geldrop_ [176  1  0 ];
infp@ con np [1431  3  3 ];
adj ervoor_ [1161  1  0 ];
n november_ [1027  1  0 ];
inf worden_ [998  1  0 ];
inf kunnen_ [909  1  0 ];
n aankomst_ [480  1  0 ];
np nijkerk_ [233  1  0 ];
np wierden_ [146  1  0 ];
v begrijpt_ [557  1  0 ];
np domburg_ [1016  1  0 ];
vp@ adv infp [1367  3  3 ];
int pardon_ [738  1  0 ];
num dertig_ [685  1  0 ];
num twaalf_ [158  1  0 ];
np limburg_ [196  1  0 ];
adj zinvol_ [1173  1  0 ];
n senioren_ [772  1  0 ];
mp snachts_ [661  1  0 ];
np woerden_ [67  1  0 ];
adv straks_ [533  1  0 ];
np brummen_ [751  1  0 ];
np swalmen_ [747  1  0 ];
n eindpunt_ [301  1  0 ];
tv jazeker_ [673  1  0 ];
np tilburg_ [81  1  0 ];
num tweeen_ [1086  1  0 ];
n terugweg_ [839  1  0 ];
qs@ per infp [1378  3  3 ];
n tijdstip_ [948  1  0 ];
np sittard_ [362  1  0 ];
adv zoiets_ [337  1  0 ];
np@ en nieuw [1504  3  3 ];
np boskoop_ [759  1  0 ];
inf zitten_ [374  1  0 ];
mp savonds_ [348  1  0 ];
n antwoord_ [546  1  0 ];
adv retour_ [267  1  0 ];
np rijssen_ [100  1  0 ];
np utrecht_ [92  1  0 ];
np brussel_ [470  1  0 ];
np noord np@ [1503  1  1 ];
imps@ per np [1324  3  3 ];
n kerstmis_ [425  1  0 ];
num@ con num [1416  3  3 ];
np vleuten_ [163  1  0 ];
np world np@ [1508  1  1 ];
np nieuw np@ [1505  1  1 ];
np den bosch [1341  1  3 ];
np souburg_ [915  1  0 ];
n sprinter_ [403  1  0 ];
infp adv inf [1202  1  3 ];
infp inf adv [1199  1  3 ];
np voorweg_ [912  1  0 ];
infp inf inf [1208  1  3 ];
ptp@ con ptp [1486  3  3 ];
imps v imps@ [1472  1  1 , 1392  1  1 , 1385  1  1 , 1357  1  1 , 1324  1  1 ];
infp inf con [1263  1  3 ];
v verstond_ [545  1  0 ];
n voorkeur_ [468  1  0 ];
np zutphen_ [106  1  0 ];
num zeuven_ [614  1  0 ];
v vertrekt_ [377  1  0 ];
n augustus_ [308  1  0 ];
ptp@ per ptp [1423  3  3 ];
num num num@ [1416  1  1 ];
np de uithof [1439  1  3 ];
np den oever [1381  1  3 ];
np usquert_ [567  1  0 ];
np de leyens [1383  1  3 ];
infp mp infp [1162  1  3 ];
infp infp mp [1126  1  3 ];
infp np infp [1165  1  3 ];
ptp ptp ptp@ [1498  1  1 , 1486  1  1 , 1390  1  1 ];
de xxxprior [1521  1  1 ];
infp ptp inf [1269  1  3 ];
adj negende_ [1096  1  0 ];
en xxxprior [1522  1  1 ];
as xxxprior [1523  1  1 ];
adj eerdere_ [877  1  0 ];
imps imps mp [1233  1  3 ];
imps imps np [1237  1  3 ];
mp xxxprior [1524  1  1 ];
indie indie_ [1005  1  0 ];
adj komende_ [686  1  0 ];
np xxxprior [1525  1  1 ];
op xxxprior [1526  1  1 ];
n donderdag_ [515  1  0 ];
adv accoord_ [469  1  0 ];
so xxxprior [1527  1  1 ];
inf weggaan_ [990  1  0 ];
adv daarvan_ [421  1  0 ];
qs xxxprior [1529  1  1 ];
vp xxxprior [1528  1  1 ];
ts xxxprior [1530  1  1 ];
adj verdere_ [803  1  0 ];
np schiedam_ [666  1  0 ];
np enschede_ [655  1  0 ];
adj laatste_ [353  1  0 ];
bosch bosch_ [387  1  0 ];
tv xxxprior [1531  1  1 ];
trade trade_ [1180  1  0 ];
con waarmee_ [1023  1  0 ];
adv hoeveel_ [501  1  0 ];
np geerdijk_ [105  1  0 ];
np@ nieuw np@ [1514  7  1 ];
adv spoedig_ [363  1  0 ];
adv precies_ [314  1  0 ];
inf blijven_ [1118  1  0 ];
np kerkrade_ [115  1  0 ];
np centraal_ [716  1  0 ];
adj vroeger_ [1114  1  0 ];
np bargeres_ [665  1  0 ];
mp smiddags_ [87  1  0 ];
n hoofdstad_ [632  1  0 ];
adv wanneer_ [288  1  0 ];
np nijmegen_ [76  1  0 ];
np franeker_ [493  1  0 ];
ptp bedankt_ [970  1  0 ];
adv correct_ [532  1  0 ];
adv foutief_ [401  1  0 ];
adv wederom_ [1083  1  0 ];
n correctie_ [820  1  0 ];
np bergen np@ [1500  1  1 ];
np lelylaan_ [700  1  0 ];
rijen rijen_ [517  1  0 ];
con wanneer_ [503  1  0 ];
inf opgeven_ [1122  1  0 ];
np berkel np@ [1499  1  1 ];
np delfzijl_ [466  1  0 ];
np hofplein_ [991  1  0 ];
ptp genoemd_ [924  1  0 ];
n zaterdags_ [477  1  0 ];
np schinnen_ [1026  1  0 ];
num honderd_ [534  1  0 ];
np alphen np@ [1513  1  1 , 1511  1  1 , 1496  1  1 ];
ptp gegeven_ [1134  1  0 ];
tv needanku_ [488  1  0 ];
gilze gilze_ [1155  1  0 ];
infp mp infp@ [1488  1  1 , 1337  1  1 , 1331  1  1 , 1329  1  1 ];
inf noteren_ [1073  1  0 ];
np randwijk_ [951  1  0 ];
v corrigeer_ [344  1  0 ];
np maarssen_ [83  1  0 ];
np schiphol_ [82  1  0 ];
infp np infp@ [1364  1  1 , 1333  1  1 , 1330  1  1 ];
np doesburg_ [734  1  0 ];
a@ erroradv s [1458  3  3 ];
mp vanavond_ [358  1  0 ];
np zevenaar_ [90  1  0 ];
np deventer_ [854  1  0 ];
num dertien_ [641  1  0 ];
imps@ per adv [1357  3  3 ];
ptp gehoord_ [1170  1  0 ];
np bolsward_ [868  1  0 ];
mp gisteren_ [945  1  0 ];
np rosmalen_ [704  1  0 ];
np lelystad_ [558  1  0 ];
np meerssen_ [210  1  0 ];
np parkwijk_ [718  1  0 ];
erroradv adv [39  1  1 ];
int herstel_ [1140  1  0 ];
oever oever_ [1046  1  0 ];
n sneltrein_ [1040  1  0 ];
np wolfheze_ [934  1  0 ];
adv opnieuw_ [731  1  0 ];
ptp geweten_ [1154  1  0 ];
num vijftig_ [281  1  0 ];
noord noord_ [978  1  0 ];
np roermond_ [53  1  0 ];
errordet det [608  1  1 ];
np paulowna_ [590  1  0 ];
errorinf inf [47  1  1 ];
imps@ pro adv [1392  3  3 ];
klomp klomp_ [568  1  0 ];
num veertig_ [167  1  0 ];
np overveen_ [960  1  0 ];
errordet con [510  1  1 ];
np uitgeest_ [309  1  0 ];
n terugreis_ [253  1  0 ];
n intercity_ [714  1  0 ];
np den helder [1305  1  3 ];
ptp verteld_ [642  1  0 ];
s@ error infp [1473  3  3 ];
np rijswijk_ [581  1  0 ];
mp smorgens_ [388  1  0 ];
np lunteren_ [77  1  0 ];
p omstreeks_ [823  1  0 ];
np lunetten_ [518  1  0 ];
np voorwegh_ [853  1  0 ];
np oorschot_ [68  1  0 ];
np den dolder [1366  1  3 ];
world world_ [1146  1  0 ];
nieuw nieuw_ [1068  1  0 ];
np stavoren_ [464  1  0 ];
np nunspeet_ [442  1  0 ];
np kerstmis_ [406  1  0 ];
np zuidhorn_ [554  1  0 ];
imps@ per pro [1385  3  3 ];
n minuutjes_ [737  1  0 ];
num zestien_ [62  1  0 ];
np houtwijk_ [404  1  0 ];
np voorburg_ [582  1  0 ];
mp@ errorp mp [1471  7  3 ];
errormp infp [45  1  1 ];
infp adv infp [1201  1  3 ];
infp infp adv [1197  1  3 ];
num twintig_ [586  1  0 ];
np ale polder [1436  1  3 ];
infp inf infp [1206  1  3 ];
errorpro det [521  1  1 ];
errorper per [29  1  1 ];
np ljouwert_ [393  1  0 ];
np brunssum_ [378  1  0 ];
zeist zeist_ [1137  1  0 ];
infp part inf [1257  1  3 ];
infp per infp [1194  1  3 ];
adj xxxprior [1532  1  1 ];
np voorhout_ [1075  1  0 ];
aan xxxprior [1534  1  1 ];
infp int infp [1322  1  3 ];
spoor spoor_ [609  1  0 ];
ale xxxprior [1533  1  1 ];
errornum num [33  1  1 ];
den xxxprior [1537  1  1 ];
infp pro infp [1210  1  3 ];
imps imps adv [1276  1  3 ];
adv xxxprior [1544  1  1 ];
det xxxprior [1542  1  1 ];
inf xxxprior [1536  1  1 ];
adv helemaal_ [103  1  0 ];
con xxxprior [1543  1  1 ];
het xxxprior [1545  1  1 ];
zee xxxprior [1535  1  1 ];
van xxxprior [1538  1  1 ];
noi xxxprior [1540  1  1 ];
avp xxxprior [1548  1  1 ];
per xxxprior [1546  1  1 ];
adv dolgraag_ [538  1  0 ];
oud xxxprior [1539  1  1 ];
infp@ so infp@ [1488  3  1 ];
imps int imps [1395  1  3 ];
np landgraaf_ [73  1  0 ];
loo xxxprior [1547  1  1 ];
int xxxprior [1550  1  1 ];
det dezelfde_ [360  1  0 ];
adv onbekend_ [504  1  0 ];
mp errormp mp [1229  1  3 ];
wtc xxxprior [1541  1  1 ];
adj volgende_ [940  1  0 ];
inf herhalen_ [191  1  0 ];
num xxxprior [1549  1  1 ];
np errornp np [1224  1  3 ];
pro xxxprior [1551  1  1 ];
adj correcte_ [1142  1  0 ];
adv namelijk_ [667  1  0 ];
inf meenemen_ [367  1  0 ];
inf aankomen_ [226  1  0 ];
np medemblik_ [870  1  0 ];
mp vanmiddag_ [307  1  0 ];
ptp xxxprior [1552  1  1 ];
np heyendaal_ [71  1  0 ];
n achterhoek_ [1018  1  0 ];
adv nogmaals_ [1120  1  0 ];
adv mogelijk_ [544  1  0 ];
ptp herhaald_ [287  1  0 ];
sss xxxprior [1553  1  1 ];
adv vannacht_ [1128  1  0 ];
adj vroegere_ [526  1  0 ];
np appelscha_ [926  1  0 ];
np doetichem_ [750  1  0 ];
adv aanwezig_ [793  1  0 ];
np barneveld_ [292  1  0 ];
adv volledig_ [125  1  0 ];
np schijndel_ [864  1  0 ];
np heemstede_ [701  1  0 ];
np capelle np@ [1512  1  1 ];
adv verkeerd_ [813  1  0 ];
np hooghalen_ [354  1  0 ];
ptp gevraagd_ [796  1  0 ];
np pijnacker_ [86  1  0 ];
infp@ adv infp [1408  3  3 , 1368  3  3 , 1364  3  3 ];
infp adv infp@ [1354  1  1 ];
np harlingen_ [829  1  0 ];
adv ongeveer_ [500  1  0 ];
adv dankuwel_ [491  1  0 ];
np friesland_ [320  1  0 ];
n verbinding_ [56  1  0 ];
infp inf infp@ [1484  1  1 , 1466  1  1 , 1370  1  1 ];
adv tevreden_ [1113  1  0 ];
np oldenzaal_ [664  1  0 ];
n bestemming_ [842  1  0 ];
adv daarvoor_ [371  1  0 ];
np gorinchem_ [828  1  0 ];
n voormiddag_ [391  1  0 ];
infp@ con infp [1457  3  3 ];
np breukelen_ [228  1  0 ];
n informatie_ [463  1  0 ];
ptp begrepen_ [383  1  0 ];
np amsterdam_ [188  1  0 ];
np nijverdal_ [569  1  0 ];
np dordrecht_ [441  1  0 ];
np hoogezand_ [256  1  0 ];
adj vroegste_ [840  1  0 ];
np culemborg_ [494  1  0 ];
np eindhoven_ [418  1  0 ];
np hoogeveen_ [242  1  0 ];
np@ den ijssel [1512  7  3 ];
num achttien_ [698  1  0 ];
np kogerveld_ [769  1  0 ];
np apeldoorn_ [604  1  0 ];
np emmeloord_ [170  1  0 ];
np coevorden_ [1090  1  0 ];
np wassenaar_ [527  1  0 ];
np oeteldonk_ [193  1  0 ];
np hoofddorp_ [144  1  0 ];
np krommenie_ [476  1  0 ];
np groningen_ [156  1  0 ];
np beverwijk_ [251  1  0 ];
np seghwaert_ [444  1  0 ];
mp sochtends_ [286  1  0 ];
np bilthoven_ [1019  1  0 ];
np castricum_ [818  1  0 ];
mp vanmorgen_ [1085  1  0 ];
tv uiteraard_ [791  1  0 ];
infp pro infp@ [1408  1  1 ];
np vlugtlaan_ [270  1  0 ];
np@ oost indie [1514  15  3 , 1505  3  3 , 1503  3  3 ];
np zuidbroek_ [373  1  0 ];
np soestdijk_ [70  1  0 ];
num vijftien_ [509  1  0 ];
np enkhuizen_ [204  1  0 ];
np zierikzee_ [919  1  0 ];
np maassluis_ [516  1  0 ];
np purmerend_ [300  1  0 ];
np rotterdam_ [298  1  0 ];
num veertien_ [736  1  0 ];
np steenwijk_ [455  1  0 ];
np antwerpen_ [409  1  0 ];
np overvecht_ [876  1  0 ];
np overwhere_ [147  1  0 ];
np drie bergen [1400  1  3 ];
num zeuvende_ [1104  1  0 ];
np ettenleur_ [394  1  0 ];
ptp verstaan_ [846  1  0 ];
np hilversum_ [50  1  0 ];
np terneuzen_ [187  1  0 ];
np molkwerum_ [684  1  0 ];
n retourreis_ [243  1  0 ];
np uithuizen_ [763  1  0 ];
np beek elsloo [1415  1  3 ];
np sportpark_ [423  1  0 ];
np loppersum_ [379  1  0 ];
np zandvoort_ [357  1  0 ];
haag xxxprior [1554  1  1 ];
infp infp infp [1205  1  3 ];
np santpoort_ [658  1  0 ];
beek xxxprior [1556  1  1 ];
lage xxxprior [1555  1  1 ];
laan xxxprior [1557  1  1 ];
np gilze rijen [1450  1  3 ];
anna xxxprior [1558  1  1 ];
naar xxxprior [1560  1  1 ];
adv inderdaad_ [894  1  0 ];
drie xxxprior [1559  1  1 ];
hoek xxxprior [1561  1  1 ];
n gelegenheid_ [326  1  0 ];
infp xxxprior [1565  1  1 ];
veen xxxprior [1562  1  1 ];
adj dertiende_ [1048  1  0 ];
np errordet np [1264  1  3 ];
koog xxxprior [1564  1  1 ];
adj mogelijke_ [1038  1  0 ];
bergen bergen_ [880  1  0 ];
np mierlo hout [1422  1  3 ];
rijn xxxprior [1566  1  1 ];
helder helder_ [132  1  0 ];
riet xxxprior [1568  1  1 ];
berkel berkel_ [943  1  0 ];
rading rading_ [792  1  0 ];
part xxxprior [1569  1  1 ];
vink xxxprior [1567  1  1 ];
adv eigenlijk_ [884  1  0 ];
imps xxxprior [1572  1  1 ];
int goeiendag_ [1168  1  0 ];
np hardenberg_ [895  1  0 ];
alphen alphen_ [407  1  0 ];
np gelderland_ [305  1  0 ];
adv duidelijk_ [128  1  0 ];
zuid xxxprior [1563  1  1 ];
n middernacht_ [918  1  0 ];
np veenendaal_ [405  1  0 ];
sint xxxprior [1571  1  1 ];
dolder dolder_ [1150  1  0 ];
np appingedam_ [474  1  0 ];
adv inmiddels_ [453  1  0 ];
np beukenlaan_ [280  1  0 ];
hout xxxprior [1574  1  1 ];
np driebergen_ [724  1  0 ];
west xxxprior [1573  1  1 ];
np marienheem_ [872  1  0 ];
adv hartelijk_ [269  1  0 ];
oost xxxprior [1575  1  1 ];
zoom xxxprior [1570  1  1 ];
np marienberg_ [1093  1  0 ];
np bodegraven_ [889  1  0 ];
adv voldoende_ [96  1  0 ];
np presikhaaf_ [454  1  0 ];
np middelburg_ [369  1  0 ];
adv misschien_ [492  1  0 ];
np doetinchem_ [159  1  0 ];
np mariahoeve_ [472  1  0 ];
np voerendaal_ [392  1  0 ];
n medewerking_ [650  1  0 ];
np colmschate_ [844  1  0 ];
np wageningen_ [832  1  0 ];
ssss xxxprior [1  1  1 ];
center center_ [1020  1  0 ];
np beekelsloo_ [114  1  0 ];
np heerenveen_ [69  1  0 ];
np sliedrecht_ [200  1  0 ];
np@ van holland [1490  3  3 ];
np roosendaal_ [815  1  0 ];
np arnemuiden_ [753  1  0 ];
mp vanochtend_ [1049  1  0 ];
infp infp infp@ [1457  1  1 , 1431  1  1 , 1428  1  1 ];
np rijsbergen_ [1032  1  0 ];
np delftsewal_ [706  1  0 ];
np harderwijk_ [588  1  0 ];
np leeuwarden_ [564  1  0 ];
ptp begrijpen_ [520  1  0 ];
inf arriveren_ [1004  1  0 ];
ptp ingelicht_ [688  1  0 ];
pro hetzelfde_ [927  1  0 ];
polder polder_ [719  1  0 ];
ptp ingegeven_ [635  1  0 ];
np aerdenhout_ [332  1  0 ];
num negentien_ [317  1  0 ];
np maastricht_ [118  1  0 ];
n sinterklaas_ [333  1  0 ];
np valkenburg_ [135  1  0 ];
mierlo mierlo_ [1034  1  0 ];
n eindstation_ [245  1  0 ];
np palenstein_ [636  1  0 ];
ptp genoteerd_ [485  1  0 ];
ijssel ijssel_ [907  1  0 ];
ptp opgegeven_ [606  1  0 ];
np zaltbommel_ [631  1  0 ];
tv jadatklopt_ [690  1  0 ];
vennep vennep_ [651  1  0 ];
np sloterdijk_ [798  1  0 ];
np chevremont_ [548  1  0 ];
np grijpskerk_ [166  1  0 ];
adv voorlopig_ [953  1  0 ];
elsloo elsloo_ [657  1  0 ];
n vertrektijd_ [110  1  0 ];
np varsseveld_ [689  1  0 ];
np ravenstein_ [529  1  0 ];
uithof uithof_ [1129  1  0 ];
np loosduinen_ [619  1  0 ];
np veenwouden_ [420  1  0 ];
np vlissingen_ [768  1  0 ];
leyens leyens_ [622  1  0 ];
np amersfoort_ [579  1  0 ];
np buytenwegh_ [451  1  0 ];
np zoetermeer_ [175  1  0 ];
np winschoten_ [122  1  0 ];
mp overmorgen_ [61  1  0 ];
ptp verbroken_ [1152  1  0 ];
n treinkosten_ [1063  1  0 ];
ptp ontvangen_ [482  1  0 ];
np mierlohout_ [481  1  0 ];
np muziekwijk_ [648  1  0 ];
num zeventien_ [566  1  0 ];
np oisterwijk_ [395  1  0 ];
np buitenpost_ [339  1  0 ];
adv plusminus_ [119  1  0 ];
np wormerveer_ [620  1  0 ];
np oosterwijk_ [561  1  0 ];
np schothorst_ [327  1  0 ];
np oosterhout_ [102  1  0 ];
indie xxxprior [1577  1  1 ];
adj aanstaande_ [908  1  0 ];
adj aankomende_ [508  1  0 ];
adj doorgaande_ [663  1  0 ];
bosch xxxprior [1578  1  1 ];
trade xxxprior [1576  1  1 ];
np lage zwaluwe [1403  1  3 ];
inf beeindigen_ [356  1  0 ];
rijen xxxprior [1579  1  1 ];
np bergambacht_ [456  1  0 ];
gilze xxxprior [1582  1  1 ];
np badbentheim_ [274  1  0 ];
np bloemendaal_ [1059  1  0 ];
np nieuw vennep [1412  1  3 ];
oever xxxprior [1583  1  1 ];
noord xxxprior [1581  1  1 ];
adj vijftiende_ [467  1  0 ];
klomp xxxprior [1584  1  1 ];
nieuw xxxprior [1587  1  1 ];
world xxxprior [1580  1  1 ];
error xxxprior [1586  1  1 ];
np hardegarijp_ [845  1  0 ];
np centrum west [1445  1  3 ];
np barendrecht_ [742  1  0 ];
zeist xxxprior [1585  1  1 ];
np stadskanaal_ [1008  1  0 ];
np lombardijen_ [410  1  0 ];
np daarlerveen_ [111  1  0 ];
spoor xxxprior [1588  1  1 ];
np sgravenhage_ [445  1  0 ];
n verbindingen_ [203  1  0 ];
np vlaardingen_ [129  1  0 ];
n inlichtingen_ [497  1  0 ];
np papendrecht_ [225  1  0 ];
np@ trade center [1508  3  3 ];
np prinsenbeek_ [297  1  0 ];
np@ de vechtwijk [1492  3  3 ];
np hellendoorn_ [84  1  0 ];
np zevenbergen_ [857  1  0 ];
mp morgenavond_ [268  1  0 ];
inf vertrekken_ [236  1  0 ];
np roodeschool_ [152  1  0 ];
adj twintigste_ [646  1  0 ];
np@ en rodenrijs [1499  3  3 ];
np eygelshoven_ [217  1  0 ];
np castricum np@ [1509  1  1 ];
mp morgenvroeg_ [141  1  0 ];
np zwijndrecht_ [283  1  0 ];
np vriezenveen_ [359  1  0 ];
np soestduinen_ [285  1  0 ];
np slotervaart_ [1067  1  0 ];
np muiderpoort_ [116  1  0 ];
np voorschoten_ [78  1  0 ];
ptp verstreken_ [860  1  0 ];
num zeuventien_ [428  1  0 ];
inf stopzetten_ [282  1  0 ];
np winterswijk_ [227  1  0 ];
np velperpoort_ [930  1  0 ];
inf errorinf inf [1326  1  3 ];
np noord holland [1361  1  3 ];
np anna paulowna [1441  1  3 ];
bergen xxxprior [1590  1  1 ];
helder xxxprior [1591  1  1 ];
berkel xxxprior [1592  1  1 ];
rading xxxprior [1589  1  1 ];
np oostsouburg_ [182  1  0 ];
capelle capelle_ [1109  1  0 ];
alphen xxxprior [1593  1  1 ];
dolder xxxprior [1594  1  1 ];
np holland spoor [1369  1  3 ];
int goedemiddag_ [1182  1  0 ];
adv betreffende_ [1050  1  0 ];
center xxxprior [1600  1  1 ];
zaandam zaandam_ [624  1  0 ];
np krabbendijke_ [874  1  0 ];
polder xxxprior [1595  1  1 ];
mierlo xxxprior [1599  1  1 ];
ijssel xxxprior [1598  1  1 ];
np leidschendam_ [676  1  0 ];
per errorper per [1267  1  3 ];
vennep xxxprior [1597  1  1 ];
elsloo xxxprior [1601  1  1 ];
uithof xxxprior [1596  1  1 ];
holland holland_ [577  1  0 ];
leyens xxxprior [1602  1  1 ];
ptp aangevraagd_ [1139  1  0 ];
np oudejaarsdag_ [861  1  0 ];
mp morgenmiddag_ [74  1  0 ];
errorp xxxprior [1603  1  1 ];
int alsjeblieft_ [785  1  0 ];
n dinsdagmorgen_ [656  1  0 ];
np geldermalsen_ [431  1  0 ];
errors xxxprior [1604  1  1 ];
adv vriendelijk_ [929  1  0 ];
errorv xxxprior [1605  1  1 ];
int goedenavond_ [1087  1  0 ];
np napoleonlaan_ [1033  1  0 ];
np lammenschans_ [899  1  0 ];
np koogzaandijk_ [975  1  0 ];
num eenendertig_ [429  1  0 ];
adv alstublieft_ [295  1  0 ];
num errornum num [1286  1  3 ];
np scheveningen_ [1010  1  0 ];
np vrijdagavond_ [672  1  0 ];
pro errorpro pro [1335  1  3 ];
np duivendrecht_ [239  1  0 ];
np bovenkarspel_ [873  1  0 ];
np nieuweschans_ [352  1  0 ];
inf overstappen_ [310  1  0 ];
n vertrekplaats_ [336  1  0 ];
centrum centrum_ [1021  1  0 ];
capelle xxxprior [1608  1  1 ];
np maandagmiddag_ [799  1  0 ];
np sint oedelrode [1442  1  3 ];
zaandam xxxprior [1606  1  1 ];
np horstsevenum_ [950  1  0 ];
np koog bloemwijk [1399  1  3 ];
holland xxxprior [1607  1  1 ];
zwaluwe zwaluwe_ [697  1  0 ];
np hollands spoor [1359  1  3 ];
np vrijdagmiddag_ [1012  1  0 ];
adj aansluitende_ [692  1  0 ];
adj allerlaatste_ [512  1  0 ];
np edewageningen_ [888  1  0 ];
np maandagmorgen_ [865  1  0 ];
adv bijvoorbeeld_ [784  1  0 ];
centrum xxxprior [1612  1  1 ];
n vrijdagochtend_ [863  1  0 ];
errormp xxxprior [1610  1  1 ];
errornp xxxprior [1611  1  1 ];
adv noodzakelijk_ [562  1  0 ];
num achtendertig_ [426  1  0 ];
zwaluwe xxxprior [1609  1  1 ];
np heerhugowaard_ [778  1  0 ];
np zaterdagavond_ [766  1  0 ];
np kersenboogerd_ [670  1  0 ];
np vierlingsbeek_ [611  1  0 ];
mp morgenochtend_ [335  1  0 ];
ptp geinformeerd_ [806  1  0 ];
np vrijdagmorgen_ [852  1  0 ];
num vijfendertig_ [478  1  0 ];
np koogbloemwijk_ [790  1  0 ];
adv rechtstreeks_ [246  1  0 ];
np lichtenvoorde_ [385  1  0 ];
np naardenbussum_ [741  1  0 ];
num tweeendertig_ [443  1  0 ];
num vierendertig_ [980  1  0 ];
ptp opgeschreven_ [1078  1  0 ];
num eenentwintig_ [826  1  0 ];
np zettenandelst_ [733  1  0 ];
imps@ pro erroradv [1472  3  3 ];
num zesentwintig_ [290  1  0 ];
np nieuw amsterdam [1418  1  3 ];
lelylaan xxxprior [1613  1  1 ];
hollands xxxprior [1614  1  1 ];
n reisgelegenheid_ [234  1  0 ];
cornelis xxxprior [1617  1  1 ];
erroradv xxxprior [1618  1  1 ];
errordet xxxprior [1619  1  1 ];
paulowna xxxprior [1616  1  1 ];
errorinf xxxprior [1615  1  1 ];
np dinsdagochtend_ [837  1  0 ];
np donderdagavond_ [808  1  0 ];
np camminghaburen_ [679  1  0 ];
lelylaan lelylaan_ [1051  1  0 ];
np hoogcatharijne_ [787  1  0 ];
errorper xxxprior [1621  1  1 ];
adj eerstvolgende_ [1054  1  0 ];
hollands hollands_ [258  1  0 ];
voorburg xxxprior [1620  1  1 ];
adj rechtstreekse_ [1006  1  0 ];
adj allervroegste_ [457  1  0 ];
errornum xxxprior [1622  1  1 ];
errorpro xxxprior [1623  1  1 ];
np driemanspolder_ [644  1  0 ];
np zaterdagmorgen_ [345  1  0 ];
n treinverbinding_ [216  1  0 ];
np shertogenbosch_ [192  1  0 ];
num drieenveertig_ [479  1  0 ];
cornelis cornelis_ [827  1  0 ];
np woensdagmorgen_ [659  1  0 ];
np zwaagwesteinde_ [730  1  0 ];
ptp doorgedrongen_ [822  1  0 ];
num vijfenvijftig_ [528  1  0 ];
num zesennegentig_ [617  1  0 ];
num vijfenveertig_ [294  1  0 ];
num achtentwintig_ [783  1  0 ];
num zevenendertig_ [603  1  0 ];
num tweeenvijftig_ [519  1  0 ];
num drieentwintig_ [130  1  0 ];
paulowna paulowna_ [936  1  0 ];
num vijfentwintig_ [249  1  0 ];
num tweeentwintig_ [424  1  0 ];
num vierentwintig_ [58  1  0 ];
np driebergen zeist [1401  1  3 ];
np zeist driebergen [1386  1  3 ];
oedelrode xxxprior [1624  1  1 ];
voorburg voorburg_ [977  1  0 ];
amsterdam xxxprior [1625  1  1 ];
kogerveld xxxprior [1626  1  1 ];
bloemwijk xxxprior [1627  1  1 ];
castricum xxxprior [1630  1  1 ];
vechtwijk xxxprior [1628  1  1 ];
rodenrijs xxxprior [1629  1  1 ];
adj eenendertigste_ [879  1  0 ];
np zaterdagochtend_ [257  1  0 ];
num dertienhonderd_ [764  1  0 ];
num negenenvijftig_ [668  1  0 ];
np driebergenzeist_ [917  1  0 ];
num negenentwintig_ [625  1  0 ];
num zestienhonderd_ [390  1  0 ];
np zaandam kogerveld [1393  1  3 ];
num zevenenveertig_ [647  1  0 ];
driebergen xxxprior [1631  1  1 ];
np cornelis lelylaan [1419  1  3 ];
num zevenentwintig_ [101  1  0 ];
oedelrode oedelrode_ [695  1  0 ];
np bredaprinsenbeek_ [600  1  0 ];
amsterdam amsterdam_ [507  1  0 ];
kogerveld kogerveld_ [1070  1  0 ];
bloemwijk bloemwijk_ [1144  1  0 ];
adj eenentwintigste_ [1106  1  0 ];
num vijftienhonderd_ [1079  1  0 ];
castricum castricum_ [1130  1  0 ];
num veertienhonderd_ [1058  1  0 ];
np hollandsche rading [1435  1  3 ];
vechtwijk vechtwijk_ [1131  1  0 ];
rodenrijs rodenrijs_ [1151  1  0 ];
adj zesentwintigste_ [380  1  0 ];
hollandsche xxxprior [1632  1  1 ];
num zeuvenentwintig_ [189  1  0 ];
schollevaar xxxprior [1633  1  1 ];
xxxphrase xxxphrase_ [2  1  0 ];
np schiedamrotterdam_ [574  1  0 ];
num negentienhonderd_ [573  1  0 ];
adj drieentwintigste_ [598  1  0 ];
np capelle schollevaar [1426  1  3 ];
adj tweeentwintigste_ [580  1  0 ];
adj vierentwintigste_ [762  1  0 ];
np kruiningenyerseke_ [299  1  0 ];
leidschendam xxxprior [1634  1  1 ];
driebergen driebergen_ [982  1  0 ];
np heemstedeaerdenhout_ [781  1  0 ];
np krommenieassendelft_ [506  1  0 ];
np leidschendam voorburg [1398  1  3 ];
np voorburg leidschendam [1387  1  3 ];
hollandsche hollandsche_ [814  1  0 ];
schollevaar schollevaar_ [1071  1  0 ];
np driebergenrijsenburg_ [328  1  0 ];
np leidschendamvoorburg_ [433  1  0 ];
np schiedamrotterdam west [1440  1  3 ];
leidschendam leidschendam_ [965  1  0 ];
schiedamrotterdam xxxprior [1635  1  1 ];
num negentienzesennegentig_ [838  1  0 ];
num negentienvijfennegentig_ [173  1  0 ];
num negentienzevenennegentig_ [1052  1  0 ];
num negentienhonderdzesennegentig_ [1011  1  0 ];
schiedamrotterdam schiedamrotterdam_ [1002  1  0 ];
##
0.000000e+00 0.000000e+00 0.000000e+00 -5.670322e-01 -9.361913e-01 -2.877371e+00 -6.157120e-01 -1.626139e+00 
-2.956552e+00 -2.655523e+00 -3.111455e+00 -1.249387e-01 -4.429758e-01 0.000000e+00 -8.802764e-01 -1.760912e-01 
-9.030900e-01 -2.826979e-01 -7.781512e-01 -1.939519e+00 -1.505150e+00 -5.223248e-01 0.000000e+00 -7.281521e-01 
-1.247431e-01 0.000000e+00 -4.013007e-01 -2.198657e+00 -2.617668e-01 0.000000e+00 -2.594825e+00 -4.103680e-01 
0.000000e+00 0.000000e+00 -3.479431e+00 0.000000e+00 -7.946346e-01 0.000000e+00 -3.284656e+00 0.000000e+00 
-6.268260e-01 -3.246375e+00 -7.603130e-01 -1.505150e+00 -3.284656e+00 -7.781512e-01 -1.060698e-01 0.000000e+00 
-1.966974e+00 -1.435632e+00 -2.351806e+00 -2.193738e+00 -1.440485e+00 -2.351806e+00 -1.151805e+00 -3.780071e-01 
-1.602923e+00 -6.891600e-01 -1.626447e+00 -2.622167e+00 -1.314328e+00 -2.211452e+00 -2.047452e+00 -1.602923e+00 
-1.165741e+00 -1.244415e+00 -2.042256e+00 -2.362530e+00 -3.061500e+00 -2.566650e+00 -3.119492e+00 -2.923197e+00 
-1.486076e+00 -2.923197e+00 -2.860937e+00 -2.316957e+00 -2.035171e+00 -2.923197e+00 -2.850646e+00 -3.265620e+00 
-2.200110e+00 -2.566650e+00 -2.240314e+00 -2.923197e+00 -3.362530e+00 -2.788498e+00 -2.473228e+00 -2.242486e+00 
-3.547405e+00 -3.956552e+00 -3.061500e+00 -1.617987e+00 -1.721551e+00 -3.362530e+00 -7.570265e-01 -2.054207e+00 
-1.962437e+00 -1.275066e+00 -3.362530e+00 -2.652408e+00 -2.923197e+00 -2.435632e+00 -3.186438e+00 -2.439558e+00 
-2.373525e+00 -3.061500e+00 -2.923197e+00 -1.991935e+00 -1.698165e+00 -3.362530e+00 -2.945346e+00 -3.362530e+00 
-3.265620e+00 -3.964589e+00 -3.186438e+00 -3.061500e+00 -3.487468e+00 -2.923197e+00 -1.752402e+00 -2.170713e+00 
-3.362530e+00 -3.663560e+00 -3.186438e+00 -2.056044e+00 -2.373525e+00 -2.807535e+00 -1.623126e+00 -2.923197e+00 
-2.170713e+00 -3.362530e+00 -1.665599e+00 -3.265620e+00 0.000000e+00 -2.225186e+00 -2.566650e+00 -3.186438e+00 
-2.702307e+00 -2.807535e+00 -3.246375e+00 -3.070284e+00 -1.623126e+00 -3.497759e+00 -3.956552e+00 -2.148448e+00 
-2.760470e+00 -3.389875e+00 -3.663560e+00 -3.663560e+00 -3.282244e+00 -3.119492e+00 -9.127533e-01 -2.983626e+00 
-3.010347e+00 -2.923197e+00 -2.035090e+00 -3.362530e+00 -1.493298e+00 -1.886716e+00 -1.465595e+00 -3.186438e+00 
-2.437146e+00 -3.070284e+00 -3.061500e+00 -3.487468e+00 0.000000e+00 -2.682596e+00 -3.362530e+00 -2.486785e+00 
-3.663560e+00 -2.642370e+00 -3.663560e+00 -3.119492e+00 -3.070284e+00 -3.389875e+00 -2.983626e+00 -2.248586e+00 
-3.487468e+00 -3.071790e+00 -3.547405e+00 -2.983626e+00 -2.642370e+00 -1.470796e+00 -3.663560e+00 -3.119492e+00 
-2.644315e+00 -3.025353e-01 -2.750508e+00 -3.010347e+00 -1.502192e+00 -3.088845e+00 -3.246375e+00 -1.687231e+00 
-2.584378e+00 -3.663560e+00 -3.119492e+00 -6.348231e-01 -3.487468e+00 -2.953437e+00 -3.265620e+00 -2.807535e+00 
-3.362530e+00 -2.828499e+00 -2.848436e+00 -2.848436e+00 -3.186438e+00 -1.693592e+00 -3.061500e+00 -2.265620e+00 
-2.296968e+00 -2.460898e+00 -3.010347e+00 -3.282244e+00 -2.964589e+00 -2.850646e+00 -2.240549e+00 -1.673871e+00 
-3.246375e+00 -3.964589e+00 -3.119492e+00 -3.061500e+00 -3.547405e+00 -2.179582e+00 -2.842609e+00 -4.582944e-01 
-1.779506e+00 -3.487468e+00 -8.304740e-01 -3.265620e+00 -3.186438e+00 -1.983777e+00 -2.384806e+00 -3.430559e+00 
-2.532330e+00 -3.487468e+00 -3.547405e+00 0.000000e+00 -5.411036e-01 -2.760470e+00 0.000000e+00 -2.663560e+00 
-2.316615e+00 -3.430559e+00 -3.186438e+00 -3.547405e+00 0.000000e+00 -3.547405e+00 -3.284656e+00 -3.061500e+00 
-2.953437e+00 -2.009663e+00 -2.923197e+00 -3.362530e+00 -2.760470e+00 -2.945346e+00 -2.352183e+00 -2.585686e+00 
-3.186438e+00 -3.663560e+00 0.000000e+00 -3.070284e+00 -3.061500e+00 -2.807535e+00 -1.644315e+00 -2.061500e+00 
-3.284656e+00 -2.232214e+00 -2.585686e+00 -2.983626e+00 -3.275910e+00 -2.983626e+00 -3.663560e+00 -2.731589e+00 
-1.822258e+00 -2.439558e+00 -3.487468e+00 -2.243264e+00 -1.094087e+00 -3.430559e+00 -2.585686e+00 0.000000e+00 
-3.964589e+00 -2.912753e+00 -3.009451e+00 -3.663560e+00 -1.562293e+00 -3.964589e+00 -2.082785e+00 -2.230449e+00 
-3.284656e+00 -3.964589e+00 -1.942717e+00 -1.833360e+00 -3.663560e+00 -1.279285e+00 -2.310693e+00 -1.716455e+00 
-3.061500e+00 -3.487468e+00 -1.860786e+00 -3.487468e+00 -3.362530e+00 -3.547405e+00 -2.585686e+00 -2.647187e+00 
-1.315321e+00 -3.964589e+00 -2.014657e+00 -2.527722e+00 -2.769254e+00 -3.186438e+00 -3.009451e+00 -3.119492e+00 
-2.283348e+00 -3.487468e+00 -2.807535e+00 -2.191164e+00 -3.547405e+00 -1.942717e+00 -2.080536e+00 -2.663560e+00 
-3.663560e+00 -3.430559e+00 -2.737760e+00 -2.807535e+00 -3.430559e+00 -3.547405e+00 -3.070284e+00 -3.487468e+00 
-3.964589e+00 -2.663560e+00 -2.622167e+00 -3.582858e+00 -3.964589e+00 -3.246375e+00 -3.547405e+00 -2.302782e+00 
-3.547405e+00 -3.284656e+00 -3.060396e+00 -3.487468e+00 -1.885408e+00 -3.547405e+00 -2.734141e+00 -2.226439e+00 
-3.430559e+00 -3.663560e+00 -3.284656e+00 -3.284656e+00 -2.105648e+00 -1.319255e+00 -3.547405e+00 -3.759366e+00 
-2.964589e+00 -1.381601e+00 -3.362530e+00 -3.964589e+00 -3.009451e+00 -3.265620e+00 -2.418578e+00 -3.964589e+00 
-1.983777e+00 -2.506505e+00 -2.292492e+00 -2.807535e+00 -2.585461e+00 -2.769254e+00 -2.527469e+00 -3.009451e+00 
-2.953437e+00 -2.885408e+00 -3.673850e+00 -3.284656e+00 -9.691001e-02 -3.964589e+00 -3.009451e+00 0.000000e+00 
-2.268652e+00 -3.430559e+00 -3.663560e+00 -3.265620e+00 -2.194514e+00 -3.547405e+00 -9.732339e-01 -7.680510e-01 
-2.381566e+00 -3.964589e+00 -2.273387e+00 0.000000e+00 -1.925662e+00 -2.476316e+00 -3.088845e+00 -3.547405e+00 
-3.964589e+00 -3.663560e+00 -3.265620e+00 -3.964589e+00 -3.119492e+00 0.000000e+00 -3.430559e+00 -1.858838e+00 
-2.018423e+00 -3.284656e+00 -2.828499e+00 -3.547405e+00 -3.964589e+00 -2.788498e+00 -3.663560e+00 0.000000e+00 
-1.904445e+00 -3.265620e+00 -3.663560e+00 -2.517432e+00 -3.964589e+00 -1.875308e+00 -1.245358e+00 -3.497759e+00 
-3.964589e+00 0.000000e+00 -2.101267e+00 -1.415425e+00 -3.487468e+00 -3.284656e+00 -2.476316e+00 -2.788498e+00 
-1.845806e+00 -3.246375e+00 -3.389875e+00 -2.029384e+00 -2.912753e+00 -2.389875e+00 -2.379154e+00 -3.964589e+00 
0.000000e+00 -3.119492e+00 -5.870594e-01 -3.964589e+00 -1.204120e+00 -2.585686e+00 -3.487468e+00 -3.964589e+00 
-5.084610e-01 -2.885408e+00 -3.362530e+00 -3.389875e+00 -3.265620e+00 -3.663560e+00 -1.340657e+00 -3.119492e+00 
-3.430559e+00 -3.430559e+00 -1.684083e+00 -3.487468e+00 -1.919267e+00 -3.284656e+00 -3.964589e+00 -3.265620e+00 
-3.663560e+00 -2.495544e+00 -3.964589e+00 -2.585686e+00 -3.964589e+00 -2.391915e+00 -3.430559e+00 -2.547405e+00 
-2.885408e+00 -3.655523e+00 -2.788498e+00 -2.495544e+00 -3.246375e+00 -2.506505e+00 -2.420522e+00 -2.702307e+00 
-2.301832e+00 -3.964589e+00 -2.964589e+00 -1.198657e+00 -3.964589e+00 -3.547405e+00 -3.389875e+00 -3.389875e+00 
-3.246375e+00 -3.663560e+00 -2.230449e+00 -1.837498e+00 -3.186438e+00 -1.929419e+00 -3.964589e+00 -3.547405e+00 
-2.503677e+00 -2.352183e+00 -1.613152e+00 -2.682596e+00 -3.284656e+00 -2.685836e+00 -3.265620e+00 -3.547405e+00 
-2.231300e+00 -3.547405e+00 -2.449478e+00 -3.964589e+00 -1.427324e+00 -3.284656e+00 -2.750508e+00 -1.897627e+00 
-3.284656e+00 -2.246375e+00 -3.964589e+00 0.000000e+00 -2.495544e+00 -1.727117e+00 -3.010300e-01 -3.284656e+00 
-2.495544e+00 -2.420522e+00 -3.964589e+00 -1.702307e+00 -2.964589e+00 0.000000e+00 -3.964589e+00 -3.389875e+00 
-2.230449e+00 0.000000e+00 -3.964589e+00 -3.964589e+00 -1.702307e+00 -1.957847e+00 -2.495544e+00 -3.964589e+00 
-3.389875e+00 -3.964589e+00 -3.284656e+00 -2.495544e+00 -1.621898e+00 -3.284656e+00 -2.111121e+00 0.000000e+00 
-2.807535e+00 -3.430559e+00 -3.284656e+00 -2.702307e+00 -2.885408e+00 -2.371314e+00 -2.731589e+00 -3.663560e+00 
-2.005903e+00 -3.430559e+00 -3.246375e+00 -1.983777e+00 -3.663560e+00 -3.284656e+00 -1.505150e+00 -3.430559e+00 
-2.885408e+00 -8.902045e-01 -3.964589e+00 -3.964589e+00 -2.708421e+00 -3.430559e+00 -3.265620e+00 -2.254467e+00 
-2.506505e+00 -3.663560e+00 -3.284656e+00 -3.547405e+00 -1.964589e+00 -3.362530e+00 -1.958511e+00 -3.362530e+00 
0.000000e+00 -3.964589e+00 -1.557366e+00 -3.186438e+00 -2.506505e+00 -3.389875e+00 -3.964589e+00 -3.964589e+00 
-3.547405e+00 0.000000e+00 0.000000e+00 -2.138515e+00 -2.495544e+00 -2.964589e+00 -1.991462e+00 -6.289185e-01 
-3.547405e+00 0.000000e+00 -1.858396e+00 0.000000e+00 -2.709317e+00 -1.115333e+00 -3.964589e+00 -2.602862e+00 
-3.186438e+00 0.000000e+00 -3.284656e+00 -3.487468e+00 -1.532400e+00 -3.430559e+00 -2.495544e+00 -2.760470e+00 
-3.964589e+00 -1.187570e+00 -2.456366e+00 -3.088845e+00 -2.709317e+00 -1.761928e+00 -2.230449e+00 -3.284656e+00 
-3.010300e-01 0.000000e+00 -3.430559e+00 -3.061500e+00 -2.593163e+00 -1.189343e+00 -1.858396e+00 -3.246375e+00 
-2.983626e+00 -2.486785e+00 -2.185678e+00 -3.964589e+00 -3.663560e+00 -3.673850e+00 0.000000e+00 -2.923197e+00 
0.000000e+00 -2.243747e+00 0.000000e+00 -2.138515e+00 -3.430559e+00 -2.885408e+00 -3.956552e+00 -2.818462e+00 
-3.547405e+00 -2.430812e+00 -2.602862e+00 -2.230449e+00 -3.964589e+00 -3.547405e+00 -3.284656e+00 -1.353559e+00 
-2.442592e-01 -2.134602e+00 -2.230449e+00 -3.071790e+00 -3.362530e+00 -3.663560e+00 -2.495544e+00 -3.389875e+00 
-3.663560e+00 -2.751279e+00 -3.547405e+00 0.000000e+00 -3.547405e+00 -2.529430e+00 -2.981214e+00 -2.331121e+00 
-3.547405e+00 0.000000e+00 -3.487468e+00 -3.964589e+00 -2.468224e+00 -3.372820e+00 -3.010347e+00 -2.495544e+00 
-3.964589e+00 -3.663560e+00 -3.265620e+00 -2.585686e+00 -3.389875e+00 -3.964589e+00 -3.663560e+00 -1.124597e+00 
-3.964589e+00 -2.582858e+00 -3.964589e+00 -3.430559e+00 -3.487468e+00 -3.487468e+00 -3.430559e+00 -3.964589e+00 
-2.964589e+00 -3.547405e+00 -2.885408e+00 -3.759366e+00 -3.964589e+00 -1.563800e+00 -1.717393e+00 -1.148063e+00 
-2.230449e+00 -3.663560e+00 -2.737760e+00 -3.284656e+00 -2.495544e+00 -1.045482e+00 -2.532330e+00 0.000000e+00 
-3.964589e+00 0.000000e+00 -1.974901e+00 0.000000e+00 -2.964589e+00 -3.964589e+00 -3.663560e+00 0.000000e+00 
-3.663560e+00 -1.761928e+00 -3.964589e+00 -1.929419e+00 -1.412151e+00 -3.547405e+00 -2.397638e+00 -3.228400e+00 
-2.532330e+00 -3.964589e+00 -3.070284e+00 -2.964589e+00 -1.622167e+00 -9.054104e-01 -3.964589e+00 0.000000e+00 
-2.292133e+00 -1.013740e+00 -3.458336e+00 -2.642370e+00 -3.265620e+00 -3.430559e+00 -3.284656e+00 -6.600519e-01 
-2.165249e+00 -2.443401e+00 -3.964589e+00 -3.284656e+00 0.000000e+00 -3.487468e+00 -3.964589e+00 -3.663560e+00 
-1.766625e+00 -3.547405e+00 -2.051153e+00 -2.175286e+00 -2.446076e+00 -3.186438e+00 -3.061500e+00 -2.005548e+00 
-2.100247e+00 0.000000e+00 -1.365799e+00 -3.362530e+00 -2.818462e+00 -3.663560e+00 -3.964589e+00 -3.265620e+00 
-3.002310e+00 -3.663560e+00 -2.175286e+00 -1.959609e+00 -9.514762e-01 -3.497759e+00 -1.104549e+00 -3.964589e+00 
-1.214967e+00 -2.527722e+00 -1.893484e+00 -3.964589e+00 -3.389875e+00 -3.284656e+00 -3.964589e+00 -1.696921e+00 
-2.172198e+00 -3.964589e+00 -2.964589e+00 -1.951752e+00 -3.547405e+00 -2.818462e+00 -1.800324e+00 -6.843323e-01 
-3.547405e+00 -3.663560e+00 -3.362530e+00 -3.228400e+00 -2.751279e+00 -3.265620e+00 -3.284656e+00 -2.348482e+00 
-3.284656e+00 -2.051153e+00 -3.964589e+00 -3.964589e+00 -2.352183e+00 -2.964589e+00 -3.487468e+00 -3.582858e+00 
0.000000e+00 -3.284656e+00 -3.673850e+00 -1.741734e+00 -1.628389e+00 -3.265620e+00 -2.622167e+00 -3.663560e+00 
-3.228400e+00 -3.547405e+00 -1.992609e+00 -2.495544e+00 -3.430559e+00 -3.974880e+00 -2.230449e+00 -2.802432e+00 
-3.964589e+00 -2.751279e+00 -2.860937e+00 -2.401277e+00 -3.284656e+00 -2.983626e+00 0.000000e+00 -2.459440e+00 
-3.284656e+00 -2.018423e+00 -3.186438e+00 -3.964589e+00 -3.070284e+00 -2.964589e+00 -2.230449e+00 -2.856276e+00 
-1.349416e+00 -3.362530e+00 -1.884725e+00 0.000000e+00 -2.734141e+00 -2.622167e+00 -3.430559e+00 -2.983626e+00 
-3.663560e+00 -2.363099e+00 -3.103462e+00 -3.547405e+00 -3.964589e+00 -3.964589e+00 -1.991935e+00 -3.547405e+00 
-2.194514e+00 -2.284431e+00 -3.547405e+00 -3.129529e+00 -3.663560e+00 -3.964589e+00 -1.531479e+00 -3.964589e+00 
-3.964589e+00 -3.010936e+00 -2.541466e+00 -2.964589e+00 -3.487468e+00 -3.964589e+00 -2.734141e+00 -1.022566e+00 
-3.228400e+00 -3.964589e+00 -2.459440e+00 -3.284656e+00 -2.230449e+00 -3.964589e+00 -3.964589e+00 -3.547405e+00 
-3.487468e+00 -3.487468e+00 -2.953437e+00 -3.010936e+00 -3.964589e+00 -3.547405e+00 -3.964589e+00 -2.495544e+00 
-3.663560e+00 -3.663560e+00 -3.964589e+00 -3.284656e+00 -3.119492e+00 -2.495544e+00 -3.964589e+00 -2.495544e+00 
0.000000e+00 -3.487468e+00 -2.532330e+00 -3.547405e+00 -2.807535e+00 -1.416363e+00 -3.582858e+00 -2.311966e+00 
-3.487468e+00 -2.923197e+00 -2.430559e+00 -2.927370e+00 -3.246375e+00 -2.860937e+00 -1.942234e+00 -3.663560e+00 
-2.533814e+00 -3.228400e+00 -3.964589e+00 -3.186438e+00 -2.927370e+00 -2.495544e+00 -3.284656e+00 -3.547405e+00 
-2.964589e+00 -2.373525e+00 -2.927370e+00 0.000000e+00 -8.620759e-01 -3.009451e+00 -3.070284e+00 -3.404492e+00 
-3.964589e+00 -2.204983e+00 -3.663560e+00 -3.663560e+00 -3.265620e+00 -3.265620e+00 -3.547405e+00 -3.119492e+00 
-1.062958e+00 -3.547405e+00 -3.430559e+00 -2.450249e+00 -2.230449e+00 0.000000e+00 -3.964589e+00 -2.750508e+00 
-3.265620e+00 -3.284656e+00 -3.964589e+00 -3.430559e+00 -3.430559e+00 -3.759366e+00 -3.964589e+00 -3.974880e+00 
0.000000e+00 -3.759366e+00 -2.501402e+00 -2.750508e+00 -1.080571e+00 0.000000e+00 -3.196729e+00 0.000000e+00 
-3.964589e+00 -3.497759e+00 -3.311966e+00 -3.964589e+00 -3.070284e+00 -2.927370e+00 -3.487468e+00 -3.964589e+00 
-3.964589e+00 -3.284656e+00 -3.265620e+00 -2.828499e+00 -6.997718e-01 -3.009451e+00 -3.487468e+00 -1.538717e+00 
-3.487468e+00 -3.228400e+00 -2.529430e+00 -2.051538e+00 -3.362530e+00 0.000000e+00 -3.246375e+00 -3.404492e+00 
-3.362530e+00 -3.009451e+00 -7.119351e-01 -3.673850e+00 -3.430559e+00 -3.547405e+00 -3.673850e+00 -3.487468e+00 
-2.927370e+00 0.000000e+00 0.000000e+00 -1.939284e+00 -3.088845e+00 -3.346157e+00 0.000000e+00 -6.340078e-01 
-3.129529e+00 -3.346157e+00 0.000000e+00 -3.372820e+00 -3.547405e+00 -3.964589e+00 -3.009451e+00 -3.487468e+00 
-2.953437e+00 -3.284656e+00 -3.663560e+00 -3.964589e+00 -3.547405e+00 -1.249387e-01 -3.009451e+00 -3.430559e+00 
-3.964589e+00 -3.275910e+00 0.000000e+00 0.000000e+00 -3.009451e+00 0.000000e+00 -1.717393e+00 -2.495544e+00 
-3.964589e+00 -3.105737e+00 -3.663560e+00 -3.389875e+00 -3.964589e+00 -3.404492e+00 -3.284656e+00 -3.070284e+00 
-3.964589e+00 0.000000e+00 -3.547405e+00 -3.663560e+00 0.000000e+00 0.000000e+00 -3.964589e+00 -2.198657e+00 
-2.953437e+00 -2.885408e+00 -3.964589e+00 -3.547405e+00 -3.311966e+00 0.000000e+00 -2.626340e+00 -3.663560e+00 
-3.964589e+00 -3.663560e+00 0.000000e+00 -3.759366e+00 -3.430559e+00 -2.395096e+00 -2.495544e+00 -2.927370e+00 
-3.547405e+00 -3.759366e+00 -3.663560e+00 -2.927370e+00 -3.547405e+00 -3.964589e+00 0.000000e+00 -2.642370e+00 
-2.495544e+00 -3.974880e+00 -3.284656e+00 0.000000e+00 -3.389875e+00 -2.198022e+00 -2.018423e+00 -3.430559e+00 
-3.228400e+00 -7.223466e-01 -3.389875e+00 -3.964589e+00 -3.964589e+00 -3.009451e+00 -2.750508e+00 -3.547405e+00 
-3.673850e+00 -2.383302e+00 -1.596597e+00 -3.964589e+00 0.000000e+00 -2.529430e+00 0.000000e+00 0.000000e+00 
-3.547405e+00 -3.009451e+00 -1.309801e-01 -3.964589e+00 -5.228787e-01 -2.107210e+00 -1.628389e+00 -3.389875e+00 
-3.759366e+00 -3.284656e+00 -3.964589e+00 -3.284656e+00 -3.547405e+00 -3.974880e+00 -3.389875e+00 -2.352183e+00 
-1.499687e+00 -2.593163e+00 -3.964589e+00 -2.228400e+00 -5.723022e-01 -3.964589e+00 -8.239087e-01 0.000000e+00 
-2.495544e+00 -3.547405e+00 0.000000e+00 -1.000000e+00 -3.547405e+00 -3.228400e+00 -3.284656e+00 -3.404492e+00 
-3.389875e+00 -3.964589e+00 -2.495544e+00 -1.893484e+00 -2.114457e+00 0.000000e+00 -1.875061e+00 -3.547405e+00 
-1.107826e+00 -3.284656e+00 -2.194514e+00 -1.352183e+00 -2.751279e+00 -3.430559e+00 -3.009451e+00 -2.194514e+00 
-3.284656e+00 -1.018885e+00 -3.009451e+00 0.000000e+00 -3.228400e+00 -3.964589e+00 -1.964966e+00 -1.006552e+00 
-3.284656e+00 0.000000e+00 0.000000e+00 0.000000e+00 -7.474824e-01 -2.130334e+00 -1.929419e+00 -2.567026e+00 
-2.751279e+00 0.000000e+00 -2.051153e+00 -2.230449e+00 -2.352183e+00 -3.284656e+00 -2.495544e+00 -2.442088e+00 
0.000000e+00 -2.612996e+00 0.000000e+00 -1.707570e+00 -2.495544e+00 -1.429060e+00 0.000000e+00 0.000000e+00 
-2.230449e+00 -2.495544e+00 -2.230449e+00 0.000000e+00 -2.927370e+00 -2.460898e+00 -3.311966e+00 -2.495544e+00 
0.000000e+00 -2.495544e+00 -2.265996e+00 -2.450249e+00 -2.683609e-01 -1.840028e+00 -2.681733e-01 -3.228400e+00 
-2.352183e+00 -1.390935e+00 -2.230449e+00 0.000000e+00 -9.814601e-01 -2.495544e+00 -1.301030e+00 -2.495544e+00 
-2.626340e+00 -2.352183e+00 -2.885408e+00 -5.614421e-01 0.000000e+00 -3.228400e+00 -2.352183e+00 -4.600090e-01 
-2.352183e+00 -2.404492e+00 -3.044148e+00 -3.974880e+00 -2.345178e+00 -1.056693e+00 -9.353885e-01 0.000000e+00 
-3.010936e+00 -3.311966e+00 -3.044148e+00 -3.044148e+00 -2.802432e+00 -2.442088e+00 -1.000000e+00 -3.044148e+00 
-3.311966e+00 -1.169086e+00 -1.721928e+00 -1.000000e+00 -2.268004e+00 -3.044148e+00 -2.743118e+00 -1.806180e+00 
-1.930204e+00 -2.850646e+00 -2.265996e+00 -3.265620e+00 -1.284954e+00 -2.685836e+00 -3.070284e+00 -3.228400e+00 
-3.228400e+00 -3.404492e+00 -2.061500e+00 -1.766002e+00 -2.230449e+00 -1.705522e+00 -3.228400e+00 -3.228400e+00 
-3.487468e+00 -2.230449e+00 -3.228400e+00 -1.604754e+00 -1.230449e+00 -3.196729e+00 -3.372820e+00 -1.464972e+00 
-1.997951e+00 -1.105510e+00 -3.311966e+00 -3.228400e+00 -3.389875e+00 -1.008600e+00 -3.284656e+00 -3.404492e+00 
-2.230449e+00 -2.927370e+00 -2.408876e+00 -3.430559e+00 -3.974880e+00 -1.628389e+00 -3.663560e+00 -2.626340e+00 
-2.834844e+00 -3.311966e+00 -7.990852e-01 -3.582858e+00 -3.228400e+00 -1.453997e+00 -2.408240e+00 -3.547405e+00 
-3.964589e+00 -1.646208e+00 -3.964589e+00 -3.311966e+00 -2.408240e+00 -3.020637e+00 -1.000000e+00 -3.044148e+00 
-3.663560e+00 -3.663560e+00 -4.968653e-01 -3.346157e+00 -1.051153e+00 -3.044148e+00 -3.228400e+00 -2.927370e+00 
-3.547405e+00 -1.330005e+00 -2.408240e+00 -3.404492e+00 -8.044803e-01 -3.547405e+00 -3.974880e+00 -1.255272e+00 
-2.130334e+00 -3.228400e+00 -3.228400e+00 -2.311966e+00 -8.325090e-01 -3.404492e+00 -3.088845e+00 -3.228400e+00 
-2.927370e+00 -3.228400e+00 -2.330414e+00 -2.927370e+00 -3.974880e+00 -7.918126e-02 -3.974880e+00 -2.130334e+00 
-1.301030e+00 -2.130334e+00 -1.176091e+00 -2.420522e+00 -3.228400e+00 -1.046512e+00 -2.751279e+00 -3.228400e+00 
-2.834844e+00 -2.351806e+00 -3.228400e+00 -3.228400e+00 -2.602862e+00 -3.228400e+00 -3.228400e+00 -5.563025e-01 
-3.228400e+00 -1.923197e+00 -2.529430e+00 -3.964589e+00 -3.228400e+00 -3.228400e+00 -3.103462e+00 -3.265620e+00 
-3.404492e+00 -3.228400e+00 -2.743118e+00 -3.311966e+00 -1.707570e+00 -3.404492e+00 -3.009451e+00 -2.107210e+00 
-1.866673e+00 -1.525634e+00 -2.743118e+00 -3.044148e+00 -8.897262e-01 -3.044148e+00 -2.052309e+00 -2.750508e+00 
-1.010300e+00 -3.044148e+00 -2.529430e+00 -3.107898e-01 -4.101745e-01 -2.373525e+00 -3.196729e+00 -3.228400e+00 
-1.301030e+00 -1.997951e+00 -2.685836e+00 -3.228400e+00 -7.781512e-01 -2.408240e+00 -3.228400e+00 -2.927370e+00 
-3.404492e+00 -3.228400e+00 -3.044148e+00 -3.228400e+00 -1.554656e+00 -1.230449e+00 -3.487468e+00 -3.061500e+00 
-3.228400e+00 -3.487468e+00 -1.806180e+00 -2.895699e+00 -2.044148e+00 -3.228400e+00 -3.964589e+00 -3.404492e+00 
-3.044148e+00 -3.964589e+00 -3.044148e+00 -2.927370e+00 -3.129782e+00 -3.404492e+00 -1.505150e+00 -2.543516e+00 
-3.974880e+00 -3.964589e+00 -1.255272e+00 -3.362530e+00 -3.119492e+00 -3.663560e+00 -3.061500e+00 -3.964589e+00 
-3.119492e+00 -7.533276e-01 -3.964589e+00 -3.362530e+00 -2.584378e+00 -2.751279e+00 -2.230449e+00 -3.228400e+00 
-1.707570e+00 -3.663560e+00 -3.228400e+00 -1.105510e+00 -3.228400e+00 -3.663560e+00 -3.964589e+00 -3.964589e+00 
-3.964589e+00 -3.964589e+00 -2.230449e+00 -3.186438e+00 -2.466868e+00 -3.663560e+00 -3.228400e+00 -3.228400e+00 
-2.567026e+00 -3.228400e+00 -3.547405e+00 -3.228400e+00 -3.663560e+00 -3.974880e+00 -3.964589e+00 -3.964589e+00 
-3.389875e+00 -3.010936e+00 -3.663560e+00 -3.362530e+00 -1.255272e+00 -3.228400e+00 -3.964589e+00 -2.230449e+00 
-3.228400e+00 -3.974880e+00 -3.964589e+00 -3.311966e+00 -2.743118e+00 -2.626340e+00 -3.311966e+00 -2.567026e+00 
-2.107210e+00 -3.311966e+00 -3.228400e+00 -3.663560e+00 -3.663560e+00 -2.751279e+00 -3.228400e+00 -3.362530e+00 
-3.265620e+00 -3.964589e+00 -3.663560e+00 -3.228400e+00 -1.989746e+00 -3.964589e+00 -2.352183e+00 -1.255272e+00 
-3.964589e+00 -3.228400e+00 -3.487468e+00 -3.228400e+00 -3.228400e+00 -3.487468e+00 -2.408240e+00 -3.103462e+00 
-3.974880e+00 -2.743118e+00 -3.228400e+00 -3.228400e+00 -2.923197e+00 -3.663560e+00 -3.404492e+00 -3.228400e+00 
-1.255272e+00 -3.964589e+00 -2.743118e+00 -3.228400e+00 -3.663560e+00 -2.709906e+00 -2.834844e+00 -3.974880e+00 
-1.707570e+00 -3.311966e+00 -3.974880e+00 -2.974880e+00 -2.408240e+00 -3.663560e+00 -3.372820e+00 -2.927370e+00 
-2.927370e+00 -3.964589e+00 -3.010936e+00 -3.372820e+00 -2.743118e+00 -3.228400e+00 -2.230449e+00 -3.964589e+00 
-3.044148e+00 -3.362530e+00 -2.760470e+00 -2.130334e+00 -3.964589e+00 -3.487468e+00 -3.964589e+00 -3.228400e+00 
-3.964589e+00 -3.228400e+00 -2.230449e+00 -3.663560e+00 -3.119492e+00 -2.923197e+00 -3.228400e+00 -3.663560e+00 
-3.964589e+00 -3.964589e+00 -3.964589e+00 -1.255272e+00 -3.964589e+00 -3.964589e+00 -3.964589e+00 -2.566650e+00 
-3.487468e+00 -3.964589e+00 -2.663560e+00 -1.564327e+00 -1.245322e+00 -1.033362e+00 -1.480762e+00 -3.947630e+00 
-1.362169e+00 -3.129970e+00 -4.315607e+00 -3.537455e+00 -8.178479e-01 -8.281382e-01 -3.947630e+00 -2.384488e+00 
-1.388236e+00 -3.537455e+00 -2.662394e+00 -1.209869e+00 -2.297183e+00 -4.491698e+00 -3.301366e+00 -4.792728e+00 
-1.783277e+00 -2.223354e+00 -3.190668e+00 -4.792728e+00 -4.190668e+00 -4.315607e+00 -2.331830e+00 -2.594071e+00 
-1.508072e+00 -4.491698e+00 -1.446570e+00 -3.889638e+00 -3.491698e+00 -1.402853e+00 -2.440545e+00 -2.042219e+00 
-2.562279e+00 -8.361752e-01 -2.381108e+00 -4.014577e+00 -4.792728e+00 -3.412517e+00 -4.792728e+00 -4.792728e+00 
-4.792728e+00 -3.588608e+00 -4.792728e+00 -4.315607e+00 -4.792728e+00 -1.748580e+00 -3.377754e+00 -3.412517e+00 
-3.889638e+00 -3.287578e+00 -3.947630e+00 -4.491698e+00 -3.085158e+00 -4.014577e+00 -4.792728e+00 -3.431000e+00 
-4.792728e+00 -3.431000e+00 -3.201663e+00 -4.315607e+00 -4.792728e+00 -4.093758e+00 -4.315607e+00 -4.491698e+00 
-3.947630e+00 -4.491698e+00 -4.792728e+00 -3.377754e+00 -3.838485e+00 -4.491698e+00 -3.889638e+00 -3.179944e+00 
-4.491698e+00 -3.361364e+00 -4.792728e+00 -4.491698e+00 -4.190668e+00 -4.491698e+00 -4.315607e+00 -4.792728e+00 
-4.792728e+00 -4.792728e+00 -4.792728e+00 -3.287578e+00 -3.947630e+00 -4.792728e+00 -4.491698e+00 -3.491698e+00 
-4.190668e+00 -4.014577e+00 -4.014577e+00 -4.315607e+00 -4.792728e+00 -4.190668e+00 -3.889638e+00 -4.792728e+00 
-4.792728e+00 -4.190668e+00 -4.491698e+00 -4.491698e+00 -4.093758e+00 -4.792728e+00 -4.491698e+00 -4.792728e+00 
-4.491698e+00 -4.491698e+00 -4.491698e+00 -4.792728e+00 -4.792728e+00 -4.491698e+00 -4.792728e+00 -4.491698e+00 
-4.491698e+00 -4.792728e+00 -4.093758e+00 -4.093758e+00 
