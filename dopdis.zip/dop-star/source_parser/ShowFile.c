#include "./ALL.h"
#include "./unary_bamboo_functions.h"

extern void PRNTTERM(ItemTree item);
extern char *OriginalWord(LevDomain i, LevDomain j);
extern void PrintBannedWord(int after_w_num, Boolean PrnCommaAfter, Boolean PrnCommaBef);
extern ProbDomain InterpolatedProb(DerFPtr DFP);
extern ProbDomain ProbOfDFP(DerFPtr DFP);

#define _mark_subst_points false
#define _prnt_postags false

#define NUM_OF_EXP_DERS 1000000
DerFPtr _ArrayOfDFPtr[NUM_OF_EXP_DERS];               int ARRAY_COUNTER=0;

void PRIX(int a) { fprintf(fpOUT, "%d", a); }

void EnterToArrayOfDFPtr(DerFPtr DFP)
{if (ARRAY_COUNTER < NUM_OF_EXP_DERS) _ArrayOfDFPtr[ARRAY_COUNTER] = DFP;
 else {fprintf(stderr,"Err: NUM_OF_EXP_DERS too Small\n"); exit(1);}
 ARRAY_COUNTER++;
}
void ShowAllArray_OfDerFPs()
{int i;
 for (i=0;i < ARRAY_COUNTER; i++) ShowMPD_OfDF(_ArrayOfDFPtr[i]->MPD_PtrL, true, true);
}
/******************************/
void StripUnnecessary(char *s, Boolean thereissub)
{char *cuopener; 

 if (s== NULL) ; 
 else if (s[0] == '\0') ;
      else if ( s[0] == '\(' ) 
             { PRS("(");
               if (thereissub == true) PRS("*"); 
               if ( (cuopener = strchr((s+1), ((int) '('))) != NULL)
                  {cuopener[0] = '\0'; PRS(s+1); cuopener[0] = '(';
                   StripUnnecessary(cuopener, false);
                  }
               else if ( (cuopener = strrchr((s+1), ((int) ','))) != NULL)
                      if ((isdigit((int) cuopener[1])) != 0)
                         {cuopener[0] = '\0'; PRS(s+1); cuopener[0] = ',';
                          PRS(")");}
                      else PRS(s+1);
                    else ; /* shouldn't be possible */
             }
           else ; /* shouldn't be possible  */
                   
}
/******************************/
extern void ShowDerF(ItemTree I);

void ShowMPD_OfDF(DerFPtr DFP,Boolean showsubs, Boolean top)
{Boolean thereissub = false; Boolean FromColam = false; char TEMP[SymLength];
       Boolean ThereIsSubstitution()
         {int i;
          if (_mark_subst_points==false) return false;

	  for (i=0; i < ((ItemCPtr) DFP->SelfItem->DerForest)->RootsSize; i++)
           if (((DerFPtr)(((ItemCPtr) DFP->SelfItem->DerForest)->Roots + i)) == DFP) return true;
          return false;
         }
       
 if (DFP == NULL) ;
 else if (DFP->SelfItem == NULL) {fprintf(stderr,"Err: DFP->SelfItem is NULL\n");exit(1);}
      else
      {TreeCodeT TreeC = TreeCodeOfDFP(DFP); InTreeCodeT OwnC = OwnCodeOfDFP(DFP);
       InTreeCodeT LCh_OwnC = Ch_OwnCodeOfDFP(DFP,  Lch_enum);
       InTreeCodeT RCh_OwnC = Ch_OwnCodeOfDFP(DFP,  Rch_enum);

       thereissub = ThereIsSubstitution();

       if (((DFP->MPD_PtrL == NULL) && (DFP->MPD_PtrR == NULL))
          && (DFP->SelfItem->RT == _Term)) { PrintBannedWord(DFP->SelfItem->i, true, false); PRS("(");}
       else {PRS("(");}

       if ((showsubs == true) && (thereissub ==true))  /* show the substitutions */ PRS("*"); 

       if ((DFP->MPD_PtrL == NULL) && (DFP->MPD_PtrR == NULL))
         if (DFP->SelfItem->RT == _Term)
             {PLHS(DFP->SelfItem);PRS(",[");
	      {strcpy(TEMP,PrefixOfUnariesUnder(TreeC, OwnC)); PRS(TEMP);}
              PRS("("); 
                if (DFP->SelfItem->Transition!= NULL)
                 if(_prnt_postags==true) {
                      if (EQ_Strings(DFP->SelfItem->Transition->Morpheme,"") == false) 
			  PRS(DFP->SelfItem->Transition->Morpheme);
                    }
              PRNTTERM(DFP->SelfItem); /* printing the terminal */
                if (DFP->SelfItem->Transition!= NULL)
                  if (DFP->SelfItem->Transition->WordBounary == true) 
			   {PRS("#");PRIX(DFP->SelfItem->Transition->WordReference);}
              PRS("_,[])");
	      {strcpy(TEMP,SuffixOfUnariesUnder(TreeC, OwnC));PRS(TEMP); }
              PRS("])");
              if (DFP->SelfItem->j == _sen_length) PrintBannedWord(_sen_length, false, true); 
             }
         else  {fprintf(stderr,"Err1: in Show_MPDOfDerF\n");exit(1); } 
       else {PLHS(DFP->SelfItem);PRS(",[");

	     {strcpy(TEMP,PrefixOfUnariesUnder(TreeC, OwnC));PRS(TEMP); }
              if (top == false) PrintBannedWord(DFP->SelfItem->i, true, false);  
	     {strcpy(TEMP,PrefixOfUnariesAbove(TreeC, LCh_OwnC));PRS(TEMP);}
             ShowMPD_OfDF(DFP->MPD_PtrL, showsubs, false);
	     {strcpy(TEMP,SuffixOfUnariesAbove(TreeC, LCh_OwnC));PRS(TEMP);}

             if ((DFP->MPD_PtrR != NULL) && (DFP->SelfItem->RT == _Binary)) 
              {PRS(","); 
               if (top == false) PrintBannedWord(DFP->MPD_PtrR->SelfItem->i, true, false);  
	       {strcpy(TEMP,PrefixOfUnariesAbove(TreeC, RCh_OwnC));PRS(TEMP);}
               ShowMPD_OfDF(DFP->MPD_PtrR, showsubs, false);
	       {strcpy(TEMP,SuffixOfUnariesAbove(TreeC, RCh_OwnC));PRS(TEMP);}
              }
             if ((top == false) && (DFP->SelfItem->j == _sen_length)) 
	           PrintBannedWord(_sen_length, false, true);  
	        {strcpy(TEMP,SuffixOfUnariesUnder(TreeC, OwnC)); PRS(TEMP);}

             PRS("])");
            }
      }
}
void ShowProbs_OfDer(DerFPtr DFP)
{int i;
 if (DFP == NULL) ;
 else { /* PRS("("); */
       PLHS(DFP->SelfItem);
       /* PRS(",[");
       if ((DFP->MPD_PtrL == NULL) && (DFP->MPD_PtrR == NULL))
             {PRS("(");PRHS1(DFP->SelfItem);PRS(",[])");}
       else {ShowMPD_OfDF(DFP->MPD_PtrL, false, false);
             if (DFP->MPD_PtrR != NULL) PRS(","); 
             ShowMPD_OfDF(DFP->MPD_PtrR, false, false);
            }
       PRS("],");PRB(DFP->MPD_Prob); 
       PRS(").\n"); 
       ShowProbs_OfDer(DFP->MPD_PtrL); ShowProbs_OfDer(DFP->MPD_PtrR);
       */
       }
}
/*****/
void ShowMPD_OfICP(ItemCPtr I)
{TreeCodeT i; int length;
 DerFPtr MPDPtr ;
 if (I==NULL) ;
 else
 if (I->RootsSize == 0);
 else for (i=0; i< I->RootsSize; ++i)
      {MPDPtr = (DerFPtr) &(I->Roots[i]);
       length = MPDPtr->SelfItem->j - MPDPtr->SelfItem->i;
       PRB(MPDPtr->MPD_Prob);PRS("    ");
       PRB((ProbDomain) (((double) 1.0) / ((double) length)) * ((double) MPDPtr->MPD_Prob)); 
       PRS("  : "); ShowMPD_OfDF(MPDPtr, true, false);PRS(".\n");
      }
/*if (I->OthersSize == 0); else for (i=0; i< I->OthersSize; ++i)
 {MPDPtr = (DerFPtr) &(I->Others[i]); ShowMPD_OfDF(MPDPtr, true, false);PRS(".\n");}
*/
}

void VShowMPD_OfItem(void *I)
{ItemTree IT = (ItemTree) I;
 if (IT != NULL) ShowMPD_OfICP((ItemCPtr) IT->DerForest);
}
Boolean RedDF_Item(ItemTree I)
{if (RedDerForest == true)  return true;
 else if (RedDF_CEntries == true) 
        if (I->Dot == rm) return true;
        else return false;  
      else return false;
}
void ShowMPD_OfPList(PtrList P)
{ProbDomain MAXP ;
 ProbDomain MAXP2;
 DerFPtr MPDPtr, MPDPtr2;
 int i;
 ProbDomain SumP;
            void MPDSelect(void *I)
               {TreeCodeT i; ItemCPtr CP; Boolean First = false;
                if (((ItemTree) I) != NULL)
                    CP = ((ItemCPtr) ((ItemTree) I)->DerForest);
                else CP = NULL;
                if (CP != NULL)
                for (i=0; i < CP->RootsSize; ++i)
                 if (RedDF_Item((ItemTree) I)==true) 
                  {MAXP = MaxProbs(ProbOfDFP((DerFPtr) &(CP->Roots[i])), MAXP, &First);
                   if (First == true) {MPDPtr = (DerFPtr) &(CP->Roots[i]);
                                       First = false;}
                   SumP = SumProbs(SumP, (CP->Roots[i]).Sum_Prob);
                   EnterToArrayOfDFPtr(&(CP->Roots[i]));
                  }
                 else if (CP->R_valids[i] == true) 
                  {MAXP = MaxProbs(ProbOfDFP((DerFPtr)&(CP->Roots[i])), MAXP, &First);
                   if (First == true) {MPDPtr = (DerFPtr) &(CP->Roots[i]);
                                       First = false;}
                   EnterToArrayOfDFPtr(&(CP->Roots[i]));
                   SumP = SumProbs(SumP, (CP->Roots[i]).Sum_Prob);
                  }
               }
 MAXP = MaxNutralConst; 
 SumP = SumNutralConst; 
 MPDPtr = NULL; 
 if (P==NULL) {/* PRS("(XXXnonOemptypf,[]).\n") ; */ EXIT(NOPF);}
 else {PListMap(P, (void *) &MPDSelect); 
       if (MPDPtr == NULL){/* PRS("(XXXnonOemptydf,[]).\n"); */ EXIT(NODF);}
       else { /* PRI(MPDPtr->MPD_PtrL->CAdr); */
             fprintf(stderr,"\n");
             fprintf(stderr,"Sentence Probability %6.6e\n",  POWER((double) SumP)); 
             fprintf(stderr,"MPD Probability %6.6e\n", POWER((double) MPDPtr->MPD_Prob)); 
             if (_interpolate_ngram== true) fprintf(stderr,"Interp. with N-gram Prob. %6.6e\n", POWER((double) MAXP)); 
             fprintf(stderr,"The parse generated by the MPD is:\n"); 
             ShowMPD_OfDF(MPDPtr->MPD_PtrL, true, true);
             PRS(".\n");
             /* fprintf(stderr,"\n%d\n", MPDPtr->num_of_roots_in_der); */
             /*
             fprintf(stderr,"\n%s\n", TName(MPDPtr->LM_Word));
             fprintf(stderr,"\n%s\n", TName(MPDPtr->RM_Word));
             printf("\n%d\n", MPDPtr->NumOfWords);
             */
            } 
      }
}

/*** The MAIN PRINTING FACILITY for DOPDIS and PARPAR *******/

void ShowMPD_OfPF(ParForest PF)
{if (PF != NULL) ShowMPD_OfPList(PF->Starts);
 else {/*PRS("(XXXnonOemptypf,[]).\n");*/ EXIT(NOPF);}
}
/*********************************************************************************************************/
/****************************************/
/****************************************/
/* Auxiliary Printing Facilities        */
/****************************************/
void ShowProbOfICP(ItemCPtr I)
{TreeCodeT i;
 DerFPtr MPDPtr ;
 ProbDomain SumP = SumNutralConst; 
 if (I==NULL) {printf("This tree has no derivations: prob 0\n");exit(1);}
 else
 if (I->RootsSize == 0) {printf("This tree has no roots: prob 0\n");
                         exit(1);}
 else {for (i=0; i < I->RootsSize; ++i)
         {MPDPtr = (DerFPtr) &(I->Roots[i]);
          SumP = SumProbs(SumP, MPDPtr->Sum_Prob);}
       PRB(SumP);
      }
}
void ShowProbOfItem(ItemTree I)
{if (I==NULL) printf("An empty tree has no probability\n");
 else ShowProbOfICP((ItemCPtr) I->DerForest);
}
/*************/
extern void EXITA(ERRORTYPE ERR, Boolean DOEXIT);

void ShowMPD_OfI(ItemTree I)
{ProbDomain MAXP ;
 ProbDomain MAXP2;
 DerFPtr MPDPtr, MPDPtr2;
 int i;
 ProbDomain SumP;
            void MPDSelect(void *I)
               {TreeCodeT i;
                Boolean First = false;
                ItemCPtr CP = ((ItemCPtr) ((ItemTree) I)->DerForest);
                if (CP != NULL)
                for (i=0; i < CP->RootsSize; ++i)
                  {
                   MAXP = MaxProbs((CP->Roots[i]).MPD_Prob, MAXP, &First);
                   if (First == true) {MPDPtr = (DerFPtr) &(CP->Roots[i]);
                                       First = false;}
                   SumP = SumProbs(SumP, (CP->Roots[i]).Sum_Prob);
                  }
               }
 MAXP = MaxNutralConst; 
 SumP = SumNutralConst; 
 MPDPtr = NULL; 
 if (I==NULL) {/* PRS("(XXXnoncfG,[]).\n") ; */ EXITA(NOCFG, false);}
 else {MPDSelect((void *) I);
      if (MPDPtr == NULL) {/* PRS("(XXXnonOemptydf,[]).\n");*/ EXITA(NODF, false);}
        else {PRS("\n");
             PRS("Tree Probability ");PRB(SumP);PRS("\n");
             PRS("MPD Prob: "); PRB(MPDPtr->MPD_Prob);PRS("\n");
             PRS("The parse generated by the MPD is:\n"); 
             ShowMPD_OfDF(MPDPtr, true, true);PRS(".\n");
            } 
      }
}
/****************/
extern int n;
void ShowProb_OfMPD(ItemTree I)
{ProbDomain MAXP ;
 ProbDomain MAXP2;
 DerFPtr MPDPtr, MPDPtr2;
 int i;
 ProbDomain SumP;
            void MPDSelect(void *I)
               {TreeCodeT i;
                Boolean First = false;
                ItemCPtr CP = ((ItemCPtr) ((ItemTree) I)->DerForest);
                if (CP != NULL)
                for (i=0; i < CP->RootsSize; ++i)
                  {MAXP = MaxProbs((CP->Roots[i]).MPD_Prob, MAXP, &First);
                   if (First == true) {MPDPtr = (DerFPtr) &(CP->Roots[i]);
                                       First = false;}
                   SumP = SumProbs(SumP, (CP->Roots[i]).Sum_Prob);
                  }
               }
 MAXP = MaxNutralConst; 
 SumP = SumNutralConst; 
 MPDPtr = NULL; 
 if (I==NULL) PRS("no derivation found") ;
 else {MPDSelect((void *) I);
      if (MPDPtr == NULL) PRS("no derivation found");
      else {PRS("root ");ShowProbs_OfDer(MPDPtr); 
            PRS(" length ");PRI(_sen_length);
             PRS(" Tree Probability ");PRB(SumP);PRS(" ");
             /* PRS(" MPD Probability ");PRB(MAXP);PRS(" "); */
             }
      }
}
/************/
/************/
/************/
/************/
/************/
/* Only roots of chunks are assumed to be marked as valid in order to use the following
   three procedures with MarkIfPV as the start procedure. These mark the items in the
   structure of a chunk, given its root, as valid. The root of a another chunk which is
   substituted under the current chunk can be met and is avoided to be entered (we assume
   bottom up evaluation of the chart and so these have been already marked */
void MarkPV(DerFPtr DF, Boolean *ChunkRoot)
{if (DF != NULL) 
  {DF->SelfItem->Valid = true;
   if ((*ChunkRoot == false) && (DF->SelfItem->PseudoValid == true)); /* Root of another chunk */
   else 
    {*ChunkRoot = false;
     MarkPV(DF->MPD_PtrL, ChunkRoot); MarkPV(DF->MPD_PtrR, ChunkRoot);
    }
  }
}
void MarkValidICP(ItemCPtr ICP)
{int i; Boolean ChunkRoot;
 if (ICP == NULL) ;
 else
 if (ICP->RootsSize == 0);
 else for (i=0; i< ICP->RootsSize; ++i) 
       {ChunkRoot = true; MarkPV((DerFPtr) &(ICP->Roots[i]), &ChunkRoot);}
}
void MarkIfPV(ItemTree item)
{ItemCPtr CP = ((ItemCPtr) item->DerForest); 
 if (item->RT == _Term) item->Valid = true;
 else if (item->PseudoValid == true) MarkValidICP(CP);
} 
/**************/
void FreeICPOf(ItemTree item)
{ItemCPtr CP = ((ItemCPtr) item->DerForest); 
 if (CP != NULL) {FreeICPtr(CP); item->DerForest = (void *) NULL;}
}
/************/
/*
   This function assumes that the derivation forest is reduced.
   So RedDerForest is assumed to be true in globals.c
  
   Mark all and only items of parses containing chunks as Valid. Since the 
   parses are already marked Valid or not Valid, we have to mark all
   items unvalid first. An item is marked valid iff:
     1. it's lhs is the root of a chunk
     2. the item is AddedBy a valid item or has as left/right sister a
        valid item.
   also:
     3. all items within a chunk are also valid

   ALSO FREE THE WHOLE DERIVATION FOREST FULLY !!!!!!!!!!!!!!!!!!!!
 
***/
void MarkVByChunks(TableType TAB, int length)
{int i,j,k; EntryPtr EPtr;
  void MarkIf(ItemTree item)
   {int r; Boolean RChValid; ItemCPtr CP = ((ItemCPtr) item->DerForest); 
       void IsErValid(void *I)
         {if (((ItemTree) I)->Valid == true) 
            {item->Valid = true; RChValid = true;}
         }
       void MarkAlsoV(void *I)
         {((ItemTree) I)->Valid = true;}
       void IsErValidD(void *ID, PtrList List)
         {RChValid = false;
          if (((ItemTree) ID)->Valid == true) 
           {item->Valid = true; PListMap(List, (void *) &MarkAlsoV);}
          else {PListMap(List, (void *) &IsErValid);
                if (RChValid == true) ((ItemTree) ID)->Valid = true; 
               }
         }

    item->Valid = false;
    if (CP != NULL) 
     {switch (item->RT) {
        case _Term  : break;
        case _Unary : if (CP->RootsSize > 0) {item->Valid = true; item->PseudoValid = true;}
                     else MapAddedBy(item, (void *) &IsErValid); 
              break;
        case _Binary: if (CP->RootsSize > 0) {item->Valid = true; item->PseudoValid = true;}
                     else if (item->Dot == rm) MapDAddedBy(item, (void *) &IsErValidD);
                          else MapAddedBy(item, (void *) &IsErValid); 
               break;
        otherwise  : fprintf(stderr, "%s\n", "RType is impossible");exit(1); break;
      } /* switch */
    }
   }

 if (RedDerForest == false) 
   {fprintf(stderr,"%s\n", "First set RedDerForest in globals.c to true...");exit(1);}
  /* Mark on top of chunks */
 PRS("MarkingTop\n");
 for (k=1;k<=length;++k)
  for (i=k;i<=length;++i)
    {EPtr = ENTRY_Of(TAB, i-k, i); SetsMap(*EPtr, (void *) &MarkIf);}
  /* Mark all pieces of the chunks */
 PRS("MarkingDown\n");
 for (k=1;k<=length;++k)
  for (i=k;i<=length;++i)
    {EPtr = ENTRY_Of(TAB, i-k, i); SetsMap(*EPtr, (void *) &MarkIfPV);}
  /* Freeing previous derivation forest */
 PRS("Freeing\n");
 for (k=1;k<=length;++k)
  for (i=k;i<=length;++i)
    {EPtr = ENTRY_Of(TAB, i-k, i); SetsMap(*EPtr, (void *) &FreeICPOf);}
}
/****/
/************/
/************/
/* THE RIGHT LINEAR CORNER ....THE RIGHT LINEAR CORNER...THE RIGHT LINEAR CORNER ****/
/* THE RIGHT LINEAR CORNER ....THE RIGHT LINEAR CORNER...THE RIGHT LINEAR CORNER ****/
/* THE RIGHT LINEAR CORNER ....THE RIGHT LINEAR CORNER...THE RIGHT LINEAR CORNER ****/
/************/
/************/
/************/
/************/
/* The Right Linear corner 
extern void InitRLTables();
extern char * HeadOfSkel(char *Skel);
extern void MapOnSkelsOf(char *NT, void (*fp)());

void PrntHeadOf(char *Skel)
{PRS(HeadOfSkel(Skel));
}
*/
extern Boolean _OutNoContext;
extern Boolean _FullSenRec;
void ShowAllStartItems(TableType TAB, int n)
{int i,j,k; EntryPtr EPtr;
  void FI_CrList(ItemTree item)
   {Rule_Ptr RPtr = RulePtr_Of(item->RuleNo, item->RT);
       NTDomain NONT = LHS_Of(RPtr);

    if ((NONT == StartNonterminal) && (IsEnded_Item(item) == true))
     {if ((_FullSenRec != true) && (k>=5) && (_OutNoContext== false))
           {PRI(i+3);PRS(" "); PRI(i+k-1); PRS(" ");}
      else if (_OutNoContext == false) {PRI(i+1);PRS(" ");PRI((i+k+1));PRS(" ");}
           else {PRI(i+1);PRS(" "); PRI(i+k-3); PRS(" ");}
      PRHS1(item);PRS("\n");
     }
     
   }

 for (i=0;i<n;i++)
  for (k=1;k<=(n-i);k++)
    {EPtr = ENTRY_Of(TAB, i, i+k); SetsMap(*EPtr, (void *) &FI_CrList);}
 PRS(".\n");
}
/*******************/
extern Boolean _TestFull(int j, int length);
void PrintLimits(ItemTree item)
{LevDomain length; LevDomain CuLev2; ItemTree MotherI;

 void Recursive(ItemTree item, LevDomain Lev)
 {void UVMap(void *P)
   {Recursive((ItemTree) P, Lev);}
  void BVMap(void *P)
   {Recursive((ItemTree) P, (Lev+1));
   }
  void VDMap(void *P, void *List)
   {LevDomain k = ((ItemTree) P)->j;
    if (Lev == 2) CuLev2 = k+1;
    PListMap((PtrList) List, (void *) &BVMap); 
    MapAddedBy(((ItemTree) P), (void *) &UVMap);
   }

  switch (item->RT) {
  case _Term  : length = ((Lev >= length) ? Lev : length);
               if (Lev == (length -2)) 
                 {PRI(CuLev2);PRI(((int) item->j)+1);PRS(" ");PRHS1(MotherI);PRS("\n");}
                /*
               if ((Lev <= (length -2)) && (Lev >= 2))
                 {PRI((int) Lev-2);PRS(":");PRI(((int) item->j)+ 1); PRS(", ");}
               if (Lev == 2) {PRHS1(MotherI); PRS("\n");}
                */
              break;
  case _Unary : MapAddedBy(item, (void *) &UVMap); /* only for strtname->Ni */
              break;
  case _Binary: MapDAddedBy(item, (void *) &VDMap); 
               break;
  otherwise  : fprintf(stderr, "%s\n", "RType is impossible");exit(1); break;
  } /* switch */
 }
 length=0; MotherI = item;
 Recursive(item, 1);
}

void ShowAllStartItemsWG(TableType TAB, int n)
{int i,j,k; EntryPtr EPtr;

  void FI_CrList(ItemTree item)
   {Rule_Ptr RPtr = RulePtr_Of(item->RuleNo, item->RT);
    NTDomain NONT = LHS_Of(RPtr);
     if ((NONT == StartNonterminal) && (IsEnded_Item(item) == true)) 
      if ((_FullSenRec == false) || (_OutNoContext == true))
        {PrintLimits(item);}
      else {PRI(i+1);PRS(" ");PRI(i+k+1);PRS(" "); PRHS1(item);PRS("\n");}
   }

  for (i=0;i<n;i++)
   for (k=1;k<=(n-i);k++)
     if ((_TestFull(i+k, n)) == true) 
      {EPtr = ENTRY_Of(TAB, i, i+k); SetsMap(*EPtr, (void *) &FI_CrList);}
 PRS(".\n");
}
/************************************/
/************************************
        {PRI(lp+1);PRS(" "); PRI(rp+1); PRS(" ");
        }
      else * FullSenRec == true *
           if (_OutNoContext == false)  
           else {PRI(lp+1);PRS(" "); PRI(rp+1); PRS(" ");}
*******/
void PRNTTERM(ItemTree item)
{char TEMP[SymLength]; Rule_Ptr RPtr; int lhs, rhs1, rhs2;
 RPtr = RulePtr_Of(item->RuleNo, item->RT);
 rhs1 = RHS1_Of(RPtr);  
 
 strcpy(TEMP,item->Transition->Rule); TEMP[strlen(item->Transition->Rule)-1]='\0';
 if (strstr((TName(rhs1)), UNKNOWNSYMwo) != NULL)
   {PRS("XXXUNKNOWN"); /* PRS(OriginalWord(item->i, item->j));*/ PRS(TEMP);}
 else {/* PRS(OriginalWord(item->i, item->j)); */ PRS(TEMP);}
}
/***/
