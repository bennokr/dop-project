#include "Universals.h"
#include "Aux.h"
#include "DefsGrammar.h"   
#include "parameters.h"

extern Boolean ErIsUnknownW; 
/*********************************************************************************************************************/
/*             GENERAL-PRUNING PARAMETERS                                                                            */
/*                                                                                                                   */
/*********************************************************************************************************************/
/* (1) FIXED BEAM-WIDTH prunding */
#define _BEAM_WIDTH      ((_sen_length > 20) ? 30 : ((_sen_length > 10) ? 30 : 30))
#define _BEAM_WIDTH_SMALL_SPAN(span)  ((_sen_length > 10) ? 30 : 30)

/*********************************************************************************************************************/
/* (2) VARIABLE BEAM: pruning by thresholding                                                                        */
/* NOTE every ratio X is expressed as log10(X)                                                                       */
/*                                                                                                                   */
/* RATIOS for SINGLE-grammars or for FIRST PCFG phase in double grammar parsers */
#define _ROOT_P_RATIO_FST \
((_sen_length > 60) ? ((ProbDomain) 2.10) : ((_sen_length > 45) ? ((ProbDomain) 2.40) : ((_sen_length > 35) ? ((ProbDomain) 3.0) : ((_sen_length > 25) ? ((ProbDomain) 3.5) : ((_sen_length > 20) ? (ProbDomain) 3.8 : (ProbDomain) 3.0)) )))

#define _INTERN_P_RATIO_FST \
( (_sen_length > 60) ? ((ProbDomain) 2.20) : ((_sen_length > 45) ? ((ProbDomain) 2.60) : ((_sen_length > 35) ? ((ProbDomain) 3.2) : ((_sen_length > 25) ? ((ProbDomain) 3.7) : ((_sen_length > 20) ? (ProbDomain) 4.0 : (ProbDomain) 3.0)) )))

/******************************************************************************************/
/******* NOT NECESSARY TO SET UNLESS USING A TWO GRAMMAR SYSTEM **************************/
                                    /* RATIOS for SECOND-PHASE in DOUBLE-grammar parsers */
#define SECOND_ROOT_NODES_PRUNE_RATIO \
   ((_sen_length > 37) ? ((ProbDomain) 2.0) : ((_sen_length > 30) ? ((ProbDomain) 2.0) : ((_sen_length > 25) ? ((ProbDomain) 2.2) : ((_sen_length > 20) ? ((ProbDomain) 2.4) : ((_sen_length > 15) ? ((ProbDomain) 2.7) : (ProbDomain) 3.0)) )))
#define SECOND_INTERN_NODES_PRUNE_RATIO\
   ((_sen_length > 37) ? ((ProbDomain) 2.2) : ((_sen_length > 30) ? ((ProbDomain) 2.3) : ( (_sen_length > 20) ? ((ProbDomain) 2.4) : ((_sen_length > 15) ? ((ProbDomain) 2.9) : (ProbDomain) 3.2)) ))
/******************************************************************************************/
/* NOT NECESSARY TO SET UNLESS USING GLOBAL-THRESHOLDING: current system is NOT using it  */
#define  GT_R_PRUNE_RATIO \
     ((_sen_length > 30) ? ((ProbDomain) 3.5) : ((_sen_length > 25) ? ((ProbDomain) 4.2) : ((_sen_length > 20) ? (ProbDomain) 4.5 : (ProbDomain) 4)) )
#define  GT_O_PRUNE_RATIO \
     ((_sen_length > 30) ? ((ProbDomain) 3.5) : ((_sen_length > 25) ? ((ProbDomain) 4.2) : ((_sen_length > 20) ? (ProbDomain) 4.5 : (ProbDomain) 4)) )

/***********************************************************************/
/* RATIO for ROOT nodes of subtrees (fragments)  */
#define FIRST_ROOT_NODES_PRUNE_RATIO        _ROOT_P_RATIO_FST
/* RATIO for internal-nodes of subtrees (fragments) */
#define FIRST_INTERN_NODES_PRUNE_RATIO      _INTERN_P_RATIO_FST
/*********************************************************************************************************************/
/*             BIGRAM-TAGGING (PRUNING) PARAMETERS                                                                   */
/*                                                                                                                   */
/*********************************************************************************************************************/
/* MAJOR BIGRAM-TAGGING (PRUNING) PARAMETERS                                                                         */
#define LEFT_TAGGING_WINDOW_SIZE   2
#define RIGHT_TAGGING_WINDOW_SIZE  2
/** At what ratio to stop bigram-pruning **/
#define _LOWER_BOUND_ON_RATIO      ((_sen_length > 60) ? 1.00 : ( (_sen_length > 30) ?  ((ProbDomain) 1.00) : ((ProbDomain) 1.00) ))
/* */
/* MINOR BIGRAM-TAGGING (PRUNING) PARAMETERS                                                                       */
/** parameters that determine: the start ratios for bigram-pruning and the step-size (DELTA) per cycle of pruning **/
/*  Larger values for the first two parameters slow pruning, larger values for the third speed pruning            **/
/*  Extremely ambiguous words as well as unknown words start pruning with a lower ratio to speed-up pruning       **/
#define _USUAL_WORDS_START_PRUNING_RATIO       ((ProbDomain) 2.80)
#define _UNKNOWNS_WORDS_START_PRUNING_RATIO    ((ProbDomain) 2.10)
#define _DELTA_RATIO                           ((ProbDomain) 0.20)
#define _LOWERBOUND_LARGE_ENTRY_SIZE           1

/***************************** END OF PARAMETERS **  END OF PARAMETERS **********************************************/
/*
**
**
**
**                                THE FOLLOWING SECTION IS SUPPOSED TO BE INTERNAL !!!!!!
**
**
**
*/
/********************************************************************************************************************/
/** The following initialization function should not be touched !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
/********************************************************************************************************************/
int V_BEAM_WIDTH_SMALL_SPAN(int span)
{return _BEAM_WIDTH_SMALL_SPAN(span);
}
void Init_pruning_parameters()
{
/*   initialization of bigram-tagging (pruning) parameters */
 L_WINDOW             = LEFT_TAGGING_WINDOW_SIZE;
 R_WINDOW             = RIGHT_TAGGING_WINDOW_SIZE;
_STEP_RATIO           = _DELTA_RATIO;
_BI_RATIO             = _USUAL_WORDS_START_PRUNING_RATIO;
_BI_RATIO_UNKNOWNS    = _UNKNOWNS_WORDS_START_PRUNING_RATIO;
_LB_LARGE_ENTRY_SIZE  = _LOWERBOUND_LARGE_ENTRY_SIZE;
_LB_RATIO             = _LOWER_BOUND_ON_RATIO;
/* initialization of pruning parameters                   */
 R_PRUNE_RATIO = FIRST_ROOT_NODES_PRUNE_RATIO;
 O_PRUNE_RATIO = FIRST_INTERN_NODES_PRUNE_RATIO;
 Second_R_PRUNE_RATIO = SECOND_ROOT_NODES_PRUNE_RATIO;
 Second_O_PRUNE_RATIO = SECOND_INTERN_NODES_PRUNE_RATIO;
 R_PRUNE_RATIO_GT = GT_R_PRUNE_RATIO;
 O_PRUNE_RATIO_GT = GT_O_PRUNE_RATIO;
 V_BEAM_WIDTH = _BEAM_WIDTH;
}
