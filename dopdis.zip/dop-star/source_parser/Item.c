#include "ALL.h"

#define _FREE_ADDED_BY_LISTS  false

extern Boolean NonEmptyRootsICPtr(ItemCPtr ICP);

/*** The items side of the entry is dealed with in the following part */
ItemTree CpyItem(ItemTree I)
{ItemTree Res;
 Res = FillItem(I->RuleNo, I->RT, I->Dot);
 Res->Level = I->Level;
 Res->FORWARD_P = I->FORWARD_P;
 Res->FWD_BKWD_P = I->FWD_BKWD_P;
 Res->RMaxPruneProbOfDer= I->RMaxPruneProbOfDer;
 Res->OMaxPruneProbOfDer= I->OMaxPruneProbOfDer;
 Res->RInsideProb=I->RInsideProb;
 Res->IN_X_OUT = I->IN_X_OUT;
 Res->MAX_GRR_PROB = I->MAX_GRR_PROB;
 return Res;
}
inline
ItemTree CpyItemFully(ItemTree I)
{ItemTree Result = CpyItem(I);
 Result->i = I->i; Result->j = I->j;
 Result->Transition = I->Transition;
 Result->Level = I->Level;
 Result->FORWARD_P = I->FORWARD_P;
 Result->FWD_BKWD_P = I->FWD_BKWD_P;
 Result->RMaxPruneProbOfDer= I->RMaxPruneProbOfDer;
 Result->OMaxPruneProbOfDer= I->OMaxPruneProbOfDer;
 Result->RInsideProb=I->RInsideProb;
 Result->IN_X_OUT = I->IN_X_OUT;
 Result->MAX_GRR_PROB = I->MAX_GRR_PROB;

 return Result;
}
inline
void CpyRestOfItem(ItemTree target, ItemTree source)
{target->i = source->i; target->j = source->j;
 target->Transition = source->Transition;
 target->Level = source->Level;
 target->FORWARD_P = source->FORWARD_P;
 target->FWD_BKWD_P = source->FWD_BKWD_P;
 target->RMaxPruneProbOfDer= source->RMaxPruneProbOfDer;
 target->OMaxPruneProbOfDer= source->OMaxPruneProbOfDer;
 target->RInsideProb=source->RInsideProb;
 target->IN_X_OUT = source->IN_X_OUT;
 target->MAX_GRR_PROB = source->MAX_GRR_PROB;

}
inline
ItemTree UpdateItem(ItemTree IDL, RDomain Rno, RType RT, DOTPLACE dot)
{IDL->RT = RT;
 IDL->RuleNo = Rno; IDL->Dot = dot; 
 /* ZZZ IDL->Right = (ItemTree) NULL; IDL->Left = (ItemTree) NULL; */ /* IDL->Adds = NULL;*/
 IDL->AddedBy = NULL; IDL->AddedByMaxGRR = NULL; 
 IDL->Valid = false; IDL->PseudoValid = false; IDL->Touched = false;
 IDL->Level = 0; IDL->DerForest = NULL; IDL->i = 0; IDL->j = 0;
 IDL->Transition = NULL; IDL->Num_OfParses = 0; 
 IDL->FORWARD_P = MaxNutralConst; IDL->FWD_BKWD_P = MaxNutralConst;
 IDL->RMaxPruneProbOfDer= MaxNutralConst; IDL->OMaxPruneProbOfDer= MaxNutralConst;
 IDL->RInsideProb= MaxNutralConst; IDL->IN_X_OUT = MaxNutralConst; IDL->MAX_GRR_PROB = MaxNutralConst;
 IDL->OldRNum = UNVALID_RNUM;

 return IDL;
}
ItemTree FillItem(RDomain Rno, RType RT, DOTPLACE dot)
{ItemTree IDL = (ItemTree) AllocElem(sizeof(struct ITEMS));
 IDL->RT = RT;
 IDL->RuleNo = Rno; IDL->Dot = dot; 
 /* ZZZ IDL->Right = (ItemTree) NULL; IDL->Left = (ItemTree) NULL; */ /* IDL->Adds = NULL;*/
 IDL->AddedBy = NULL; IDL->AddedByMaxGRR = NULL; 
 IDL->Valid = false; IDL->PseudoValid = false; IDL->Touched = false;
 IDL->Level = 0; IDL->DerForest = NULL; IDL->i = 0; IDL->j = 0;
 IDL->Transition = NULL; IDL->Num_OfParses = 0; 
 IDL->FORWARD_P = MaxNutralConst; IDL->FWD_BKWD_P = MaxNutralConst;
 IDL->RMaxPruneProbOfDer= MaxNutralConst; IDL->OMaxPruneProbOfDer= MaxNutralConst;
 IDL->RInsideProb= MaxNutralConst; IDL->IN_X_OUT = MaxNutralConst; IDL->MAX_GRR_PROB = MaxNutralConst;
 IDL->OldRNum = UNVALID_RNUM;

 return IDL;
}
ItemTree XFillItem(RDomain Rno, RType RT, DOTPLACE dot, WordList trans)
{ItemTree I=FillItem(Rno, RT, dot);
 I->Transition= (WordList) trans;
 return I;
}
/******************************************/
void PTreeItem(RDomain Rno, RType RT, DOTPLACE dot, ItemTree left, ItemTree right)
{PRS("<");PRI(Rno); PRI(dot); PRI(RT);PRS(">"); }

void AppToItem(ItemTree item, void (* fp)())
{if (item == NULL) ; /* printf("Err: item is NULL\n");*/
 else {(* fp)(item->RuleNo, item->RT, item->Dot); }
}


void PItem(ItemTree item)
{ /* PRI(item->Level);*/
 if (item->Level >= 0 ) {
 PRS("["); PRI(item->i);PRI(item->j); PRS("] ");
 AppToItem(item, (void *) &ShowItem); 
 /* PRS(" ");PRI(item->Level); PRS("<");PRI(item->i);PRS(",");PRI(item->j);PRS(">");
  if (item->DerForest == NULL) PRS("NULL"); else PRS("VVV"); PRS("\n");
  if (item->Valid == true) PRS("   valid\n"); else PRS("    UNVALID\n");*/
 }
}

void fPItem(ItemTree item, FILE *file)
{Rule_Ptr RPtr; NTDomain lhs, rhs1, rhs2;
 RPtr = RulePtr_Of(item->RuleNo, item->RT); lhs = LHS_Of(RPtr); rhs1 = RHS1_Of(RPtr); rhs2 = RHS2_Of(RPtr);
 /* G_Array = NTArray; */
 
 fprintf(file, "<%s ->",Name(lhs)); if (item->Dot==lm) fprintf(file, "*");
 if (item->RT == _Term) {fprintf(file, "%s",TName(rhs1)); if (item->Dot==mid) fprintf(file, "*"); }
 else {fprintf(file, "%s",Name(rhs1)); if (item->Dot==mid) fprintf(file, "*");
       if (item->RT == _Binary) {fprintf(file, " %s", Name(rhs2));  if (item->Dot==rm) fprintf(file, "*");}
      }
 fprintf(file,">");
}
void POldItem(ItemTree item)
{RDomain Temp;
 Temp = item->RuleNo;
 item->RuleNo = item->OldRNum; PItem(item); 
 item->RuleNo = Temp;
}

void VPItem(void *item)
{ItemTree it = (ItemTree) item;
 PRI(it->Level);
 AppToItem(it, (void *) &ShowItem);
}

inline
void IVPItem(void *J)
{if (J == NULL) PRS("NONE\n");
 else VPItem(J);
}
inline
Boolean NonEmptyDerForest(ItemTree I)
{if (I == NULL) return false;
 else return (NonEmptyICPtr(((ItemCPtr) I->DerForest)));
}
inline
Boolean NonEmptyRootsDerForest(ItemTree I)
{if (I == NULL) return false;
 else return (NonEmptyRootsICPtr(((ItemCPtr) I->DerForest)));
}

inline
Boolean EqItem(ItemTree item1, ItemTree item2)
{Boolean B1, B2, B3;
 if ((item1 == NULL) || (item2 == NULL)) return false;
 else {B1 = (item1->RuleNo == item2->RuleNo) ? true: false ; 
       B2 = ((item1->RT == _Eps) && (item2->RT == _Eps)) ?
                                    true: (item1->Dot == item2->Dot); 
       B3 = (item1->RT == item2->RT); 
       return (((B1==true) && (B2==true) && (B3==true)) ? true : false);
      }
}           
inline
Boolean GrItem(ItemTree item1, ItemTree item2)
{if ((item1 == NULL) || (item2 == NULL)) return false;
 else if (item1->RuleNo > item2->RuleNo) return true;
      else if (item1->RuleNo == item2->RuleNo) 
              if (item1->RT > item2->RT) return true;
              else if ((item1->RT == item2->RT) && (item1->RT != _Eps))
                      if (item1->Dot > item2->Dot) return true;
                      else return false;
                   else return false;
           else return false;
}
inline
Boolean LeItem(ItemTree item1, ItemTree item2)
{if ((item1 == NULL) || (item2 == NULL)) return false;
 else if (item1->RuleNo < item2->RuleNo) return true;
      else if (item1->RuleNo == item2->RuleNo) 
              if (item1->RT < item2->RT) return true;
              else if ((item1->RT == item2->RT) && (item1->RT != _Eps))
                      if (item1->Dot < item2->Dot) return true;
                      else return false;
                   else return false;
           else return false;
}
inline
Boolean GeqItem(ItemTree item1, ItemTree item2)
{return ((GrItem(item1, item2)) || (EqItem(item1, item2)));}
inline
Boolean LeqItem(ItemTree item1, ItemTree item2)
{return ((LeItem(item1, item2)) || (EqItem(item1, item2)));}

inline
void VEqItems(void *PtrA, void *PtrB, Boolean *EQ)
{ItemTree A = (ItemTree) PtrA;
 ItemTree B = (ItemTree) PtrB;
 /* *EQ = EqItem(A, B); */
 *EQ = (A == B) ? true: false;
}
/****/
inline
Boolean EndedItem(ItemTree item)
{ if (item != NULL)
           {RType RT = item->RT; DOTPLACE dot = item->Dot;
            switch (RT) {
              case _Eps: return true;break;
              case _Term : if (dot == mid) return true;
                          else {fprintf(stderr, "Err: Item has wrong dot !!\n"); exit(1); }
                          break;
              case _Unary: if (dot == mid) return true;
                          else {fprintf(stderr, "Err: Item has wrong dot !!\n"); exit(1); }
                          break;
              case _Binary: if (dot == rm) return true;
                           else if (dot == mid) return false;
                                else {fprintf(stderr, "Err: Item has wrong dot !!\n"); exit(1); }
                           break;
               otherwise : return false; break;
            }/* switch*/
           }
  else return false;
  return false;
}
inline
Boolean GoodItem(ItemTree item)
{Boolean result;
  if (item != NULL)
           {RType RT = item->RT; DOTPLACE dot = item->Dot;
            switch (RT) {
              case _Eps: result = true;break;
              case _Term : if ((dot == mid) && (item->RuleNo >= 0) && (item->RuleNo < TRSize)) result = true;
                          else {fprintf(stderr, "Err: wrong item !!\n"); exit(1); }
                          break;
              case _Unary: if ((dot == mid) && (item->RuleNo >= 0) && (item->RuleNo < URSize)) result = true;
                          else {fprintf(stderr, "Err: wrong item !!\n"); exit(1); }
                          break;
              case _Binary: if (((dot == rm) || (dot == mid)) && 
                                (item->RuleNo >= 0) && (item->RuleNo < BRSize)) result = true;
                            else {fprintf(stderr, "Err: wrong item !!\n"); exit(1); }
                           break;
               otherwise : result = false; break;
            }
           }
  else result = true;
 if (result == false) { fprintf(stderr,"Err: wrong item !!\n");exit(1);}
 return result;
}
/***********************/
inline
NTDomain LHS_OfItem(ItemTree I)
{return (LHS_OfR(I->RuleNo, I->RT));}
inline
NTDomain RHS1_OfItem(ItemTree I)
{return (RHS1_OfR(I->RuleNo, I->RT));}
inline
NTDomain RHS2_OfItem(ItemTree I)
{return (RHS2_OfR(I->RuleNo, I->RT));}

/* is the item ssss->X or sss->X ?: we assume here that there is only one start rule ssss->sss in grammar */
static NTDomain NT_NUMof_sss = UNVALID_SYMNUM;
static NTDomain NT_NUMof_ssss = UNVALID_SYMNUM;

Boolean StartSymbolsItem(ItemTree I)
{Boolean RESULT = false; int num = 0;
 void ApplyToRnumOf(RDomain Rnum)
    {if (RHS1_OfR(Rnum, _Unary) != _NumOfPriorSym) /* not ssss->xxxprior */
      {if (NT_NUMof_ssss == UNVALID_SYMNUM) NT_NUMof_ssss = LHS_OfR(Rnum, _Unary); /* initializing */
       if (NT_NUMof_sss == UNVALID_SYMNUM)  NT_NUMof_sss  = RHS1_OfR(Rnum, _Unary);/*initializing  */
     
       if ( (LHS_OfItem(I) == NT_NUMof_ssss) /* || (LHS_OfItem(I) == NT_NUMof_sss) */ ) RESULT = true;
       num++; if (num > 1) {fprintf(stderr,"Err: too many start-items in StartSymbolsItem\n"); exit(1);}/* are things ok*/
      }
    }

 if (I == NULL) return false;
 MapOn_Rules_Of(NT_Ptr_Of(StartNonterminal, LHS_), _Unary, (void *) &ApplyToRnumOf);
 return RESULT;
}
/************************/
/************************/
void FreeAddedByOf(ItemTree I)
{if (_FREE_ADDED_BY_LISTS == true)
  if (I != NULL) 
  {if ((I->Dot == rm) && (I->RT == _Binary)) FreePDList(I->AddedBy);
   else FreePListN(I->AddedBy); 
   I->AddedBy = NULL;
  }
}
ItemTree FreeInsideItem(ItemTree I)
{if (I == NULL) return NULL;
 else {if (_FREE_ADDED_BY_LISTS == true)
       if ((I->Dot == rm) && (I->RT == _Binary)) FreePDList(I->AddedBy);
       else FreePListN(I->AddedBy); I->AddedBy = NULL;
       FreeICPtr((ItemCPtr) I->DerForest); I->DerForest = NULL;
       return I;
      }
}
ItemTree FreeItemNotDF(ItemTree I)
{if (I == NULL) return NULL;
 else {if (_FREE_ADDED_BY_LISTS == true)
       if ((I->Dot == rm) && (I->RT == _Binary)) FreePDList(I->AddedBy);
       else FreePListN(I->AddedBy); I->AddedBy = NULL;
       cfree(I); return NULL;
      }
}
ItemTree FreeItem(ItemTree I)
{if (I == NULL) return NULL;
 else {I = FreeInsideItem(I); cfree(I); return NULL;}
}
ItemTree FreeItemEmptyDF(ItemTree I)
{if (NonEmptyDerForest(I) == false) return FreeInsideItem(I);
 else return I;
}
ItemTree TotFreeIifEmpDF(ItemTree I)
{PRS("xxx\n");
 if (NonEmptyDerForest(I) == false) {return FreeItem(I);}
 else return I;
}
/*-----*/
ItemTree FreeUnVItem(ItemTree I)
{if (I == NULL) return NULL;
 else if (I->Valid == false) return (FreeItem(I));
      else return I;
}
void FreeDerForestOfItem(ItemTree I)
{if (I != NULL) FreeICPtr((ItemCPtr) I->DerForest);}   
/*******************/
inline
char *TerminalOf(ItemTree item)
{Rule_Ptr RPtr; NTDomain rhs1; int TotLength = 0;
 if (item->RT != _Term) {fprintf(stderr, "Err: TerminalOf !!\n"); exit(1);}
 RPtr = RulePtr_Of(item->RuleNo, item->RT); rhs1 = RHS1_Of(RPtr);
 if (!strcmp((TName(rhs1)), UNKNOWNSYM))
   return "UNKNOWN";
 else return (TName(rhs1));
}

/*-------------------------*/
inline
char  *PartOfItem(ItemTree I, SYM_LOC  LOC)
{if (I == NULL) return NULL;

 switch (LOC) {
   case LHS_  : return (Name(LHS_OfItem(I)));
               break;
   case RHS_1 : if (I->RT == _Term) return TerminalOf(I); 
                else return (Name(RHS1_OfItem(I)));
               break;
   case RHS_2 : if (I->RT != _Binary) return NULL;
               return (Name(RHS2_OfItem(I)));
               break;
 }
 fprintf(stderr,"LOC has wrong value in PartOfItem\n"); exit(1);
}
/*---------------------------*/
extern TreeCodeT RootsSizeOfDF(ItemCPtr IC);
extern TreeCodeT OthersSizeOfDF(ItemCPtr IC);

inline
TreeCodeT DFSizeOfItem(ItemTree I, Code_Soort CT)
{if (I == NULL) return 0;
 switch (CT) {
   case ROOT_enum: return RootsSizeOfDF((ItemCPtr) I->DerForest); break;
   case OTHERS_enum: return OthersSizeOfDF((ItemCPtr) I->DerForest); break;
 }
 fprintf(stderr,"CT has wrong value in DFSizeOfItem\n"); exit(1);
}

/* assumes both items are not NULL */
inline
Boolean Same_Entry_Items(ItemTree I1, ItemTree I2)
{if ((I1->i == I2->i) && (I1->j == I2->j)) return true;
 else return false;
}
/*----------------------------------*/
inline
TDomain GetTerminalOfItemIfAny(ItemTree I)
{if (I->RT != _Term) return UNVALID_SYMNUM;
 else {Rule_Ptr RPtr = RulePtr_Of(I->RuleNo, I->RT); NTDomain rhs1 = RHS1_Of(RPtr);
       if (!strcmp((TName(rhs1)), UNKNOWNSYM)) return UNVALID_SYMNUM;
       else return rhs1;
      }
}
/******************************/
inline ItemTree ObtainMaxLevelItem(PtrList PL)
{ItemTree res; PtrList this = NULL ; LevDomain Max = -1; 
 if (PL == NULL) return NULL;

 this = PL;
 res = (ItemTree) PL->Ptr;
 while (this !=NULL) {if (((ItemTree) this->Ptr)->Level > Max) res = (ItemTree) this->Ptr; this = this->Next;  }
 return res;
}
