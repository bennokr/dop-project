#include "./ALL.h"

/*********************************/

inline
ProbDomain Trans_2_log10(double A)
{return ((ProbDomain) log10(A));
}

/* All the following should become simply macros */
inline
void IsTooSmall(ProbDomain P)
{/*if ((P < ((ProbDomain) SumNutralConst))) {fprintf(stderr,"Err: Prob is too small\n");  exit(1);}*/
}
inline
Boolean IsZeroProb(ProbDomain P)
{if (P == SumNutralConst) return true;
 if (P == MaxNutralConst) return true;
 return false;
}
/***/
inline
Boolean EQUAL_Probs(ProbDomain A, ProbDomain B)
{if (((float) A) == ((float) B)) return true;
 else return false;
}
inline
ProbDomain ProbOf(CodePtr CP)
{ if ((IsRoot(CP)) == true) return ((ProbDomain) TheProbOf[CP->TreeC]);
  else return (MultNutralConst);
}
inline
ProbDomain MultProbs(ProbDomain P1, ProbDomain P2)
{if ((IsZeroProb(P1) == true) || (IsZeroProb(P2) == true)) return SumNutralConst; 
 else
 if (P1 == MultNutralConst) return P2;
 else if (P2 == MultNutralConst) return P1;
      else {return ((ProbDomain) (P1 + P2));}
}

inline
ProbDomain DevideProbs(ProbDomain P1, ProbDomain P2)
{if (P2 == MultNutralConst) return P1;
 else
  if (IsZeroProb(P1) == true) return SumNutralConst; 
  else if (IsZeroProb(P2) == true) {PRS("Err: deviding by zero\n"); exit(1);}
      else {return ((ProbDomain) (P1 - P2));}
}

inline
ProbDomain SumProbs(ProbDomain P1, ProbDomain P2)
{RealProbDomain A1;
 RealProbDomain A2;
 ProbDomain SUM;
 if (P1 == SumNutralConst) return P2;
 else if (P2 == SumNutralConst) return P1;
      else {A1 = (RealProbDomain) P1; A2 = (RealProbDomain) P2;
            A1 = (RealProbDomain) (POWER((double) A1));
            A2 = (RealProbDomain) (POWER((double) A2));
            SUM = ((ProbDomain) Trans_2_log10((double) (A1 + A2)));
            return ((ProbDomain) SUM);
           }
}
inline
ProbDomain SubtractProbs(ProbDomain P1, ProbDomain P2)
{RealProbDomain A1;
 RealProbDomain A2;
 ProbDomain SUM;
 if ((P1 == SumNutralConst) && (P2 == SumNutralConst)) return SumNutralConst;
 else
 if (P1 == SumNutralConst) {fprintf(stderr, "1Err: subtraction of probs is weird (%e  %e) log probs\n", P1, P2);exit(1);} 
 else if (P2 == SumNutralConst) return P1;
      else {A1 = (RealProbDomain) P1; A2 = (RealProbDomain) P2;
            A1 = (RealProbDomain) (POWER((double) A1));
            A2 = (RealProbDomain) (POWER((double) A2));
            if ((int) ((A1 - A2) < 0)) {fprintf(stderr, "Err: subtraction of probs leads to negative %e  %e\n", A1, A2);exit(1);}
            else {SUM = ((ProbDomain) (Trans_2_log10((double)(A1 - A2))));
                  return ((ProbDomain) SUM);}
           }
}
inline
ProbDomain MaxProbs(ProbDomain P1, ProbDomain P2, Boolean *First)
{ProbDomain MaxP;
 
 IsTooSmall(P1); IsTooSmall(P2);
 if (((P2 == MaxNutralConst) && (P1 == MaxNutralConst))) {*First = true; MaxP = P1;}
 else
 if ((P2 == MaxNutralConst)) {*First = true; MaxP = P1;}
 else if ((P1 == MaxNutralConst)) {*First = false; MaxP = P2;}
      else if ((P1 == P2)) 
            {/* if (((rand())%2)== 0) {MaxP = P1; *First = true;} else */ 
             {MaxP = P2; *First = false;}
            }
           else if ((P1 > P2)) { MaxP = P1; *First = true;}
                else { MaxP = P2; *First = false;}
 return MaxP;
}
/***************************/
inline
ProbDomain SumRsProbs(Rule_Apps RA)
{TreeCodeT i; ProbDomain sum = SumNutralConst;
 if (RA == NULL) return SumNutralConst;
 else if (RA->Roots_Size == 0) return SumNutralConst;
 else for (i=0; i < RA->Roots_Size; i++)
       sum = SumProbs(sum, (ProbOf(&(RA->Roots_Nodes[i].Code))));
 return sum;
}
/*---------------------------*/
inline
ProbDomain Prob_From_R(RDomain RuleNo, RType RT, C_Addr_Domain CAdr, Code_Soort CT)
{Rule_Apps RA = R_AppsOf(RuleNo, RT);
 NodePtr NP = NodePtrOf(CAdr, RA, CT);
 return ((ProbDomain) ProbOf(&(NP->Code)));
}
/*---------------------------*/
inline
ProbDomain CodeProbability(ItemTree IT, DerFPtr DFP, Code_Soort CT)
{ProbDomain P = MultNutralConst;
           /* for A->B*C the code probability is delayed until A->BC* */
 if ((IT->RT == _Binary) && (IT->Dot == mid)) P = MultNutralConst;
 else P = Prob_From_R(IT->RuleNo, IT->RT, DFP->CAdr, CT);
 return P;
}
/*---------------------------*/
inline
ProbDomain ProbOfWord(ItemTree I)
{if (I->RT == _Term)
  if (I->Transition != NULL) return ((ProbDomain) I->Transition->Probability);
  else return MultNutralConst;
 else {fprintf(stderr, "Err: Only terminal rule may have lexical probability\n");exit(1);}
}

/* In EBL, when pre-parsing then we don't want to take prob of transitions into account */
inline
ProbDomain ProbOfWordOrOne(ItemTree I)
{if (TakeProbOfTrans == true) {if (I->RT != _Term) PItem(I); return ((ProbDomain) ProbOfWord(I));}
 else return MultNutralConst;
}
/*-------------------------*/
inline
ProbDomain NthRootOf(ProbDomain P, short int N)
{
 if (N < 0) {fprintf(stderr,"Err: in NthRootOf\n"); exit(1);}
 if (N == 0) return P;
 if (P == SumNutralConst) return SumNutralConst;
 return ((ProbDomain) (P/((ProbDomain) N)));
}
