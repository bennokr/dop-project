#include "./ALL.h"
#include "UnknownWords.h"

Boolean _glob_allow_unk4all=true;

extern char *Name(NTDomain NTno);
extern char *TName(TDomain NTno);

/** the globals of a grammar */
  NTDomain StartNonterminal ;
  NTDomain NonTSize ;
  TDomain TermsSize ;
  RDomain TRSize  ;
  RDomain URSize  ;
  RDomain BRSize  ;
  RDomain EpsRSize  ;
  struct RuleStruct  *EpsRules;
  struct RuleStruct *TRules ;
  struct RuleStruct *URules ;
  struct RuleStruct *BRules ;
  struct NTStruct *NTArray ;
  struct NTStruct *Rhs1Array ;
  struct NTStruct *Rhs2Array ;
  struct TermStruct *TermsArray ;
  struct Place_Struct *T_R_Apps ;
  struct Place_Struct *B_R_Apps ;
  struct Place_Struct *Eps_R_Apps ;
  struct Place_Struct *U_R_Apps ;
  TreeCodeT TotalRootsNum ;
  ProbDomain *TheProbOf ;
  NTDomain _BIGRAM_SYM_NUM;                                                                                                                    
/********************************/
/* The type Terminals and its 
   operation on TermArray       */

inline Term_Ptr Term_Ptr_Of(TDomain TermNo)
{ if (TermNo > TermsSize) return NULL;
  else if (TermNo < 0) return NULL;
       else return (TermsArray + TermNo);
}
inline char *Term_Name_Of(Term_Ptr Ptr)
{if (Ptr == NULL) return NULL;
 else return Ptr->Term;
}
inline RDomain *T_Rules_Of(Term_Ptr Ptr)
{ if (Ptr == NULL) return NULL;
  else return Ptr->TRules;
}
inline RDomain T_R_Count_Of(Term_Ptr Ptr)
{ if (Ptr == NULL) return UNVALID_RNUM;
  else return Ptr->TCount;
}
inline void TMapOn_Rules_Of(Term_Ptr Ptr, void (* func)())
{RDomain i;
 RDomain *Rules;
 RDomain count = T_R_Count_Of(Ptr);

 if (Ptr != NULL) 
   {Rules = T_Rules_Of(Ptr);
    for (i=0; i < count; ++i) (*func)(Rules[i]);}
}
/******************************************************/

/**************************************************************************************/
/* Operations on the Nonterminals type. I.e. on the three arrays NT-, Rhs1- and 
   Rhs2Array.  G-Array is a global which must be set first to one of these three
   arrays before the use of any of the following functions.                           */
/*------------------------------------------------------------------------------------*/
inline NT_Ptr NT_Ptr_OfI(NTDomain NT)
{ if (NT > NonTSize) return NULL;
  else if (NT < 0) return NULL;
       else return (G_Array + NT);
}
inline
NT_Ptr NT_Ptr_Of(NTDomain NT, SYM_LOC loc)
{switch (loc) {
   case LHS_  : G_Array = NTArray; break;
   case RHS_1 : G_Array = Rhs1Array; break;
   case RHS_2 : G_Array = Rhs2Array; break;
 };
 return (NT_Ptr_OfI(NT));
}
/***********/
inline char *NT_Name_Of(NT_Ptr Ptr)
{if (Ptr == NULL) return NULL;
 else return Ptr->NT;
}
inline RDomain *Rules_Of(NT_Ptr Ptr, RType RT)
{if (Ptr == NULL) return NULL;
 else switch (RT) {
      case  _Unary : return (Ptr->URules);
               break;
      case _Binary : return (Ptr->BRules);
               break;
      case _Term   : return (Ptr->TRules);
               break;
      case _Eps    : return (Ptr->EpsRules);
               break;
      default : return NULL; break;
    }; /* switch */
}
inline RDomain R_Count_Of(NT_Ptr Ptr, RType RT)
{if (Ptr == NULL) return UNVALID_RNUM;
 else switch (RT) {
      case _Unary : return (Ptr->UCount);
               break;
      case _Binary : return (Ptr->BCount);
               break;
      case _Term   : return (Ptr->TCount);
               break;
      case _Eps   : return (Ptr->EpsCount);
               break;
      default : return UNVALID_RNUM; break;
    }; /* switch */
}
/*--------------*/
/*****************************/
inline char *Name(NTDomain NTno)
 {G_Array = NTArray;
 if (NTno != UNVALID_SYMNUM) return (NT_Name_Of(NT_Ptr_Of(NTno, LHS_)));else return UNVALID_SYM;}
inline char *TName(TDomain NTno)
 {if (NTno != UNVALID_SYMNUM) return (Term_Name_Of(Term_Ptr_Of(NTno)));else return UNVALID_SYM;}
inline void WRDot(DOTPLACE D, int n)
{if (D == n) PRS("*");}
/*************************/
/* Finding the serial number of a non-terminal */
int NONTCMP(e1, e2)
  const void *e1;
  const void *e2;
{int i;
 char *v1 = ((struct NTStruct *) e1)->NT;
 char *v2 = ((struct NTStruct *) e2)->NT;
 i = (strcmp(v1, v2));
 return (i);
}
inline
NTDomain NT_NUM_Of(char *NONT)
{extern Boolean ERROR;
 NT_Ptr HERE;
 struct NTStruct NTSt;
 NTSt.TRules = NULL; NTSt.TCount = 0;
 NTSt.EpsRules = NULL; NTSt.EpsCount = 0;
 NTSt.BRules = NULL; NTSt.BCount = 0;
 NTSt.URules = NULL; NTSt.UCount = 0;
 NTSt.NT = NONT;

 HERE = (NT_Ptr) bsearch((void *) &NTSt, (void *) &NTArray[0], (size_t) NonTSize, sizeof(struct NTStruct), NONTCMP); 
 if (HERE != NULL)
     return (NTDomain) (HERE - NTArray) ;
 else {return UNVALID_SYMNUM;}
}
/*******************************/

/**************************************************************************************/
/* Operations on Rules I.e.  operations on the arrays of rules.                       */
/*------------------------------------------------------------------------------------*/
/* returns Rule_Ptr or NULL        */
inline
Rule_Ptr RulePtr_Of(RDomain RNumber, RType RT)
{   switch (RT) {
      case _Unary : if ((RNumber >= URSize) || (RNumber < 0)) return NULL;
                   else return &URules[RNumber];
               break;
      case _Binary : if ((RNumber >= BRSize) || (RNumber < 0)) return NULL;
                    else return &BRules[RNumber];
               break;
      case _Term   : if ((RNumber >= TRSize) || (RNumber < 0)) return NULL;
                    else return &TRules[RNumber];
               break;
      case _Eps    : if ((RNumber >= EpsRSize) || (RNumber < 0)) return NULL;
                    else return &EpsRules[RNumber];
               break;
      default : return NULL; break;
    }; /* switch */
}
/*-----------------*/
inline
NTDomain LHS_Of(Rule_Ptr RPtr)
{if (RPtr == NULL) return UNVALID_SYMNUM;
 else return (RPtr->lhs);
}
inline
NTDomain RHS1_Of(Rule_Ptr RPtr)
{if (RPtr == NULL) return UNVALID_SYMNUM;
 else return (RPtr->rhs1);
}
inline
NTDomain RHS2_Of(Rule_Ptr RPtr)
{if (RPtr == NULL) return UNVALID_SYMNUM;
 else return (RPtr->rhs2);
}
/*-------------------*/
inline
NTDomain LHS_OfR(RDomain RNumber, RType RT)
{Rule_Ptr RPtr = RulePtr_Of(RNumber, RT);
 if (RPtr == NULL) return UNVALID_SYMNUM;
 else return (RPtr->lhs);
}
inline
NTDomain RHS1_OfR(RDomain RNumber, RType RT)
{Rule_Ptr RPtr = RulePtr_Of(RNumber, RT);
 if (RPtr == NULL) return UNVALID_SYMNUM;
 else return (RPtr->rhs1);
}
inline
NTDomain RHS2_OfR(RDomain RNumber, RType RT)
{Rule_Ptr RPtr = RulePtr_Of(RNumber, RT);
 if (RPtr == NULL) return UNVALID_SYMNUM;
 else return (RPtr->rhs2);
}
/*******************************************************************************************/
/* Give rule number for NT->RHS1 RHS2.                                                     */
/* The following must be split in two versions: one for Unary,Binary
   and Eps rules and One for Terminal rules Or otherwise type conflicts
   might take place on NTDomain RHS1. Alternatevily NTDomain must be
   equal to TDomain which is not really attractive for memory use                          */
/*-----------------------------------------------------------------------------------------*/
/* This is for Unary, Binary and Eps                               */
/* return number of NT->RHS1 RHS2, or UNVALID_RNUM if non-existent */
/* RHS1 must be a nonterminal or NULL; RHS2 can be NULL            */
RDomain RuleNumOfNT(NTDomain NT, NTDomain RHS1, NTDomain RHS2, RType RT)
{RDomain i; RDomain *Rules;
 RDomain count ; NT_Ptr Ptr; Boolean Found;
     void SelectRule(RDomain ThisRuleNum)
         {Rule_Ptr RP = RulePtr_Of(ThisRuleNum, RT);
          if ((RHS1_Of(RP)) == RHS1)
             if (RT == _Unary) Found = true; /* Unary case */
             else if ((RHS2_Of(RP)) == RHS2) Found = true; /* Binary case */
                  else Found = false;
          else Found = false;
         }
 Found = false;
 if (RT == _Term) {fprintf(stderr,"Err: In DefsGrammar.c, this function expects no term rules\n");exit(1);}

 Ptr = NT_Ptr_Of(NT, LHS_);       /* Pointing to all rules with lhs NT */
 Rules = Rules_Of(Ptr, RT); /* getting all rule with lhs NT and of type RT */
 count = R_Count_Of(Ptr, RT);
  if (RT == _Eps) return Rules[0]; /* There is only one Eps-rule with lhs NT */
  else {for (i=0; i < count; i++) {SelectRule(Rules[i]); if (Found == true) break;}
        if (Found == false) return UNVALID_RNUM; /* refErr1 */
        else return Rules[i];
      }
}
/*---------------------------------*/
/* return number of LHS->RHS1 RHS2 */
/* RHS1 must be a nonterminal      */
/* RHS2 can be NULL                */
RDomain RNumOfNT_ByLHS(char *LHS, char *RHS1, char *RHS2, RType RT)
{RDomain i; RDomain *Rules; RDomain NT; RDomain count ; NT_Ptr Ptr; Boolean Found;

     void SelectRuleByLHS(RDomain ThisRuleNum)
         {Rule_Ptr RP = RulePtr_Of(ThisRuleNum, RT);
          if (!strcmp((Name(RHS1_Of(RP))), RHS1))
             if (RT == _Unary) Found = true; /* Unary case */
             else if (!strcmp((Name(RHS2_Of(RP))), RHS2)) Found = true; /* Binary case */
                  else Found = false;
          else Found = false;
         }

 Found = false;
 if (RT == _Term) {fprintf(stderr,"Err: In DefsGrammar.c, this function expects no term rules\n");exit(1);}
 NT = NT_NUM_Of(LHS);   /* get nonterminal number of LHS */
 Ptr = NT_Ptr_Of(NT, LHS_);       /* Pointing to all rules with lhs NT */
 if (Ptr == NULL) 
           {PRS("Warning: RuleNumOf: There is a non-existing rule  ");
            PRS(Name(NT));PRS("-->");PRS(RHS1);PRS(" ");if (RT == _Binary) PRS(RHS2);PRS("\n");
            return UNVALID_RNUM;
            /* EXIT(0);*/
           }
 Rules = Rules_Of(Ptr, RT); /* getting all rule with lhs NT and of type RT */
 count = R_Count_Of(Ptr, RT);

 if (count >= 0)
  if (RT == _Eps) return Rules[0]; /* There is only one Eps-rule with lhs NT */
  else {for (i=0; i < count; i++) {SelectRuleByLHS(Rules[i]); if (Found == true) break;}
       if (Found == false)
           {PRS("Warning: RuleNumOf: There is a non-existing rule\n");
            PRS(Name(NT));PRS("-->");PRS(RHS1);PRS(" ");if (RT == _Binary) PRS(RHS2);PRS("\n");
            return UNVALID_RNUM;
            /* EXIT(0); */
           }
       else return Rules[i];
      }
 else {fprintf(stderr,"Err: in DefsG... count < 0\n");exit(1);}
}
/*----------------------*/
/* The following searches by the RHS1 (sometimes useful for efficiency) */
RDomain RNumOfNT_ByRHS1(char *LHS, char *RHS1, char *RHS2, RType RT)
{RDomain i; RDomain *Rules; RDomain NT; RDomain count ; NT_Ptr Ptr; Boolean Found;

     void SelectRuleByRHS1(RDomain ThisRuleNum)
         {Rule_Ptr RP = RulePtr_Of(ThisRuleNum, RT);
          if (!strcmp((Name(LHS_Of(RP))), LHS))
             if (RT == _Unary) Found = true; /* Unary case */
             else if (!strcmp((Name(RHS2_Of(RP))), RHS2)) Found = true; /* Binary case */
                  else Found = false;
          else Found = false;
         }

 Found = false;
 if (RT == _Term) {fprintf(stderr,"Err: In DefsGrammar.c, this function expects no term rules\n");exit(1);}
 NT = NT_NUM_Of(RHS1);   /* get nonterminal number of RHS1 */
 Ptr = NT_Ptr_Of(NT, RHS_1);       /* Pointing to all rules with rhs1 NT */
 if (Ptr == NULL) 
           {PRS("Warning: RuleNumOf: There is a non-existing rule\n");
            PRS(LHS);PRS("-->");PRS(Name(NT));PRS(" ");if (RT == _Binary) PRS(RHS2);PRS("\n");
            return UNVALID_RNUM;
            /* EXIT(0); */
           }

 Rules = Rules_Of(Ptr, RT); /* getting all rule with rhs1 NT and of type RT */
 count = R_Count_Of(Ptr, RT);

 if (count >= 0)
  if (RT == _Eps) return Rules[0]; /* There is only one Eps-rule with rhs1 NT */
  else {for (i=0; i < count; i++) {SelectRuleByRHS1(Rules[i]); if (Found == true) break;}
       if (Found == false)
           {  /* PRS("Err: RuleNumOf: There is a non-existing rule\n");
                 PRS(LHS);PRS("-->");PRS(Name(NT));PRS(" ");if (RT == _Binary) PRS(RHS2);PRS("\n");
                 EXIT(0);
              */
            return UNVALID_RNUM;
           }
       else return Rules[i];
      }
 else {/* fprintf(stderr,"Err: in DefsG... count < 0\n");exit(1); */ return UNVALID_RNUM; }
}
/*--------------------------------------------*/
/* This is for Terminal rules                 */
/* return number of NT->RHS1, or UNVALID_RNUM */
RDomain RuleNumOfT(NTDomain NT, TDomain RHS1)
{RDomain i; RDomain *Rules;
 RDomain count ; NT_Ptr Ptr; Boolean Found;
     void SelectRule(RDomain ThisRuleNum)
        {Rule_Ptr RP = RulePtr_Of(ThisRuleNum, _Term);
         if ((RHS1_Of(RP)) == RHS1) Found = true;
         else Found = false;
        }
 Found = false;
 Ptr = NT_Ptr_Of(NT, LHS_);       /* Pointing to all rules with lhs NT */
 Rules = Rules_Of(Ptr, _Term); /* getting all rule with lhs NT and of type Term */
 count = R_Count_Of(Ptr, _Term);
 for (i=0; i < count; i++) {SelectRule(Rules[i]); if (Found == true) break;}
 if (Found == false) return UNVALID_RNUM; /* refErr2 */
 else return Rules[i];
}
/*--------------------------------*/
/* This is for Terminal rules     */
/* return number of LHS->RHS1     */
RDomain RNumOfT(char *LHS, char *RHS1)
{RDomain i; RDomain *Rules; NTDomain NT;char *temp;
 RDomain count ; NT_Ptr Ptr; Boolean Found;
     void SelectRule(RDomain ThisRuleNum)
        {Rule_Ptr RP = RulePtr_Of(ThisRuleNum, _Term);
         if (!strcmp((temp = TName(RHS1_Of(RP))), RHS1)) 
              {/* PRS(temp); PRS("==");PRS(RHS1);PRS("\n"); */ Found = true;}
         else {/* PRS(temp); PRS("!!");PRS(RHS1);PRS("\n"); */ Found = false;}
        }
 Found = false;
 NT = NT_NUM_Of(LHS);   /* get nonterminal number of LHS */
 Ptr = NT_Ptr_Of(NT, LHS_);       /* Pointing to all rules with lhs NT */
 Rules = Rules_Of(Ptr, _Term); /* getting all rule with lhs NT and of type Term */
 count = R_Count_Of(Ptr, _Term);
 for (i=0; i < count; i++) {SelectRule(Rules[i]); if (Found == true) break;}
 if (Found == false) return UNVALID_RNUM;
  /*{PRS("Err: RuleNumOf: There is a non-existing terminal rule\n"); PRS(Name(NT));PRS("-->");PRS(RHS1);PRS("\n"); EXIT(0); }*/
 else {return Rules[i];}
}

/**************************************************************************************/
/*--------------*/
/* Map func on the RT rules
   of Ptr. func takes a rule
   number only.             */
inline void MapOn_Rules_Of(NT_Ptr Ptr, RType RT, void (* func)())
{RDomain i;
 RDomain *Rules;
 RDomain count = R_Count_Of(Ptr, RT);

 Rules = Rules_Of(Ptr, RT);
 for (i=0; i < count; ++i) (*func)(Rules[i]); 
}

/* func(NT_Ptr A, NTDomain B) */
inline
void MapOnAllNonterminals(void (* func)())
{NTDomain i; G_Array = NTArray;
 for (i=0; i < NonTSize; i++) {/* fprintf(stderr,"%d %d\n", i, NonTSize);*/ (*func)(G_Array+i, i);}
}
/*************************************/
/** Tagging the input sentence with the numbers 
    of the words as preparation for parsing        ****/
inline
int WORDCMP(e1, e2)
  const void *e1;
  const void *e2;
{int i;
 char *v1 = ((struct TermStruct *) e1)->Term;
 char *v2 = ((struct TermStruct *) e2)->Term;
 i = (strcmp(v1, v2));
 return (i);
}
inline TDomain T_NUM_Of(char *Word)
{extern Boolean ERROR;
 Term_Ptr HERE;
 struct TermStruct TmSt;
 TmSt.TRules = NULL;
 TmSt.TCount = 0;
 TmSt.Term = Word;

 HERE = (Term_Ptr) bsearch((void *) &TmSt, (void *) &TermsArray[0], (size_t) TermsSize, sizeof(struct TermStruct), WORDCMP); 
 if (HERE != NULL) return (TDomain) (HERE - TermsArray) ;
 else {ERROR = true; /* fprintf(stderr, "unknown word %s \n", Word); */ return UNVALID_SYMNUM;}
}
/* func takes the name of the terminal */
void Map_On_All_Terminals(void (* func)())
{TDomain i;
 for (i=0; i< TermsSize; i++) (*func)(TermsArray[i].Term);
}
/*******************************/
/* Operations on a list of words
   (i.e. Sentence). An array of
   wordnumbers is constructed for
   the sentence. All the parsing 
   will take place on this array */
extern int SentenceCount(Sentence S);
extern Boolean ErIsUnknownW;

TDomain *TagSentence(Sentence S)
{extern int n; TDomain *Arr; TDomain count = 0;
    void Cnvrt(Queue Word)
       {char ThisWord[SymLength];
        strcpy(ThisWord, Word->Rule); /* try as is - maybe capitalized or so */
        *(Arr+count) = T_NUM_Of(ThisWord);
        // if (Arr[count] == UNVALID_SYMNUM)  try fully lower-case 
        // {strcpy(ThisWord, TOLOWERx(Word->Rule)); *(Arr+count) = T_NUM_Of(ThisWord); }
        if (Arr[count] == UNVALID_SYMNUM) 
         {Word->UnknownWord = true; ErIsUnknownW = true; /* fprintf(stderr,"UNKNOWN-WORD: %s \n"); */}
        count++;
       }

 WordList temp;
 int leng = 0; temp = S->WORDS;
 while (temp != NULL) {leng++;temp = temp->Next;}
 Arr = NULL;
 if (leng != 0)
    {Arr = (TDomain *) MultAlloc(leng, sizeof(TDomain));
     MapSentenceWG_L(S, (void *) &Cnvrt);          /* tag the words */
    }
 else ;
 /* if (ErIsUnknownW == true) exit(1); */

 return Arr;
}
/*****************************/
/* HERE: compilation depends on whether we use morphological analysis or not !! */


// #ifdef MORPHO_ANALYSIS
//char *GetUnknownSym(char *word, Boolean FstWord)
//{return (TOLOWERx(UnknownWExten(word, FstWord)));
//}
//#else
inline
char *GetUnknownSym(char *word, Boolean FstWord)
{return UNKNOWNSYM;
}
//#endif
/*****************************/

inline
TDomain *TagUnknownWs(Sentence WG, TDomain *Sen)
{int i; WordList tempsen, tempNext; Boolean FstWord = true; char TEMP[SymLength];

 ERROR = false;

 if (Sen != NULL)
 {tempsen = WG->WORDS; i = 1;
  while (tempsen != NULL)
   {if (Sen[i-1] == UNVALID_SYMNUM) 
      {strcpy(TEMP, GetUnknownSym(tempsen->Rule, FstWord));
       Sen[i-1] = T_NUM_Of(TEMP);
       if (Sen[i-1] == UNVALID_SYMNUM) 
          {fprintf(stderr,"Cannot find words %s and %s\n", tempsen->Rule, TEMP); ERROR = true;} /* when "unknown_" is not in the grammar */
       else {UpdateProb(tempsen, _SIMILARITY_PROB); ERROR = false;}
       fprintf(stderr,"working with %s for (%s)\n", TEMP,tempsen->Rule);
      }
    tempsen = tempsen->Next; i++;
    FstWord = false;
   }
 }
 else ;
 return Sen;
}

void PrintUnknownWs(Sentence WG, TDomain *Sen)
{int i; WordList tempsen, tempNext; 
 
 if (Sen != NULL)
 {tempsen = WG->WORDS; i = 1;
  while (tempsen != NULL)
   {if (Sen[i-1] == UNVALID_SYMNUM) {PRS(tempsen->Rule);PRS("\n");}
    tempsen = tempsen->Next; i++;
   }
 }
 else ;
}
/********************************************************************************************/
/********************************************************************************************/
/********************************************************************************************/
