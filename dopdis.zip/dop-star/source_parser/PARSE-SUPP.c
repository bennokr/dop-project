/*************************/
/* The Epsilon part was never updated. So it is basic and therefore */
/* does not allow for use of epsilon rules in the grammar           */
/*************************/
void EpsCompSet(TableType TAB, int i, int j)
{Boolean B1, B2; 
 int l;
 EntryPtr ThisEntryPtr = ENTRY_Of(TAB, i, j);
 B1 = false; B2 = false;

 for (l=0; l < EpsRSize; ++l)
     UpdateEntry(TAB, FillItem(l, Eps, mid), i, j);      
  do { 
   B1 = Complete(TAB, i, j);
   B2 = Deduce(TAB, i, j);
  } while ((B1 == true) || (B2 == true)); 
}
void FillDiagonal(TableType TAB, int n)
{int i;
 EntryPtr ThisEntryPtr, AnotherPtr;
  EpsCompSet(TAB, 0, 0);
  /* ReduceAddsBy(TAB, 0, 0);  */
  ThisEntryPtr = ENTRY_Of(TAB, 0, 0);
  for (i=1; i <= n; ++i) {AnotherPtr = ENTRY_Of(TAB, i, i);
                          *AnotherPtr = CopySet(*ThisEntryPtr);}
}
/***********************************************/
/* Part necessary for empty rules              */
/* for empty rules */
Boolean ELDeduce(TableType TAB, int i, int j)
{EntryPtr ThisEntryPtr = ENTRY_Of(TAB, i, j);
 return (A_Deduce_Step(TAB, i, j, i, true));
}

/* for empty rules */
Boolean ERDeduce(TableType TAB, int i, int j)
{EntryPtr ThisEntryPtr = ENTRY_Of(TAB, i, j);
 return (A_Deduce_Step(TAB, i, j, j, true));
}

void CompleteAll(TableType TAB, int i, int j)
{Boolean B1, B2;
 B1 = false; B2 = false;
  do {
   B1 = Complete(TAB, i, j);
   B2 = ((ELDeduce(TAB, i, j)) || (ERDeduce(TAB, i, j)));
  }  while ((B1 == true) || (B2 == true));
}

