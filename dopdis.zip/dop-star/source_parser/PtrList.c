#include "Universals.h"
#include "Aux.h"
#include "PtrList.h"
/******************/
PtrList CrPList()
{return NULL;}
/***********/
PtrList NewPtr(void *Ptr)
{PtrList IDL = (PtrList) AllocElem(sizeof(struct PtrLStr));
 IDL->Next = NULL;
 IDL->Ptr = Ptr;
 IDL->Data = NULL;
 return IDL;
}
/***********/
/* Eq takes two void pointers (each in 
fact to an item) and a pointer to a 
boolean in which it returns for example 
whether or not the two item are identical.
For items Eq checks whether the two pointers are identical !!
Search: returns the place where Ptra is or
else a NULL */

inline
PtrList Search(void *Ptra, PtrList L, void (* Eq)())
{Boolean B = false;
 PtrList Head = L;
 while ((Head != NULL) && (B != true))
       {Eq(Ptra, Head->Ptr, &B);
        if (B == false) Head = Head->Next;}
 return Head;
}
/*******************/
/* Returns a pointer to the item before the one containing
   Ptra, if there is such one. Otherwise returns a NULL.
   Notice that a null is also returned in case Ptra is the first
   in L. FOUND is true iff Ptra is in L.
*/   
inline
PtrList PrevTo(void *Ptra, PtrList L, Boolean *FOUND, void (* Eq)())
{Boolean B = false;
 PtrList Head = L;
 PtrList Prev = NULL;
 while ((Head != NULL) && (B != true))
       {Eq(Ptra, Head->Ptr, &B);
        if (B == false) {Prev = Head;
                         Head = Head->Next;}
       }
 *FOUND = B;
 if (Head == NULL) Prev = NULL; /* Ptra is not found */
 return Prev;
}
/***********/
/* VEqItem works as described in Search above. */
/* It is assumed given outside this module  */
/* Enters Ptra in L on the first place. Keeps L as 
   a set; if Ptra is already in L then it is made the first in L
   i.e. L->Ptr is in fact Ptra. 
*/
inline
PtrList EnterP(void *Ptra, PtrList L)
{extern void VEqItems();
 PtrList P, New, Prev;
 Boolean F = false;
 Prev = PrevTo(Ptra, L, &F, &VEqItems);
 if (F != false)  /* IS IN L */
    if (Prev == NULL) /* is first item in L*/
       return L;
    else {P = Prev->Next;  /* move the PtrStruct currying Ptra to the front of L */
          Prev->Next = Prev->Next->Next; 
          P->Next = L;
          return P;
         }
 else {New = NewPtr(Ptra);
        New->Next = L; 
        return New;
       }
}
/***********/
/* Queue */
inline
PtrList EnterQueue(void *Ptra, PtrList L)
{PtrList this = L;
 PtrList Last = NULL;
 PtrList New = NewPtr(Ptra);
 
 while (this != NULL) {Last = this; this = this->Next;}
 if (Last != NULL) {Last->Next = New; return L;}
 else return New;
}
/***********/
/***********/
inline
PtrList EnterPStack(void *Ptra, PtrList L)
{ PtrList New = NewPtr(Ptra);
  if (L != NULL) New->Next = L; 
  return New;
}
/***********/
inline PtrList CopyPtrList(PtrList L)
{PtrList this = L; PtrList new = CrPList();
 while (this != NULL) {new = EnterPStack(this->Ptr, new); this = this->Next;}
 return new;
}
/***********/
/* make one list of Ptr and L such that Ptr is at the beginning of it */
inline
PtrList StackPList(PtrList Ptr, PtrList L)
{PtrList Last = NULL;
 if (Ptr == NULL) return L;
 else {Last = Ptr;
       while (Last->Next != NULL) Last = Last->Next;
       Last->Next = L;
       return Ptr;
      }
}
/***********/
inline void PDListMapRev(PtrList L, void (* fp)())
{PtrList This = L;
 if (This != NULL) {PDListMapRev(This->Next, fp); (*fp)(This); }
}
inline void PDListMap(PtrList L, void (* fp)())
{PtrList This = L;
 while (This != NULL) {(*fp)(This); This = This->Next; }
}
inline void PListMapRev(PtrList L, void (* fp)())
{PtrList This = L;
 if (This != NULL) {PListMapRev(This->Next, fp); (*fp)(This->Ptr);}
}
inline void PListMap(PtrList L, void (* fp)(void *))
{PtrList This = L;
 while (This != NULL) {(*fp)(This->Ptr); This = This->Next; }
}
/* fp takes a (void *) and a Boolean *STOP */
inline void PListMapUntill(PtrList L, void (* fp)())
{Boolean Stop =false; PtrList This = L;
 while ((This != NULL) && (Stop == false)) 
   {(*fp)(This->Ptr, &Stop);
    This = This->Next;
   }
}
/* fp takes a PtrList and a Boolean *STOP */
inline void PListMapUntillN(PtrList L, void (* fp)())
{Boolean Stop =false; PtrList This = L;
 while ((This != NULL) && (Stop == false)) 
   {(*fp)(This, &Stop);
    This = This->Next;
   }
}

inline
void PListMapEx(PtrList L, void (* fp)(), int i)
{PtrList This = L;
 while(This != NULL) {(*fp)(This->Ptr, i);
                       This = This->Next;
                     }
}
inline
PtrList PLRemoveIf(PtrList L, void (* fp)())
{PtrList This;
 Boolean B = false;
 PtrList Former;
  
 if (L != NULL) 
    {Former = L;
     This = L->Next;
     while(This != NULL) 
        {(*fp)(This->Ptr, &B);
	 if (B==true) {Former->Next = This->Next;
		 This->Next = NULL; free(This);
		 This = Former->Next;
		}
	 else {Former = This;
	       This = This->Next;}
        }
     /* remove the first if  B */
     (*fp)(L->Ptr, &B); if (B==true) {Former = L->Next; free(L); 
                                      return Former;}
    }
 return L;
}
inline
Boolean PLAnyFulfil_fp(PtrList L, void (* fp)())
{PtrList This = L;
 Boolean B = false;
 while ((This != NULL) && (B == false))
  {(*fp)(This->Ptr, &B);
   This = This->Next;}
 return B;
}
/**************************/
/* Maintains a set ********/
/**************************/
/* Old recursive version: replace 16 02 2006*/
/**
PtrList UnitePLSet(PtrList P1, PtrList P2)
{           PtrList ADDItem(void *J, PtrList P) {P = EnterP(J, P);return P;}
 if (P2 == NULL) return P1 ;
 else P1 = ADDItem(P2->Ptr, UnitePLSet(P1, P2->Next));
 return P1;
}
**/
inline PtrList UnitePLSet(PtrList P1, PtrList P2)
{PtrList this;
 if (P2 == NULL) return P1 ;
 else {this = P2; while (this != NULL)  {P1 = EnterP(this->Ptr, P1); this = this->Next;}}
 return P1;
}
/* if P1 and P2 are sets and their intersection is empty */
/* then the result is a set P1vP2                        */
/* Otherwise lists P1 and P2 are merged                  */
PtrList MergePLOld(PtrList P1, PtrList P2)
{PtrList Res = P2;
      inline void EnterThis(void *P) {Res = EnterPStack(P, Res);}

 if (P1 == NULL) return P2;
 else PListMap(P1, (void *) &EnterThis);
 return Res;
}
/* same as MergePL but more efficient in memory use */
/* Queues S after T                                 */
inline PtrList QueueList(PtrList S, PtrList T)
{PtrList Last = NULL; PtrList This = T;
 if (S == NULL) return T;
 else if (T == NULL) return S;
      else {while (This != NULL) {Last = This; This = This->Next;}
            Last->Next = S;
            return T;
           }
}       
inline PtrList MergePL(PtrList P1, PtrList P2)
{return QueueList(P1, P2);}
/**************************/
PtrList PtrLRotate(PtrList P)
{PtrList PtrL = CrPList();
        void CopyEl(void *J)
             {PtrL = EnterP(J, PtrL);}
 PListMap(P, (void *) &CopyEl);
 return PtrL;
}
/****************/
inline
PtrList EnterPOrdered(void *Ptra, PtrList P, void (* fp)())
{PtrList New = NewPtr(Ptra);
 PtrList This = P;  
 PtrList Prev = NULL;
 Boolean B = true;
if (Ptra != NULL) 
{
 if (This != NULL)
   {fp(This->Ptr, Ptra, &B);
    while (B == true)
     {Prev = This; This = This->Next;
      if (This == NULL) break;
      else fp(This->Ptr, Ptra, &B);
     }
   }
 if (Prev == NULL) {New->Next = P; return New;}
 else {New->Next = Prev->Next;
       Prev->Next = New;
       return P;}
}
else return P;
}
/***************************************/
inline
void FreePListN(PtrList L)
{PtrList Head = L;
 PtrList Prev;
 while (Head != NULL)
  { Prev = Head;
    Head = Head->Next; 
    free(Prev); 
  }
}
inline
void FreePDList(PtrList L)
{PtrList Head = L; PtrList Prev = NULL;
 while (Head != NULL) {
   Prev = Head;
   Head = Head->Next;
   FreePListN((PtrList) Prev->Data); 
   free(Prev);
 }
}    
/****************************************/
/* We assume Data is also a PtrList */
/* Enter Ptr into a list under P->Data */
inline
void EnterToDataOfFirst(void *Ptr, PtrList P)
{if (P == NULL) {fprintf(stderr,"Err: entering Data into an empty ptrlist\n"); exit(1);}
 P->Data = (void *) EnterPStack(Ptr, (PtrList) P->Data);
}
/****************************************/
inline
void *PListHeadPtr(PtrList PL)
{if (PL == NULL) return NULL;
 else return PL->Ptr;
}
/****************************************/
inline
PtrList RemoveIfNULL(PtrList PL)
{PtrList Next = PL;
 if (PL != NULL)
   {PL->Next = RemoveIfNULL(PL->Next);
    if (PL->Ptr == NULL) {Next = PL->Next; free(PL);}
    return Next;
   }
 else return PL;
} 
/*****************/
