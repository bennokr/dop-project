#include "./ALL.h" 
#include "./NgramProbModule.h"
#include "./OptimizeLexicals.h"

extern void InitGrammarNum();
extern void POldItem(ItemTree item);
Boolean Warning_given = false;
ItemTree DEBUGITEM;
/***************************************************/
/* In this File: The derivation forest computation */
/* Three version: serial, interleaved  and semi-   */
/*    interleaved                                  */
/***************************************************/
/* for the ngrams */
#define  _TakeSTART_END  true
extern ProbDomain _Lambda_WG;

/**/
inline
ProbDomain IpMultProbs(ProbDomain GRAM, ProbDomain WG)
{if (_WORDGRAPH_PROBS_METHOD == _REGULAR_INTEGRATION) return MultProbs(WG,GRAM);
 else /* if (_WORDGRAPH_PROBS_METHOD == _Interpolated) */
        {ProbDomain WGW = MultProbs(Trans_2_log10((ProbDomain) _Lambda_WG), WG);
         ProbDomain GRAMW = MultProbs(Trans_2_log10((ProbDomain) (1-_Lambda_WG)), GRAM);
         return SumProbs(WGW, GRAMW);
        }
}
/**/
inline
ProbDomain StartEndNgramProb(ItemTree I, TDomain WordNum)
{ProbDomain StartFactor = MultNutralConst; ProbDomain EndFactor = MultNutralConst; ProbDomain RESULT = MultNutralConst;
 
 /* Bigram probabilities for START and END of sentence added here */
 if (I->RT == _Term) /* {fprintf(stderr, "Err: Only terminal rule may have lexical probability\n");exit(1);} */
  if ((_TakeSTART_END==true) && (_ngram_is_used == true))
    {if (I->i == 0) StartFactor = GetStartProbOf(WordNum); 
     else StartFactor = MultNutralConst;
     if (I->j == _sen_length) EndFactor = GetEndProbOf(WordNum);
     else EndFactor = MultNutralConst;
    }

 return (MultProbs(StartFactor,EndFactor)); /* one word sentences need this */
} 

/* This is a function which allows us (if we wish) to apply a function to the probability of the word under I */
/* Now we simply give the word probability back: for the future this can be usefull                           */
inline
ProbDomain ProbOfWordOrOneX(ItemTree I, TDomain WordNum)
{ProbDomain RESULT = ProbOfWordOrOne(I); 

 return RESULT;
}

inline
int DetermineNumOfWs(ItemTree IT, TDomain Term_IfTermRule)
{int NumOfWs = 0;
 if (Term_IfTermRule != UNVALID_SYMNUM) 
  {NumOfWs = 1;
   if (_TakeSTART_END==true)
    {if (IT->i==0) NumOfWs = NumOfWs+1; /* because of START for Ngrams */
     if (IT->j==_sen_length) NumOfWs = NumOfWs+1; /*  because of START for Ngrams */
    }
  }
 else NumOfWs =0;       
 return NumOfWs;
}
/**********/
void InitInternOfICP(ItemTree IT, ItemCPtr ICP)
{int i; NodePtr NP; Rule_Apps RA; int NumOfWs;
   TDomain Term_IfTermRule = GetTerminalOfItemIfAny(IT);
   ProbDomain WordGraphProb = ProbOfWordOrOneX(IT, Term_IfTermRule);
   ProbDomain StartOrEndNgram = StartEndNgramProb(IT,Term_IfTermRule);

 NumOfWs = DetermineNumOfWs(IT, Term_IfTermRule);  


 if (ICP == NULL) {fprintf(stderr, "Err: initializing NULL ICP\n"); exit(1);}

 RA = R_AppsOf(IT->RuleNo, IT->RT);
 for (i=0; i < ICP->RootsSize; ++i)
     {NP = NodePtrOf(ICP->Roots[i].CAdr, RA, ROOT_enum);
      FillDFPtr(&(ICP->Roots[i]),
                (IpMultProbs(ProbOf(&(NP->Code)), WordGraphProb)), (IpMultProbs(ProbOf(&(NP->Code)), WordGraphProb)),
                NULL, NULL, IT, i, ROOT_enum, NULL, NP->OTS);
      ICP->R_NowAtPos[i] = i;
      if (CheckSubtreeActivity(TreeCodeOfNP(NP), S, _sen_length)==true)
        ICP->R_valids[i] = true;
      else ICP->R_valids[i] = false;
     }
 for (i=0; i < ICP->OthersSize; ++i)
     {NP = NodePtrOf(ICP->Others[i].CAdr, RA, OTHERS_enum);
      FillDFPtr(&(ICP->Others[i]),
                ((ProbDomain) IpMultProbs(MultNutralConst, WordGraphProb)), ((ProbDomain) IpMultProbs(MultNutralConst, WordGraphProb)),
                NULL, NULL, IT, i, OTHERS_enum, NULL, NP->OTS);
      ICP->O_NowAtPos[i] = i;
      if (CheckSubtreeActivity(TreeCodeOfNP(NP), S, _sen_length)==true)
        ICP->O_valids[i] = true;
      else ICP->O_valids[i] = false;
     }
 FlushBuff(1);
}
/****************/
/* Notice, the following function does not initialize; it only allocates */
inline
C_Addr_Domain *AllocPos(TreeCodeT Size)
{C_Addr_Domain *New = (C_Addr_Domain *) MultAlloc(Size, sizeof(C_Addr_Domain));
 return New;
}
/*******************************************************************************
 Inits the set A(R) for R which is a Term/Eps rule:
 Assigns to Sum_Prob and MPD_Prob of each OTHERS-code (ROOT-code)
 value 1 (resp. the probability of its tree) as a start value. 
 Also initialize all MPD_PtrL/R to NULL, SelfItem to IT 
      and O/R_valids to NULL unless the global RedDerForest is false - XXXX this was changed !!
 This global is set to false in order NOT to reduce the derivation-forest 
 to only the viable codes. In that case, one must not set R_valids
 and O_valids to NULL.
*****/
void InitValuesICP(ItemTree IT, ItemCPtr ICP)
{TreeCodeT i; NodePtr NP; Rule_Apps RA; int NumOfWs;
 TDomain Term_IfTermRule = GetTerminalOfItemIfAny(IT);
 ProbDomain WordGraphProb = ProbOfWordOrOneX(IT, Term_IfTermRule);
 ProbDomain StartOrEndNgram = StartEndNgramProb(IT,Term_IfTermRule);

 NumOfWs = DetermineNumOfWs(IT, Term_IfTermRule);  

  RA = R_AppsOf(IT->RuleNo, IT->RT);
  ICP->R_valids = NULL; ICP->O_valids = NULL;
  ICP->R_NowAtPos = AllocPos(ICP->RootsSize); 
  ICP->O_NowAtPos = AllocPos(ICP->OthersSize);

 /* if (RedDerForest == false)  XXXXX */
    {ICP->R_valids =  (Boolean *) MultAlloc(ICP->RootsSize , sizeof(Boolean));
     ICP->O_valids =  (Boolean *) MultAlloc(ICP->OthersSize , sizeof(Boolean));
    }
 for (i=0; i < ICP->RootsSize; ++i) 
     {NP = NodePtrOf(ICP->Roots[i].CAdr, RA, ROOT_enum);
      /* OLDVerIs InitDF1   */
      FillDFPtr(&(ICP->Roots[i]), 
                (IpMultProbs(ProbOf(&(NP->Code)), WordGraphProb)), (IpMultProbs(ProbOf(&(NP->Code)), WordGraphProb)), 
                NULL, NULL, IT, i, ROOT_enum, NULL, NP->OTS);
      ICP->R_NowAtPos[i] = i; 
      if (CheckSubtreeActivity(TreeCodeOfNP(NP), S, _sen_length)==true)
        ICP->R_valids[i] = true;
      else ICP->R_valids[i] = false;
     }
 for (i=0; i < ICP->OthersSize; ++i) 
     {NP = NodePtrOf(ICP->Others[i].CAdr, RA, OTHERS_enum);
      /*OLDVerIs InitDF2 */
      FillDFPtr(&(ICP->Others[i]), 
                ((ProbDomain) IpMultProbs(MultNutralConst, WordGraphProb)), ((ProbDomain) IpMultProbs(MultNutralConst, WordGraphProb)),
                NULL, NULL, IT, i, OTHERS_enum, NULL, NP->OTS);
      ICP->O_NowAtPos[i] = i;
      if (CheckSubtreeActivity(TreeCodeOfNP(NP), S, _sen_length)==true)
        ICP->O_valids[i] = true;
      else ICP->O_valids[i] = false;
     }
 FlushBuff(1);
}
/*------------------------------*/
inline
void GetICPOfItem(ItemTree IT, ItemCPtr ICP)
{NodePtr NP; 
 Rule_Apps RA;
 if (ICP == NULL)
  {RA = R_AppsOf(IT->RuleNo, IT->RT); IT->DerForest = (void *) CpyR_Apps(RA, IT);
   InitValuesICP(IT, (ItemCPtr) IT->DerForest);
   FlushBuff(1);
  }
 else InitInternOfICP(IT, ICP);
}
/*------------------------------*/
/* If a code has probability zero (e.g. pruned), it can be eliminated */
void MarkZerosUnValid(ItemCPtr ICP, TreeCodeT *RsizeP, TreeCodeT *OsizeP)
{TreeCodeT i;

 if(_APPLY_PRUNE == true)
  {
 if (*RsizeP > 0) 
  for (i=0; i < ICP->RootsSize; ++i) 
    if ((ICP->Roots[i].MPD_Prob == SumNutralConst) && (ICP->R_valids[i] == true))
       {ICP->R_valids[i] = false; *RsizeP = (*RsizeP) -1;}

 if (*OsizeP > 0) 
  for (i=0; i < ICP->OthersSize; ++i) 
    if ((ICP->Others[i].MPD_Prob == SumNutralConst) && (ICP->O_valids[i] == true))
       {ICP->O_valids[i] = false; *OsizeP = (*OsizeP) -1;}
  }
}
/***********************************************************************/
/* Two tasks for this procedure:
   1. For saving space: this procedure reduces the DerForest of IT only
        to those viable codes (given as valid in R_valids and O_valids). 
       The number of Roots/Others codes that are viable is given resp. 
       Rnum and Onum. Thus it copies the viable codes into a more compact 
       structure.
   2. It multiplies each remaining code with its prob. as defined in the
      RB-STSG.
  
 The global RedDerForest switches the reduction of space to on/off when 
 set to resp. true/false. In case of interleaved CKY attribute computation
 it must be set to false.

This returns also the maximum probability of all OTHERS_enum codes.
******************************/
void RedToValids_Mult(ItemTree IT, TreeCodeT Rnum, TreeCodeT Onum)
{TreeCodeT i, rsizeBefRed, osizeBefRed, WasAt; TreeCodeT RsizeTemp, OsizeTemp; Boolean VOIDB;
 ItemCPtr ICP; DerFPtr Roots; DerFPtr Others;
    void Red_ROOTS() 
     {TreeCodeT i =0; TreeCodeT j = 0;
      if (Rnum > 0)
       for (i=0; i < rsizeBefRed; ++i)
        {WasAt = (Roots[i]).CAdr; 
         if (ICP->R_valids[WasAt] == true)
             {CpyDerFPtrEx(IT, &(ICP->Roots[j]), &(Roots[i]), ROOT_enum); ICP->R_NowAtPos[WasAt] = j; j++;}
         else ICP->R_NowAtPos[WasAt] = _C_Addr_UNV ;
        } /* for */
      else {ICP->Roots = NULL; 
            for (i=0; i < rsizeBefRed; ++i) {ICP->R_NowAtPos[i] = _C_Addr_UNV; ICP->R_valids[i] = false;} }
     }/*---------------------------*/
     void Red_OTHERS()
      {TreeCodeT i =0; TreeCodeT j = 0;
       if (Onum > 0) 
         for (i=0; i < osizeBefRed; ++i)
           {WasAt = (Others[i]).CAdr;
            if (ICP->O_valids[WasAt] == true) 
              {CpyDerFPtrEx(IT, &(ICP->Others[j]), &(Others[i]), OTHERS_enum); ICP->O_NowAtPos[WasAt] = j; j++;}
            else ICP->O_NowAtPos[WasAt] = _C_Addr_UNV; 
           }/* for */
       else {ICP->Others = NULL; 
             for (i=0; i < osizeBefRed; ++i) {ICP->O_NowAtPos[i] = _C_Addr_UNV; ICP->O_valids[i] = false;} }
      }/*---------------------------*/ 

 ICP = (ItemCPtr) IT->DerForest;
 Roots = ICP->Roots; Others = ICP->Others; rsizeBefRed = ICP->RootsSize; osizeBefRed = ICP->OthersSize; 

 if ( RedDerForest == true ) 
 {/* ICP->R_NowAtPos = AllocPos(ICP->RootsSize); ICP->O_NowAtPos = AllocPos(ICP->OthersSize);*/
  ICP->RootsSize = Rnum; ICP->OthersSize = Onum;
  ICP->Others = ALLDerFPtr(Onum, OTHERS_enum); ICP->Roots = ALLDerFPtr(Rnum, ROOT_enum); 

  Red_ROOTS(); Red_OTHERS(); 
  cfree(Roots); cfree(Others); 

  /* {cfree(ICP->R_valids); cfree(ICP->O_valids); ICP->R_valids = NULL; ICP->O_valids = NULL;} */
  IT->DerForest = (void *) ICP;
 }
 else {/* Only multiplication of codes without reduction of codes */
       for (i=0; i < rsizeBefRed; ++i)
        if (ICP->R_valids[i] == true) 
         {CpyDerFPtrEx(IT, &(ICP->Roots[i]), &(Roots[i]), ROOT_enum);}
 
       for (i=0; i < osizeBefRed; ++i)
        if (ICP->O_valids[i] == true) 
         {CpyDerFPtrEx(IT, &(ICP->Others[i]), &(Others[i]), OTHERS_enum); }
      }
}
/********************************/
/* itemI_J (A->BC*) is updated from cpyOfitemI_K (a copy of A->BC*) which has been computed
   from one of the possible A->B*C, called itemI_K, with all its C->x*. For the update
   we need also the prob.'s and addresses from itemI_K (A->B*C) which
   is the "original" der.forest - cpyOfitemI_K is a copy which enables the
   multiplication (i.e. has extras: R/O_valids arrays, probabilities
   which are 0).

   For ListOfChNodes: for every DFP of every A->B*C a PtrList of length 1 is computed that points 
   to the DFP itself (ListOfChNodes->Ptr) and has a list (ListOfChNodes->Data) that is a PtrList
   of all the C->gamma* DFPs that can be combined with it in a valid manner.
   When Updating for A->BC*: cpyOfitemI_K (A->B*C) donates its ListOfChNodes, which is stacked at 
   the beginning of the list ListOfChNodes of A->BC*.
*/
/*******************/
/* Update1By2(A->BC*, TEMPORARY COPY of A->B*C which holds RIGHT CHILD C->x* info, ORIGINAL A->B*C  */   
/* We update A->BC* from (A->B*C,  C->x*): no multiplication with subtree prob yet                  */
inline
void UpdateDF1By2(DerFPtr itemI_J, DerFPtr cpyOfitemI_K, DerFPtr itemI_K)
{Boolean First = false; Boolean FirstFinal = false; ProbDomain CurrMPD_Prob;  ProbDomain AccumNgramProb = MultNutralConst;
 DerFPtr TempItemR_Chs = cpyOfitemI_K; /* just for readability reasons: cpyOfitemI_K holds a temporary copy of A->B*C with calculations */

 /* add the sum of der's probs in temp copy of A->B*C (holding A->B*C x C->x*) to the sum in A->BC* */
 itemI_J->Sum_Prob = SumProbs(itemI_J->Sum_Prob, (MultProbs(itemI_K->Sum_Prob, TempItemR_Chs->Sum_Prob)) );  

 if (TempItemR_Chs->ListOfChNodes != NULL)
  {itemI_J->ListOfChNodes = EnterPStack((void *) itemI_K, itemI_J->ListOfChNodes);      /* stack it */
   (itemI_J->ListOfChNodes)->Data = (TempItemR_Chs->ListOfChNodes)->Data;               /* Inherit the Data */
  }

 CurrMPD_Prob   = MultProbs(TempItemR_Chs->MPD_Prob, itemI_K->MPD_Prob);   /* multiplying by subtree prob takes place later: CpyDerFPtrEx */

 itemI_J->MPD_Prob = MaxProbs(CurrMPD_Prob, itemI_J->MPD_Prob, &First);

 if (First == true) 
   {itemI_J->MPD_PtrL = itemI_K->MPD_PtrL; itemI_J->MPD_PtrR = TempItemR_Chs->MPD_PtrR;
    /* itemI_J->num_of_roots_in_der = itemI_K->num_of_roots_in_der + TempItemR_Chs->num_of_roots_in_der; */
   }
}
/*****************************/
/*****************************************/
/* Notice: ResI should be complete such that  */
/*     if ResI->Roots[i]==CAdr then CAdr == i */
/*     same for ResI->Others.                 */
/* OrigGivI is the original item A->B*C of which */
/* the derivation-forest was copied into GivI to */
/* be used for the computation of der.forest of  */
/* A->BC* (i.e. ResI). The MPD_PtrL's of the     */
/* codes of ResI should point to the codes       */
/* of OrigGivI which resulted in MPDs, not to    */
/* in GivI (which is temporary and will disppear.*/ 
/*                                               */
/* ResI is the Item that holds the final results: A->BC*         */
/* GivI is the a copy of OrigGivI (B->alpha*) which holds for the*/
/* ResI the multiplication of OrigGivI with all possible         */
/* C->beta* (Right-Children)                                     */ 
                    
/* Update1By2(A->BC*, TEMPORARY COPY of A->B*C, ORIGINAL A->B*C  */
TreeCodeT Update1By2(ItemTree ResI, ItemTree GivI, Code_Soort CT, ItemTree OrigGivI)
{TreeCodeT j ;
 C_Addr_Domain ccc;
 TreeCodeT I = 0;
 ItemCPtr ICGivI = (ItemCPtr) GivI->DerForest;
 ItemCPtr ICResI = (ItemCPtr) ResI->DerForest;
 ItemCPtr ICOrGivI = (ItemCPtr) OrigGivI->DerForest;
             void DealWithRs()
                  {if (ICResI->R_valids[ccc] == false)
                      {ICResI->R_valids[ccc] = true; ++I; }
                   UpdateDF1By2(&(ICResI->Roots[ccc]), &(ICGivI->Roots[j]), &(ICOrGivI->Roots[j]));
                  }
             void DealWithOs()
                  {if (ICResI->O_valids[ccc] == false)
                      {ICResI->O_valids[ccc] = true; ++I; }
                   UpdateDF1By2(&(ICResI->Others[ccc]), &(ICGivI->Others[j]), &(ICOrGivI->Others[j]));
                  }
 if (1==0){ PRS("...updating from "); PItem(OrigGivI); PRS("\n");}
 switch (CT) {
   case ROOT_enum: if (ICGivI->RootsSize <= ICResI->RootsSize)
                     for (j = 0; j < ICGivI->RootsSize; ++j)
                     {ccc = ICGivI->Roots[j].CAdr;
                      if (ICGivI->R_valids[j] == true) 
                         if (RedDerForest == true) DealWithRs();
                         else if (ICOrGivI->R_valids[j] == true) DealWithRs(); 
                     }
                   else {fprintf(stderr, "RProblems in Update1By2 in DERIVATION.c");
                         exit(1); return (0); }/* smg must have went wrong */
         break;
   case OTHERS_enum: if (ICGivI->OthersSize <= ICResI->OthersSize)
                      for (j = 0; j < ICGivI->OthersSize; ++j)
                      {ccc = ICGivI->Others[j].CAdr;
                       if (ICGivI->O_valids[j] == true) 
                         if (RedDerForest == true) DealWithOs();
                         else if (ICOrGivI->O_valids[j] == true) DealWithOs(); 
                      }
                     else {
         printf("\n*********\n");
         fprintf(stderr, "OProblems in Update1By2 in DERIVATION.c\n");
         printf("%d %d %d\n",ICGivI->OthersSize,ICResI->OthersSize,
                 ICOrGivI->OthersSize);
         PItem(ResI);PRS("--Res--"); printf("%d \n", ICResI->OthersSize);
         PItem(GivI);PRS("--Giv--"); printf("%d \n",ICGivI->OthersSize);
         PItem(OrigGivI);PRS("--OrigGivI--"); printf("%d \n",ICOrGivI->OthersSize);
         printf("\n*********\n");
         exit(1); return (0); }/* smg must have went wrong */
         break;
     otherwise : break;
 } /****/
 return I;
}
/*******************************/
/* Computes the derivation forest of the item given by Ptr. */
/* InitDFofItem = true implies initialize the derivation forest of the Item */
/*              Otherwise : Don't                                           */      
/* The Item must have a list of AddedBy that points to those items that made*/
/* the given item be in the chart.                                          */ 
/* Items A->BC* are computed from all A->B*C with their respective C->beta* */
/* For every A->B*C and its resp. C->beta* the computation is curried out   */
/* in a temporary copy of A->B*C (incl derivation-forest) called DupI.      */
/* Subsequently A->BC* is updated  by the results from DupI.                */
/**/
extern void PrntDList(PtrList PL);  

void CompItem(void *Ptr, Boolean InitDFofItem, DuoPtr Duo)
{ItemTree IT, DupI ; ItemCPtr ICP; Rule_Apps RA; 
 TreeCodeT Rnum = 0; /* num of roots in total */
 TreeCodeT Onum = 0; /* num of others in total */
 TreeCodeT RnumTemp = 0; TreeCodeT OnumTemp = 0; Child_Type Ch;

       inline
       void MUL(void *Ptr)
        {ItemTree Ich = (ItemTree) Ptr;
         Boolean AnyRV = false; /* whether this item had any roots */
         Boolean AnyOV = false; /*  ....   ...   ... ...  ... others */
         Duo = CleanDuo(Duo); 
         if ((Same_Entry_Items(Ich, IT) == true) && (Ich->Level >= IT->Level)) 
           if ((_Allow_Same_Level == false) && (Warning_given== false))
            {Warning_given = true;
             fprintf(stderr,"\n Warning:possibly dangerous dependency order between unary items\n entry P <%d,%d> Ch <%d,%d> (%d <= %d) \n", 
                             IT->i,IT->j,Ich->i,Ich->j, IT->Level, Ich->Level); fPItem(IT,stderr); fPItem(Ich,stderr);PRS("\n");
             /* exit(1); */
            }
         Duo = MultItems(IT, Ich, Ch, &AnyRV, Duo);
         Rnum = Rnum + Duo->RsNum; Onum = Onum + Duo->OsNum;
                /* as a side effect of the two above statements the probability 
                is computed as sum or max as necessary for resp. Sent.Prob or 
                MPD.  However, this comp. prob of the code MUST still be 
                multiplied with the prob. of the code in order to get the 
                real prob. wanted. */
                /* if ((AnyRV == false) && (AnyOV == false))
                remove Adds and AddedBy pointers between IT and Ich */ ;
          FlushBuff(2); /* flush child buffer */
        }
        void MulAll(PtrList This)
           {ItemTree Temp;
            ItemTree ItemIK = (ItemTree) This->Ptr;
            PtrList ItemsKJ = (PtrList) This->Data;

            DupI->DerForest = (void *) CpyICPtr((ItemCPtr) ItemIK->DerForest, false, IT, ICP->RootsSize, ICP->OthersSize);

            if (DupI->DerForest == NULL) {fprintf(stderr,"Err1: in MulAll\n"); exit(1);} 
            if (DupI->RuleNo != ItemIK->RuleNo) 
               {fprintf(stderr,"Err2: in MulAll\n  old=%d  new=%d  (A->BC* old=%d new=%d)\n", ItemIK->OldRNum, ItemIK->RuleNo, IT->OldRNum, IT->RuleNo); 
                InitGrammarNum(1);
                POldItem(ItemIK); POldItem(IT);
                InitGrammarNum(2);
                PItem(ItemIK); PItem(IT);
                exit(1);
               }

            Temp = IT; IT = DupI; DEBUGITEM = IT; /* just because MUL does it with IT */
            PListMap(ItemsKJ, (void *) &MUL); 
            IT = Temp;
            /* Update1By2 updates IT by the knowledge in DupI.  Probabilities are updated in IT (Max or sum) and the validity set also */
            if (1==0) {PRS("and updating ....\n");}
            RnumTemp = RnumTemp + (Update1By2(IT, DupI, ROOT_enum, ItemIK)); /* itemIK is incomplete: A->B*C */
            OnumTemp = OnumTemp + (Update1By2(IT, DupI, OTHERS_enum, ItemIK));
            FreeICPtr(DupI->DerForest); /* here we free it each time: RefFree:DupI->DerForest */
           }

 IT = (ItemTree) Ptr; DupI = CpyItem(IT); DEBUGITEM = IT;
 if ((IT->DerForest != NULL) && (Active_Grammar_Number == 2)) 
    {fprintf(stderr, "Err: this item already has a derivation forest !!\n");PItem(IT);exit(1);}

 if (InitDFofItem == true) {RA = IR_AppsOf(IT->RuleNo, IT->RT,1); IT->DerForest = (void *) CpyR_Apps(RA, IT); }
 ICP = (ItemCPtr) IT->DerForest; 
 if (ICP == NULL) {fprintf(stderr, "Err: an item without occurrences list ?\n");exit(1);}
    
 switch (IT->RT) {
    case _Eps  : /* InitValuesICP(IT, ICP); */
                break;
    case _Term : InitValuesICP(IT, ICP);
                break;
    case _Unary: Ch = Lch_enum; 
                PListMap(IT->AddedBy, (void *) &MUL);
                RedToValids_Mult(IT, Rnum, Onum);
                break;
    case _Binary: switch (IT->Dot) {
                   case lm  : break;/* shouldn't be possible */
                   case mid : Ch = Lch_enum;
		              PListMap(IT->AddedBy, (void *) &MUL); 
                              RedToValids_Mult(IT, Rnum, Onum);
                              break;
                   case rm  : Ch = Rch_enum;
                              if (1==0) {PItem(IT); PRS("["); PRI(IT->i); PRS(",");PRI(IT->j);PRS("]\n");}
                              PDListMap(IT->AddedBy, (void *) &MulAll);
                              if (1==0) {PRS("\n--------------------\n");}
                              RedToValids_Mult(IT, RnumTemp, OnumTemp);
                              break;
                  }/***/
                  break;
    otherwise : break;
 } /* -- */
 FlushBuff(1);   /* flush the parent buffer */
 FreeItemNotDF(DupI); /* free all but der-forest of DupI:  see RefFree:DupI->DerForest  */
}
/***********************/
/* A version for non-interleaved computation */
void CompDFEntry(EntryPtr EPtr, DuoPtr Duo)
{    inline void AppCompItem( void *I) {CompItem(I, true, Duo);}

 /* if (Semi_Interleaved == true) MapOnLevelsOf(*EPtr, (void *) &AppCompItem); else */
  MapOnLevelsOfV(*EPtr, (void *) &AppCompItem); /* two-phase: only on valids */
}
/***************************/
/* The computation of the derivation-forest and MPD takes place on
   the CFG-parse-forest. The forest contains valid and unvalid
   items which AddedBy relationship. The computation is done
   only for valid items. Unvalid items stay in the AddedBy relationship
   but do not contribute anything to the computation since they always
   have a derivation-forest which is NULL.
*/
/***************************/
void CompDFTable(TableType TAB, int n, DuoPtr Duo)
{int k, j; EntryPtr EPtr;

 if ((Interleaved == false) && (Semi_Interleaved == false))
  {fprintf(stderr, "Constructing the derivation-space ...");  
   for (k = 1; k <= n; ++k)
    {for (j = k; j <= n; ++j)
        {EPtr = ENTRY_Of(TAB, (j-k), j); CompDFEntry(EPtr, Duo); }
     PruneForLength(TAB, n, k);  
     fprintf(stderr,"(%d)",k);
    }
   fprintf(stderr, "\n"); 
  }
}

/*---------------------------------------------------------------------------------*/
/**********************************/
/*** Semi-interleved  */
/**********************************/
/** Other modes that two-phases are: interleaved and semi-interleaved */
/* Interleaved: each time an item is added (even if it was there already) 
      to a table-entry in the CKY, its probability is computed/updated from 
      the items that just resulted in adding it (the last items that did so).
   Semi-interleaved: after the entry is completed (no items can be added anymore)
       then we apply the computation of the derivation-forest to every item.
***************************************/
/* For the semi-interleaved computation of derivation-forest */
/* Unaries: if true and Ended is true then: do only unary items, else do the other items */
void CompDFEntrySemiI(TableType TAB, int i, int j, DuoPtr Duo, Boolean Ended, Boolean Unaries, Boolean PrepForPruning)
{EntryPtr EPtr; Boolean PrunableItem = false;
     inline void PruneSkndGrammar(LevDomain level) 
        {if (PrunableItem == true) PruneEntry(TAB, i, j, Ended, Unaries, true); PrunableItem = false;  }
     inline Boolean DoThisItem(ItemTree I, Boolean DoEnded, Boolean DoUnaries)
      {if (I != NULL)
        if ( ((DoUnaries == true) && (I->RT == _Unary)) || 
             ((DoUnaries == false) && (DoEnded == true) && (EndedItem(I) == true) && (I->RT != _Unary)) ||
             ((DoUnaries == false) && (DoEnded == false) && (EndedItem(I) == false))   
           ) return true;
        else return false;
       else return false;
      }
     inline void AppCompItem(void *IV)
      {ItemTree I = (ItemTree) IV;
        if ((DoThisItem(I, Ended, Unaries)) == true)
         if (((ItemCPtr) I->DerForest) == NULL) 
           {CompItem(I, true, Duo);
            if (_PARSER_VERSION == _MPD_VERSION)
              if ((NUM_OF_GRAMS() == SINGLE_G) || (ParsingMethod == _SKND_G_ONLY)) FreeAddedByOf(I);  
            if ((PrepForPruning == true) && (_APPLY_PRUNE == true)) {I->Attempt_Pruning_Item = true; PrunableItem = true;}
           }
         else I->Attempt_Pruning_Item = false;
        else I->Attempt_Pruning_Item = false;
      }
 
 if ((Ended == false) && (Unaries == true)) 
    {fprintf(stderr,"Err: unaries are always ended (CompDFEntrySemiI)\n"); exit(1);}

 EPtr = ENTRY_Of(TAB, i, j); 
 if ((Semi_Interleaved == true) && (_DisambiguateB == true)) 
   if ((Active_Grammar_Number == 1) || (ParsingMethod == _SKND_G_ONLY))  
        MapOnLevelsOfEnded(*EPtr, (void *) &AppCompItem, Ended); 
   else /* ExMapOnLevelsOfEnded(*EPtr, (void *) &AppCompItem, (void *) &PruneSkndGrammar, Ended); */
       Controlled_MapOnLevelsOf(*EPtr, (void *) &AppCompItem, (void *) &PruneSkndGrammar, (void *) &DoThisItem, Ended, Unaries); 
}
/*
**
**
*/
/**********************************/
/*references for explanations:    */
/* refCpy:
*     Copy DerForest of ItemIK without probabilities 
*     and with IT as SelfItem. Unfortunately, currently
*     it does not copy viability lists. 
*     In case RedDerForest = false then further speed up 
*     can be achieved by:
*       1. Allow to copy viability lists in CpyICPtr.
*       2. In the case of Binary + rm items multiply (in MultICPtrs)
*          only viable parent codes. 
**/
/***
*  OriginalRedRoots1:
*      j = 0;
* if (Rnum > 0)
*  for (i=0; i < ICrsize; ++i)
*     {* WasAt = (Roots[i]).CAdr; *
*      if (ICP->R_valids[i] == true)
*         {CpyDerFPtrEx(IT, &(ICP->Roots[j]), &(Roots[i]), ROOT_enum); ++j;
*          * ICP->R_NowAtPos[WasAt] = j-1; *
*         }
*      * else ICP->R_NowAtPos[i] = 0 * ;
*     }
*
/* Hereunder was OriginalRedRoots1: *
 if (Rnum > 0)
  {for (i=0; i < ICrsize; ++i)
    if (ICP->R_valids[i] == true)              * ROOTS OPTIM *
     {Boolean First = false;
      CpyDerFPtrEx(IT, &(RootDFTemp[0]), &(Roots[i]), ROOT_enum);
      MaxR = MaxProbs(MaxR, (RootDFTemp[0]).MPD_Prob, &First);
      SumR = SumProbs(SumR, (RootDFTemp[0]).Sum_Prob);
      if (First == false)
       {if (ICP->Roots != NULL) cfree(ICP->Roots);
        ICP->Roots = &(RootDFTemp[0]);  RootDFTemp = ALLDerFPtr(1, ROOT_enum);
       }
      else ;
    }
   if (ICP->Roots != NULL) (ICP->Roots[0]).Sum_Prob = SumR; * one root carries the sum *
   cfree(RootDFTemp);
 }
              
***********/
/*
*  BELOW IS 
* CLOSED CLOSED 
* CLOSED CLOSED 
* CLOSED CLOSED 
* CLOSED CLOSED  
*void Red_NOT_MPD_ROOTS()
*{ICP->Roots = ALLDerFPtr(Rnum, ROOT_enum);
*      j = 0;
*      if (Rnum > 0)
*       for (i=0; i < rsizeBefRed; ++i)
*         {WasAt = (Roots[i]).CAdr;
*          if (ICP->R_valids[WasAt] == true)
*             {CpyDerFPtrEx(IT, &(ICP->Roots[j]), &(Roots[i]), ROOT_enum);
*              ICP->R_NowAtPos[WasAt] = j; j++;
*             }
*          else ICP->R_NowAtPos[WasAt] = 0 ;
*         }
*}*---------------------------*
*
*void Red_MPD_ROOTS() * assumes that Rnum > 0 *
*      {* in case of MPD we leave one root only *
*       TreeCodeT i =0; TreeCodeT j = 0; ProbDomain MaxR = MaxNutralConst; ProbDomain SumR = SumNutralConst; 
*       DerFPtr SingleRootDF = ALLDerFPtr(1, ROOT_enum);  * one root is sufficient *
*       for (i=0; i < rsizeBefRed; ++i)
*         {WasAt = (Roots[i]).CAdr; 
*          if (ICP->R_valids[WasAt] == true)
*           {Boolean First = false; 
*            MaxR = MaxProbs(MaxR, Roots[i].MPD_Prob, &First);   
*            if (First == false) * if the current root is larger than the cur-max-prob root then exchange them *
*               {CpyDerFPtrEx(IT, SingleRootDF, &(Roots[i]), ROOT_enum); * copying and multiplying *
*                SumR = SumProbs(SumR, SingleRootDF->Sum_Prob);
*               }
*            else {CpyDerFPtrEx(IT, &(Roots[i]), &(Roots[i]), ROOT_enum); * just multiplying (trick !!) *
*                  SumR = SumProbs(SumR, Roots[i].Sum_Prob);
*                 }
*           }
*          ICP->R_NowAtPos[WasAt] = 0 ;
*         } * for *
*        SingleRootDF->Sum_Prob = SumR; * passing the total sum of all roots *
*        ICP->Roots = SingleRootDF;  ICP->RootsSize = 1; 
*}
**---------------------------*
*void Red_ROOTS() {
*       if (Rnum > 0) * any roots valid ? *
*         if ( (_Whole_DFSpace == true) ||  
*              ( ((IT->RT == _Binary) && (IT->Dot == mid)) ) || (rsizeBefRed == 1) ) Red_NOT_MPD_ROOTS();
*         else Red_NOT_MPD_ROOTS(); * IN CASE OF MPD: one root is suffiecient - efficiency *
*       else ICP->Roots = NULL;
*      }
**---------------------------*/ 
