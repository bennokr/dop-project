/* What header files are necessary ? *******************************/
/** General declations and definitions */
/*******************/
#include "Universals.h"
#include "Aux.h"
#include "CodeType.h"
#include "Constants.h"
#include "unary_bamboo_functions.h"
/**************************/

/********** INCLUDE HERE .unary_file.c  ****************************/
#include <.unary_file.c>
/**************************/
int Which_Nodes_Number=0;
int *WhichPlaceArray = NULL;
struct Bamboo_Struct *WhichUnaryArray= NULL;
/**********/
Boolean TEST_UNARY_EMPTY()
{if (Which_Nodes_Number==0) return true; if (WhichUnaryArray==NULL) return true;
 return false;
}

/** contains the functions that accompany the unary-bamboo package */

NodeUnaryPtr PlaceOfUnaryForNode(TreeCodeT TCode, InTreeCodeT NCode)
{NodeUnaryPtr N_U_Ptr=NULL; TreeCodeT CU_T_N = TCode; NodeUnaryPtr RESULT; int start;

 RESULT = NULL;
 if (Which_Nodes_Number==0) return NULL; if (WhichUnaryArray==NULL) return NULL;

 start = WhichPlaceArray[TCode];                   
 /* fprintf(stderr,"\n %d  %d --->%d\n", TCode,NCode, start); */

 if (start==-1) return NULL; /* unvalid case */

 while ((start<Which_Nodes_Number) && (CU_T_N==TCode) && (RESULT==NULL)) 
 {N_U_Ptr = WhichUnaryArray+start; CU_T_N = N_U_Ptr->TreeC;
  if ((N_U_Ptr->TreeC == TCode) && (N_U_Ptr->NodeC == NCode)) RESULT = N_U_Ptr;
  start++;
 }

 return RESULT;
}
/*********************************************************/
char *SuffixOfN_U_Ptr(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; NodeUnaryPtr NUPtr=NULL;
 strcpy(RESULT,"");
 NUPtr = PlaceOfUnaryForNode(TCode, NCode);

 if (NUPtr == NULL) return RESULT;
 else {strcpy(RESULT,NUPtr->SuffixSub); return RESULT;}
}

char *PrefixOfN_U_Ptr(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; NodeUnaryPtr NUPtr=NULL;
 strcpy(RESULT,"");
 NUPtr = PlaceOfUnaryForNode(TCode, NCode);

 if (NUPtr == NULL) return RESULT;
 else {strcpy(RESULT,NUPtr->PrefixSub); return RESULT;}
}
/*************************************************************/
/*************************************************************/
/*************************************************************/
char *PrefixOfUnariesAbove(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; strcpy(RESULT,"");
 WhichPlaceArray = Above_Array_Of_Place_Per_Sub;
 WhichUnaryArray=UnaryAboveNodes;
 Which_Nodes_Number = Nodes_Number_Above;
 if (TEST_UNARY_EMPTY()==true) return RESULT;
 strcpy(RESULT, PrefixOfN_U_Ptr(TCode, NCode));
 return RESULT;
}
char *SuffixOfUnariesAbove(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; strcpy(RESULT,"");
 WhichPlaceArray = Above_Array_Of_Place_Per_Sub;
 WhichUnaryArray=UnaryAboveNodes;
 Which_Nodes_Number = Nodes_Number_Above;
 if (TEST_UNARY_EMPTY()==true) return RESULT;
 strcpy(RESULT,SuffixOfN_U_Ptr(TCode, NCode));
 return RESULT;
}
/****/
char *PrefixOfUnariesUnder(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; strcpy(RESULT,"");
 WhichPlaceArray = Under_Array_Of_Place_Per_Sub;
 WhichUnaryArray=UnaryUnderNodes;
 Which_Nodes_Number = Nodes_Number_Under;
 if (TEST_UNARY_EMPTY()==true) return RESULT;
 strcpy(RESULT,PrefixOfN_U_Ptr(TCode, NCode));
 return RESULT;
}
char *SuffixOfUnariesUnder(TreeCodeT TCode, InTreeCodeT NCode)
{static char RESULT[SymLength]; strcpy(RESULT,"");
 WhichPlaceArray = Under_Array_Of_Place_Per_Sub;
 WhichUnaryArray=UnaryUnderNodes;
 Which_Nodes_Number = Nodes_Number_Under;
 if (TEST_UNARY_EMPTY()==true) return RESULT;
 strcpy(RESULT, SuffixOfN_U_Ptr(TCode, NCode));
 return RESULT;
}
