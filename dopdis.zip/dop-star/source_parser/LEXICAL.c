/*******************/
/* All the files necessary */
/*for the lexical analysis */
/* The lexical analysis    */
/*******************/
#include "Queues.c"
#include "sentence.c"
#include "lex.yy.c"
#include "WordGraph.c"

/******************************************/
