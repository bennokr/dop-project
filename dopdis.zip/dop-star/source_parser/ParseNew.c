#include "/usr/include/limits.h"
#include "./ALL.h"
#include "ExtractChunks.h"

/************** My own files  ********/
/*  Main takes an input and output file and*/
/*  parses the sentences in the input files */
/*******************************************/

extern int getopt( int argc, char* argv[], char* optstring );
extern char* optarg;
extern int optind, opterr;

extern Boolean Right_Linear;
extern Boolean _DisambiguateB;
extern Boolean _MakePForest;
extern Boolean _FullSenRec;
extern Boolean _OutNoContext;

Boolean _ShowChunks = false;

void main(argc, argv, envp)
int argc;
char **argv, **envp;
{char* options = "bhcSPpNRFXi:o:";
 int  opt_ch;
 int error_flag = 0;

  FILE *fopen();
  void yyparse();
  clock_t start, finish;
  double duration;

  start = clock();
  Right_Linear = false;
  fpOUT = stdout; fpIN = stdin;

  opt_ch = getopt( argc, argv, options );
  while ( opt_ch != -1 )
   {switch( opt_ch ) {
     case 'N' : _DisambiguateB = false; break;
     case 'b' : _BIGRAM_PRUNE = true; break; 
     case 'c' : _DisambiguateB = false; _ShowChunks = true; break; 
     case 'F' : Right_Linear = true; _FullSenRec = true; break;
     case 'R' : Right_Linear = true; break; 
     case 'X' : _DisambiguateB = false; _OutNoContext = true; break;
     case 'P' : _APPLY_PRUNE = true;  break;     
     case 'p' : ParsingMethod = SDOP; break;
     case 'S' : Semi_Interleaved = true; break; 
     case 'i' : 
           if ((fpIN = fopen(optarg, "r")) == NULL) printf("Can't open %s\n", *argv);
           break;
     case 'o' :
           if ((fpOUT = fopen(optarg, "w")) == NULL) printf("Can't open %s\n", *argv);
           break;
     case 'h' : error_flag++; break;  
     case '?' : error_flag++; break;
    }
    opt_ch = getopt( argc, argv, options );
   }
        /* case file names without -i and -o */
   if ( argc - optind > 0 ) 
    if (fpIN == stdin)
     {if (argv[optind][0] != '-')
       {fpIN = fopen( argv[optind], "r" );
        if ( !fpIN ) 
         {fprintf( stderr, "File <%s> does not exist\n", argv[optind] ); exit( 1 );}
       }
      else error_flag++;
     }
    else /* input file read */
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
   if ( argc - ++optind > 0 ) 
    if (fpOUT == stdout)
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
    else error_flag++;
   else error_flag++;

         /* In case of error  */
   if ( error_flag )
   {char* basename = strrchr( argv[0], '/' );

    if ( basename ) basename++;
    else basename = argv[0];
    fprintf(stderr, "Usage: %s [options] -i <infile> -o <outfile>"
               " [infile [outfile] ]\n", basename );
      fprintf( stderr, "Options:\n" );
      fprintf( stderr, "  -h  print this message\n" ); 
      fprintf( stderr, "  -R  Only for Right Linear Grammars\n" );
      fprintf( stderr, "  -N  Only recognize, don't disambiguate, don't build parse forest\n" );
      fprintf( stderr, "  -c  As -N but show the chunks made by partial-parser\n" );
      fprintf( stderr, "  -F  (Assumes -R, Input contains NO context) retrieve full sentence\n" );
      fprintf( stderr, "  -X  (Assumes -N, Input must contain context) Discard context effect from output\n");
      fprintf( stderr, "  -p  Do not employ partial-parser (first grammar) before using the second grammar\n");
      fprintf( stderr, "  -P  Prune using BEAM-with-Priors\n");
      fprintf( stderr, "      The default is to use the partial-parser as in pardopdis                    \n");
      exit( 1 );
   }

  /** Do the parsing **/
  yyparse();

 finish = clock();
 duration = (double) finish - start;
/* printf("Duration is :%f secs\n", duration/60);*/
}
/*******************************************/
/*******************************************/
/*******************************************/
/****** GLOBAL VARIABLES ******************/
extern void InitGrammar();
extern Sentence TheWG;
extern Sentence TheSen; 
extern TDomain *S; /*** The input sentence encoded */
extern int n;     /*** The length of the input sentence **/
extern Boolean ERROR;
extern TableType CKYTAB; /*** The CYK table.             */
extern ParForest PARF ;
extern Boolean Interleaved;
extern TDomain *TagSentence(Sentence S);
extern TDomain *TagUnknownWs(Sentence WG, TDomain *Sen); 
extern void CountNodesInTAB(TableType TAB, int length);
/*******************************************/
/* A global that is used NOT as a global in the original
   parser. Due to the addition of the Interleaved mode
   and for the sake of minimizing changes in the original
   parser, we had to allow this global to be there.
   Appologies for this !!
***/
DuoPtr Duo;

 int start, finish, midT;
 clock_t StartT, FinishT, MidT;
 struct tms bufstr;
 struct tms *buffer;

void yyparse()
{extern int yylex();
 int ex,i;


 TestGlobalSetting(DOUBLE_G);
 ConstructG1toG2(); /* construct transformation from rules of G1 to rules of G2 */

 PARF = CrParF(); ERROR = false; n =0; Duo = NewDuo();

 bufstr.tms_utime = 0; bufstr.tms_cutime = 0;
 start = times(&bufstr);
 StartT = bufstr.tms_utime + bufstr.tms_cutime;

 /***** First read the sentence or word-graph ***********/
 /* ArrayOfTransitions contains the transitions of the input Word-Graph */

  ArrayOfTransitions = ReadWordGraph(); 

 /*****************************************/
 /******* Then parse it        ************/
    n = TheSen->length; 
    PRS("Sentence length is: ");PRI(n);PRS("\n");
 if (ERROR == false)
   {
    Double_PARSE(&CKYTAB, TheWG, &S, n, &PARF, Duo); 

    if ((_DisambiguateB == true) && (ERROR == false))
     {if (Semi_Interleaved == false) CompDFTable(CKYTAB,n, Duo);
      ShowMPD_OfPF(PARF); 
      /* CountNodesInTAB(CKYTAB, n); */
     }
    else {/*ShowAllStartItemsWG(CKYTAB,n);*/}
  }
 else {/*printf("\n Syntax Error: unexpected word in input sentence.\n");
       printf(" Word %d is not acceptable !!\n", (TheSen->length+1));*/
       /* PRS("tree(XXXnonparsable,[]).\n"); */ EXIT(NONP);
      }
/*
 {finish = times(&bufstr);
 FinishT = bufstr.tms_utime + bufstr.tms_cutime;
 fprintf(stdout, "%s", "CPU-time is (in secs.): ") ;
 fprintf(stdout, "%f\n", ((float) ((FinishT - StartT)/60.0)));
 }
*/
 PRINTTIME();

 /* free(TheSen); free(S); free(CKYTAB); */
}
/*******/
void PRINTTIME()
{finish = times(&bufstr);
 FinishT = bufstr.tms_utime + bufstr.tms_cutime;
 fprintf(stdout, "%s", "CPU-time is (in secs.): ") ;
 /* PRBM((float) ((FinishT - StartT)/60.0));*/
 fprintf(stdout, "%.12f\n", ((float) ((FinishT - StartT)/60.0)));
}
