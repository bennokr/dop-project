#include "./ALL.h"
#include "./G12G2.h"
/*
struct G1toG2Struct {
   URSizeG1;
   BRSizeG1;
   TRSizeG1;
   EpsRSizeG1;
   RDomain *UG1toG2Arr;
   RDomain *BG1toG2Arr;
   RDomain *TG1toG2Arr;
   RDomain *EpsG1toG2Arr;
};
typedef struct G1toG2Struct *G1toG2;
*/
/* A global for this unit only !!!! */
G1toG2 GlobalG1toG2;

G1toG2 NewG1toG2(RDomain US, RDomain BS, RDomain TS, RDomain EpsS)
{G1toG2 Res = (G1toG2) AllocElem(sizeof(struct G1toG2Struct));
 Res->URSizeG1 = US; Res->BRSizeG1 = BS; Res->TRSizeG1 = TS; Res->EpsRSizeG1 = EpsS;
 Res->UG1toG2Arr = (RDomain *) MultAlloc(US,sizeof(RDomain));
 Res->BG1toG2Arr = (RDomain *) MultAlloc(BS,sizeof(RDomain));
 Res->TG1toG2Arr = (RDomain *) MultAlloc(TS,sizeof(RDomain));
 Res->EpsG1toG2Arr = (RDomain *) MultAlloc(EpsS,sizeof(RDomain));
 return Res;
}


RDomain TransFormRNum(ItemTree I)
{RDomain Res ; RDomain RNumber = I->RuleNo; RType RT = I->RT;

   switch (RT) {
      case _Unary : if ((RNumber >= URSize) || (RNumber < 0)) Res = UNVALID_RNUM;
                   else Res = GlobalG1toG2->UG1toG2Arr[RNumber];
               break;
      case _Binary : if ((RNumber >= BRSize) || (RNumber < 0)) Res =  UNVALID_RNUM;
                    else Res = GlobalG1toG2->BG1toG2Arr[RNumber];
               break;
      case _Term   : if ((RNumber >= TRSize) || (RNumber < 0)) Res = UNVALID_RNUM;
                    else Res = GlobalG1toG2->TG1toG2Arr[RNumber];
               break;
      case _Eps    : if ((RNumber >= EpsRSize) || (RNumber < 0)) Res = UNVALID_RNUM;
                    else Res = GlobalG1toG2->EpsG1toG2Arr[RNumber];
               break;
      otherwise :fprintf(stderr,"Err: impossible RType (%d  %d)\n", I->i, I->j);
               PItem(I); exit(1); break;
    }; 
 if (Res == UNVALID_RNUM)
   {PRI(RNumber); PRI(RT);PRS("\n"); PRI(URSize);PRI(BRSize);PRI(TRSize);PRI(EpsRSize);PRS("\n");
    fprintf(stderr, "Err: unknown rule number ...\n");exit(1);}
 return Res;
}

extern void UseInternGrammar(int GramNum);
extern void CloseExternGrammar(int GramNum);

/* Assumes G1 is in use */
RDomain TransFormRNumII(RDomain RNumOrig, RType RT)
{RDomain Res; NTDomain lhs, rhs1, rhs2; TDomain rhs1t; Rule_Ptr RP ;
 char *lhsname, *rhs1name, *rhs2name, *rhs1tname, *newlhsname, *newrhs1name;

 UseInternGrammar(1);
 /* RP = RulePtr_Of(RNumOrig, RT); */
 if (RT == _Term)
   {/* lhs = LHS_Of(RP); rhs1t = RHS1_Of(RP); OLD USE */
    lhs = LHS_OfR(RNumOrig, RT); rhs1t = RHS1_OfR(RNumOrig, RT); lhsname = Name(lhs); rhs1tname = TName(rhs1t); 

    /* translating to G2 */
    UseInternGrammar(2); 
    Res = RNumOfT(lhsname, rhs1tname); if (Res == UNVALID_RNUM) {fprintf(stderr,"Err in TransFormRNumII\n"); EXIT(0);}
    
    if ( (EQ_Strings(lhsname, Name(LHS_OfR(Res, _Term))) == false) ||
         (EQ_Strings(rhs1tname, TName(RHS1_OfR(Res, _Term))) == false) ) {fprintf(stderr,"Err in translating G1toG2 (TERM RULE)!!\n");exit(1);}

    UseInternGrammar(1);
    return Res;
    }
 else
   {/* lhs = LHS_Of(RP); rhs1 = RHS1_Of(RP); rhs2 = RHS2_Of(RP); OLD USE */
    lhs = LHS_OfR(RNumOrig, RT); rhs1 = RHS1_OfR(RNumOrig, RT); rhs2 = RHS2_OfR(RNumOrig, RT);
    lhsname = Name(lhs); rhs1name = Name(rhs1);  if (RT == _Binary) rhs2name = Name(rhs2); else rhs2name = NULL;

    UseInternGrammar(2); 
    Res = RNumOfNT_ByLHS(lhsname,rhs1name,rhs2name,RT); 
    if (Res == UNVALID_RNUM) {fprintf(stderr,"Err in TransFormRNumII %s --> %s %s \n", lhsname, rhs1name, rhs2name); EXIT(0);}

    if ( (EQ_Strings(lhsname, newlhsname = Name(LHS_OfR(Res, RT))) == false) ||
         (EQ_Strings(rhs1name, newrhs1name = Name(RHS1_OfR(Res, RT))) == false) ) 
         {fprintf(stderr,"Err in translating G1toG2  (LHS or RHS1): %s -->%s  vs %s-->%s\n", lhsname, rhs1name, newlhsname, newrhs1name);exit(1);}
    if (RT == _Binary) if (EQ_Strings(rhs2name, Name(RHS2_OfR(Res, RT))) == false) {fprintf(stderr,"Err in translating G1toG2 (RHS2) !!\n");exit(1);}

    UseInternGrammar(1);
    return Res;
   }
}

/* Assumes that G1 is the grammar in use                */
/* construct a transformation from G1 rules to G2 rules */
/* After Constructing this transformation, one can use  */
/* the function TransFormRNum above                     */
void  ConstructG1toG2()
{G1toG2 Res = NULL; RDomain i; 

 UseInternGrammar(1);
 Res = NewG1toG2(URSize, BRSize, TRSize, EpsRSize);

 for (i=0; i < URSize; i++) Res->UG1toG2Arr[i] = TransFormRNumII(i, _Unary);
 for (i=0; i < BRSize; i++) Res->BG1toG2Arr[i] = TransFormRNumII(i, _Binary);
 for (i=0; i < TRSize; i++) Res->TG1toG2Arr[i] = TransFormRNumII(i, _Term);
 if (EpsRSize > 0) for (i=0; i < EpsRSize; i++) Res->EpsG1toG2Arr[i] = TransFormRNumII(i, _Eps);
 else Res->EpsG1toG2Arr = NULL;

 GlobalG1toG2 = Res;
}
