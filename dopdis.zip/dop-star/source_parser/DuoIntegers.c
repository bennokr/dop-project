#include "./ALL.h"

/******
struct DuoStr {
     TreeCodeT RsNum;
     TreeCodeT OsNum;
};
typedef struct DuoStr *DuoPtr;
*******/
inline
DuoPtr NewDuo()
{DuoPtr Duo = (DuoPtr) AllocElem(sizeof(struct DuoStr));
 Duo->RsNum = 0;
 Duo->OsNum = 0;
 return (Duo);
}
inline
DuoPtr CleanDuo(DuoPtr Duo)
{if (Duo != NULL)
  {Duo->RsNum = 0; Duo->OsNum = 0; return (Duo);}
 else return NULL;
}
