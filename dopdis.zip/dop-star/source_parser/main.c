#include "./ALL.h"
#include "./RAMcodes.h"
#include "./NgramsGrammar.h"
#include "./UnknownWords.h"
#include "./unary_bamboo_functions.h"
#include <sys/resource.h>
#include <unistd.h>
/**/
/************** My own files  ********/
/*  Main takes an input and output file and*/
/*  parses the sentences in the input files */
/*******************************************/
/*
extern int getopt( int argc, char* argv[], char* optstring );
extern char* optarg;
extern int optind, opterr;
*/

Boolean _glob_exact_match_pos = true;

extern Boolean Right_Linear;
extern Boolean _DisambiguateB;
extern Boolean _MakePForest;
extern Boolean _FullSenRec;
extern Boolean _OutNoContext;
extern void USAGE(char *basename);
extern void OpenCodesFiles();
extern void CloseCodesFiles();
extern Boolean _APPLY_PRUNE;
extern Boolean _Break_Cycles;
extern void ShowInputFormat();

Boolean _Count_Parses = false;
struct rusage *UsagePtr =  NULL; 
struct rusage *UsagePtrCh = NULL; 
extern char CodeBINName[];
extern char ChPlBINName[];          
extern ProbDomain GetProbOfBigram(char *CW1, char *W);
/*
**
*/
extern void yyparse();
extern void PrintDinSet(DinSet set);
extern ProbDomain _Lambda_LRR;

#define LEN_DIR_PATH   2048
static char CU_DIRECTORY[LEN_DIR_PATH];

int Length_Cut_off = 10000;

int main(argc, argv, envp)
int argc;
char **argv, **envp;
{char* options = "0HBdn@#UIsptbCWhSNci:o:M:m:K:D:!:A:+:l:f:F:T:R:P:"; 
 int  opt_ch; ProbDomain tmp; int IntTmp;  int i;
 int error_flag = 0; 
 char CHAR;
 FILE *fopen(); clock_t start, finish; double duration;
 Right_Linear = false;
 fpOUT = stdout; fpIN = stdin;
 strcpy(CU_DIRECTORY,getenv("PWD")); 
 MPP_Sample_Size = 0;

  opt_ch = getopt( argc, argv, options );
  while ( opt_ch != -1 )
   {switch( opt_ch ) {
     case '0' :  ShowInputFormat(); exit(1);
		 break;
     case '+' : sscanf( optarg, "%lf", &tmp ); _Lambda_WG = (ProbDomain) tmp; 
                if ((tmp>1) || (tmp<0)) 
		    {fprintf(stderr, "Interpolation factor is in [0,1] range\n");exit(1);}
                _WORDGRAPH_PROBS_METHOD = _INTERP_INTEGRATION;     
                 fprintf( stderr, 
		 "Interpolating Wordgraph probs (%f) with Grammar Probs (%f)\n", _Lambda_WG, 1-_Lambda_WG);
                break;
     case 'A' : sscanf( optarg, "%lf", &tmp ); _Lambda_LRR = (ProbDomain) tmp; 
                if ((tmp>1) || (tmp<0)) {fprintf(stderr, "Interpolation factor is in [0,1] range\n");exit(1);}
                _PARSER_VERSION = _GLRR_VERSION;     
                break;
     case 'H' :  HEBREW_POSTAG_SIMILARITY = true;
                 break;
     case 'B' :  _PARSER_VERSION = _LRRMPD_VERSION;
                 break;
     case 'T' :  sscanf( optarg, "%c", &CHAR ); 
		 if (CHAR=='W') _which_corpus = _WSJ;
		 else if (CHAR=='N') _which_corpus = _Negra;
		      else if (CHAR=='H') _which_corpus = _Hebrew;
		           else _which_corpus = _GENERAL;
	         switch (_which_corpus)
		 {       case _Hebrew: fprintf(stderr, "Current corpus is Hebrew\n"); break;
			 case _WSJ: fprintf(stderr, "Current corpus is Wall Street Journal\n"); break;
			 case _Negra: fprintf(stderr, "Current corpus is Negra\n"); break;
			 case _GENERAL: break;
		 }
                 break;
     case 'F' :  sscanf( optarg, "%d", &IntTmp ); 
		 _FilterPosTags = true; _match_on_unknown_only = true;
		 if (IntTmp==0) _glob_exact_match_pos = false;
		 else _glob_exact_match_pos = true;
                 break;
     case 'f' :  sscanf( optarg, "%d", &IntTmp ); 
		 if (IntTmp==0) _glob_exact_match_pos = false;
		 else _glob_exact_match_pos = true;
		 _FilterPosTags = true; 
                 break;
     case '@' :  _Allow_Same_Level = true; 
                 break;
     case '#' : _PoSTagSequencesInput = true;
                 break;
     case 'I' : ShowIdentity(); exit(0);
                 break;
     case 'C' : _Break_Cycles = false; 
                 break;
     case 'P' : _APPLY_PRUNE = true;   Semi_Interleaved = true;  
		 sscanf( optarg, "%d", &IntTmp );  
		 switch (IntTmp) {
                   case 0: _PRIOR_KIND_GLOB_EX = _by_nont; break;
                   case 1: _PRIOR_KIND_GLOB_EX = _by_nont_w_lpos; break;
		   default: fprintf(stderr,"Err: -P{0,1} only\n"); exit(1); break;
		 }
                 break;
     case '!' : sscanf( optarg, "%s", &CU_DIRECTORY); 
                break;
     case 'L' : fprintf(stderr,"Option -L is currently not available\n");
		exit(1); /*  LEXICALIZED_WSJ = true; */
                break;
     case 'N' : _DisambiguateB = false; 
                break;
     case 'l' : sscanf( optarg, "%d", &IntTmp ); 
		fprintf(stderr,"Cutoff sentence length is %d\n", IntTmp);
		Length_Cut_off=IntTmp; break;
     case 'm' : sscanf( optarg, "%d", &IntTmp ); MPP_Sample_Size = IntTmp;
	       	_Print_All_Sampled = false; _Print_All_Sampled_DER = false;
                _PARSER_VERSION = _MPP_VERSION; 
                break;
     case 'M' : sscanf( optarg, "%d", &IntTmp ); MPP_Sample_Size = IntTmp;
	       	_Print_All_Sampled = true; _Print_All_Sampled_DER = false;
                _PARSER_VERSION = _MPP_VERSION; 
                break;
     case 'K' : sscanf( optarg, "%d", &IntTmp ); MPP_Sample_Size = IntTmp;
	       	_Print_All_Sampled = false; _Print_All_Sampled_DER = true;
                _PARSER_VERSION = _MPP_VERSION; 
                break;
     case 'D' : sscanf( optarg, "%d", &IntTmp ); MPP_Sample_Size = IntTmp; 
                _PARSER_VERSION = _MPD_VERSION; 
                break;
     case 'd' : _PARSER_VERSION = _GLRR_VERSION;
                break;
     case 'W' : _Whole_DFSpace = true;
                break;
     case 'R' : Right_Linear = true; sscanf( optarg, "%d", &IntTmp );
                if (IntTmp==1)  _FullSenRec = true; else  _FullSenRec = false;
                break; 
     case 'X' : _DisambiguateB = false; _OutNoContext = true; 
                break;
     case 'S' : Semi_Interleaved = true; 
                break;
     case 's' : _SpareMemoryPruning = true; 
                break;
     case 'b' : _BIGRAM_PRUNE = true; 
                break;
     case 't' : _Show_PosTags_global = true;
                break;
     case 'p' : ParsingMethod = _SKND_G_ONLY; break;    
                break;
     case 'U' : _Resolve_Unknown = false; 
                break;
     case 'i' : 
           if ((fpIN = fopen(optarg, "r")) == NULL) printf("Can't open %s\n", *argv);
           break;
     case 'c' : _DisambiguateB = false; _Count_Parses = true; _ShowChunks = true; break;
     case 'o' :
           if ((fpOUT = fopen(optarg, "w")) == NULL) printf("Can't open %s\n", *argv);
           break;
     case 'h' : error_flag++; break;
     case '?' : error_flag++; break;
    }
    opt_ch = getopt( argc, argv, options );
   }
        /* case file names without -i and -o */
   if ( argc - optind > 0 ) 

    if (fpIN == stdin)
     {if (argv[optind][0] != '-')
       {fpIN = fopen( argv[optind], "r" );
        if ( !fpIN ) 
         {fprintf( stderr, "File <%s> does not exist\n", argv[optind] ); exit( 1 );}
       }
      else error_flag++;
     }
    else /* input file read */
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }

   if ( argc - ++optind > 0 ) 
    if (fpOUT == stdout)
     if (argv[optind][0] != '-')
     {fpOUT = fopen( argv[optind], "w" );
      if (!fpOUT) {fprintf( stderr, "File <%s> cannot be opened\n", argv[optind] );exit(1);}
     }
    else error_flag++;
   else error_flag++;

         /* In case of error  */
   if ( error_flag )
   {char* basename = strrchr( argv[0], '/' );

    if ( basename ) basename++;
    else basename = argv[0];
    USAGE(basename);
      exit( 1 );
   }


  if (CU_DIRECTORY[strlen(CU_DIRECTORY)-1] !='/') strcat(CU_DIRECTORY,"/");
  /** Do the parsing **/


  yyparse();

 return 0;
}
/*******************************************/
/*******************************************/
/*******************************************/
/****** GLOBAL VARIABLES ******************/
extern void InitGrammar();
extern Sentence TheWG;
extern Sentence TheSen; 
extern TDomain *S; /*** The input sentence encoded */
extern Boolean ERROR;
extern TableType CKYTAB; /*** The CYK table.             */
extern ParForest PARF ;
extern Boolean Interleaved;
extern TDomain *TagSentence(Sentence S);
extern TDomain *TagUnknownWs(Sentence WG, TDomain *Sen); 
extern void PrintUnknownWs(Sentence WG, TDomain *Sen); 
/*******************************************/
/* A global that is used NOT as a global in the original
   parser. Due to the addition of the Interleaved mode
   and for the sake of minimizing changes in the original
   parser, we had to allow this global to be there.
   Appologies for this !!
***/
int start, finish, midT;
/**** TIMING globals **/
clock_t StartT, FinishT, MidT;
struct tms bufstr;
struct tms *buffer;
/***/

void yyparse()
{extern int yylex();
 int ex,i;
 NodePtr NP;

 TestGlobalSetting(); 
 PARF = CrParF(); ERROR = false; _sen_length =0; Duo = NewDuo(); 

 {bufstr.tms_utime = 0; bufstr.tms_cutime = 0; start = times(&bufstr); StartT = bufstr.tms_utime + bufstr.tms_cutime;}
 /******* Initialize all kind of values (Grammar parameters etc) ****/
 if (NUM_OF_GRAMS() == SINGLE_G)
   {OpenCodesFiles();
    InitGrammar(); /* for single-grammars we initialize here */ 
    InitializeRAM_RApps();
    Init_Various_PriorProbs_Tables(); /* Show_PriorProbs(); exit(1); */
   }
 else if (ParsingMethod == _BOTH_G) UseGrammar(1);
      else UseGrammar(2);

 /***** First read the sentence or word-graph ***********/
 /* ArrayOfTransitions contains the transitions of the input Word-Graph */

 ArrayOfTransitions = ReadWordGraph(); 

 /*****************************************/
 /******* Then parse it        ************/
 _sen_length = TheSen->length;

 /* if (1==1) if (_sen_length > 18) _PARSER_VERSION = _MPD_VERSION; */

  if (1==0) 
   { if (TheSen->length <= 15 )
	 {_APPLY_PRUNE = false; Semi_Interleaved=false; fprintf(stderr, "Note: parsing without pruning\n"); }}

  { if (TheSen->length > Length_Cut_off) ERROR = true; }

  if (1==0) { if (TheSen->length > 500) _SpareMemoryPruning = true; }

 Init_pruning_parameters();

 if (_Show_PosTags_global == false) {fprintf(stderr,"Sentence length is: %d\n", _sen_length);}

 if (ERROR == false)
   {if (NUM_OF_GRAMS() == SINGLE_G)
      {S = TagSentence(TheWG); 
        if (ERROR == true)
          if (_Resolve_Unknown == true) {ERROR = false; S = TagUnknownWs(TheWG, S);}
          else ERROR = false;
        else;
      }
    else ; /* done in Double_PARSE after grammar initialization */

    if (ERROR == true) {fprintf(stderr,"\n Error1: Exiting due to unknown words:\n");  PrintUnknownWs(TheWG, S);  EXITA(NONW,false);}
    else
    if ( ((S != NULL) && (ERROR == false)) || (NUM_OF_GRAMS() == DOUBLE_G))
      {

       switch (NUM_OF_GRAMS()) {
         case SINGLE_G: fprintf(stderr, "Parsing ... \n");
                        CKYTAB = PARSE(&CKYTAB, S, _sen_length, Duo);  
                        fprintf(stderr, "Delimiting the parse-space ...\n");
                        /* PrintTable(CKYTAB, _sen_length); */
                        PARF = GenParF(CKYTAB, _sen_length); 
                        if (Semi_Interleaved == false) FreeUnvalidItems(CKYTAB, _sen_length);
                   break;
        case DOUBLE_G: Double_PARSE(&CKYTAB, TheWG, &S, _sen_length, &PARF, Duo); 
                   break;
       }/* end-of-switch */

       if (_DisambiguateB == true)
        {CompDFTable(CKYTAB, _sen_length, Duo); 
         if (_PARSER_VERSION == _MPD_VERSION) ShowMPD_OfPF(PARF); /* do MPD */
         else  if (_PARSER_VERSION == _MPP_VERSION) SampleDerfromPF(PARF); /* do MPP */
               else if (_PARSER_VERSION == _LRRMPD_VERSION)
                     {ShowMPD_OfPF(PARF); MaxGlobalRecallRate(CKYTAB, PARF, _sen_length); }
                    else MaxGlobalRecallRate(CKYTAB, PARF, _sen_length);
               
           /* CountNodesInTAB(CKYTAB, _sen_length); */
        }
       else 
         {/* ShowAllStartItems(CKYTAB,_sen_length); PRS("\n"); */ if (_Count_Parses == true) NumOfNodesInPF(PARF);}
         CloseCodesFiles();
     } /* if no error */ 
  else if (ERROR == false) {/*  PRS("tree(XXXnongram,[]).\n"); */ EXITA(NONG,false);}
 } /* if no error */
 else {EXITA(NONP,false);}

 PRINTTIME(); /* free(TheSen); free(S); free(CKYTAB); */

 /* FreeTable(CKYTAB, _sen_length);
  FreeParForest(PARF);
 FreeWordGraph(TheSen);
 FreeWordGraph(TheWG);
 */
 fflush(stderr);fflush(fpOUT);
 exit(0);
}
/*******/
/*--------------------------*/

void USAGE(char *basename)
{
 fprintf(stderr, "\n");
 fprintf(stderr, "\n");
 fprintf(stderr, "Usage: %s [options] -i <infile> -o <outfile> \n", basename );
 fprintf(stderr, "   or: %s [options] [infile] [outfile] \n", basename );
 fprintf(stderr, "\n");
 fprintf( stderr, "Information options:\n" );
 fprintf( stderr, "  -I  About this parser (information)\n");
 fprintf( stderr, "  -0  Print the input format that this parser expects\n" );
 fprintf( stderr, "  -h  Print this message\n" );
 fprintf( stderr, "Tree-bank options (for some morphology of unknown words - only when parser is trained suitably!!):\n" );
 fprintf( stderr, " -T [WNHG]: WSJ (W), Negra (N), Hebrew (H), General (G) which is the default (i.e. no assumptions)\n" );
 fprintf( stderr, "\n" );
 fprintf( stderr, "First options:\n" );
 fprintf( stderr, "  -T[]  \n");
 fprintf( stderr, "  -l<int>  Cutoff length at <int> (sentences longer than <int> are discarded)\n");
 fprintf( stderr, "  -U  Do NOT attempt resolving unknown words\n");
 fprintf( stderr, "  -#  Parsing PoSTag sequences instead of morpheme sequences (for Hebrew)\n");
 fprintf( stderr, "  -@  Do not try to avoid cycles (for OVIS)\n");
 fprintf( stderr, "  -!<directory> specifies that the binary files .CodesFile.bin and .ChildsPaces.bin are found at directory \n");
 fprintf( stderr, "  -f[0,1] Filter according to constituents given in the input (CAT/word style)\n" );
 fprintf( stderr, "  -F[0,1] like -f[0,1], but for POSTAGs given in input filter only for unknown words (CAT/word style)\n" );
 fprintf( stderr, "          0 implies given CAT is Prefix of allowed CAT \n" );
 fprintf( stderr, "          1 implies given CAT is Equal to allowed CAT \n" );
 fprintf( stderr, "          \n" );
 fprintf( stderr, "Options for disambiguation algorithm (instead of MPD):\n" );
 fprintf( stderr, "  -m<#num>  Select the Most Probable Parse (MPP) (default is MPD) using <#num> sample-size\n");
 fprintf( stderr, "  -M<#num>  like -m but also printout all sampled parses\n");
 fprintf( stderr, "  -K<#num>  like -m but also printout all sampled derivations\n");
 fprintf( stderr, "  -d        Compute Goodman's Max Recall Rate Parse\n");
 fprintf( stderr, "  -B        Compute both Goodman's Max Recall Rate Parse and the MPD\n");
 fprintf( stderr, "  -A<#fac>  Interpolate Max Recall Rate with Context-Free Recall Rate and Parent-Child Rate\n");
 fprintf( stderr, "            Linear interpolation   fac*LRR + ((1-fac)/2)*CFPR + ((1-fac)/2)*PaCh \n");
 fprintf( stderr, "More options:\n" );
 fprintf( stderr, "  -+<#fac>  Interpolate Wordgraph probs (fac) with Lexical Grammar Probabilities (1-fac) \n");
 fprintf( stderr, "  -C  Do all chains of unaries (see default below - but break any chains deeper than 20)\n" );
 fprintf( stderr, "  -P{0,1}  Prune derivation-forest using BEAM-with-Priors !!\n");
 fprintf( stderr, "         0  Prior is marginal prob of constituent label !!\n");
 fprintf( stderr, "         1  Prior is joint prob of constituent label and postag immidiately to its left!!\n");
 fprintf( stderr, "  -S  Semi-Interleaved computation of parse- and derivation-forest\n");
 fprintf( stderr, "  -b  Apply a bigram-language model for some pruning of the Part-Of-Speech Tags before parsing\n");
 fprintf( stderr, "  -t  Print-out the Part-Of-Speech Tags that are assigned to the words (don't parse)\n");
 fprintf( stderr, "  -N  Only recognize, don't disambiguate, don't build parse forest\n" );
 fprintf( stderr, "  -c  SINGLE GRAMMAR: Like -N but also count the number of parses in *ECNF* CFG parse-forest\n" );
 fprintf( stderr, "      DOUBLE GRAMMAR: Show the chunks constructed by the first grammar (skip any further parsing)\n");
 fprintf( stderr, "  -R[0,1]  Parse under the assumption that the grammar is a right linear grammar (finite-state)\n" );
 fprintf( stderr, "       0: just parse under right linear assumption\n" ); 
 fprintf( stderr, "       1: Assumes -R, Input contains NO context: retrieve full sentence\n" ); 
 fprintf( stderr, "  -p  SINGLE GRAMMAR: has no effects\n");
 fprintf( stderr, "      DOUBLE GRAMMAR: parse input using only the second grammar (don't employ the first)\n");   
 fprintf( stderr, "  -W  Build WHOLE derivation-forest (don't optimize assuming MPD)\n");
 fprintf( stderr, "  -s  spare memory in pruning (simply does stricter pruning)\n");
 fprintf( stderr, "  -H  (Hebrew Only: POSTAG in input) Match unknown POSTAGs in input to known ones by similarity\n");
 fprintf( stderr, "    [DEFAULT: all options are set OFF]\n");
 fprintf(stderr, "\n");
/* fprintf(stderr, "--------------------------------------------------------------------------\n");
 ShowInputFormat();
*/ fprintf(stderr, "--------------------------------------------------------------------------\n");
 fprintf( stderr, "Options that are currently not in use:\n");
 fprintf( stderr, "  -L  Assume a WSJ head-lexicalized STSG\n");  
 fprintf( stderr, "  -X  (Assumes -N, Input must contain context) Discard context effect from output\n"); 
 fprintf( stderr, "  -I  Interleaved computation of parse- and derivation-forest: one-phase parser\n");
 fprintf( stderr, "------------- \n");
 fprintf( stderr, " NOTES: 1. The symbols \"sss\", \"ssss\", \"xxxprior\" and \"xxxunknown\" are reserved\n");
 fprintf( stderr, "        2. This parser might have problems with cyclic rules X->X\n");
 fprintf( stderr, "        3. This parser cuts off chains of unary rules at chain-length 2.\n");
 fprintf( stderr, "        4. This parser does not accept epsilon rules.\n");
 fprintf( stderr, "------------- \n");
}
void OpenCodesFiles()
{char CodeFileName[1000]; char ChsFileName[1000];
 strcpy(CodeFileName,CU_DIRECTORY); strcpy(ChsFileName,CU_DIRECTORY);
 strcat(CodeFileName,CodeBINName); strcat(ChsFileName,ChPlBINName);

          if ((fpCodes = fopen(CodeFileName, "r")) == NULL)
                               {printf("Can't open %s\n", CodeFileName);
                                exit(1);}
          if ((fpChsPl = fopen(ChsFileName, "r")) == NULL)
                              {printf("Can't open %s\n", ChsFileName);
                                exit(1);}
}
void CloseCodesFiles()
{char CodeFileName[1000]; char ChsFileName[1000];
 strcpy(CodeFileName,CU_DIRECTORY); strcpy(ChsFileName,CU_DIRECTORY);
 strcat(CodeFileName,CodeBINName); strcat(ChsFileName,ChPlBINName);

          fclose(fpCodes); fclose(fpChsPl);
}
int YYLEXXX()
{return (yylex());
}

void ShowInputFormat()
{
 fprintf( stderr, "This parser has various input formats:\n");
 fprintf( stderr, "  A. Simple sentence as sequence of words (form I below)\n");
 fprintf( stderr, "  B. Stochastic Finite State Automaton (form II below)\n");
 fprintf( stderr, "     This allows the output of e.g. a speech-recognizer to be pipelined to the parser\n");
 fprintf( stderr, "  C. A set of labeled constituents (form III below)\n");
 fprintf( stderr, "     A set of constituents in the input is used to filter (option -f[0,1]) the parse-space\n");
 fprintf( stderr, "     only to those parses that include the given constituents\n");
 fprintf( stderr, "\n");
 fprintf( stderr, "Definitions: -Words or terminals ([a-zA-Z]+_)\n");
 fprintf( stderr, "             -Nonterminals ([a-zA-Z][a-zA-Z-]*)\n");
 fprintf( stderr, "                          ([a-zA-Z][a-zA-Z-]*@)\n");
 fprintf( stderr, "             -Reserved are the words: XXXunknown, xxxunknown, xxxprior, xxxphrase_\n");
 fprintf( stderr, "             -Below 1 <= i < j <= (sentence_length+1)\n");
 fprintf( stderr, "\n");
 fprintf( stderr, "Format I: Sequence of words followed with a full stop \".\"\n");
 fprintf( stderr, "Format II: Sequence of transitions followed with a full stop \".\" where:\n");
 fprintf( stderr, "            A transition is a quadraple  \"i j word probability\" (probability may be ommitted)\n");
 fprintf( stderr, "            where (1 <=i < j <= sentence_length+1); probability is log_10(probability);\n");
 fprintf( stderr, "Format III: Sequence of labeled-constituents followed with a full stop \".\" where:\n");
 fprintf( stderr, "            A labeled-constituent is a five-tuple \"i j CAT/word probability\" (probability may be ommitted\n");
 fprintf( stderr, "            where (1 <=i < j <= sentence_length+1); probability is log_10(probability);\n");
 fprintf( stderr, "            CAT is a phrasal category (non-terminal) such that if the category CAT is not \n");
 fprintf( stderr,"             a postag, i.e. a higher level category, then (j-i>1) and (word==xxxphrase_).\n");
}


