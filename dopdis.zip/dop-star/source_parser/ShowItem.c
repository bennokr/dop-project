#include "./ALL.h"

/**************************/
void ShowRHS2(RDomain Rno, 
     RType RT, DOTPLACE dot)
{Rule_Ptr RPtr;
 NTDomain lhs, rhs1, rhs2;
 RPtr = RulePtr_Of(Rno, RT); rhs2 = RHS2_Of(RPtr);  
 
 /* G_Array = Rhs2Array; */
 PRS(Name(rhs2));
}
void ShowRHS1(RDomain Rno, 
     RType RT, DOTPLACE dot)
{Rule_Ptr RPtr;
 NTDomain lhs, rhs1, rhs2;
 RPtr = RulePtr_Of(Rno, RT);
 rhs1 = RHS1_Of(RPtr);  
 
 if (RT == _Term) PRS(TName(rhs1));
 else {/* G_Array = NTArray; */
       PRS(Name(rhs1));}
}
void ShowLHS(RDomain Rno, 
     RType RT, DOTPLACE dot)
{Rule_Ptr RPtr;
 NTDomain lhs, rhs1, rhs2;
 RPtr = RulePtr_Of(Rno, RT);
 lhs = LHS_Of(RPtr); 
 /* G_Array = NTArray; */
 
 PRS(Name(lhs));
}
void ShowItem(RDomain Rno, RType RT, DOTPLACE dot)
{Rule_Ptr RPtr;
 NTDomain lhs, rhs1, rhs2;
 RPtr = RulePtr_Of(Rno, RT);
 lhs = LHS_Of(RPtr); rhs1 = RHS1_Of(RPtr); rhs2 = RHS2_Of(RPtr); 
 /* G_Array = NTArray; */
 
 PRS("<"); 
 PRS(Name(lhs)); PRS(" -> "); WRDot(dot, lm);
 if (RT == _Term) {PRS(TName(rhs1)); WRDot(dot, mid);}
 else {PRS(Name(rhs1)); WRDot(dot, mid);
       if (RT == _Binary) {PRS(" ");PRS(Name(rhs2)); WRDot(dot, rm);}
      }
 PRS(">"); 
}
void LarLevel(void *PtrA, void *PtrB, Boolean *LAR)
{ItemTree A = (ItemTree) PtrA;
 ItemTree B = (ItemTree) PtrB;
 *LAR = false;
 *LAR = (A->Level >= B->Level) ? true : false;
}
/*** Moved to Item.c ***
void VEqItems(void *PtrA, void *PtrB, Boolean *EQ)
{ItemTree A = (ItemTree) PtrA;
 ItemTree B = (ItemTree) PtrB;
 *EQ = (A == B) ? true: false;
}
****/
/*************************************************/
Boolean IsEnded_Item(ItemTree item)
{
 switch (item->RT) {
   case _Binary : if (item->Dot == rm) return true; else return false;
                 break;
   case _Unary : if (item->Dot == mid) return true; else return false;
                 break;
   case _Term : if (item->Dot == mid) return true; else return false;
                 break;
   case _Eps : return true;
                 break;
   default : printf("Err: item type undefined\n"); 
              return false;
                 break;
 } /* switch */
}
/****************/
void Disconnect(ItemTree Parent, ItemTree Child)
{ItemTree TEMP;
     void EqCh(void *chi, Boolean *EQ)
       {ItemTree CH = (ItemTree) chi;
        *EQ = (CH == TEMP) ? true : false;
       }
     void REMOVE(PtrList P)
       {P->Data = PLRemoveIf((PtrList) P->Data, &EqCh);
        if (P->Data == NULL) P->Ptr = NULL;
       }
 switch (Parent->RT) {
   case _Term   : break;
   case _Eps    : break;
   case _Unary  : TEMP = Child;
            Parent->AddedBy = PLRemoveIf(Parent->AddedBy, &EqCh);
            TEMP = Parent;
            /* Child->Adds = PLRemoveIf(Child->Adds, &EqCh);*/
           break;
   case _Binary : TEMP = Child;
            PDListMap(Parent->AddedBy, (void *) &REMOVE);
            TEMP = NULL;
            Parent->AddedBy = PLRemoveIf(Parent->AddedBy, &EqCh);
            TEMP = Parent;
            /* Child->Adds = PLRemoveIf(Child->Adds, &EqCh);*/
           break;
   otherwise : break;
 } 
}
/********************/
void PRHS1(ItemTree item)
{AppToItem(item, (void *) &ShowRHS1);}
void PRHS2(ItemTree item)
{AppToItem(item, (void *) &ShowRHS2);}

void PRHS1V(void *IV)
{PRHS1((ItemTree) IV);PRS("\n");}

void PLHS(ItemTree item)
{AppToItem(item, (void *) &ShowLHS);}
