/***************************************************************/
/*** THIS MODULE CAN BE DISTRUCTIVE:                           */
/* Whenever WhatToDo is set to AddedBy it computes MAX_GLLR and*/
/* during maximization it destroys the AddedBy structure for   */
/* items in order to put in it the maximimum children only     */
/* USE The AddedByMaxGRR instead to avoid this                 */
/***************************************************************/
/***************************************************************/
/**/
#include "./ALL.h"
#include "./GenHashUnit.h"
#include "./GenHASHTABLE.h"
#include "./InsideOutside.h"
extern char *ImageNontOf(NTDomain NTnum);


/*
**
**
*/
/* IMG has either value "Name" or "ImageNontOf" */
#define IMG  Name
/************************************/
#define _DEBUG    		false
#define _DEBUG_EX 		false
#define _DEBUG_EX_II 		false
#define _PR_ITEM(I)          	true 
#define _DEBUG_TERM_ENTRIES 	true

#define _INTERP_ALL   true   /* keep true unless you want to use the following instead */
#define _INTERP_CFPR  false                                   
#define _INTERP_P_CHR ((_INTERP_CFPR == true) ? false : true ) 
#define _NUM_OF_ALGORS  ((_INTERP_ALL==true) ? 3 : 2)

ProbDomain _Lambda_LRR = ((ProbDomain) 1);     /* LRR is preferred unless ...*/
#define _REST_FAC               ((((ProbDomain) 1.0) - _Lambda_LRR)/((ProbDomain)(_NUM_OF_ALGORS-1)))
#define _Lambda_CFPR		( _REST_FAC )
#define _Lambda_PACH		( _REST_FAC ) 
#define _USE_RR_PER_NONT  	true

void _PRINT_IDEN_ALG()
{if (_INTERP_ALL == true)
  fprintf(fpOUT,"CFPR (%1.2f\%) + LRR (%1.2f\%) + PaCh (%1.2f\%)\n", _Lambda_CFPR,_Lambda_LRR,_Lambda_PACH);
 else
 if (_INTERP_CFPR == true) fprintf(fpOUT,"CFPR (%1.2f\%) algorithm interpolated with LRR (%1.2f\%)\n", _Lambda_CFPR,_Lambda_LRR);
 else
 if (_INTERP_P_CHR == true) fprintf(fpOUT,"P_CHR (%1.2f\%) algorithm interpolated with LRR (%1.2f\%)\n", _Lambda_CFPR,_Lambda_LRR);
 else ;
}
/************************************/
/* Parameters that I am unsure of  */
#define _UNARY_IN_GLRR    	true
#define _AVG_UNARY_LRR    	true
#define SYM_LENGTH              500
/**/
ProbDomain AvgProbs(ProbDomain A, ProbDomain B)
{return DevideProbs(SumProbs(A,B), Trans_2_log10((double) 2));
}

Boolean AverageQ(ItemTree I)
{if ((I->i!=0) || (I->j!=_sen_length)) return true;
 else if ((EQ_Strings(Name(LHS_OfItem(I)),"sss") == true)
         || (EQ_Strings(Name(LHS_OfItem(I)),"ssss") == true)) return false;
      else return true;
} 

ProbDomain InterploteMetrics(ProbDomain LRR, ProbDomain CFPR, ProbDomain P_CHR)
{ProbDomain LRRfactor  = MultProbs(Trans_2_log10((double) _Lambda_LRR), LRR);
 ProbDomain CFPRfactor = MultProbs(Trans_2_log10((double) _Lambda_CFPR), CFPR);
 ProbDomain PA_CHfactor = MultProbs(Trans_2_log10((double) _Lambda_PACH), P_CHR);

 if (_INTERP_ALL == true)
    return (SumProbs(SumProbs(LRRfactor,CFPRfactor),PA_CHfactor));
 else
 if (_INTERP_CFPR == true) return SumProbs(LRRfactor, CFPRfactor);
 else if (_INTERP_P_CHR == true) return SumProbs(LRRfactor, PA_CHfactor);
      else {fprintf(stderr,"Err: limited choice: CFPR or PA_CHR");exit(1);}
}

/***********************************/
/***********************************/
/***********************************/
/* FIXED PARAMETERS                */
/***********************************/
#define _No_Outside PseudoValid

/* THE FOLLOWING CAN TAKE VALUES OF PtrLists in Item.h e.g. AddedBy or AddedByMaxGRR */
#define WhatToDo AddedByMaxGRR

enum _WHAT_TO_COMP_TYPE {_GLRR=1,_MPDTE=2};
enum _WHAT_TO_COMP_TYPE WHAT_TO_COMPUTE = _GLRR;

#define _GLLR_4_ENDED_ITEMS_ONLY       true    /* LEAVE true: only ended items are counted in GLLR: unended items serve as temps only */
#define _DEBUG_BINARY_UPD false                /* KEEP THIS FALSE: IT IS WRONG TO DO */
/**/
/**/
/**/
/**/
/************/
static ProbDomain _GLOB_SEN_PROB = MultNutralConst;
extern Boolean ECNF_MARKED(char *Name); 
/********************************************************************************************************************************/
/* all kind of usefull functions that should have been included somewhere else (:-(                                             */
/********************************************************************************************************************************/
TreeCodeT GetChplace(DerFPtr P_DF, Child_Type chnum, Code_Soort CT, ItemCPtr ICPch)
{TreeCodeT Chplace = _C_Addr_UNV; Boolean FoundCh=false;

 Chplace = WhereIsChildOf(P_DF->CAdr, CT, chnum, &FoundCh);
 if ((FoundCh == true) && (Chplace != _C_Addr_UNV))
    {Chplace = ICPch->O_NowAtPos[Chplace];
     if ((Chplace < ICPch->OthersSize) && (Chplace != _C_Addr_UNV))   /* is the child code valid */
        return Chplace;
     else if (Chplace != _C_Addr_UNV) /* for controle only !! */
            {fprintf(stderr, "Err: Problems in ApplToSingle %u\n", Chplace); exit(1);}; 
    }

 return _C_Addr_UNV;
}

char *StringOfPA_CH(ItemTree I, Child_Type WhichCh)
{int LHS = (int) LHS_OfItem(I); int RHS1 = (int) RHS1_OfItem(I); int RHS2 ;
 static char RESULT[SYM_LENGTH]; 

 if (I->RT==_Binary) RHS2 = (int) RHS2_OfItem(I);   else RHS2 = UNVALID_SYMNUM;

 strcpy(RESULT,"");
 if (WhichCh==Lch_enum) 
   {strcpy(RESULT, IMG(LHS)); strcat(RESULT,"-L-"); 
    if (I->RT==_Term) strcat(RESULT, TName(RHS1));
    else strcat(RESULT, IMG(RHS1));
   }
 else
   {if (I->RT==_Binary) {strcpy(RESULT, IMG(LHS)); strcat(RESULT,"-R-"); strcat(RESULT, IMG(RHS2));}
    else strcpy(RESULT,UNVALID_SYM); /* for unaries there is no right child */
   }
 return RESULT;
}

char *StringOfProduction(ItemTree I)
{int LHS = (int) LHS_OfItem(I); int RHS1 = (int) RHS1_OfItem(I); int RHS2 ;
 static char RESULT[SYM_LENGTH]; 

 if (I->RT==_Binary) RHS2 = (int) RHS2_OfItem(I);   else RHS2 = UNVALID_SYMNUM;

 strcpy(RESULT,"");
   {strcpy(RESULT, IMG(LHS)); strcat(RESULT," "); 
    if (I->RT==_Term) strcat(RESULT, TName(RHS1));
    else {strcat(RESULT, IMG(RHS1));
          if (I->RT==_Binary) {strcat(RESULT," "); strcat(RESULT, IMG(RHS2));}
          else strcat(RESULT, UNVALID_SYM);
         }
   }
 return RESULT;
}
/*********************************************************************************************************************************/
/***  The Array used for gathering the per non-terminal (rather than item) Recall Rate values                                   **/
/***  The Array used for gathering the per non-terminal (rather than item) Recall Rate values                                   **/
/*********************************************************************************************************************************/
extern void ResetProbOfHTable(HASHTABLE HTP);

#define NTSizeOfArray   ((int) NonTSize)
#define PchSizeOfArray  ((int) URSize+BRSize)
HASHTABLE RecallRatePerNonT_Array; 
HASHTABLE ParentChRecallRate_Array ; 
HASHTABLE ProductionRecallRate_Array ; 


void InitArrayOfRR() 
{int i;
 if (RecallRatePerNonT_Array==NULL) RecallRatePerNonT_Array = NewHTable();
 else ResetProbOfHTable(RecallRatePerNonT_Array);

 if (ParentChRecallRate_Array==NULL) ParentChRecallRate_Array = NewHTable();
 else ResetProbOfHTable(ParentChRecallRate_Array);

 if (ProductionRecallRate_Array==NULL) ProductionRecallRate_Array = NewHTable();
 else ResetProbOfHTable(ProductionRecallRate_Array);
}

void UpdateLhsRR(ItemTree I)
{int LHS = (int) LHS_OfItem(I); static char PA_LCH[SYM_LENGTH]; static char PA_RCH[SYM_LENGTH]; 
 static char PROD[SYM_LENGTH]; 

 /* Per nonterminal Recall algorithm: LRR */
 (ENT2HTableAddProb(RecallRatePerNonT_Array, IMG(LHS), I->IN_X_OUT));

 /* for the PA_CH Rate algorithm */
 {/* For PA_CHR */
  strcpy(PA_LCH, StringOfPA_CH(I, Lch_enum)); strcpy(PA_RCH, StringOfPA_CH(I, Rch_enum));
  (ENT2HTableAddProb(ParentChRecallRate_Array, PA_LCH, I->IN_X_OUT));
  if (I->RT==_Binary) (ENT2HTableAddProb(ParentChRecallRate_Array, PA_RCH, I->IN_X_OUT));
 }
 /* for productions CFPR */
 {strcpy(PROD, StringOfProduction(I));
  (ENT2HTableAddProb(ProductionRecallRate_Array, PROD, I->IN_X_OUT));
 }
}

void UpdateItemFromLhsRR(ItemTree I)
{if (strstr(Name(LHS_OfItem(I)),"sss")!=NULL) I->IN_X_OUT = MaxNutralConst; 
 else {ProbDomain ThisParent_CH_Rate = SumNutralConst; static char PA_LCH[SYM_LENGTH]; static char PA_RCH[SYM_LENGTH];
       ProbDomain ThisProdRate= SumNutralConst; ProbDomain ThisNontRate= SumNutralConst;

       {/* for PA_CHR */
        strcpy(PA_LCH, StringOfPA_CH(I, Lch_enum)); strcpy(PA_RCH, StringOfPA_CH(I, Rch_enum));
        /* note that this is Avg not Sum */
        if (I->RT==_Binary)
          ThisParent_CH_Rate = AvgProbs(HASHProbOf(ParentChRecallRate_Array, PA_LCH), HASHProbOf(ParentChRecallRate_Array, PA_RCH)); 
        else ThisParent_CH_Rate = HASHProbOf(ParentChRecallRate_Array, PA_LCH);
       }
       
       ThisNontRate = HASHProbOf(RecallRatePerNonT_Array, IMG((int) LHS_OfItem(I)));
       ThisProdRate = HASHProbOf(ProductionRecallRate_Array, StringOfProduction(I));

       I->IN_X_OUT  = InterploteMetrics(ThisProdRate, ThisNontRate, ThisParent_CH_Rate);
      }
}
void UpdateRecallRatePerNonT(int i, int j, EntryPtr EP) 
{InitArrayOfRR();
 SetsMapEnded(*EP, (void *) &UpdateLhsRR); /* update the sum by the lhs non-terminal of ENDED items in this Entry */
 SetsMapEnded(*EP, (void *) &UpdateItemFromLhsRR);  /* make the item's IN_X_OUT be that of its lhs non-terminal */
}
/**********************************************************************************************************************************/
/** PER ITEM FUNCTIONS FOR INSIDE AND OUTSIDE  											 **/
/** PER ITEM FUNCTIONS FOR INSIDE AND OUTSIDE  											 **/
/**********************************************************************************************************************************/
/* FOR THE SSSS item */
ProbDomain InsideProbOfItemRoots(ItemTree I)
{ProbDomain SUM; int NUM;
  void SumUp(DerFPtr FP) {SUM = SumProbs(FP->Sum_Prob, SUM); NUM++;} 

 SUM = SumNutralConst; NUM = 0;
 if (I == NULL) return SumNutralConst;
 if (NonEmptyDerForest(I) == false) return SumNutralConst;
 if (NonEmptyRootsDerForest(I) == true) Map_OnCodesOf(I, ROOT_enum, &SumUp);
                           /*** else Map_OnCodesOf(I, OTHERS_enum, &SumUp); ***/

 return (SUM);
}

ProbDomain InsideXOutsideOfItem(ItemTree I)
{ProbDomain SUM; Boolean Which = 0; int ir = 0; int io=0;
  void SumUp(DerFPtr DFP)
   {if (Which==1) ir++; else io++;

    if (DFP->DF_OUTSIDE_PROB != SumNutralConst)
     {SUM = SumProbs(SUM, MultProbs(DFP->Sum_Prob, DFP->DF_OUTSIDE_PROB)); 

      if (DFP->DF_OUTSIDE_PROB==SumNutralConst)
         {fprintf(stderr,"Err9 InsideXOutsideOfItem %6.6e %6.6e (%d)  <%d,%d>\n", 
                          DFP->DF_OUTSIDE_PROB, DFP->Sum_Prob, Which, I->i, I->j); PItem(I); exit(1);}

      if (1==0)
      if (_GLOB_SEN_PROB < ((ProbDomain) MultProbs(DFP->Sum_Prob, DFP->DF_OUTSIDE_PROB)))
        {fprintf(stderr,"Err8 InsideXOutsideOfItem %6.6e, (%6.6e,%6.6e), %6.6e, (%d) <%d,%d>\n", 
                         SUM,  DFP->Sum_Prob, DFP->DF_OUTSIDE_PROB, _GLOB_SEN_PROB, Which, I->i, I->j); PItem(I); exit(1);}

      if (_DEBUG_EX_II==true) 
           {PItem(I); fprintf(stderr," %6.6e  %6.6e\n", POWER((double)DFP->DF_OUTSIDE_PROB), POWER((double) DFP->Sum_Prob));}
     }
   }
 SUM = SumNutralConst;
 if (I == NULL) return SumNutralConst; if (NonEmptyDerForest(I) == false) return SumNutralConst;
 Which = 1; Map_OnCodesOf(I, ROOT_enum, &SumUp); 
 Which = 0; Map_OnCodesOf(I, OTHERS_enum, &SumUp);

 if (SUM == SumNutralConst)
    {fprintf(stderr,"Err5 InsideXOutsideOfItem %6.6e %6.6e (%d,%d))\n", SUM, _GLOB_SEN_PROB, ir, io); PItem(I); fprintf(stderr,"\n");exit(1);}
 if (1==0)
 if (((float) SUM) > ((float) _GLOB_SEN_PROB))
        {fprintf(stderr,"Err7 InsideXOutsideOfItem %6.6e %6.6e\n", SUM, _GLOB_SEN_PROB); PItem(I); fprintf(stderr,"\n");exit(1);}

 return (SUM);
}

ProbDomain RecallRateOfItem(ItemTree I, ProbDomain SEN_PROB)
{ProbDomain SUM; 
 /* HERE WAS Ref: ALTInsideXOutside */

 if (EndedItem(I)==false) return SumNutralConst;

 SUM = InsideXOutsideOfItem(I);
 if (1==0) if (SUM != MaxNutralConst) if (( SUM > 0) || (SUM > SEN_PROB)) {PItem(I); fprintf(stderr,"%e  %e\n", SUM, SEN_PROB);}

 if ((_DEBUG_EX==true) && (_PR_ITEM(I)==true)) {PItem(I); fprintf(stderr,"%6.6e  %6.6e\n", POWER(SUM), POWER(SEN_PROB));}

 return (ProbDomain) (DevideProbs(SUM, SEN_PROB));
}

/*********************************************************************************************************************************/
/*  COMPUTING THE OUTSIDE PROBABILITIES FOR ITEMS										 */
/*  COMPUTING THE OUTSIDE PROBABILITIES FOR ITEMS										 */
/*  COMPUTING THE OUTSIDE PROBABILITIES FOR ITEMS										 */
/*********************************************************************************************************************************/
void InitDFoutside(ItemTree I, ProbDomain P)
{ 
 void updtDFRoot(DerFPtr DF)   {DF->DF_OUTSIDE_PROB = P;}
 void updtDFOthers(DerFPtr DF) {DF->DF_OUTSIDE_PROB = (ProbDomain) SumNutralConst;}

 if (NonEmptyDerForest(I) == false);
 else {Map_OnCodesOf(I, ROOT_enum, &updtDFRoot); Map_OnCodesOf(I, OTHERS_enum, &updtDFOthers);}
}
/*---*/
/* for A->B*C and C->gamma*: these must exchange the insides  !! for computing outside */
extern void prntnode(DerFPtr DF);

void UpdChFromSisters(ItemTree I, Code_Soort CT, DerFPtr LDFch, DerFPtr RDFch)
{ProbDomain code_prob = MultNutralConst; ProbDomain InsideProbOfLsis = MultNutralConst;

 if (( LDFch->TempProb) != ( SumNutralConst)) 
 {
  {/* I = A->B*C is left child of A->BC* and RDFch is the right child C->beta* */
   /* because the left-sis I=A->B*C had kept outside of A->BC* in a temp, it gets now really updated  by the right-sis */
   LDFch->DF_OUTSIDE_PROB = SumProbs(LDFch->DF_OUTSIDE_PROB, MultProbs(LDFch->TempProb, RDFch->Sum_Prob));
   InsideProbOfLsis = LDFch->Sum_Prob;
  }
  /* updating outside of the right sister C->beta* */
  RDFch->DF_OUTSIDE_PROB = SumProbs(RDFch->DF_OUTSIDE_PROB,  MultProbs(LDFch->TempProb, InsideProbOfLsis));

  if (LDFch->DF_OUTSIDE_PROB == SumNutralConst) {PItem(LDFch->SelfItem);PRS("\n");}
  if (RDFch->DF_OUTSIDE_PROB == SumNutralConst) {PItem(RDFch->SelfItem);PRS("\n");}

  LDFch->SelfItem->_No_Outside=false; RDFch->SelfItem->_No_Outside=false;
 }
}
/****/
/* update the childs outside from its parents I                      */
/* exchange inside is true for A->B*C with its right sister only     */
void UpdChFromParentDFP(ItemTree I, Code_Soort CT, DerFPtr P_DF, DerFPtr DFch, Boolean exchange_inside, Child_Type ChNum)
{ProbDomain code_prob = MultNutralConst; 

 if ((EndedItem(I) == false) && (ChNum==Rch_enum) && (exchange_inside==false))
     {fprintf(stderr,"ERROR EXCH: %d %d\n", EndedItem(I), exchange_inside); 
      PItem(I); PItem(P_DF->SelfItem);  PItem(DFch->SelfItem); exit(1);
     }

 if ((EndedItem(I) == false) && (ChNum==Rch_enum) && (exchange_inside == true)) 
      {/* I = A->B*C that represents its parent A->BC* and DFch is its Right sister !!: They exchange OUTSIDE !!*/
       UpdChFromSisters(I, CT, P_DF, DFch);
      }
 else if (P_DF->DF_OUTSIDE_PROB != SumNutralConst) 
      {if (EndedItem(I) == true) code_prob = CodeProbability(I, P_DF, CT);
       else code_prob = MultNutralConst;

       if ( (EndedItem(I) == true) && (I->RT == _Binary) && (ChNum==Lch_enum)) 
         {DFch->TempProb = MultProbs(P_DF->DF_OUTSIDE_PROB, code_prob); /* keeping parent OUtsidexSubreeProb on child in a temp */
         }
       else /* must be an unary or a binary unended A->B*C that is a parent of B->gamma* */
         DFch->DF_OUTSIDE_PROB = SumProbs(DFch->DF_OUTSIDE_PROB, MultProbs(P_DF->DF_OUTSIDE_PROB, code_prob));

        P_DF->SelfItem->_No_Outside=false;  DFch->SelfItem->_No_Outside=false; 
      }
}
/*---*****************************************************************---*/
/* echange_inside must fulfill:
   When (chnum==Lch_enum)
     {I is parent item, Ch is its left child and exchange_inside==false}
   When (chnum==Rch_enum)
     {I is the left-SISTER of Ch (the right-sister) and exchange_insides==true}
*/

void GET_OUTProb_OfCh_FromParent(ItemTree I, ItemTree Ch, Child_Type chnum, Boolean exchange_insides)
{ItemCPtr ICPch; Code_Soort CT; Rule_Apps P_RA; Rule_Apps Ch_RA;

 void DoThisParentDF(DerFPtr P_DF)
   {TreeCodeT Chplace; Boolean FoundCh ;  Boolean Open_ChQ=false;

     void UpdRootCh(DerFPtr DFch) {UpdChFromParentDFP(I, CT, P_DF, DFch, exchange_insides, chnum);}

    FoundCh = false; 
    Open_ChQ = IsOpenCh(P_DF->OpenTrees, chnum);

    if (((P_DF->DF_OUTSIDE_PROB != SumNutralConst) && (exchange_insides == false)) ||
        ((P_DF->TempProb != SumNutralConst) && (exchange_insides == true)) )
     switch (Open_ChQ) /* is ch an open tree or does it expect an internal child */
      {case false :  /* P_DF should search for its child DFP */
              if (ICPch->OthersSize == 0) ; /* no valid children for DFp in ICPch */
              else {Chplace = GetChplace(P_DF, chnum, CT, ICPch); /* where the child of P_DF might be on ICPch */
                    if ((Chplace < ICPch->OthersSize) && (Chplace != _C_Addr_UNV))   /* is the child code valid */
                       UpdChFromParentDFP(I, CT, P_DF, ICPch->Others+Chplace, exchange_insides, chnum);
                    else  /* child is not on this child item: maybe on another one ! */
                       if (1==0)
                         {PItem(I); PItem(Ch);PRS("\n");
                         }
                    } 
                    break;
       case true  : /* P_DF takes all root DFPs of Ch */
                    Map_OnCodesOf(Ch, ROOT_enum, &UpdRootCh);
                    break;
      };
   }


 ICPch = (ItemCPtr) Ch->DerForest; 
 P_RA = IR_AppsOf(I->RuleNo, I->RT, 1); Ch_RA = IR_AppsOf(Ch->RuleNo, Ch->RT, 2); 

 CT = ROOT_enum;   Map_OnCodesOf(I, ROOT_enum,   &DoThisParentDF);
 CT = OTHERS_enum; Map_OnCodesOf(I, OTHERS_enum, &DoThisParentDF);

 /* UNNECESSARY SINCE THIS IS CHECKED AUTOMATICALLY: ResetBuffering(); */
}
/*------------------------------------------------------------*/
/*------------------------------------------------------------*/
/* here I is A->BC* and LCh is A->B*C: thus DerForest of I is subset-equal of that of LCh */
/* ALWAYS LCh is A->B*C form !!!!!!!!!                                                    */
void Binary_UpdLCh_outside(ItemTree I, ItemTree LCh)
{TreeCodeT Chplace; ItemCPtr ICPLch = (ItemCPtr) LCh->DerForest; Code_Soort CT; 
  void DoLch(DerFPtr DFP)
   {if (DFP->DF_OUTSIDE_PROB != SumNutralConst)
    switch (CT) {
      case ROOT_enum   : Chplace =  ICPLch->R_NowAtPos[DFP->CAdr]; 
                         /* if ((Chplace !=  _C_Addr_UNV) && (ICPLch->R_valids[Chplace] == true)) */
                         if (Chplace !=  _C_Addr_UNV) 
                           UpdChFromParentDFP(I, CT, DFP, ICPLch->Roots+Chplace, false, Lch_enum); /* inherit parent outside*DFP-prob */
                         else ; /* {fprintf(stderr,"Err: Binary_UpdLCh_outside 1 -- %d\n", Chplace);exit(1);} */
                      break;
      case OTHERS_enum : Chplace =  ICPLch->O_NowAtPos[DFP->CAdr];
                         /* if ((Chplace !=  _C_Addr_UNV)  && (ICPLch->O_valids[Chplace] == true)) */
                         if (Chplace !=  _C_Addr_UNV)  
                           UpdChFromParentDFP(I, CT, DFP, ICPLch->Others+Chplace, false, Lch_enum);
                         else ; /* {fprintf(stderr,"Err: Binary_UpdLCh_outside 2 -- %d\n", Chplace);exit(1);} */
                      break;
    };
   }

 if (I != NULL) 
 {if ((EndedItem(I)==true) && (I->RT==_Binary))
 {
  /* at first: outside of Lchild is set at that of parent and multiplied with rule prob */
  CT = ROOT_enum;   Map_OnCodesOf(I, ROOT_enum, &DoLch);
  CT = OTHERS_enum; Map_OnCodesOf(I, OTHERS_enum, &DoLch);
 }
 else {fprintf(stderr,"Err: Binary_UpdLCh_outside\n");exit(1);}
 }
}
/*--------------------------------------------------------------------*/
/* Outside of Rch C->beta* is updated using its left sister A->B*C    */
/* We use GET_OUTProb_OfCh_FromParent also here because A->B*C is playing */
/* the role of parent here by passing the temp-probs of its parent    */

void OutsideOfRChildFromLSIS(ItemTree P, ItemTree LCh, ItemTree Rch)
{GET_OUTProb_OfCh_FromParent(LCh, Rch, Rch_enum, true); 
}
/*-------------------------------------------------------------------*/
void ResetTempProb(ItemTree I)
{void DoLch(DerFPtr DFP) {DFP->TempProb = SumNutralConst;}
 Map_OnCodesOf(I, ROOT_enum, &DoLch); Map_OnCodesOf(I, OTHERS_enum, &DoLch);
}
/*-------------------------------------------------------------------*/
/* Computing the Recall Rate of I = (Inside*Outside/sen-prob) */
/* updating outside of children of I                          */
void UpdOUT_ChsOfItem(ItemTree I, ProbDomain _SEN_PROB)
{ItemTree LCh; PtrList P; int i=0;
  void ApplyToRChs(void *ptr)
   {ItemTree Rsis = (ItemTree) ptr; OutsideOfRChildFromLSIS(I, LCh, Rsis);
   }

  void UpdateChItems(PtrList ChL)
  {PtrList ChRLst = (PtrList) ChL->Data; LCh = (ItemTree) ChL->Ptr; i++;
   if (LCh->Touched == false) {/* to avoid cycles */
    if (ChRLst != NULL) /* dealing with LCh = A->B*C and ChRLst contains various C->beta* */
      {/* order important here: first update left child: A->B*C later C->beta* **/
       Binary_UpdLCh_outside(I, LCh);
       PListMap(ChRLst, (void *) &ApplyToRChs);
       ResetTempProb(LCh);
      }
    else /*either unary A->B*  or A->B*C as parent*/
         GET_OUTProb_OfCh_FromParent(I, LCh, Lch_enum, false); /* given outside of parent: compute outside of child */
   }
  }


 if ((I->Touched == false) && (I->_No_Outside==false) && (I->Valid==true))
 {
  if (1==0) if ((I->i==0) && (I->j==_sen_length)) {PItem(I); PRS("\n");}

  if (I->AddedBy != NULL) PDListMap(I->AddedBy, (void *) &UpdateChItems);
 
  I->IN_X_OUT = RecallRateOfItem(I, _SEN_PROB); 
  if (1==0) if ( I->IN_X_OUT > 0) {PItem(I); fprintf(stderr,"%e\n", I->IN_X_OUT);}

  I->Touched = true;
 }
}
/*------------------------------------------------------------*/
/* compute the recall rate of each item       */
/* First compute outside and then recall rate */
void ComputeOutsidePerItem(TableType TAB, ParForest PARF, int length)
{ProbDomain _SENTENCE_PROB; ItemTree SSSSitem; 

   void Set_Item(ItemTree I)       {I->Touched = false; I->_No_Outside=true;}
   void Reset_Item(ItemTree I)     {I->Touched = false; I->_No_Outside=true;}

   void UpdOUT_ChsOfItemN(ItemTree I) { UpdOUT_ChsOfItem(I, _SENTENCE_PROB);}

   void ApplySetToEntry(int i, int j, EntryPtr EP) 
     {RevMapOnLevelsOf(*EP, (void *) &Set_Item); /* to avoid cycles !! */
     }
   void ApplyOutsideToEntry(int i, int j, EntryPtr EP) 
     {RevMapOnLevelsOf(*EP, (void *) &UpdOUT_ChsOfItemN); /* run on items from higher to lower: updating children's outside and LRR */
      RevMapOnLevelsOf(*EP, (void *) &Reset_Item); /* to avoid cycles !! */
     }
   void InitOutsideOfStart(PtrList P)
   {if (P != NULL) {SSSSitem = (ItemTree) P->Ptr;  InitDFoutside(SSSSitem, MultNutralConst); 
                    _SENTENCE_PROB = InsideProbOfItemRoots(SSSSitem); _GLOB_SEN_PROB = _SENTENCE_PROB;
                    SSSSitem->IN_X_OUT = RecallRateOfItem(SSSSitem, _GLOB_SEN_PROB); 
                    SSSSitem->_No_Outside=false;
                   }
    }

 if (PARF != NULL) 
   {if (1==0) fprintf(stderr, "  (computing outside probabilities...");
    RevMapOnTableEntries(TAB, length, (void *) &ApplySetToEntry); /* run on table entries from high to low for outside calcs */
    InitOutsideOfStart(PARF->Starts); 
    RevMapOnTableEntries(TAB, length, (void *) &ApplyOutsideToEntry); /* run on table entries from high to low for outside calcs */
    if (1==0) fprintf(stderr, ")\n");
   }
}
/*****************************************************************************************************************************/
/*****************************************************************************************************************************/
/* Computing the global labeled recall rate tree                                                                             */
/* Computing the global labeled recall rate tree                                                                             */
/*****************************************************************************************************************************/
/* for computing the GLRR  or for computing Something else  */

ProbDomain CombineProbs(ProbDomain A, ProbDomain B) 
{if (1==0) fprintf(stderr, "%e \n", SumProbs(A,B));
 return SumProbs(A, B);
}
/***/
extern void MaxGRR_Item(ItemTree I);

/* void ComputeRecallRatePerItem(TableType TAB, ParForest PARF, int length) {ComputeOutsidePerItem(TAB, PARF, length);}*/

void ComputeCombinProbPerItem(TableType TAB, ParForest PARF, int length) 
{if (WHAT_TO_COMPUTE == _GLRR ) ComputeOutsidePerItem(TAB, PARF, length); 
 else /* _do nothing because it is unnecessary */ ;
}
/*---------------------------------------------------------------------------------------------------------------*/
ProbDomain MaxGRR_Lst(PtrList Lst, PtrList *MaxChLst)
{ProbDomain MaxGRR_Of_Chs;  ProbDomain Max_Rsis_Prob; ItemTree Max_Rsis; ItemTree Max_Lsis; ItemTree ThisMax_Rsis;
  void MaxGRR_R_sis(void *Ptr)
   {ItemTree Rsis = (ItemTree) Ptr; Boolean FIRST = false;
    Max_Rsis_Prob = MaxProbs(Rsis->MAX_GRR_PROB, Max_Rsis_Prob, &FIRST);
    if (FIRST == true) ThisMax_Rsis = Rsis;
   }
  void ApplyToLeft(PtrList ChL)
   {Boolean FIRST = false; ProbDomain ThisMaxGRR; 
    ItemTree item = (ItemTree) ChL->Ptr; PtrList ChRLst = (PtrList) ChL->Data;
    if (ChRLst != NULL) /* dealing with item= A->B*C and ChRLst contains various C->beta* */
       {ThisMax_Rsis = NULL; Max_Rsis_Prob = MaxNutralConst; PListMap(ChRLst, (void *) &MaxGRR_R_sis);}
    else {ThisMax_Rsis = NULL; Max_Rsis_Prob = SumNutralConst;}
    ThisMaxGRR = SumProbs(item->MAX_GRR_PROB, Max_Rsis_Prob); 
    MaxGRR_Of_Chs = MaxProbs(ThisMaxGRR, MaxGRR_Of_Chs, &FIRST);
    if (FIRST == true) {Max_Lsis = item; Max_Rsis = ThisMax_Rsis;}
   }

 {MaxGRR_Of_Chs = MaxNutralConst; Max_Rsis = NULL; Max_Lsis =NULL; ThisMax_Rsis= NULL;}

 if (Lst != NULL) {
   PDListMap(Lst, (void *) &ApplyToLeft);
   *MaxChLst = EnterPStack((void *) Max_Lsis, NULL); EnterToDataOfFirst((void *) Max_Rsis, *MaxChLst);
 }
 else {*MaxChLst = NULL; MaxGRR_Of_Chs = MaxNutralConst; fprintf(stderr, "Err: NO ADDEDBY !!\n"); exit(1);}

 return MaxGRR_Of_Chs;
}
/*---*/
void MaxGRR_PerItem(ItemTree I)
{static PtrList MaxChLst = NULL; ProbDomain Max_Of_Chs = SumNutralConst; ProbDomain InsOut = SumNutralConst; 

 if (I->Touched == false) {
  switch (I->RT) {
    case _Term   : Max_Of_Chs = SumNutralConst;
                   I->MAX_GRR_PROB = SumProbs(Max_Of_Chs, I->IN_X_OUT);
              break;
    case _Unary  : Max_Of_Chs = MaxGRR_Lst(I->AddedBy, &MaxChLst);
                     if (_UNARY_IN_GLRR == true) 
                       if (_AVG_UNARY_LRR == true) 
                         if (AverageQ(I)==true)
                         {/* A->B: we subtract first the g(B) and then add the AvgProbs(g(A),g(B)) instead */
                          Max_Of_Chs = SubtractProbs(Max_Of_Chs, ((ItemTree) MaxChLst->Ptr)->IN_X_OUT);
                          I->MAX_GRR_PROB = SumProbs(Max_Of_Chs, AvgProbs(((ItemTree) MaxChLst->Ptr)->IN_X_OUT, I->IN_X_OUT));
                         }
                         else  I->MAX_GRR_PROB = Max_Of_Chs; 
                       else I->MAX_GRR_PROB = SumProbs(Max_Of_Chs, I->IN_X_OUT);
                     else I->MAX_GRR_PROB = Max_Of_Chs; /* only pass max of the children */
                   break;
    case _Binary : 
                   {Max_Of_Chs = MaxGRR_Lst(I->AddedBy, &MaxChLst);
                    if (_GLLR_4_ENDED_ITEMS_ONLY == true)
                       if (EndedItem(I) == true) I->MAX_GRR_PROB = SumProbs(Max_Of_Chs, I->IN_X_OUT);
                       else I->MAX_GRR_PROB = Max_Of_Chs; /* only pass max of the children */
                    else I->MAX_GRR_PROB = SumProbs(Max_Of_Chs, I->IN_X_OUT); 
                   }
                   break;
  }; /* end of switch */

  if (I->WhatToDo != NULL) {FreePListN(I->WhatToDo);} 
  I->WhatToDo = MaxChLst;
  I->Touched = true;
 }/* if touched */
}
/*---*/
void ApplyMaxGRRToEntryPerItem(int i, int j, EntryPtr EP) 
{void Reset_Item(ItemTree I)     {I->Touched = false; }
 void Reset_ItemProb(ItemTree I) {I->Touched = false; I->MAX_GRR_PROB = MaxNutralConst;}

 if (_USE_RR_PER_NONT == true)
  UpdateRecallRatePerNonT(i, j, EP); /* make the recall rates of an item be that of its LHS non-terminal */

 MapOnLevelsOf(*EP, (void *) &Reset_ItemProb); 
 MapOnLevelsOf(*EP, (void *) &MaxGRR_PerItem); 
 MapOnLevelsOf(*EP, (void *) &Reset_Item); 
}
/*---*/
extern void PrintSumTermItems(TableType TAB,  int length)  ;

void MaxGlobalRecallRate(TableType TAB, ParForest PARF, int length)
{fprintf(stderr,"\n");
 if (PARF != NULL)
  {ComputeCombinProbPerItem(TAB, PARF, length);  /* compute the Inside-x-Outside for each item in chart */
   fprintf(stderr,"Sentence Probability %6.6e\n",  POWER((double) _GLOB_SEN_PROB));

   MapOnTableEntries(TAB, length, (void *) &ApplyMaxGRRToEntryPerItem);
   ShowMaxGRR(PARF);
  }
 else ShowMaxGRR(PARF);

 PrintSumTermItems(TAB, length);
}
/*********************************************************************************************************************************/
/*********************************************************************************************************************************/
/* PRINTING FACILITIES														 */
/*********************************************************************************************************************************/
/* we never print the SSSS label */
extern void ShowUnderAddedBy(PtrList PL);

void ShowThisItemNode(ItemTree I)
{if (EndedItem(I) == true)
  {PRS("(");PRS(Name(LHS_OfItem(I))); 
      if ((_DEBUG==true) && (_PR_ITEM(I)==true)) 
       {fprintf(stderr," %6.6e   %6.6e  \n", POWER((double) I->IN_X_OUT),  POWER((double) I->MAX_GRR_PROB));}
   PRS(",["); if (I->RT == _Term) {PRS("(");PRS(TName(RHS1_OfItem(I)));PRS(",[])");}
   else ShowUnderAddedBy(I->WhatToDo); 
   PRS("])"); 
  }
 else ShowUnderAddedBy(I->WhatToDo); 
}
void ShowUnderAddedBy(PtrList PL)
{ItemTree itemL; ItemTree itemR;
 if (PL!= NULL)
  {itemL = (ItemTree) PL->Ptr; if (PL->Data != NULL) itemR = (ItemTree) ((PtrList) PL->Data)->Ptr;
   ShowThisItemNode(itemL); if (itemR != NULL) {PRS(","); ShowThisItemNode(itemR); } 
  }
}
void ShowSSSS_GRR(ItemTree SSSSitem)
{if (SSSSitem->WhatToDo != NULL)
  {fprintf(stderr,"Recall rate: %6.6e\n",  POWER((double) SSSSitem->MAX_GRR_PROB));
   ShowUnderAddedBy(SSSSitem->WhatToDo);
  }
 else EXIT(NOPF);
 PRS(".\n");
}
void ShowMaxGRR(ParForest PARF)
{_PRINT_IDEN_ALG();
 if (PARF != NULL)
  if (PARF->Starts != NULL) ShowSSSS_GRR((ItemTree) PARF->Starts->Ptr);
  else EXIT(NOPF);
 else EXIT(NOPF);
}
/*********************************************************/
void SumUpAndPrint(int i, int j, EntryPtr ThisEPtr)
{ProbDomain SUM ;
  void SumUpItem(void *VI)
   {ItemTree I= (ItemTree) VI;
    if (I->RT == _Term) SUM=SumProbs(SUM, I->IN_X_OUT); /* the IN_X_OUT changes at some point to accomodate the LRR of the item/node */
   }

 SUM = SumNutralConst;
 SetsMapEnded(*ThisEPtr, (void *) &SumUpItem);

 fprintf(stderr,"Sum of recall rate for (%d, %d) = %6.6e \n", i, j, POWER((double) SUM));
}
void PrintSumTermItems(TableType TAB, int length)
{if (_DEBUG_TERM_ENTRIES==true)
   MapOnEntriesForSpan(TAB, 1, length, (void *) &SumUpAndPrint);
}
/*******/
/*********************************************************/
/* For the WSJ :                                         */
/* return the original nonterminal: NT-head has image NT */
char *ImageNontOf(NTDomain NTnum)
{static char res[SYM_LENGTH]; char *temp; char nonterm[SymLength]; char RES[SymLength]; 

 strcpy(res,"");

 /* if (_DO_IMAGE_NONT == false) {strcpy(res, Name(NTnum)); return res;} */

 strcpy(nonterm, Name(NTnum)); strcpy(RES,"");
 temp = strstr(nonterm,"-");
 if (temp == NULL)  {strcpy(res, Name(NTnum)); return res;}   
 else {strncpy(RES, nonterm, (strlen(nonterm) - strlen(temp)));
       RES[(strlen(nonterm) - strlen(temp))] = '\0';
       strcpy(res, RES);
       return res;
      }
}
/**********************************************************************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/
/*** REFERENCES
 Ref: ALTInsideXOutside

  void SumUp(DerFPtr FP) 
    {if (FP->DF_OUTSIDE_PROB != MaxNutralConst) 
       {SUM = SumProbs(SUM, MultProbs(FP->DF_OUTSIDE_PROB, FP->Sum_Prob)); 
        if (_DEBUG_EX_II==true) 
           {PItem(I); fprintf(stderr,"(%6.6e  %6.6e)\n", POWER((double)FP->DF_OUTSIDE_PROB), POWER((double) FP->Sum_Prob));}
       }
    }

 SUM = SumNutralConst; if (I == NULL) return SumNutralConst; if (NonEmptyDerForest(I) == false) return SumNutralConst;
 Map_OnCodesOf(I, ROOT_enum, &SumUp); 
 Map_OnCodesOf(I, OTHERS_enum, &SumUp);
**********/
