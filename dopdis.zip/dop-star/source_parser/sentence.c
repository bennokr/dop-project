/****** CLOSED
#include "./Universals.h"
#include "./Aux.h"
#include "./Queues.h"
#include "./PtrList.h"
#include "./sentence.h"
#include "./DefsGrammar.h"
**/
#include "./ALL.h"
/****************************/
extern void PRINTSENTENCE(Sentence S);
extern void QMapEx(Queue Q, void (*func)());

int SentenceCount(Sentence S)
{WordList This;
 int max = 0;
 if (S == NULL) return 0;
 else {This = S-> WORDS; 
       while (This != NULL) {max = This->WordNumber; This = This->Next;}} 
 return max;
}

Sentence CrSen()
{Sentence Sen = (Sentence) AllocElem(sizeof(struct Sentences));
 Sen->length = 0;
 Sen->WORDS = (WordList) NULL;
 Sen->Last = (WordList) NULL;
 return Sen;
}
void FreeSentence(Sentence Sen)
{
 FreeQueue(Sen->WORDS);
 cfree(Sen);
}
Sentence EnterWord(Sentence Sen, char *w)
{Sentence S; WordList Temp;
 S = Sen; if (S == NULL) S = CrSen();
 Temp = Enqueue(w, S->Last); 
 if (S->WORDS == NULL) {S->WORDS = Temp;S->Last = Temp;} /* first entered */
 else S->Last = S->Last->Next;
 S->length++;
 return S;
}
Sentence EnterWordEx(Sentence Sen, char *w, NumOfWordsType i)
{Sentence S;WordList Temp;
 S = Sen; if (S == NULL) S = CrSen();
 Temp = EnqueueEx(w,i, S->Last);
 if (S->WORDS == NULL) {S->WORDS = Temp;S->Last = Temp;} /* first entered */
 else S->Last = S->Last->Next;
 S->length++;
 return S;
}
Sentence EnterWordWG(Sentence Sen, char *w, NumOfWordsType i, NumOfWordsType j)
{Sentence S; WordList Temp;
 S = Sen; if (S == NULL) S = CrSen();
 Temp = EnqueueWG(w,i,j, S->Last);
 if (S->WORDS == NULL) {S->WORDS = Temp; S->Last = Temp;}/* first entered */
  else S->Last = S->Last->Next;

 if (S->length < (j-1)) S->length = j-1; /* number of largest state in this word-graph */
 return S;
}

extern WordList EnqueueWGP(char *R, NumOfWordsType i, NumOfWordsType j, WordList Q, ProbDomain Prob);
Sentence EnterWordWGP(Sentence Sen, char *w, NumOfWordsType i, NumOfWordsType j, ProbDomain Prob)
{Sentence S; WordList Temp;
 S = Sen; if (S == NULL) S = CrSen();
 Temp = EnqueueWGP(w,i,j, S->Last,Prob);
 if (S->WORDS == NULL) {S->WORDS = Temp; S->Last = Temp;}/* first entered */
 else S->Last = S->Last->Next;

 if (S->length < (j-1)) S->length = j-1; /* number of largest state in this word-graph */
 return S;
}
char *ThisWord(Sentence Sen)
{if (Sen == NULL) return NULL;
 else if (Sen->WORDS == NULL) return NULL;
      else return Sen->WORDS->Rule;
}
Sentence RestOfSentence(Sentence Sen)
{Sentence S1= CrSen();
 if (Sen == NULL) return NULL;
 else if (Sen->WORDS == NULL) return NULL;
      else {S1->length = (Sen->length -1);
            S1->WORDS = Sen->WORDS->Next;
            return S1;}
}
void MapSentence(Sentence Sen,void (*func)())
{if (Sen != NULL) QMap(Sen->WORDS, func);}
void MapSentenceEx(Sentence Sen,void (*func)())
{if (Sen != NULL) QMapEx(Sen->WORDS, func);}
void MapSentenceWG(Sentence Sen,void (*func)())
{if (Sen != NULL) QMapWG(Sen->WORDS, func);}
void MapSentenceWG_L(Sentence Sen,void (*func)())
{if (Sen != NULL) QMapWG_L(Sen->WORDS, func);}

/**************************/
void Store(char *a)
{extern Sentence TheSen;
 TheSen = EnterWord(TheSen, a);
}
Sentence StoreEx(Sentence S, char *a, NumOfWordsType i)
{return (EnterWordEx(S, a, i));
}
Sentence StoreWG(Sentence S, char *a, NumOfWordsType i, NumOfWordsType j)
{return (EnterWordWG(S, a, i, j));
}
Sentence StoreWGP(Sentence S, char *a, NumOfWordsType i, NumOfWordsType j, ProbDomain Prob)
{return (EnterWordWGP(S, a, i, j,Prob));
}
char *FindWord(Sentence S, NumOfWordsType WN)
{char *Here;
      void TryThis(char *w, NumOfWordsType num)
       {if (num == WN) Here = w; }
 Here = NULL;
 MapSentenceEx(S, (void *) &TryThis);
 return Here;
}
/***********************/
extern void UpdateProb(WordList Q, ProbDomain Prob);

int UpdateProbOfLastOld(Sentence S, ProbDomain Probs)
{if (S == NULL) return 1; if (S->Last == NULL) return 1;
 UpdateProb(S->Last, Probs); 
 return 0;
}
int UpdateProbOfLast(Sentence S, ProbDomain Probs)
{if (S == NULL) return 1; if (S->Last == NULL) return 1;
 UpdateProb(S->Last, Probs); 
 return 0;
}
int UpdateMorphemeOfLast(Sentence S, char *Morpheme)
{char TEMP[SymLength];
 strcpy(TEMP,Morpheme); TEMP[strlen(TEMP)-1]='\0'; /* stripping / */
 if (1==0) if (NT_NUM_Of(TEMP)==UNVALID_SYMNUM) {fprintf(stderr,"\n--->>>%s\n",TEMP);exit(1);}
 if (S == NULL) return 1; if (S->Last == NULL) return 1;
 UpdateMorpheme(S->Last,Morpheme);
 return 0;
}
int UpdateBounaryOfLast(Sentence S, char *input)
{int val;
 if (S == NULL) return 1; if (S->Last == NULL) return 1;
 (S->Last)->WordBounary = true;
  sscanf(input, "#%d", &val);
 (S->Last)->WordReference =val;
 return 0;
}

/* if given a place <i,j> (belonging to an unknown word) the return that word */
/* in word-graphs this simply returns the first encountered word that is marked
   as unknown in the word-graph */
extern Sentence TheWG;
char *OriginalWord(LevDomain i, LevDomain j)
{WordList Qlist;
 if (TheWG == NULL) return UNKNOWNSYM; /* in cases of tree-evaluation */
 Qlist = TheWG->WORDS;

 if (Qlist != NULL) {
   while ((Qlist != NULL) && (Qlist->WordNumber != i+1) && (Qlist->EndPoint != j+1) 
          /*  && (Qlist->UnknownWord == false)*/ ) Qlist = Qlist->Next;

   if ((Qlist->WordNumber != i+1) || (Qlist->EndPoint != j+1)) 
       {fprintf(stderr,"ErrI: (%d %d) vs (%d %d)\n",i+1, j+1, Qlist->WordNumber, Qlist->EndPoint);exit(1);}

   if (Qlist != NULL) {
                        /* PRS("\n"); PRI(Qlist->WordNumber); PRI(Qlist->EndPoint); PRS("\n"); */
                        return Qlist->Rule;  
                      }
   else {ERROR = true; return UNKNOWNSYM;} 
 }
 else return UNKNOWNSYM; /* in cases of tree-evaluation */
}
/****/
void PRINTSENTENCE(Sentence S)
{ void PRW(WordList ThisW)
   {PRI(ThisW->WordNumber); PRS(" "); PRI(ThisW->EndPoint); PRS(ThisW->Rule); PRS(" "); 
    PRBS((double) ThisW->Probability); PRS("\n");
   }
 MapSentenceWG_L(S, (void *) &PRW);
 PRS(".\n");
}
/*******/
/* If the input is a sequence of <category,word> pairs, i.e. a (partial) tree                                      */
/* we get a sequence of [i, j, category/word, prob] in the input (where we refer to category as morpheme sometimes)*/
/* In this procedure, we build a square table of nxn (where n is sentence length) and store in every entry [i,j]   */
/* the categories of [i, j, category/word, prob] (that is if there are many such transitions in input with same    */
/* [i, j, category/xxxx, xxxx].                                                                                    */
/* We use this table in PARSE.c for filtering out other parses as the input partial parse is considered a filter   */

#define Max_NTDList_Len 100 /* Brrrrrrr : KEEP LARGER THAN 0 */
#define NTDList  NTDomain *

NTDList Alloc_NTDList()
{int i;
 NTDList RES = (NTDList) MultAlloc(Max_NTDList_Len, sizeof(NTDomain));
 for (i=0; i< Max_NTDList_Len; i++) RES[i]=UNVALID_SYMNUM;
 return RES;
}
Boolean Is_In_NTDList(NTDList List, NTDomain NT)
{int i;
 if (List==NULL) return true;
 else
 for (i=0; i< Max_NTDList_Len; i++) 
  {/* fprintf(stderr,"%s %s\n", Name(List[i]), Name(NT) ); */
   /*SPEEDUP: List is empty after this point anyway */
   if (List[i]==UNVALID_SYMNUM) {/* fprintf(stderr, "(%d  %s)\n", i, Name(List[i]));*/ return false; }
   else if (List[i]==NT) return true; 
        else /*DO NOTHING: GO ON */;
 }

 return false;
}
NTDList EnterToNTDL(NTDList List, NTDomain NT)
{int i; NTDList RES; Boolean STOP=false;
 /* fprintf(stderr,"Entering %s: ", Name(NT)); */
 if (List==NULL) RES = Alloc_NTDList(); else RES = List;

 for (i=0; ((i < Max_NTDList_Len) && (STOP==false)); i++) 
    if (RES[i]==UNVALID_SYMNUM) {RES[i]=NT; /*fprintf(stderr,"%d ===> %s",i, Name(NT), Name(RES[i]) );*/  STOP=true;}
    else ;/* just go on */

 /* fprintf(stderr,"\n"); */
 return RES;
}
/**************************/
/* if we have constituents <i, j> and <m,n> in the input */
/* we have to satisfy both:                              */
/* Any constituent <k,l> satisfies both iff              */
/*     - <k,l> \in <i, j> or  \in <m,n>                  */
/*     - <k,l> \out <i,j> or \out <m,n>                  */
/**************************/
NTDList **TableOfPhrases = NULL;
Boolean **TableOfCrossBrackets = NULL;
Boolean **TableOfMatchingConsts= NULL;
Boolean EMPTY_PHRASE_FILTERS=true;
int _length_of_input=0;

void UpdateCrossBracketsTable(int start_t, int end_t)
{int i;int k; int j;

 if ((end_t-start_t) > 1) /* brackets must span more than a single word!*/
  for (k=start_t+1; k<=end_t-1; k++) /* any point between start en end */
   {for (i=0; i<=start_t-1; i++) TableOfCrossBrackets[i][k]=true;
    for (j=end_t+1; j<=_length_of_input; j++) TableOfCrossBrackets[k][j]=true;
   }
}

void UpdateMatchingBracketsTable(int start_t, int end_t)
{int i;int k; int j;
 if ((end_t-start_t) > 1) /* brackets must span more than a single word!*/
  {for (i=0; i<start_t;i++) for (k=1; k<=(start_t - i); k++) TableOfMatchingConsts[i][i+k]=true;
   for (i=start_t; i<end_t; i++) for (k=1; k<=(end_t - i); k++) TableOfMatchingConsts[i][i+k]=true;
   for (i=end_t; i<_length_of_input;i++) for (k=1; k<=(end_t - i); k++) TableOfMatchingConsts[i][i+k]=true;
  } 
}

void DoOneTrans(int start_t, int end_t, int word_seq_num, WordList transition)
{char TEMP[MaxTreeL]; int start, end;
 start = start_t; end = end_t;
 strcpy(TEMP, transition->Morpheme); 

 if (EQ_Strings(transition->Rule, _XXXPHRASE)==true)
 {
   /* fprintf(stderr,"===> %d  %d  %s\n", start_t+1, end_t+1, TEMP); */
  EMPTY_PHRASE_FILTERS=false;
  TEMP[strlen(TEMP)-1]='\0'; /* throwing away the "/" */
  if ((EQ_Strings(TEMP,"sss")==true) || (EQ_Strings(TEMP,"ssss")==true)) /* do nothing */;
  else {/* an actual category different from sss and ssss*/
      /** if (NT_NUM_Of(TEMP) == UNVALID_SYMNUM) {fprintf(stderr,"\n---> %s\n",TEMP); exit(1);} **/
     /* put into array of NTDomain */
    (TableOfPhrases[start+1][end+1]) = EnterToNTDL(TableOfPhrases[start+1][end+1], NT_NUM_Of(TEMP)); 
    UpdateCrossBracketsTable(start, end); UpdateMatchingBracketsTable(start, end);
    /* fprintf(stderr,"%s  %d\n", TEMP, NT_NUM_Of(TEMP)); */
    }
 }
}
void Build_TableOfMorphs(Sentence WG)
{int i, j; int n = WG->length; _length_of_input = n;
 if (TableOfPhrases==NULL) {
  TableOfCrossBrackets = (Boolean **) MultAlloc(n+2, sizeof(Boolean *)); 
  for (i=0;i<=n+1; i++) TableOfCrossBrackets[i] = (Boolean *) MultAlloc(n+2, sizeof(Boolean)); 
  for (i=0;i<=n+1; i++) for (j=0;j<=n+1; j++) TableOfCrossBrackets[i][j] = false;

  TableOfMatchingConsts = (Boolean **) MultAlloc(n+2, sizeof(Boolean *)); 
  for (i=0;i<=n+1; i++) TableOfMatchingConsts[i] = (Boolean *) MultAlloc(n+2, sizeof(Boolean)); 
  for (i=0;i<=n+1; i++) for (j=0;j<=n+1; j++) TableOfMatchingConsts[i][j] = false;

  TableOfPhrases = (NTDList **) MultAlloc(n+2, sizeof(NTDList *)); /* An array n+1 of pointers to NTDList */
  for (i=0;i<=n+1; i++) TableOfPhrases[i] = (NTDList *) MultAlloc(n+2, sizeof(NTDList)); 
  for (i=0;i<=n+1; i++) for (j=0;j<=n+1; j++) TableOfPhrases[i][j] = NULL;

  MapOnTransitionOfWG((void *) &DoOneTrans); 
  /* MapOnWGsSetOfEntries((void *) &DoOneTrans); */
 }
}
/**************************/
Boolean In_InputPhraseLabelfor(int i, int j, NTDomain NT)
{
 if (Is_In_NTDList(TableOfPhrases[i+1][j+1], NT) == true) return true;
 else { /* fprintf(stderr,"%d  %d  %s   \n", i+1, j+1, Name(NT)); */
       return false;
      }
}

Boolean InputPhraseLabel_AllowedQ(int i, int j, NTDomain NT)
{
 if (_FilterPosTags ==  false) return true;

 /* fprintf(stderr,"%d   %d:   %s\n", i, j, Name(NT)); */
 if (EMPTY_PHRASE_FILTERS==true) return true; /* no phrasal filters in input */

 if ((NT_NUM_Of("sss")==NT) || (NT_NUM_Of("ssss")==NT)) return true;

 /* now check if i,j crosses specified phrasal-filters */
 /* changed 5 July 2005 */
 if (In_InputPhraseLabelfor(i, j, NT) == true) return true;

 if (TableOfMatchingConsts[i][j]==true) return true; 
 else {/* fprintf(stderr,"%d %d %s \n", i, j, Name(NT)); */ return false;}
}
/*****/
// changed 5 July 2005 
// if (TableOfCrossBrackets[i][j]==true) {return false; }
// //
