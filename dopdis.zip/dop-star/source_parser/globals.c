#include "./ALL.h"

/************************************************************************/
/* Global variables of the Parser DOPDIS                                */ 


/* Original implementation: Interleaved = false; RedDerForest = true;    */
/* Interleaved = true; RedDerForest = false;                             */
/* NOTICE: If Interleaved = true then RedDerForest must be false         */ 
/*         However RedDF_CEntries can be true/false                      */
/* RedDF_CEntries allows in case of Interleaved to reduce the space      */
/* in a limited way. Only after a chart entry has been fully computed it */
/* is then reduced.                                                      */

Boolean _shortest_derivation = false;
Boolean LEXICALIZED_WSJ = false;
enum _PARSER_VERSION_TYPE _PARSER_VERSION = _MPD_VERSION; /* default is MPD */
Boolean Semi_Interleaved = false; /* Semi-interleaved computation */
Boolean Right_Linear = false;    /* Right Linear grammar ?                 */
Boolean _APPLY_PRUNE = false;
Boolean _BIGRAM_PRUNE = false;
Boolean _match_on_unknown_only=false;

Boolean RedDerForest = true; /*     true: saves memory use/costs time */
Boolean RedDF_CEntries = false; /* Lazy reduction of space  is possible  */
/***/
/* one solution for cycles is to set this to false */
Boolean _Allow_Same_Level = false  ;
/******************************************************/
/* The following globals must remain always UNCHANGED */
Boolean _Print_All_Sampled = false;
Boolean _Print_All_Sampled_DER = false;
int MPP_Sample_Size = 1;
GRAM_COUNT _NumOfGrammars_Used = SINGLE_G;
WhichParserT ParsingMethod = _BOTH_G;
Boolean _ShowChunks = false;
Boolean _Show_PosTags_global = false;
Boolean Interleaved = false;    /* Interleaved prob computation with CKY */
Boolean _DisambiguateB = true;
Boolean _MakePForest = true;	
Boolean _FullSenRec = false;
Boolean _OutNoContext = false;
Boolean TakeProbOfTrans = true;
Boolean CoLaM_On = false;      /* Using CoLaM or not: Only if INTERLEAVED is true :         */
Boolean _Whole_DFSpace = false; /* false: optimized MPD is the default */
Boolean _SpareMemoryPruning = false;
Boolean _Resolve_Unknown = true;
Boolean _PoSTagSequencesInput = false;    
 Boolean _OVIS_BKF_Pruning = false;
 Boolean  _ngram_is_used = false;
 Boolean _FilterPosTags = false;
/****/
Sentence TheWG = NULL;
Sentence TheSen = NULL;
PtrListArray ArrayOfTransitions = NULL;
PtrListArray ArrayOfTransSet = NULL;

TDomain *S = NULL;              /*** The input sentence encoded */
int _sen_length = 0;                      /* The length of the input sentence */
Boolean ERROR = false;
TableType CKYTAB = NULL;           /*** The CYK table.             */
ParForest PARF = NULL;          /* The Parse-Forest structure   */
Boolean ErIsUnknownW = false;
_WORDGRAPH_PROBS_COMB_T _WORDGRAPH_PROBS_METHOD = _REGULAR_INTEGRATION;
ProbDomain _Lambda_WG = 1.0;

FILE *fpOUT ;
FILE *fpIN ;
FILE *fpCodes = NULL;
FILE *fpChsPl = NULL;
DuoPtr Duo=NULL;       

NTDomain _NumOfStartSym = UNVALID_SYMNUM;
NTDomain _NumOfStopSym = UNVALID_SYMNUM;


Boolean HEBREW_POSTAG_SIMILARITY = false;     

/***********************/
GRAM_COUNT NUM_OF_GRAMS()
{switch (NUMofGRAMMARS_Used()) {
   case 1: return SINGLE_G; break;
   case 2: return DOUBLE_G; break;
 }/* switch */
return SINGLE_G;
}
void TestGlobalSetting()
{GRAM_COUNT GC = NUM_OF_GRAMS();
 if (GC == SINGLE_G)
  {if ((Interleaved == true) && (RedDerForest == true)) 
       {printf("Warning: global RedDerForest must be false when Interleaved is true\n"); 
        printf("         global RedDerForest is now false\n"); 
        RedDerForest = false;
       }
   if ((RedDF_CEntries == true) && (Interleaved == false))
       {printf("Warning: global RedDF_CEntries must be false when Interleaved is false\n"); 
        printf("         global RedDF_CEntries is now false\n"); 
        RedDF_CEntries = false;
       }
  } /* SINGLE_G */
 else if (Interleaved == true) 
       {printf("Warning: global Interleaved must be false when integrating two grammars\n"); 
        printf("         global Interleaved is now set to false\n"); 
        Interleaved = false;
       }
 if ((Interleaved == true) && (Semi_Interleaved == true))
      {printf("WARNING: global Interleaved and global Semi_Interleaved can not both be true \n"); 
       printf("       I assume Semi_Interleaved is true and Interleaved is false \n"); 
       Semi_Interleaved = true;
      }


 /* YOU CAN'T PRUNE WITH -W */
 if ((_Whole_DFSpace == true) && (_APPLY_PRUNE == true))
    {fprintf(stderr,"Error: you can't prune (-P) when asking for whole-space (-W) \n"); exit(1);}

 /* setting global parameters values */
 if (_PARSER_VERSION == _MPP_VERSION) _Whole_DFSpace = true; /* use an MPD-optimization */
 else _Whole_DFSpace = false; /* for sampling MPP the optimization is not good */
}
/*-------------------------------------------------------*/
void TestCodeFiles()
{if ((fpCodes == NULL) || (fpChsPl == NULL))
   fprintf(stderr, "Err: code files are closed\n");
}
/*-------------------------------------------------------*/
