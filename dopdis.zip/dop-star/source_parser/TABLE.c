#include "./Universals.h"
#include "./Aux.h"
#include "./DefsGrammar.h"
#include "./PtrList.h"
#include "Queues.h"
#include "CodeType.h"
#include "sentence.h"
#include "./Item.h"
#include "./Trees.h"
#include "./HashTable.h"
#include "./SetsHashed.h"
#include "./TABLE.h"

extern int _sen_length;
extern Boolean _GLOBAL_THRESH_ENABLED;

/* NEW: 15 Feb 2008: run on table from right to left or left to right */
#define RIGHT_TO_LEFT true
#define S_MaxLength 200
#define _follow_for_free_fast 4
/*************/
EntryPtr CrEntry()
{EntryPtr P = (EntryPtr) AllocElem(sizeof(EntryType));   /* AllocElem(sizeof(EntryType)); */
 *P = InitSet(0, 0);
 return P;
}
EntryPtr FreeEntryPtr(EntryPtr EP)
{if (EP != NULL) {FreeSet(*EP); free(EP);}
 return NULL; 
}
void NewEntry(TableType TB, int i, int j, int length)
{if ((j > i) && (i >= 0) && (j <= length)) *((*(TB + i))+(j-i)) = InitSet(i, j);
 else {fprintf(stderr,"Err: NewEntry\n");exit(1);}
}

void CompactEntry(TableType TABLE, int i, int j, int sen_length)
{EntryPtr NewEPtr; EntryPtr EPtr; EntryType ENT;

  ItemTree CheckI(ItemTree I)
   {if (I != NULL) UpdateEntry(TABLE, I, i, j);
    return NULL;
   }

  EPtr = ENTRY_Of(TABLE,i,j); ENT = *EPtr; 
  NewEntry(TABLE, i, j, sen_length);  NewEPtr = ENTRY_Of(TABLE,i,j);
  (*NewEPtr)->Max_Prob_To_Right = (*EPtr)->Max_Prob_To_Right;
  (*NewEPtr)->AlphaXBeta = (*EPtr)->AlphaXBeta;
  (*NewEPtr)->RMax_Node_Prob = (*EPtr)->RMax_Node_Prob;
  (*NewEPtr)->OMax_Node_Prob = (*EPtr)->OMax_Node_Prob;

  XSetsMap(ENT, &CheckI);

  FreeSet(ENT);
}

TableType CrTable(int n)
{int i ;
 int j;
 if (n >= 0)
  {TableType TB = (TableType) MultAlloc(n+1, sizeof(EntryPtr));
   for (i =0; i <= n; ++i) 
      *(TB + i) = (EntryPtr) MultAlloc(n-i+1, sizeof(EntryPtr));

   for (i=0; i <= n; ++i)
    for (j = 0; j <= (n-i); ++j)
      *((*(TB + i))+j) = InitSet(i,i+j);
   return TB;
  } 
 else return NULL;
}

EntryPtr ENTRY_Of(TableType TAB, int i, int j)
{extern int n; /* The size of the table */
 EntryPtr LPtr;
 if ((i <= _sen_length) && (i >= 0))
     if ((j >= i) && (j <= _sen_length))
             { LPtr = *(TAB+i); return (LPtr+(j-i));}
     else return NULL;
 else return NULL;
}

EntryPtr CopyEntry(EntryPtr EPtr)
{EntryPtr ENT;
   void CpI(ItemTree I) {Add((CpyItemFully(I)), *ENT);}

 ENT = CrEntry(); SetsMap(*EPtr, (void *) &CpI); 
 (*ENT)->Max_Prob_To_Right = (*EPtr)->Max_Prob_To_Right;
 (*ENT)->AlphaXBeta = (*EPtr)->AlphaXBeta;
 (*ENT)->RMax_Node_Prob = (*EPtr)->RMax_Node_Prob;
 (*ENT)->OMax_Node_Prob = (*EPtr)->OMax_Node_Prob;

 return ENT;
}


void MapOnEntryEnded(TableType TAB, int i, int j, void  (* fp)())
{EntryPtr EPtr = ENTRY_Of(TAB, i, j); 
 SetsMapEnded(*EPtr, fp);
}

void UpdateEntry(TableType TAB, ItemTree et, int i, int j)
{EntryPtr EPtr = ENTRY_Of(TAB, i, j); 
 et->i = (LevDomain) i; et->j = (LevDomain) j;
 *EPtr = Add(et, *EPtr); 
}

void XUpdateEntry(TableType TAB, ItemTree et, int i, int j, WordList trans)
{EntryPtr EPtr = ENTRY_Of(TAB, i, j); 
 et->i = (LevDomain) i; et->j = (LevDomain) j; et->Transition = trans;
 *EPtr = XAdd(et, *EPtr); 
}
Boolean SearchTable(TableType TAB, int n, ItemTree I)
{int k, j;
 EntryPtr EPtr;
 Boolean Found = false;
 ItemTree temp = NULL;
 for (k = 0; k <= n; ++k)
  for (j = k; j <= n; ++j)
    {EPtr = ENTRY_Of(TAB, (j-k), j);
     /* temp = SearchHT(I, (*EPtr)->ItemPtr); ZZZ*/
     temp = SeekItem(I, (*EPtr)); 
   if (Found != true)
     if (temp != NULL)
      {/* PRS("\n");PItem(temp); PItem(I);PRS("\n");*/
       if (I == temp) Found = true;
       else Found = false;
      }
     else Found = false;
    }
 return (Found);
}
/*----------------------------*/
/* fp takes <i, j, EntryPtr>  */
void MapOnTableEntries(TableType TAB, int n, void (* fp)())
{int i, k, j; EntryPtr ThisEPtr ;
 for (k = 1; k <= n; ++k)
  for (j = k; j <= n; ++j)
    {ThisEPtr = ENTRY_Of(TAB, (j-k), j); 
     (* fp)(j-k, j, ThisEPtr);
    }
}
void RevMapOnTableEntries(TableType TAB, int n, void (* fp)())
{int i, k, j; EntryPtr ThisEPtr ;
 for (k = n; k > 0; --k)
  for (j = k; j <= n; ++j)
    {ThisEPtr = ENTRY_Of(TAB, (j-k), j); 
     (* fp)(j-k, j, ThisEPtr);
    }
}
/* maps fp on the sequence of numbers k: i < k < j */
void MapBetweenIJ(int i, int j, void (* fp)())
{int k; 
 if (j-i < 1) {fprintf(stderr,"Err: in MapBetweenIJ\n"); exit(1);}
 for (k=j-1; k > i; k--) (*fp)(k); 
}
/*--*/
void MapOnLeftSpineEntries(TableType TAB, int n, void (* fp)())
{int k; EntryPtr ThisEPtr ;
 for (k = 1; k <= n; ++k) {ThisEPtr = ENTRY_Of(TAB, 0, k); (* fp)(0, k, ThisEPtr);}
}
void MapOnRightSpineEntries(TableType TAB, int n, void (* fp)())
{int k; EntryPtr ThisEPtr ;
 for (k = 1; k <= n; ++k) {ThisEPtr = ENTRY_Of(TAB, (n-k), n); (* fp)((n-k), n, ThisEPtr);}
}
/*--*/
void MapOnEntriesForSpanRev(TableType TAB, int span, int n, void (* fp)())
{int j; EntryPtr ThisEPtr ;
  for (j = n; j >= span; j--)
    {ThisEPtr = ENTRY_Of(TAB, (j-span), j); (* fp)(j-span, j, ThisEPtr);}
}
void MapOnEntriesForSpanOrig(TableType TAB, int span, int n, void (* fp)())
{int j; EntryPtr ThisEPtr ;
  for (j = span; j <= n; ++j)
    {ThisEPtr = ENTRY_Of(TAB, (j-span), j); (* fp)(j-span, j, ThisEPtr);}
}
void MapOnEntriesForSpan(TableType TAB, int span, int n, void (* fp)())
{ if (RIGHT_TO_LEFT == true) MapOnEntriesForSpanRev(TAB, span, n, fp);
  else MapOnEntriesForSpan(TAB, span, n, fp);
}
void MapOnEntriesBetweenIJ(TableType TAB, int i, int j, void (* fp)())
{int span; int l; EntryPtr ThisEPtr ;
  for (span = (j-i); span >= 1; span--)
   for (l = i; l <= (j-span); l++)
    {ThisEPtr = ENTRY_Of(TAB, l, l+span); (* fp)(l, l+span, ThisEPtr);}
}
/*--*/
/* map fpBef on each entry in the span, then apply spanFP to the span */
/* then map fpAft to all span entries                                 */
/* fpBef and fpAft take <i, j, EntryPtr> and spanFP takes <TAB, n, span>                           */
void MapOnEntriesPerSpanI(TableType TAB, int n, void (* fpBef)(), void (* spanFP_A)(), void (* fpAft)(), void (* spanFP_B)())
{int span;
 for (span = 1; span <= n ; span++)
    {MapOnEntriesForSpan(TAB, span, n, fpBef);
     (*spanFP_A)(TAB, n, span);
     MapOnEntriesForSpan(TAB, span, n, fpAft);
     (*spanFP_B)(TAB, n, span);
    }
}
/* still buggy but worth studying !!! */
void MapOnEntriesPerSpanII(TableType TAB, int n, void (* fpBef)(), void (* spanFP_A)(), void (* fpAft)(), void (* spanFP_B)())
{int l; int k;
 for (l = (n-1); l >=0; l--) /* starting from behind to avoid unended binary items: now we can free them on time */
  for (k= 1; k <= (n-l); k++)
   {(*fpBef)(l, (l+k), ENTRY_Of(TAB, l, l+k)); /* here for example we deduce */
    (*fpAft)(l, (l+k), ENTRY_Of(TAB, l, l+k)); /* here for example we complete */
    if (k == (n-l)) (*spanFP_B)(TAB, n, (n-l));                 /* freeing and the like */
   }
}
void MapOnEntriesPerSpan(TableType TAB, int n, void (* fpBef)(), void (* spanFP_A)(), void (* fpAft)(), void (* spanFP_B)())
{if ((_GLOBAL_THRESH_ENABLED == true)) MapOnEntriesPerSpanI(TAB, n, fpBef,  spanFP_A, fpAft, spanFP_B);
 else MapOnEntriesPerSpanII(TAB, n, fpBef,  spanFP_A, fpAft, spanFP_B);
}
/*----------------------------*/
void  FreeUnvalidItems(TableType TAB, int n)
{  void FreeUnvItemsInEntry(int i, int j, EntryPtr ThisEPtr)
     {XSetsMap(*ThisEPtr,  &FreeUnVItem); CompactEntry(TAB, i, j, n);}

 MapOnTableEntries(TAB, n, (void *) &FreeUnvItemsInEntry);
}
void  FreeUnvalidItemsBetweenIJ(TableType TAB, int i, int j, int n)
{  void FreeUnvItemsInEntry(int k, int l, EntryPtr ThisEPtr)
     {XSetsMap(*ThisEPtr,  &FreeUnVItem); CompactEntry(TAB, k, l, n);}

 MapOnEntriesBetweenIJ(TAB, i, j, (void *) &FreeUnvItemsInEntry);
}
/*---*/
void  FreeUnvalidItemsLeftSpine(TableType TAB, int n)
{  void FreeUnvItemsInEntry(int i, int j, EntryPtr ThisEPtr)
     {if (i != 0) {fprintf(stderr,"Err: in FreeUnvalidItemsLeftSpine\n");exit(1);}
      XSetsMap(*ThisEPtr,  &FreeUnVItem); CompactEntry(TAB, i, j, n);}

 MapOnLeftSpineEntries(TAB, n, (void *) &FreeUnvItemsInEntry);
}
void  FreeUnvalidItemsRightSpine(TableType TAB, int n)
{  void FreeUnvItemsInEntry(int i, int j, EntryPtr ThisEPtr)
     {if (j != n) {fprintf(stderr,"Err: in FreeUnvalidItemsRightSpine\n");exit(1);}
      XSetsMap(*ThisEPtr,  &FreeUnVItem); CompactEntry(TAB, i, j, n);
     }

 MapOnRightSpineEntries(TAB, n, (void *) &FreeUnvItemsInEntry);
}
void  FreeEmptyDFItems(TableType TAB, int i, int j, Boolean Ended)
{EntryPtr ThisEPtr = ENTRY_Of(TAB, i, j);
 XSetsMapEnded(*ThisEPtr,  &FreeItemEmptyDF, Ended);
}
void  TotallyFreeEmptyDFItems(TableType TAB, int i, int j, Boolean Ended)
{EntryPtr ThisEPtr = ENTRY_Of(TAB, i, j);
 XSetsMapEnded(*ThisEPtr, &TotFreeIifEmpDF, Ended);
}
void  FreeInsideOfItems(TableType TAB, int i, int j, Boolean Ended)
{EntryPtr ThisEPtr = ENTRY_Of(TAB, i, j);
 XSetsMapEnded(*ThisEPtr,  &FreeInsideItem, Ended);
}
/***************************************************/
void FreeEntry(EntryPtr EPtr)
{if (EPtr != NULL) FreeSet(*EPtr);
}
void FreeEntryDF(EntryPtr EPtr)
{  
 if (EPtr != NULL) SetsMap(*EPtr, &FreeDerForestOfItem);
}
void FreeTable(TableType TAB, int n)
{void FreeUnvItemsInEntry(int i, int j, EntryPtr ThisEPtr)
     {FreeEntry(ThisEPtr);}

 MapOnTableEntries(TAB, n, (void *) &FreeUnvItemsInEntry);
}
void FreeWholeDerivForest(TableType TAB, int n)
{int k, j;
 EntryPtr ThisEPtr;

 for (k = 0; k <= n; ++k)
  for (j = k; j <= n; ++j)
    {ThisEPtr = ENTRY_Of(TAB, (j-k), j);
     FreeEntryDF(ThisEPtr);
    }
}
/****************************************/
static Boolean ENTRIES_FREED = false;

void FreeFastArraySpan(TableType TAB, int span, int length)
{int runner; void FreeFastForEntry(int i, int j, EntryPtr EP) {FreeFastExtension(*EP);}

 if ((FREE_FAST_ARRAYS(span) == true) && (ENTRIES_FREED == false))
  {for (runner=1; runner <= span; runner++) MapOnEntriesForSpan(TAB, runner, length, (void *) &FreeFastForEntry); 
   ENTRIES_FREED = true;
  }
}
/****************************************/
/* Some procedures for testing and printing */
/****************************************/
/****************************************/
void PNItem(ItemTree I)
{PItem(I); PRS("\n");
}
void CItem(int Rno, RType RT, DOTPLACE dot)
{printf("Another\n");}
void CountItem(ItemTree item)
{AppToItem(item, (void *) &CItem);}

void VPValidItem(void *J)
{ItemTree item = (ItemTree) J;
 if (item->Valid == true) PItem(item);
}
void PValidItem(ItemTree item)
{if (item->Valid == true) PItem(item);
}
void PrintEntry(TableType TAB, int i, int j)
{EntryPtr EPtr = ENTRY_Of(TAB, i, j); 
    void PItemX(ItemTree I)
     {(GoodItem(I)); PItem(I); /*ShowDerF(I);*/}
 /* if ((*EPtr)->Size >= 0) */
 {
 printf("Entry %d %d\n", i, j);
 printf("=======\n"); /* SetsMap(*EPtr, (void *) &ShowDerF); */ /* SetsMap(*EPtr, (void *) &PItemX);   */
 SetsMap(*EPtr, (void *) &PItemX);
 /* printf("\n"); PRS("\n VALID ITEMS ARE\n"); SetsMap(*EPtr, (void *) &PValidItem); */
 }
}
void PrintTable(TableType TAB, int n)
{  void PrnEntry(int i, int j, EntryPtr EPtr)
     {PrintEntry(TAB, i, j); PRS("\n"); }
 MapOnTableEntries(TAB, n, (void *) &PrnEntry);
}
/******************************/
/******************************/
void PrDecenEnt(TableType TAB, int i, int j)
{EntryPtr EPtr = ENTRY_Of(TAB, i, j); 
 /*SetsMap(*EPtr, (void *) &PrDecen);*/
 SetsMap(*EPtr, (void *) &PrintAddedBy);
 PRS("\n---- ---------- ------------------- -------\n");
 /* SetsMap(*EPtr, (void *) &PrintAdds);*/
}
void PrDecenTable(TableType TAB, int n)
{int k, j;
 for (k = 0; k <= n; ++k)
  for (j = k; j <= n; ++j)
    {printf("Entry %d %d\n", (j-k), j);
     printf("=======\n");
     PrDecenEnt(TAB, (j-k), j);
     printf("\n");
    }
}
