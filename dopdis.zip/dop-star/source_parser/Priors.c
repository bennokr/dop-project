#include "./ALL.h"   

#define _NO_PRIOR_PROB ((ProbDomain) -10.0)
#define BKF_NO_PRIOR_PROB_WLPOS ((ProbDomain) -5.0)


#define PRIORDELIMITER "%%%" 
#define _SEN_START_POS "XXXSENSTART"

_PRIOR_KIND_DOMAIN _PRIOR_KIND_GLOB_EX = _by_nont;
NTDomain _NumOfPriorSym  = UNVALID_SYMNUM;



extern void MapOnEntryEnded(TableType TAB, int i, int j, void  (* fp)());
Boolean _PriorsExist = false;
static Boolean _StartsExist = false;
/*************************/
/* An array that holds for every non-terminal NT the probability xxxstart->NT */
static ProbDomain* NonT_Starts_Array = NULL;

void CrStartsArray()
{if (NonT_Starts_Array != NULL) cfree(NonT_Starts_Array); 
 NonT_Starts_Array = (ProbDomain *) MultAlloc(NonTSize, sizeof(ProbDomain));
}
/*----------------------*/
/* sets the kind of prior global variable */
void InitPriorKind()
{NTDomain NT_Prior_num; 
  void CheckRule(RDomain Rno)
   {/* fprintf(stderr,"%s %s\n", Name(LHS_OfR(Rno, _Unary)), Name(RHS1_OfR(Rno, _Unary))); */
    if (strstr(Name(LHS_OfR(Rno, _Unary)), _rule_parts_marker) != NULL) _PRIOR_KIND_GLOB = _by_rule; }

 _PRIOR_KIND_GLOB = _by_nont;
 NT_Prior_num = PriorNT_NUM_Of();
 if (_NumOfPriorSym != UNVALID_SYMNUM) MapOn_Rules_Of(NT_Ptr_Of(NT_Prior_num, RHS_1), _Unary, (void *) &CheckRule);
 /* fprintf(stderr,"%d\n", _PRIOR_KIND_GLOB ); */
}
/* Returns the number of the rule NTno->xxxprior */
/*                                               */
RDomain PriorRuleOf(NTDomain NTno, NTDomain NumOfPriorSym)
{return (RuleNumOfNT(NTno, NumOfPriorSym, UNVALID_RNUM, _Unary));}        

/* Returns the number of the rule xxxstart->NTno */
/*                                               */
RDomain STARTRuleOf(NTDomain NumOfStartSym, NTDomain NTno)
{return (RuleNumOfNT(NumOfStartSym, NTno, UNVALID_RNUM, _Unary));}        
/*----------------------*/
/* For initializing the priors we need binary-search for rules       */
/* This is slow. After initialization, we can get the priors in O(1) */
/** A prior rule has exactly one root-code                           */

ProbDomain SlowPrior_ProbOfNT(NTDomain NT, NTDomain NumOfPriorSym)
{NodePtr NP = NULL;  C_Addr_Domain CAdr = 0;  Code_Soort CT = ROOT_enum;
 RDomain RuleNo = PriorRuleOf(NT, NumOfPriorSym); 
 if (RuleNo == UNVALID_RNUM) {return MultNutralConst;}
 else {Rule_Apps RA;
	 RA = R_AppsOf(RuleNo, _Unary);
       if ((RA->Roots_Size != 1) || (RA->Others_Size != 0))
        {fprintf(stderr, "1Error in Prior_ProbOfNT (%d, %d)\n", (int) RA->Roots_Size, (int) RA->Others_Size); 
         ShowItem(RuleNo, _Unary, mid); fflush(stderr); exit(1);}
       NP = NodePtrOf(CAdr, RA, CT);
       return (ProbOf(&(NP->Code)));
      }
}                             
/*-*/
ProbDomain SlowStart_ProbOfNT(NTDomain NT, NTDomain NumOfStartSym)
{NodePtr NP = NULL;  C_Addr_Domain CAdr = 0;  Code_Soort CT = ROOT_enum;
 RDomain RuleNo = STARTRuleOf(NumOfStartSym, NT); 
 if (RuleNo == UNVALID_RNUM) return _NO_PRIOR_PROB;
 else {Rule_Apps RA = R_AppsOf(RuleNo, _Unary);
       if ((RA->Roots_Size != 1) || (RA->Others_Size != 0))
          {fprintf(stderr, "2Error in Prior_ProbOfNT\n"); ShowItem(RuleNo, _Unary, mid); exit(1);}
       NP = NodePtrOf(CAdr, RA, CT);
       return (ProbOf(&(NP->Code)));
      }
}                             
/*************************************************************************************/
/* ERROR is reset to false since NT_NUM_Of sets it to true if PRIOR_SYM is undefined */
/* We want to allow also grammars without PRIOR_SYM                                  */
NTDomain PriorNT_NUM_Of()
{NTDomain N = NT_NUM_Of(PRIOR_SYM); ERROR = false; return N;}

NTDomain StartNT_NUM_Of()
{NTDomain N = NT_NUM_Of(START_SYM); if (N == UNVALID_SYMNUM) N = UNV_START_SYMNUM; ERROR = false; return N;}

NTDomain StopNT_NUM_Of()
{NTDomain N = NT_NUM_Of(STOP_SYM); if (N == UNVALID_SYMNUM) N = UNV_STOP_SYMNUM; ERROR = false; return N;}
/*----------------------*/
void Init_Various_PriorProbs_Tables()
{ void UpdatePerNonT(NT_Ptr this, NTDomain NTnum)
   {if ((_PriorsExist == true) && (_PRIOR_KIND_GLOB == _by_nont)) 
	    this->NTprior = (ProbDomain) SlowPrior_ProbOfNT(NTnum, _NumOfPriorSym);
    
    if (_StartsExist == true) NonT_Starts_Array[NTnum] = (ProbDomain) SlowStart_ProbOfNT(NTnum, _NumOfStartSym);
   }

 CrStartsArray(); 
 _NumOfStartSym = StartNT_NUM_Of(); _NumOfPriorSym = PriorNT_NUM_Of(); _NumOfStopSym = StopNT_NUM_Of(); InitPriorKind();

 if (_NumOfPriorSym == UNVALID_SYMNUM) {_PriorsExist = false; ERROR = false;} else _PriorsExist = true;
 if (_NumOfStartSym == UNVALID_SYMNUM) {_StartsExist = false; ERROR = false;} else  _StartsExist = true;

 MapOnAllNonterminals((void *) &UpdatePerNonT);
 _BIGRAM_SYM_NUM = NT_NUM_Of(_BIGRAM_SYM);
}
/***************************************************************************************/
/* Priors with immidately preceding postags!!                        ******************/
ProbDomain WposPrior4start(NTDomain NT)
{char symbol[SymLength];
 strcpy(symbol, _SEN_START_POS); strcat(symbol, PRIORDELIMITER); strcat(symbol,Name(NT));
 /**fprintf(stderr,"%s\n", symbol); **/
 return Prior_ProbOfNT(NT_NUM_Of(symbol));
}
ProbDomain WposPriorOf(NTDomain NT, int iofpos, int jofpos)
{char symbol[SymLength]; ProbDomain Max; Boolean First; char name[SymLength];Boolean inputpos; NTDomain NTwLPOS;
   void DoOnePos(ItemTree I)
   {if (I->RT==_Term)
     {ProbDomain this;
      if (I->Transition==NULL) /* if input contains a given postag, we use that one! */
      {{strcpy(symbol, Name(LHS_OfItem(I))); strcat(symbol, PRIORDELIMITER); strcat(symbol,name);}
       {NTwLPOS= NT_NUM_Of(symbol);
        if (NTwLPOS!=UNVALID_SYMNUM) this = Prior_ProbOfNT(NTwLPOS);
        else this = MultProbs(Prior_ProbOfNT(NT), BKF_NO_PRIOR_PROB_WLPOS); /* bkf: prior without lpos */
       }
       Max = MaxProbs(this, Max, &First);
      }
      else 
      {{strcpy(symbol,I->Transition->Morpheme); symbol[strlen(symbol)-1]='\0'; /*throwing away "/" from POS */
	strcat(symbol, PRIORDELIMITER); strcat(symbol,name);}
       {NTwLPOS= NT_NUM_Of(symbol);
        if (NTwLPOS!=UNVALID_SYMNUM) this = Prior_ProbOfNT(NTwLPOS);
        else this = MultProbs(Prior_ProbOfNT(NT), BKF_NO_PRIOR_PROB_WLPOS); /* bkf: prior without lpos */
       }
       Max = MaxProbs(this, Max, &First);
      }
     }
   }
 inputpos=false; 
 Max=MaxNutralConst; First = false; strcpy(name, Name(NT));
 MapOnEntryEnded(CKYTAB, iofpos, jofpos, (void *) &DoOnePos);
 /* if (Max==MaxNutralConst) if it was not found I should backoff to prior of lhs but how? */
 return Max;
}
/* most probable combination of nont w a postag immidiately to the left */
ProbDomain Prior_ProbOfNTwpos(ItemTree I)
{int iofpos = I->i-1; int jofpos = I->i;
 if (iofpos == -1) return WposPrior4start(LHS_OfItem(I));
 return WposPriorOf(LHS_OfItem(I), iofpos, jofpos);
}
/***************************************************************************************/
/* find prior in O(1)   */
ProbDomain Prior_ProbOfNT(NTDomain NT)
{if (NT==UNVALID_SYMNUM) return _NO_PRIOR_PROB;
 if (_PriorsExist == true) return (NT_Ptr_Of(NT, LHS_))->NTprior;
 else return MultNutralConst;
}
/*-*/
ProbDomain Start_ProbOfNT(NTDomain NT)
{
 if (_StartsExist == true) return NonT_Starts_Array[NT];
 else return MultNutralConst;
}

/* the item representation into a non-terminal depends on the item's kind */
char *RepresentItem(ItemTree I)
{static char RES[MaxRule];
 strcpy(RES,"");
 switch (I->RT) {
   case _Term  : strcat(RES,Name(LHS_OfItem(I))); strcat(RES, _rule_parts_marker);strcat(RES, _GLOB_TERM_SYM);
         break;
   case _Unary : strcat(RES,Name(LHS_OfItem(I))); strcat(RES, _rule_parts_marker); strcat(RES, Name(RHS1_OfItem(I)));
         break;
   case _Binary: strcat(RES,Name(LHS_OfItem(I))); strcat(RES, _rule_parts_marker); 
                 strcat(RES, Name(RHS1_OfItem(I))); strcat(RES, _rule_parts_marker); 
                 if (EndedItem(I) == true) strcat(RES, Name(RHS2_OfItem(I))); 
                 else strcat(RES,_ANY_NONT_SYM);
         break;
 }/*switch */
 return RES;
}
/* either nont or most probable combination of nont with pos tag immidiately to the left */
ProbDomain Prior_ProbOfNT_EX(ItemTree I)
{if (_PRIOR_KIND_GLOB_EX == _by_nont) return (Prior_ProbOfNT(LHS_OfItem(I)));
 else if (_PRIOR_KIND_GLOB_EX == _by_nont_w_lpos) return (Prior_ProbOfNTwpos(I));
      else return MaxNutralConst;
}

ProbDomain PriorProbOfItem(ItemTree I)
{if (_PRIOR_KIND_GLOB == _by_nont)
   {return ( (EndedItem(I) == true) ? (Prior_ProbOfNT_EX(I)) : (Prior_ProbOfNT(RHS1_OfItem(I))) );}
 else
 if (_PRIOR_KIND_GLOB == _by_rule)
    {NTDomain NTNUM_Of_I = NT_NUM_Of(RepresentItem(I));
     if (NTNUM_Of_I != UNVALID_SYMNUM) return (SlowPrior_ProbOfNT(NTNUM_Of_I, _NumOfPriorSym) );
     else {fprintf(stderr,"%s has no prior\n", RepresentItem(I)); exit(1); }
    }
}
/***************************************************************************************/
void Show_PriorProbs()
{
  void ShowPriorOf(NT_Ptr this, NTDomain NTnum)
   {PRS(this->NT); PRS("  "); PRB(this->NTprior); PRS("\n"); }

 if (_NumOfPriorSym == UNVALID_SYMNUM) _NumOfPriorSym = PriorNT_NUM_Of(); 
 if (_NumOfPriorSym != UNVALID_SYMNUM) 
   {_PriorsExist = true; MapOnAllNonterminals((void *) &ShowPriorOf);}
 else {_PriorsExist = false; }
} 
/*-*/
void Show_StartProbs()
{
  void ShowStartOf(NT_Ptr this, NTDomain NTnum)
   {PRS(START_SYM);PRS("->");PRS(this->NT); PRS("  "); PRB(NonT_Starts_Array[NTnum]); PRS("\n"); }

 if (_NumOfStartSym == UNVALID_SYMNUM) _NumOfStartSym = StartNT_NUM_Of(); 
 if (_NumOfStartSym != UNVALID_SYMNUM) 
   {_StartsExist = true; MapOnAllNonterminals((void *) &ShowStartOf);}
 else {_StartsExist = false; }
} 
/*----------------------*/
