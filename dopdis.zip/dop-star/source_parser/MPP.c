#include "./ALL.h"
#include "GenHashUnit.h"
#include "GenHASHTABLE.h"
#include "unary_bamboo_functions.h"

/* use either frequency or sum of probabilities of sampled derivations for selecting the MPPO/MPS */
#define _UseSampleFrequency false
#define _leave_SQ_Bracket_in_Der true


extern int MPP_Sample_Size;
extern Boolean _Print_All_Sampled;
extern void EXT_PRS(UnitPtr UP); 
extern void EXT_PRS_DER(UnitPtr UP);
extern void APPEND_TERM(char *RESULT, ItemTree item);

Boolean _Uniform_Dist = false; /* if true: only for faking */
extern void ShowDerF(ItemTree I);

ProbDomain RandomProb(ProbDomain SUM)
{ProbDomain RandProb; RealProbDomain SUM_X = (RealProbDomain) (POWER((double) SUM));
 
 RandProb = ( (RealProbDomain) SUM_X * ((RealProbDomain) drand48() ) );
 return (ProbDomain) (log10((double) RandProb));
}
/*------------*/
/* returns a random number [1, SUM] */
int RandomNum(int SUM)
{return  ((int) 1 + (SUM * (rand()/(RAND_MAX+1.0)) ));
}
/******************************/
/* Given a Distribution and the total sum of all probabilities: 
   sample one from the distribution                             
*/
Boolean SSS = false;
Boolean FirstSample = true;

PtrList PLSampleANodeFrom(PtrList Distribution, ProbDomain SumOfSums)
{int NUM =0; ProbDomain SUM = SumNutralConst; ProbDomain SUMZ = SumNutralConst; 
 ProbDomain RandProb = SumNutralConst; PtrList PLNode = NULL; int RandNum; ItemTree I;

    void SumUpProbs(void *P)
     {SUM = SumProbs(SUM, ((DerFPtr) P)->Sum_Prob); NUM++;
     }
    void XSelect(PtrList This, Boolean *STOP)
     {Boolean FIRST = false; ProbDomain MAX; 

      if (_Uniform_Dist == false)
        {SUMZ = SumProbs(SUMZ, ((DerFPtr) This->Ptr)->Sum_Prob); 
         MAX = MaxProbs(SUMZ, RandProb, &FIRST); /* SUMZ >= RandProb ---> FIRST = true */
        }
      else if (RandNum == NUM) FIRST = true;

      if ( FIRST == false ) {NUM++;}
      else {*STOP = true; PLNode = This;}
     }

 if (Distribution == NULL) return NULL;
 PListMap(Distribution, (void *) &SumUpProbs);

 if ((SSS == true) && (FirstSample == true)) 
    {FirstSample = false; 
     /* PRS("\n"); PRI(NUM); PRB(SUM); PRS("\n"); */
    }

 if (_Uniform_Dist == false )
    RandProb = RandomProb(SUM); /* note: SUM >= (RandomProb(SUM)) > SumNutralConst */
 else RandNum = RandomNum(NUM);
                       /* PRS("has "); PRI(NUM); PRS(" : selected "); */

 NUM = 1; SUMZ = SumNutralConst;
 PListMapUntillN(Distribution, (void *) &XSelect); 
                       /* PRI(NUM); PRS("\n"); */
 return PLNode;
}
/***********************************/
DerFPtr SampleANodeFrom(PtrList Distribution, ProbDomain SumOfSums)
{PtrList PLofDer;
 if (Distribution == NULL) return NULL;
 PLofDer = PLSampleANodeFrom(Distribution, SumOfSums);
 if (PLofDer == NULL) return NULL;
 else return ((DerFPtr) PLofDer->Ptr); 
}
/*------------------*/


Boolean HasSubSiteDFP(DerFPtr DFP, Child_Type CHT)
{/* Rule_Apps RAp = IR_AppsOf(DFP->SelfItem->RuleNo, DFP->SelfItem->RT, 1); 
 NodePtr NPp = NodePtrOf(DFP->CAdr, RAp, DFP->CSoort); 
 return TakeRsOnly(NPp, CHT);  */
 return (IsOpenCh(DFP->OpenTrees, CHT));
}
/*------------------*/
/***/
ProbDomain OneProb;
char OneDerivation[MaxTreeL];
char OneTree[MaxTreeL];
char OneSentence[MaxTreeL];
/*******************************************************************/
char Remove_RESULT[MaxRule];
char *RemoveSQBracket(char *tree)
{int i,j; 
 if (_leave_SQ_Bracket_in_Der == true) return tree;

 strcpy(Remove_RESULT,""); 
 j=0;
 for (i=0; i<strlen(tree); i++) 
  if ((tree[i]!=']') && (tree[i]!='[')) {Remove_RESULT[j]=tree[i]; j++;}
 Remove_RESULT[j]='\0';
 /* fprintf(stderr,"%s\n %s\n", tree, Remove_RESULT); */
 return Remove_RESULT;
}
/********************/
char *GET_TERM_Struct_OneTree(DerFPtr DFP, TreeCodeT TreeC, InTreeCodeT OwnC)
{static char RESULT[MaxRule];
 strcpy(RESULT, PartOfItem(DFP->SelfItem,LHS_));             
 strcat(RESULT, ",["); 
 strcat(RESULT,PrefixOfUnariesUnder(TreeC, OwnC)); 
 strcat(RESULT, "("); 
 APPEND_TERM(RESULT, DFP->SelfItem); 
 strcat(RESULT, ",[])"); 
 strcat(RESULT,SuffixOfUnariesUnder(TreeC, OwnC)); 
 strcat(RESULT, "]");                   
 return RESULT;
}
char *LchBef_Struct_OneTree(DerFPtr DFP, TreeCodeT TreeC, InTreeCodeT OwnC,  InTreeCodeT LCh_OwnC)
{static char RESULT[MaxRule];
 strcpy(RESULT, PartOfItem(DFP->SelfItem,LHS_)); 
 strcat(RESULT, ",["); 
 strcat(RESULT,PrefixOfUnariesUnder(TreeC, OwnC));
 strcat(RESULT,PrefixOfUnariesAbove(TreeC, LCh_OwnC));
 strcat(RESULT, "(");
 return RESULT;
}
char *LchAft_Struct_OneTreeBIN(DerFPtr DFP, TreeCodeT TreeC, InTreeCodeT OwnC,  InTreeCodeT LCh_OwnC)
{static char RESULT[MaxRule];
 strcpy(RESULT, ")"); 
 strcat(RESULT,SuffixOfUnariesAbove(TreeC, LCh_OwnC));
 strcat(RESULT,SuffixOfUnariesUnder(TreeC, OwnC)); 
 return RESULT;
}
char *LchAft_Struct_OneTree(DerFPtr DFP, TreeCodeT TreeC, InTreeCodeT OwnC,  InTreeCodeT LCh_OwnC)
{static char RESULT[MaxRule];
 strcpy(RESULT, ")"); 
 strcat(RESULT,SuffixOfUnariesAbove(TreeC, LCh_OwnC));
 strcat(RESULT,SuffixOfUnariesUnder(TreeC, OwnC)); 
 strcat(RESULT, "]"); 
 return RESULT;
}
char *RchBef_Struct_OneTree(DerFPtr DFP, TreeCodeT TreeC, InTreeCodeT OwnC,  InTreeCodeT RCh_OwnC)
{static char RESULT[MaxRule];
 strcpy(RESULT,PrefixOfUnariesAbove(TreeC, RCh_OwnC));
 return RESULT;
}
char *RchAft_Struct_OneTree(DerFPtr DFP, TreeCodeT TreeC, InTreeCodeT OwnC,  InTreeCodeT RCh_OwnC)
{static char RESULT[MaxRule];
 strcpy(RESULT, ")"); 
 strcat(RESULT,SuffixOfUnariesAbove(TreeC, RCh_OwnC));
 strcat(RESULT, "]"); 
 return RESULT;
}
/*
**
*/
/* Given a node DFP: go on sampling a derivation from it*/
void SampleADerfromNode(DerFPtr DFP, Boolean prnt_this)
{PtrList ThisL = CrPList(); Boolean prnt_next = true; Boolean EXIT_THIS = false; char TEMP[MaxRule];
 DerFPtr ThisNodeL = NULL; DerFPtr ThisNodeR = NULL; ProbDomain SumOfSums = SumNutralConst;

 SSS = true; FirstSample = true;
 /* PRS("---   Sampling:"); prntself(DFP); PRS("\n"); */

 if (DFP != NULL) 
  if (DFP->SelfItem != NULL)
   if ((DFP->SelfItem->RT != _Term) && (DFP->ListOfChNodes == NULL))
      {fprintf(stderr, "Err: a DFP has NULL children for item \n"); PItem(DFP->SelfItem); PRS("\n"); EXIT_THIS = true;}
   else ; /* {PItem(DFP->SelfItem);PRS("\n");} */
  else {fprintf(stderr, "Err: a DFP->SelfItem is NULL in MPP.c\n"); EXIT_THIS = true;}
 else {fprintf(stderr, "Err: a DFP is NULL in MPP.c\n"); EXIT_THIS = true;}

 if (EXIT_THIS == false)
  {TreeCodeT TreeC = TreeCodeOfDFP(DFP); InTreeCodeT OwnC = OwnCodeOfDFP(DFP);
   InTreeCodeT LCh_OwnC = Ch_OwnCodeOfDFP(DFP,  Lch_enum);
   InTreeCodeT RCh_OwnC = Ch_OwnCodeOfDFP(DFP,  Rch_enum);

  switch (DFP->SelfItem->RT) {
    case   _Term:
            if (prnt_this == true)
             {if (DFP->CSoort == ROOT_enum) 
	       {strcat(OneDerivation, "*"); OneProb = MultProbs(OneProb, CodeProbability(DFP->SelfItem, DFP, DFP->CSoort));}

              strcpy(TEMP, GET_TERM_Struct_OneTree(DFP, TreeC, OwnC));
	      strcat(OneTree, TEMP); strcat(OneDerivation, RemoveSQBracket(TEMP));
              APPEND_TERM(OneSentence, DFP->SelfItem);
             }
             break;
    case  _Unary:
            if ( HasSubSiteDFP(DFP, Lch_enum) == true ) /* children are roots */
                 ThisNodeL = SampleANodeFrom(DFP->ListOfChNodes, SumOfSums); 
            else if (DFP->ListOfChNodes->Next == NULL) /* only one non-root child ! */
                     {ThisNodeL = ((DerFPtr) DFP->ListOfChNodes->Ptr);
                      /* PRS("	 		has 1 left internal child \n");*/
                      }
                 else {fprintf(stderr, "Err: TWO CHILDREN for the same NODE ?\n"); exit(1);}

            if (prnt_this == true) 
	      {if (DFP->CSoort == ROOT_enum) 
                  {strcat(OneDerivation, "*"); 
		   OneProb = MultProbs(OneProb, CodeProbability(DFP->SelfItem, DFP, DFP->CSoort));
		  }

               strcpy(TEMP, LchBef_Struct_OneTree(DFP, TreeC, OwnC,LCh_OwnC));
               strcat(OneTree, TEMP); strcat(OneDerivation, RemoveSQBracket(TEMP));
              }

              SampleADerfromNode(ThisNodeL, true); 

            if (prnt_this == true) 
	      {strcpy(TEMP, LchAft_Struct_OneTree(DFP, TreeC, OwnC,LCh_OwnC));
               strcat(OneTree, TEMP); strcat(OneDerivation, RemoveSQBracket(TEMP));
	      }
            break;

    case _Binary:
                if ( HasSubSiteDFP(DFP, Lch_enum) == true )
                  ThisL = PLSampleANodeFrom(DFP->ListOfChNodes, SumOfSums); 
                else {ThisL = DFP->ListOfChNodes; /* OTHER_enum child - there is only one */
                      /* PRS("	 		has 1 left internal child \n"); */
                     }
                ThisNodeL = (DerFPtr) PListHeadPtr(ThisL);

                if (EndedItem(DFP->SelfItem) == true) 
                 {if ( HasSubSiteDFP(DFP, Rch_enum) == true )
                   ThisNodeR = SampleANodeFrom((PtrList) ThisL->Data, SumOfSums); 
                  else if (ThisL->Data != NULL)
                       {ThisNodeR = (DerFPtr) ((PtrList) ThisL->Data)->Ptr;
                        /* PRS("	 		has 1 right internal child \n");*/
                       }
                      else {fprintf(stderr, "Err: Second CHILD is NULL ?\n"); exit(1);}  
                  prnt_next = false;
                 }
                else {ThisNodeR = NULL;}

                if (prnt_this == true) 
                 {if (DFP->CSoort == ROOT_enum) 
                   {strcat(OneDerivation, "*"); 
		    OneProb = MultProbs(OneProb, CodeProbability(DFP->SelfItem, DFP, DFP->CSoort));
		   }
                 strcpy(TEMP, LchBef_Struct_OneTree(DFP, TreeC, OwnC,LCh_OwnC));
                 strcat(OneTree, TEMP); strcat(OneDerivation, RemoveSQBracket(TEMP));
                 }
                SampleADerfromNode(ThisNodeL, prnt_next); 
                if (prnt_this == true)
	          {strcpy(TEMP, LchAft_Struct_OneTreeBIN(DFP, TreeC, OwnC,LCh_OwnC));
                   strcat(OneTree, TEMP); strcat(OneDerivation, RemoveSQBracket(TEMP)); 

	           strcpy(TEMP, RchBef_Struct_OneTree(DFP, TreeC, OwnC, RCh_OwnC));
		   strcat(OneTree, ","); strcat(OneTree, TEMP); strcat(OneTree, "("); 
		   strcat(OneDerivation, ",");  strcat(OneDerivation, RemoveSQBracket(TEMP)); strcat(OneDerivation, "(");  
		  }
                if (ThisNodeR != NULL) SampleADerfromNode(ThisNodeR, true);
                if (prnt_this == true) 
		  {strcpy(TEMP, RchAft_Struct_OneTree(DFP, TreeC, OwnC, RCh_OwnC));
                   strcat(OneTree, TEMP); strcat(OneDerivation, RemoveSQBracket(TEMP));
		  }
                break;
  }/* end of switch */
 }/* if */
}
/**-----------------------------------------**/
void SamplefromPForest(PtrList P, HASHTABLE AllParses, HASHTABLE AllSentences, HASHTABLE AllDerivations)
{int i; PtrList DFPsPList ; ProbDomain SumOfSums = SumNutralConst; DerFPtr ThisNode = NULL; Boolean NEW = false;

            void Add_A_Der(DerFPtr P)
             {if (((DerFPtr) P)->CSoort != ROOT_enum) {fprintf(stderr,"Err: NOT ROOT ?\n");exit(1);}
              DFPsPList = EnterPStack((void *) P, DFPsPList);
              SumOfSums = SumProbs(SumOfSums, P->Sum_Prob);
             }
            void AddDerProbOf(void *I)
               {TreeCodeT i;
                if (I != NULL) {
                 ItemCPtr CP = ((ItemCPtr) ((ItemTree) I)->DerForest);
                 if (CP != NULL)
                  for (i=0; i < CP->RootsSize; ++i)
                   if (RedDF_Item((ItemTree) I)==true) Add_A_Der(&(CP->Roots[i]));
                   else if (CP->R_valids[i] == true) Add_A_Der(&(CP->Roots[i]));
                       else ; /* do nothing */
                 else ; /* do nothing */
                }
               }

 if (P==NULL) {EXIT(NOPF);}
 else 
   {DFPsPList = CrPList(); PListMap(P, (void *) &AddDerProbOf);

    for (i=1; i <= MPP_Sample_Size; i++)
     {strcpy(OneTree,""); strcpy(OneSentence,"");  strcpy(OneDerivation,""); OneProb = MultNutralConst;
      ThisNode = SampleANodeFrom(DFPsPList, SumOfSums); 
      if (ThisNode == NULL) {EXIT(NODF);}
      else {strcat(OneTree, "("); SampleADerfromNode(ThisNode, false); strcat(OneTree, ").\n");}

      /* fprintf(stderr,"%s\n", OneDerivation); */
      NEW = (ENT2HTableUpdateProb(AllDerivations, OneDerivation, OneProb));
      if (NEW == true)  /* if the derivation is new we update probs of parses and sentences */
        { NEW = (ENT2HTableAddProb(AllParses, OneTree, OneProb));
          NEW = (ENT2HTableAddProb(AllSentences, OneSentence, OneProb));
        }
     }

     FreePListN(DFPsPList);
  }
}
/*-----------------*/
ProbDomain EntropyOf(ProbDomain logprob)
{ProbDomain prob = (ProbDomain) (POWER((double) logprob));  
 return (((ProbDomain) -1) * prob * logprob);
}

ProbDomain ComputeEntropy(UnitPtr UP)  /* for a parse */
{int i; 
 /* fprintf(stderr,"%e\n", UP->UnitProb); */
 return EntropyOf(UP->UnitProb); 
}
/*---------*/
void SampleDerfromPF(ParForest PF)
{int i; char *MPP = NULL; ProbDomain Entropy = ((double) 0); char *MPS; ProbDomain MPPProb; ProbDomain MPSProb;

 HASHTABLE AllParses ; HASHTABLE AllSentences ; HASHTABLE AllDerivations;

 void ComputeEntropyI(UnitPtr UP)  {Entropy = Entropy + ComputeEntropy(UP);}

 AllParses = NewHTable(); AllSentences = NewHTable(); AllDerivations = NewHTable();

 if (PF != NULL)
   {
    fprintf(stderr, "(sampling %d  derivations from the derivation-space)\n", MPP_Sample_Size);
    SamplefromPForest(PF->Starts, AllParses, AllSentences, AllDerivations);

    if (_UseSampleFrequency == true) {MPP = MaxFreqKeyOf(AllParses); MPS = MaxFreqKeyOf(AllSentences);}
    else {MPP = MaxProbKeyOf(AllParses, &MPPProb); MPS = MaxProbKeyOf(AllSentences, &MPSProb);} 

    PRS("S: "); PRS(MPS);PRS("\n");
    if (MPP != NULL) 
       {if (_UseSampleFrequency == false) MapOnHTableUnits(AllParses, (void *) &ComputeEntropyI); 

        if (_Print_All_Sampled_DER== true)
           {MapOnHTableUnits(AllDerivations, (void *) &EXT_PRS_DER);
           }
	else
        if (_Print_All_Sampled == true)
           {PRS("\n There are "); PRI((int) NumOfUnitsInHT(AllParses)); PRS(" sampled parses:\n"); 
            MapOnHTableUnits(AllParses, (void *) &EXT_PRS);
           }
        else
	{/* PRINTING MPP/MPS */
         PRS("\n The Most Probable Parse (out of "); 
         PRI((int) NumOfUnitsInHT(AllParses)); PRS(" sampled parses) is\n"); 
         PRS(MPP);
          if (_UseSampleFrequency == false) {
           PRS("MPP Probability  ");   PRB(MPPProb); PRS("\n");
           PRS("MPS Probability  ");   PRB(MPSProb); PRS("\n");
           /* fprintf(stderr,"Estimated Sentence Entropy: %6.6e\n", Entropy); */
          }
        }/* PRINTING MPP/MPS */
       }
    else EXIT(NODF);
   }
 else {EXIT(NOPF);}
}
/********************************************************************************/
/********************************************************************************/
extern char *OriginalWord(LevDomain i, LevDomain j);

void APPEND_TERM(char *RESULT, ItemTree item)
{Rule_Ptr RPtr; int lhs, rhs1, rhs2; char TEMP[SymLength];
 RPtr = RulePtr_Of(item->RuleNo, item->RT);
 rhs1 = RHS1_Of(RPtr);

 if (!strcmp((TName(rhs1)), UNKNOWNSYM))
   {strcat(RESULT,"UNKNOWN"); 
    /* strcpy(TEMP, (OriginalWord(item->i, item->j))); The following instead!*/ strcpy(TEMP, (item->Transition->Rule));
    strcat(RESULT,TEMP);/* strcat(RESULT," ");*/
   }
 else {strcat(RESULT, PartOfItem(item, RHS_1));/* strcat(RESULT," ");*/}
}
void EXT_PRS(UnitPtr UP) 
{int i;
 if (_UseSampleFrequency==true)
  for (i=1; i<= UP->UnitFreq; i++) 
     {fprintf(fpOUT, "%s\n", UP->Rule); fflush(fpOUT); fflush(stderr);}
 else {fprintf(stderr,"%6.6e ",POWER(UP->UnitProb)); fprintf(fpOUT, "%s", UP->Rule); fflush(fpOUT); fflush(stderr);}
 fflush(fpOUT);
}
void EXT_PRS_DER(UnitPtr UP) 
{int i;
 if (_UseSampleFrequency==true)
  for (i=1; i<= UP->UnitFreq; i++) 
     {fprintf(fpOUT, "%s\n", UP->Rule); fflush(fpOUT); fflush(stderr);}
 else {fprintf(stderr,"%6.6e ",POWER(UP->UnitProb)); fprintf(fpOUT, "(%s).\n", UP->Rule); fflush(fpOUT); fflush(stderr);}
 fflush(fpOUT);
}
