#include "./ALL.h"

/*****************************/
extern ParForest PARF;
extern Boolean Interleaved;
/***************************/
/* VERY IMPORTANT
  A parseforest generation has
   been abandoned only because of memory
   problems.
   SO therefore, when the AddedBy list
   was changed for items A->BC*, things
   were only updated for MarkPF. The rest
   of the procedures and functions were'nt
   updated as necessary. 
*/
/***************************/
Boolean ParForestEmpty(ParForest PARF)
{if (PARF == NULL) return true;
 else if (PARF->Starts == NULL) return true;
      else return false;
}
PtrList StartItemsList(TableType TAB, int n)
{PtrList PL;
     void FI_CrList(ItemTree item)
      {Rule_Ptr RPtr; NTDomain NONT; 
       if (item != NULL) {
         RPtr = RulePtr_Of(item->RuleNo, item->RT);
         NONT = LHS_Of(RPtr);
         if ((NONT == StartNonterminal) && (IsEnded_Item(item) == true))
                    PL = EnterP((void *) item, PL);
       }
      }
 EntryPtr EPtr = ENTRY_Of(TAB, 0, n);
 PL = CrPList();
 SetsMapEnded(*EPtr, (void *) &FI_CrList);
 return PL;
}
/***************************/
PtrList AllStartItems(TableType TAB, int n)
{PtrList PL;int i,j,k;
     void FI_CrList(ItemTree item)
      {Rule_Ptr RPtr = RulePtr_Of(item->RuleNo, item->RT);
       NTDomain NONT = LHS_Of(RPtr);
       if (item != NULL)
        if ((NONT == StartNonterminal) && (IsEnded_Item(item) == true))
                    PL = EnterPStack((void *) item, PL);
      }
 PL = CrPList();
 for (i=0;i<n;i++)
  for (k=1;k<=(n-i);k++)
    {EntryPtr EPtr = ENTRY_Of(TAB, i, i+k);
     SetsMap(*EPtr, (void *) &FI_CrList);}
 return PL;
}
/********************/
ParForest CrParF()
{return NULL;
}
ParForest InitParF()
{ParForest PF = (ParForest) AllocElem(sizeof(struct ParseForestStr));
 PF->Starts = NULL;
 PF->Ends = NULL;
 PF->StructBU = NULL;
 PF->StructTD = NULL;
 return PF;
}
/****************************/
ParForest GenParF(TableType TAB, int n)
{PtrList P = NULL;
 ParForest PF = NULL;
 PF = InitParF();
 P = StartItemsList(TAB, n);
 PF->Starts = P;
 if (P == NULL);
 else /* if (Semi_Interleaved == false) */
        {MarkPF(P, MAX_LEVEL); PF->Starts = P; }
 return PF;
}
/********/
ParForest GenChunks(TableType TAB, int n)
{int i,k; PtrList P = NULL; ParForest PF = NULL;
 void MarkAnItem(ItemTree I)
   {P->Ptr = (void *) I;
    MarkPF(P, MAX_LEVEL); 
   }
 void GenEntryChunks(int i, int j, EntryPtr EPtr)
    {SetsMapEnded(*EPtr, (void *) &MarkAnItem); } 
 PF = InitParF();
 PF->Starts = StartItemsList(TAB, n);

 /* Marking all complete chunks as valid */
 P = EnterPStack((void *) NULL, P); /* just a trick to use MarkPF(PtrList,int) */
 RevMapOnTableEntries(TAB, n, (void *) &GenEntryChunks);
 FreePListN(P);
 return PF;
}
/*******************************/
extern void MarkPFDown(PtrList P);
extern void MarkPFLeftSpineOnly(PtrList P);
extern void MarkPFChValid(PtrList P); 
/* mark items in entries [0,x] as valid if they are part of an ended chunk */

void GenChunksLeftSpineOnly(TableType TAB, int n)
{int i,k; PtrList P = NULL; 
 void MarkAnItem(ItemTree I)   {P->Ptr = (void *) I; MarkPFLeftSpineOnly(P);}
 void GenEntryChunks(int i, int j, EntryPtr EPtr) {if (i == 0) SetsMapEnded(*EPtr, (void *) &MarkAnItem);} 

 /* Marking left complete chunks as valid */
 P = EnterPStack((void *) NULL, P); /* just a trick to use MarkPFLeftSpineOnly(PtrList,int) */
 RevMapOnTableEntries(TAB, n, (void *) &GenEntryChunks);
 FreePListN(P);
}
/***-------*/
void MarkPFChValid(PtrList P)
{   void MarkCHValid(void *CH) {ItemTree I = (ItemTree) CH; if (I != NULL) I->Valid = true;}
    void MarkItem(PtrList J)
       {ItemTree item = (ItemTree) J->Ptr; PtrList  Rest = (PtrList) J->Data;    
        item->Valid = true; if (Rest != NULL) PListMap(Rest, (void *) &MarkCHValid);
       }
 if (P == NULL); 
 else PDListMap(P, (void *) &MarkItem);
}
void GenChunksBetweenIJII(TableType TAB, int i, int j, int n)
{EntryPtr EPtr; 
 void MarkAnItem(ItemTree I) {I->Valid = true;}
 void MarkChValidIf(ItemTree I) {if (I->Valid == true) MarkPFChValid(I->AddedBy); }
 void MarkChildren(int k, int l, EntryPtr EPtrX) {SetsMap(*EPtrX, (void *) &MarkChValidIf);} 

 /* Marking left complete chunks as valid at the span's left-spine entry */
 EPtr = ENTRY_Of(TAB, i, j); 
 SetsMap(*EPtr, (void *) &MarkAnItem);

 MapOnEntriesBetweenIJ(TAB, i, j, (void *) &MarkChildren); /* important: MapOnEntriesBetweenIJ works top-down i.e from span (j-i) till span 1*/
}
/***-------*/
void GenChunksBetweenIJ(TableType TAB, int i, int j, int n)
{EntryPtr EPtr; PtrList P = NULL;  
 void MarkAnItem(ItemTree I)   {P->Ptr = (void *) I; MarkPFDown(P);}
 void GenEntryChunks(int i, int j, EntryPtr EPtr) {SetsMapEnded(*EPtr, (void *) &MarkAnItem);} 

 /* Marking left complete chunks as valid at the span's left-spine entry */
 P = EnterPStack((void *) NULL, P); /* just a trick to use MarkPFDown(PtrList,int) */     
 MapOnEntriesBetweenIJ(TAB, i, j, (void *) &GenEntryChunks); /* important: MapOnEntriesBetweenIJ works top-down i.e from span (j-i) till span 1*/
 FreePListN(P);
}
/*******************************/
void ParForestMap(ParForest PF, void (* fp)(), TravType Trav)
{      void MapLevel(void *J)
          {PtrList PP = (PtrList) J;
           /* PRS("\n***********\n");*/
           PListMap(PP, fp); } 

  switch (Trav) {
   case B_U : PListMap(PF->StructBU, (void *) &MapLevel);
            break;
   case T_D : PListMap(PF->StructTD, (void *) &MapLevel);
            break;
   case O_THER : break;
   otherwise : break;
  } 
}
void FreeParForest(ParForest PF)
{if (PF != NULL) 
  {FreePListN(PF->Starts); FreePListN(PF->StructBU); 
   FreePListN(PF->Ends); FreePListN(PF->StructTD); cfree(PF);}
}
/*******************************/
/* depth-first travs en map  */
/*******************************/
/* Only marking the items in the table    */
/* MakeASetOfI makes sets out of Adds and AddedBy
   of the given item
   However : For expected memory problems, this task is
        moved to be done during construction of the table already.
*/
/******************************************/
/* Marks the parse-forest items as valid  and assigns to every item A
************/
void MarkPF(PtrList P, LevDomain i)
{   void MarkItem(PtrList J)
       {ItemTree item = NULL; PtrList  Rest;
        item = (ItemTree) J->Ptr; Rest = (PtrList) J->Data;
        if (item != NULL)
          if (item->Valid == false) {item->Valid = true; MarkPF(item->AddedBy, i-1);}
        if (Rest != NULL) MarkPF(Rest, i);
       }
 if (P == NULL); 
 else PDListMap(P, (void *) &MarkItem);
}
/************/
void MarkPFLeftSpineOnly(PtrList P)
{   void MarkItem(PtrList J)
       {ItemTree item = (ItemTree) J->Ptr; PtrList  Rest = (PtrList) J->Data;    
        if (item->Valid == false)
         {item->Valid = true; MarkPFLeftSpineOnly(item->AddedBy);
          /*   if (Rest != NULL) MarkPFLeftSpineOnly(Rest); We go only down the left spine */
         }
       }
 if (P == NULL); 
 else PDListMap(P, (void *) &MarkItem);
}
void MarkPFDown(PtrList P)
{   void MarkItem(PtrList J)
       {ItemTree item = (ItemTree) J->Ptr; PtrList  Rest = (PtrList) J->Data;    
        if (item->Valid == false)
         {item->Valid = true; MarkPFDown(item->AddedBy);
          if (Rest != NULL) MarkPFDown(Rest);
         }
       }
 if (P == NULL); 
 else PDListMap(P, (void *) &MarkItem);
}
/*********************************************************************************************************************************/
/**************************************/
/* For testing: print facilities.     */
/**************************************/
/*
 To make this work you need to change PListMap
 to apply an fp on PtrList and then when item->AddedBy
 is NULL then Data is a pointer to 1, otherwise it is
 computed from all the AddedBy pointers (take care of pairs).
void ProbUp(void *J)
{ItemTree item = (ItemTree) J;
 if (item->AddedBy == NULL) 
 PItem(item);PRS("\n");
 PRS("Its parent is\n");
}
*/
void VUpPrnt(void *J)
{ItemTree item = (ItemTree) J;
 if (item->AddedBy == NULL) PRS("-----------\n");
 PItem(item);PRS("\n");
 PRS("Its parent is\n");
}
void VDownPrnt(void *J)
{ItemTree item = (ItemTree) J;
 PItem(item);PRS("\n");
 if (item->AddedBy == NULL) PRS("\n-----------\n");
 else PRS("Its decendent is\n");
}
void VoidPrnt(void *J, int i)
{ItemTree item = (ItemTree) J;
 PRS("Level ");PRI(i);PRS(" ");PItem(item);PRS("\n");
 PRS("Its decendent is\n");
 PrntLst(item->AddedBy, i, item->RT);
}
void PrntLst(PtrList P, int i, RType RT)
{if (P == NULL) ; /* PRS("~~~~~~~\n");*/
 else 
   switch (RT) {
     case _Unary : PListMapEx(P, (void *) &VoidPrnt, ++i);
                  break;
     case _Binary: PListMapEx(P, (void *) &VoidPrnt, ++i);
                  break;
     otherwise  : PRS("\n Er100: RT shouldn't be like this\n");
                  break;
   } /* switch */
}
void PrntTD(TableType TAB, int n)
{PtrList TL;
 TL = StartItemsList(TAB, n);
 /* if (TL == NULL) PRS("YES\n"); PListMap(TL, &VPItem);*/
 PrntLst(TL, 0, _Unary);
}
void ShowParF(ParForest PF)
{PRS("\nThe Parse Forest is\n");
 PRS("Starts\n"); PListMap(PF->Starts, &VPItem);
 PRS("\n-----\n");
 PRS("Ends\n"); PListMap(PF->Ends, &VPItem);
 PRS("\n");
}
void sameadd(void *J)
{ItemTree item = (ItemTree) J;
 if (item->RuleNo == 1)
   if (item->RT == _Term) {PItem(item);
                          PRI((long) item);
                         }
}
/**********CLOSED CLOSED ***********************************************************************/
/**********CLOSED CLOSED ***********************************************************************/
/**********CLOSED CLOSED ***********************************************************************/
/****************
The older version:
   A priority-level L(A) such:
     for every two items in the parse-forest, A and B: (A is addedBy B) IFF  ( L(A) > L(B) )
   The priority levels are necessary during computing the derivation-forest and the probabilities
   because we employ an algorithm that is not fully interleaved (either two phases or 
   semi-interleaved). In that context, lower-levels must be computed before higher-levels.
   Note that an item that has not be ranked yet has level 0.
****************/
/* LEVELS_UPDATE */
void MarkPFOLD(PtrList P, LevDomain i)
{   void MarkItem(PtrList J)
       {ItemTree item = (ItemTree) J->Ptr;
        PtrList  Rest = (PtrList) J->Data;
        if ((i < item->Level) || (item->Level == 0))  
           {item->Level = i; item->Valid = true; MarkPF(item->AddedBy, i-1);}
        if (Rest != NULL) MarkPF(Rest, i);
       }
 if (P == NULL); 
 else PDListMap(P, (void *) &MarkItem);
}
