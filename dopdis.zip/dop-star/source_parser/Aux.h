extern char *TOLOWERx(char *a);

extern void PRBS(ProbDomain a);
extern void PRINTTIME(); 
extern char *TOLOWER(char *a);

/* if the following is defined: it results in a smaller memory implementation */
/*
#ifndef _SMALL_IMPLEMENTATION #define _SMALL_IMPLEMENTATION  xxx #endif
*/
/*
**
*/

extern FILE *fpIN, *fpOUT;
/****/
enum ErrValues {ALLOC=1,NONG=2,NONW=3,EMPTY=4,NONP=5,NOPF=6,NODF=7,NOCFG=8};
#ifndef ERRORTYPE
#define ERRORTYPE enum ErrValues
#endif

/********************/
extern void PRINTTIME();
extern void EXIT(ERRORTYPE ERR);
/************************************/
/*** General types and definitions */
#ifndef _SMALL_IMPLEMENTATION
enum RTypes {_NONE = 0, _Unary = 1, _Binary = 2, _Term = 3, _Eps = 4};
#ifndef RType
#define RType enum RTypes 
#endif
#endif
#ifdef _SMALL_IMPLEMENTATION
#ifndef RType
#define RType char
#define _NONE  0
#define _Unary  1
#define _Binary  2
#define _Term  3
#define _Eps  4
#endif
#endif
/********************/
#ifndef _SMALL_IMPLEMENTATION
enum boolean {false = 0 , true = 1}; 
#define Boolean enum boolean 
#endif
#ifdef _SMALL_IMPLEMENTATION
#ifndef Boolean
#define false 0
#define true 1
#define Boolean char
#endif
#endif

/********************/
#ifndef MAXLENG 
#define MAXLENG SymLength
#endif

extern void *AllocElem(size_t size);
extern void *MultAlloc(size_t count, size_t elemsize);
extern void PRI(long int a);
extern void PRC(char *a);
extern void PRS(char *a);
extern void WRITE(char *a);
/*********************/
extern void PRB(ProbDomain a);
extern double POWER(ProbDomain a);
extern void PRBM(float a);
extern char *NewStringOf(char *A);
extern void yyerror(char *str);
extern Boolean Negate(Boolean X);
extern char *REMOVE_VOID_PREFIX(char *S);
extern char *TOUPPER(char *a);
extern Boolean EmptyString(char *str);

extern  clock_t StartT, FinishT, MidT;
extern struct tms bufstr;
extern struct tms *buffer;                                                                                             
extern Boolean StringComp(void *str1, void *str2); 
extern Boolean EQ_Strings(char *str1, char *str2);

