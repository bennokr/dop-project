#include "./ALL.h"
#include "./Grammar.h"
#include "./RAMcodes.h"

Rule_Apps *_TermRApps = NULL;
Rule_Apps *_UnaryRApps = NULL;
Rule_Apps *_BinaryRApps = NULL;

void InitializeRAM_RApps()
{RDomain i;
 /* fprintf(stderr,"Initializing %d %d %d\n", TRSize, URSize, BRSize); */
 if (_USE_RAM==true) {
  if (TRSize>0) _TermRApps = (Rule_Apps *) MultAlloc(TRSize, sizeof(Rule_Apps));
  else _TermRApps=NULL;
  if (URSize >0) _UnaryRApps = (Rule_Apps *) MultAlloc(URSize, sizeof(Rule_Apps));
  else _UnaryRApps=NULL;
  if (BRSize >0) _BinaryRApps = (Rule_Apps *) MultAlloc(BRSize, sizeof(Rule_Apps));
  else _BinaryRApps=NULL;

 if (_TermRApps!=NULL) for (i=0; i< TRSize;i++) _TermRApps[i] = NULL;
 if (_UnaryRApps!=NULL) for (i=0; i< URSize;i++) _UnaryRApps[i] = NULL;
 if (_BinaryRApps!=NULL) for (i=0; i< BRSize;i++) _BinaryRApps[i] = NULL;

  /* if ((_TermRApps == NULL) || (_UnaryRApps == NULL) || (_BinaryRApps == NULL)) exit(1); */
 }
}

void SaveRAppsInRAM(RType RT, Rule_Apps RApps, RDomain RNum)
{Rule_Apps NewRAppsV = RApps;

 if (_USE_RAM==true)

 switch (RT) {
  case _Term: if (_TermRApps!=NULL) _TermRApps[RNum] = NewRAppsV; break;
  case _Unary: if (_UnaryRApps!=NULL) _UnaryRApps[RNum] = NewRAppsV; break;
  case _Binary: if (_BinaryRApps!=NULL) _BinaryRApps[RNum] = NewRAppsV; break;
 };
}
Rule_Apps FetchRAppsFromRAM(RType RT, RDomain RNum)
{Rule_Apps RES = NULL;

 if (_USE_RAM == false) return NULL; /* get it from the file */

 /* if ((_TermRApps == NULL) || (_UnaryRApps == NULL) || (_BinaryRApps == NULL)) exit(1);*/ 

 switch (RT) {
  case _Term: if (_TermRApps!=NULL) RES = _TermRApps[RNum]; break;
  case _Unary: if (_UnaryRApps!=NULL) RES = _UnaryRApps[RNum]; break;
  case _Binary: if (_BinaryRApps!=NULL) RES = _BinaryRApps[RNum]; break;
 }
 return RES;
}

