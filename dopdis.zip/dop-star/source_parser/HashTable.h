#ifndef HashUnit
#define HashUnit TreeType
#endif

#ifndef MAXOF
#define MAXOF(A, B)  ((A > B) ? A : B)
#endif 
#ifndef MINOF
#define MINOF(A, B)  ((A < B) ? A : B)
#endif 

/************************/
/* number of hash places is a function of the total number of rules */
/* we allow about on average _PER_BUCK rules per bucket in the hash table */
#define _PER_BUCK 128
#define X_MAX (MAXOF(TRSize,MAXOF(BRSize, URSize))/_PER_BUCK)

/**************************/
/* A hashtable with buckets */
/* Ended Items take the first buckets and other items the last buckets */
/**************************/
#define X_BRSize X_MAX /* (MINOF(BRSize, X_MAX)) */
#define X_URSize X_MAX /* (MINOF(URSize, X_MAX)) */

#ifndef HashValue
#define HashValue  (2 * X_MAX + 3) // (X_BRSize + MAXOF(X_BRSize, X_URSize) + 3)
#endif

/**************************************************************/
/**************************************************************/
/* BuckFact buckets of HashValue are reserved for ended items */
#ifndef BuckFact
#define BuckFact (HashValue - (X_BRSize+1))
#endif

#ifndef EndedBuckSize
#define EndedBuckSize BuckFact
#endif
#ifndef OthsBuckSize
#define OthsBuckSize (HashValue - BuckFact)
#endif
#ifndef StartEnded
#define StartEnded 0
#endif
#ifndef StartOths
#define StartOths BuckFact
#endif

typedef HashUnit *HashTable;

/************/
int Mod(int x, int y);
HashTable InitHashTB();
/* Two buckets: first for ended items, second for other items */
int HashInBuck(ItemTree item, HashTable HT);
/**************************/ 
/* returns a tree under which Rn rt is an item to be entered or to be found */
TreeType SearchHT(ItemTree item, HashTable HT);
/*************************/
void EnterHT(ItemTree item, HashTable HT, Boolean *Change);
/*************************/
void HashTMap(HashTable HT, void (* fp)());
/*************************/
void HashTMapEnded(HashTable HT, void (* fp)());
/*************************/
void HashTMapOths(HashTable HT, void (* fp)());
/*************************/
/* fp takes an ItemTree and returns an ItemTree */
void XHashTMap(HashTable HT, ItemTree (* fp)());

void XHashTMapEnded(HashTable HT, ItemTree (* fp)(), Boolean Ended);
void CompactHashT(HashTable HT, Boolean Ended);
