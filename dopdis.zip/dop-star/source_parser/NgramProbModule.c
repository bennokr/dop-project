#include "./ALL.h"
#include "./NgramsGrammar.h"

#define UnvProb 1000

Boolean  ThereAreNgrams=false;

extern ItemTree DEBUGITEM; 
/* Globals for first time initialization */
Boolean NgramArraysInitialized =false;
extern void initialize_ngrams();


int NGRAMCMP(e1, e2)
  const void *e1;
  const void *e2;
{int i;
 char *v1 = ((struct ngram_struct *) e1)->word_ngram;
 char *v2 = ((struct ngram_struct *) e2)->word_ngram;
 i = (strcmp(v1, v2));
 return (i);
}

Ngram_Ptr FindNgramIn(char *ngram, Ngram_Ptr ArrayToSearch, int SizeArrayToSearch)
{Ngram_Ptr HERE; struct ngram_struct NTSt;
 NTSt.word_ngram = ngram; NTSt.probability = 0; NTSt.bkf_weight_as_context =0;
 
 HERE = (Ngram_Ptr) bsearch((void *) &NTSt, (void *) &ArrayToSearch[0], (size_t) SizeArrayToSearch, sizeof(struct ngram_struct), NGRAMCMP);

 return HERE;
}


/* This function became a dummy after we cleaned it from Ngram stuff */
ProbDomain GetStartProbOf(TDomain WordNum)
{if (_USE_WBIGRAM_RATIOS == false) return MultNutralConst; /* just for testing without ngrams */
 if (_ngram_is_used == false) return MultNutralConst; 
 if (ThereAreNgrams==false) return MultNutralConst;

 return MultNutralConst;
}

/* This function became a dummy after we cleaned it from Ngram stuff */
ProbDomain GetEndProbOf(TDomain WordNum)
{if (_USE_WBIGRAM_RATIOS == false) return MultNutralConst; /* just for testing without ngrams */
 if (_ngram_is_used == false) return MultNutralConst; 
 if (ThereAreNgrams==false) return MultNutralConst;

 return MultNutralConst;
}
/***************************************************************/
/********************************************************************/
/********************************************************************/
Boolean NgramProbUseCondition(Child_Type ChNum)
{if ((_ngram_is_used== true) && (ChNum == Rch_enum)) 
   return true;
 else return false;
}
