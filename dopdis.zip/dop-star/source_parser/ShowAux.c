#include "ALL.h"

/**************** Maybe for counting parses ****/
NUM_OF_PARSES_T NumOfNodesInItem(ItemTree I)
{NUM_OF_PARSES_T  Result =0; NUM_OF_PARSES_T  ResultL = 0; NUM_OF_PARSES_T  ResultR = 0;

   void CountVR(void *VI)
    {if (VI != NULL)
      if (((ItemTree) VI)->Num_OfParses == 0) ResultR += NumOfNodesInItem((ItemTree) VI);
      else ResultR += ((ItemTree) VI)->Num_OfParses;
    }

   void CountVL(void *VI)
    {if (VI != NULL)
      if (((ItemTree) VI)->Num_OfParses == 0) ResultL += NumOfNodesInItem((ItemTree) VI);
      else ResultL += ((ItemTree) VI)->Num_OfParses;
    }

   void CountVD(PtrList PL)
    {ResultL=0; ResultR=0; 
     CountVL(PL->Ptr); /* counting the left one */
     PListMap((PtrList) PL->Data, (void *) CountVR);
     Result = Result + ResultL*ResultR;
    }

 if (I!=NULL) {
     switch (I->Dot) {
       case lm  : break;/* shouldn't be possible */
       case mid : if (I->RT == _Term) ResultL = 1;
                  else {ResultL = 0; PListMap(I->AddedBy, (void *) &CountVL);}
	          Result = ResultL;
                  break;
       case rm  : ResultL = 0; ResultR = 0;
                  PDListMap(I->AddedBy, (void *) &CountVD);
                  break;
       default  : printf("error: default value for Dot in ShowAux.c\n"); exit(1); 
                  break;
      }/***/
   return Result;
 }
 else return 0;
}
void NumOfNodesInPF(ParForest PF)
{NUM_OF_PARSES_T  Result ;
    void SumNums(void *P)
     {ItemTree I = (ItemTree) P;
      /* ItemCPtr CP = ((ItemCPtr) I->DerForest);
      if (CP->RootsSize > 0) */ 
      Result += NumOfNodesInItem(I);
     }
 
 if (PF != NULL) 
   if (PF->Starts != NULL)
      {Result = 0;
       PListMap(PF->Starts, (void *) &SumNums);
       PRS("length:"); PRI(_sen_length);PRS("  Number of parses:");PRI(Result);
      }
   else {PRS("length:"); PRI(_sen_length);PRS("  Number of parses:");PRS("  0 (no start items)");}
 else {PRS("length:"); PRI(_sen_length);PRS("  Number of parses:");PRS("  0 (empty parse-forest)");}
 PRS("\n");
}
/********************/
void CountNodesInTAB(TableType TAB, int length)
{int i,j,k; EntryPtr EPtr; NUM_OF_PARSES_T  Result;
    void CountItemIf(ItemTree I)
     {if (I!=NULL)
       if (I->Valid == true) Result++;
     }
    
 Result = 0;
 for (k=1;k<=length;++k)
  for (i=k;i<=length;++i)
    {EPtr = ENTRY_Of(TAB, i-k, i); SetsMap(*EPtr, (void *) &CountItemIf);}
 PRI(length);PRS("  ");PRI(Result);PRS("\n");
}
