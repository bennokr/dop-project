
#include "./Universals.h"
#include "./Aux.h"
#include "./Constants.h"

extern Boolean ErIsUnknownW;
extern int _sen_length;

clock_t StartT, FinishT, MidT;
struct tms bufstr;
struct tms *buffer;

inline
int Mod(int x, int y)
{return ((int) (fmod((double) x,(double) y))); }

void PRINTTIME()
{int start, finish, midT; 
 finish = times(&bufstr);
 FinishT = bufstr.tms_utime + bufstr.tms_cutime;
 fprintf(stderr, "%s", "\nCPU-time is (in secs.): ") ;
 fprintf(stderr, "%.12f\n", ((float) ((FinishT - StartT)/ (float) CLK_TCK)));
}                                                                                                                          

void EXITPrnt(ERRORTYPE ERR, Boolean DOEXIT)
{int i; char OUTPUTtree[MaxTreeL];

 void PrntOneWord(char *word)
  {strcat(OUTPUTtree, "(xxxxxxx,[("); strcat(OUTPUTtree, word); strcat(OUTPUTtree, ",[])]),"); 
  }

 strcpy(OUTPUTtree,"");
 if (_sen_length > 0)
  {strcat(OUTPUTtree, "\n(sss,[(XXXXXXX,["); 
   {MapOnWGsWords((void *) &PrntOneWord); OUTPUTtree[strlen(OUTPUTtree)-1]='\0'; /* getting rid of extra comma */}
   strcat(OUTPUTtree, "])]).\n"); 

   PRS(OUTPUTtree);
  }
}

void EXITA(ERRORTYPE ERR, Boolean DOEXIT)
{char StrForUnknown[100] = "";
 EXITPrnt(ERR, DOEXIT);
 if (ErIsUnknownW == true) strcpy(StrForUnknown,"(UNKNOWN_,[])");

 switch (ERR) {
  case ALLOC: fprintf(stderr,"XXXMullocProblems\n");  
              break;
  case NONG : fprintf(stderr,"XXXnongram\n"); 
              break;
  case NONW : fprintf(stderr,"XXXnonword\n"); 
              break;
  case EMPTY: fprintf(stderr,"%s%s\n", "XXXempty", StrForUnknown); 
              break;
  case NONP : fprintf(stderr,"XXXnonparsable\n");
              break;
  case NOPF : fprintf(stderr,"XXXnonOemptypf\n");
              break;
  case NOCFG: fprintf(stderr, "XXXnoncfG\n"); 
              break;
  case NODF : fprintf(stderr,"XXXnonOemptydf\n"); 
              break; 
  default:  fprintf(stderr,"Error of unknown type has occurred\n"); 
          break;
 }
  PRINTTIME();
  if (DOEXIT==true) exit(0);
}
void EXIT(ERRORTYPE ERR)
{EXITA(ERR, true);
}
/**********************************/
/* PRE: size is the size of an obj*/
/*      the returned ptr must be  */
/*      cast into "ptr of obj"    */
/* Synopsis:                      */
/* Allocates space for an obj and */
/* returns a pointer to it.       */
inline
void *AllocElem(size_t size)
{void *ptr;
 ptr = NULL;
 ptr = (void *) calloc(1, size);
 if (ptr == NULL) {fprintf(stderr,"Alloc %d\n", (int) size); 
                   EXIT(ALLOC); return NULL;}
 else return ptr;
}
inline
void *MultAlloc(size_t count, size_t elemsize)
{void *ptr;
 ptr = NULL;
 if (count <= 0) return NULL;
 ptr = (void *) calloc(count, elemsize);
 if (ptr == NULL) {fprintf(stderr,"Alloc %d    %d\n", (int) count, (int) elemsize);
                   EXIT(ALLOC); return NULL;}
 else return ptr;
}
void PRI(long int a) { fprintf(fpOUT, "%ld ", a); }
void PRC(char *a) { fprintf(fpOUT,"%s", a); }
void PRS(char *a) {if (a!=NULL) if (strcmp(a,"")) {fprintf(fpOUT, "%s", a); fflush(fpOUT);}}
void PRSN(char *a) {fprintf(fpOUT, "%s\n", a);}
void PRBS(ProbDomain a) {fprintf(fpOUT, "%6.6f", (float) a);}
double POWER(ProbDomain a)
{return ((double) pow((double) 10.0, (double) a));}
void PRB(ProbDomain a) {/* fprintf(fpOUT, "%12.16e ", ( a)); */
                        if (a == SumNutralConst) fprintf(fpOUT, "%6.6e ", ((double) 0.0)); 
                        else fprintf(fpOUT, "%6.6e ", (POWER((double) a))); 
                        }
/*void WRITE(char *a) {fputs(a, fpOUT);}*/
void WRITE(char *a) {PRS(a);}

char *TOLOWERx(char *a)
{return a;
}

char *TOLOWER(char *a)
{int j = 0; static char new[SymLength]; int i = 0;

 new[0] = '\0';
 if (a != NULL)
  {while (a[i] != '\0')
    {if (isalpha(a[i])!= 0) {new[j] = (char) tolower((int) a[i]); i++;j++;}
     else {new[j] = a[i]; i++;j++;}}
   new[j] = '\0';
   return new;
  }
 else return NULL;
}
char *TOUPPER(char *a)
{int j = 0; static char new[SymLength]; int i = 0;

 new[0] = '\0';
 if (a != NULL)
  {while (a[i] != '\0')
    {if (isalpha(a[i])!= 0) {new[j] = (char) toupper((int) a[i]); i++;j++;}
     else {new[j] = a[i]; i++;j++;}}
   new[j] = '\0';
   return new;
  }
 else return NULL;
}
inline
char *NewStringOf(char *A)
{char *New = NULL; int Totlength = strlen(A) ;
 if (Totlength >= 1)
  {New = (char *) MultAlloc((size_t) (Totlength+1),(sizeof(char)));
   strcpy(New,A); 
  }
 return New;
}      
void yyerror(char *str)
{fprintf(stderr, str); exit(1);
}
Boolean Negate(Boolean X)
{if (X == true) return false;
 else return true;
}

char *REMOVE_VOID_PREFIX(char *S)
{char REST[SymLength] = "YES"; int i = 0; int pref_length = strlen(_VOID_PREFIX); 
 if (S == NULL) return NULL;
 else while ((S[i] != '\0') && (i < pref_length) && (_VOID_PREFIX[i] == S[i])) i++;
 if (i < pref_length) return NewStringOf(S);
 else {return NewStringOf(S+(pref_length));}
}
inline
Boolean EmptyString(char *str)
{if (str == NULL) return true;
 if (!strcmp(str,"")) return true;
 return false;
}
inline
Boolean EQ_Strings(char *str1, char *str2)
{if ((str1 == NULL) && (str2 == NULL)) return true;
 if (!strcmp(str1, str2)) return true;
 return false;
}
inline
Boolean StringComp(void *str1, void *str2)
{char *STR1 = str1; char *STR2 = str2;
 if (strcmp(STR1, STR2) >= 0) return true;
 else return false;
}
/* if str2 prefix of str1 */
extern Boolean _glob_exact_match_pos;

inline
Boolean PrefixOfString(char *str1, char *str2)
{char *temp; char TEMP[SymLength];

 if (_glob_exact_match_pos==true) return EQ_Strings(str1, str2);

 temp = strstr(str1,str2); 
 if (temp==NULL) return false;
 strcpy(TEMP,temp);

 if (EQ_Strings(str1, TEMP)==true) {return true; /* prefix !! */}
 return false;
}
