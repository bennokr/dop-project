#include "./Universals.h"
#include "./Aux.h"
#include "./PtrList.h"
#include "./Queues.h"
#include "./sentence.h"
#include "./WordGraph.h"
/************/
NumOfWordsType N = 0;
NumOfWordsType CntlSWG = 0;
NumOfWordsType CntlWG = 0;
Boolean Start_Read = true;
extern Sentence TheSen;
extern int YYLEXXX();
FILE *temporary, *temporaryin, *temporaryout;
#ifndef MaxLengthOfSentence
#define MaxLengthOfSentence 50000
#endif

extern Sentence TheWG;
/* short int WhichLex;  */

extern PtrListArray ArrayOfTransSet; /* A set of transitions i.e. no repition in transitions */
extern void PrntSetOfEntries();

extern void MapSentenceEx(Sentence Sen,void (*func)());
/************/
void WriteTo(char *word, Queue Q) { printf("%s ", word); }
void WriteToEx(char *word, NumOfWordsType i) { PRI(i);PRS(" "); PRS(word);PRS("\\ "); }
void WriteToWG(char *word, NumOfWordsType i, NumOfWordsType j) { PRI(i);PRS(" ");PRI(j);PRS(" "); PRS(word);PRS("\n"); }
void AddUndSc(char *word, NumOfWordsType j)
{int i=0;
 if (word != NULL)
  while (word[i] != '\0') i++;
 if (word[i-1] != '_') {word[i] = '_'; word[i+1] = '\0';}
} 

char *ReadInputstring();
void Analyse(FILE *IN);
/************/
FILE *tempFilePtr;

/* takes a list of transitions that have the same start-point START and returns 
   a list that contains for every END only one from all transitions <START,END,X> 
   The result is thus  a list of chart-entries that has been filled by the WG.
*/ 
PtrList SetDeduceOf(PtrList PTL)
{int i;Boolean *TempArr;
 PtrList Result = NULL;
     void MarkAndAdd(void *A)
      {if (TempArr[EndPointOf((WordList) A)-1] == false) 
        {Result = EnterPStack(A, Result); TempArr[EndPointOf(A)-1] = true;}
      }
 TempArr = (Boolean *) MultAlloc(TheWG->length+1, sizeof(Boolean));
 for (i=0; i <= TheWG->length; i++) TempArr[i] = false;
 PListMap(PTL, (void *) &MarkAndAdd);
 cfree(TempArr);
 return Result;
}

/********************************/
void InitArrayOfTransSet(int length)
{int i;
 ArrayOfTransSet = (PtrListArray) MultAlloc(length, sizeof(PtrList));
 for (i=0; i < length; i++) ArrayOfTransSet[i] = NULL;
}
/****** Checking whether it is a sentence or a word-graph *****/
Boolean IsSentence()
{int i; Boolean A_Sentence = true;
 for (i=0; i < (TheWG->length); i++) 
  if (ArrayOfTransSet[i] != NULL) 
   if (ArrayOfTransSet[i]->Next != NULL) A_Sentence = false;
 return A_Sentence;
}
/******/
/* Returns an array of lists . The list at position n-1 contains 
   YYLEXXXpointers to the transitions in TheWG that go out of the
   state numbered n .
**/
extern void PrintQ(Queue Q);

PtrListArray ReadWordGraph()
{Boolean ERROR; PtrListArray PtrLArray;int i; 
        void FillPLArray(Queue Q)
         {PtrLArray[Q->WordNumber-1] = EnterPStack((void *) Q, PtrLArray[Q->WordNumber-1]);}

     /* identifying words from input and putting them in TheSen */
  TheSen = CrSen(); TheWG = CrSen();  
  ERROR = YYLEXXX();                /* Filling the TheWG and TheSen */
 
  if (ERROR == 1) {printf("Error Occured in reading from input\n");exit(1);}
  else {PtrLArray = (PtrListArray) MultAlloc(TheWG->length, sizeof(PtrList));
        for (i=0; i < TheWG->length; i++) PtrLArray[i]=NULL; 
        InitArrayOfTransSet(TheWG->length);
             /* taking care that each word is underscored */
        MapSentenceEx(TheSen, (void *) &AddUndSc);
        MapSentenceEx(TheWG, (void *) &AddUndSc);
             /* filling the transitions in buckets in PtrLArray according to their start points */
        MapSentenceWG_L(TheWG, (void *) &FillPLArray);
             /* making sets of the buckets according to <start,end> points */
        for (i=0; i < (TheWG->length); i++) ArrayOfTransSet[i] = SetDeduceOf(PtrLArray[i]);
         /*MapSentenceWG_L(TheWG, (void *) &PrintQ); PRS("\n"); PrntSetOfEntries(); */
	 /* Build a square table to contain the morphemes/categories in the input */
	                           Build_TableOfMorphs(TheWG);

        return PtrLArray;
       }
}
/**********************/
char *ReadInputstring()
{char *L = (char *) AllocElem(MaxLengthOfSentence * sizeof(char));
 int i = 0;
 char *Err;
 L[0]='\0';

 if ((Err = fgets(L,MaxLengthOfSentence,fpIN)) == NULL) 
    {fprintf(stderr,"Err in reading from input file\n");exit(1);} 
 else return L;
}
/**************************************************************************************/
/* fp takes a WordList */
void MapOnArrayOfTransSet(void (* fp)(), Direction_Type direction)
{int i;
   void ReMapV(void *P) { (*fp)((WordList) P);}

 if (ArrayOfTransSet == NULL) {fprintf(stderr, "Err: MapOnBucketIn_ArrOfTransSet\n"); exit(1);}
 else switch (direction) {
       case _rightwards: for (i=0; i < TheWG->length; i++) 
                           if (ArrayOfTransSet[i] != NULL) PListMap(ArrayOfTransSet[i], (void *) &ReMapV);
                         break;
       case _leftwards: for (i=TheWG->length -1; i >= 0; i--)
                           if (ArrayOfTransSet[i] != NULL) PListMap(ArrayOfTransSet[i], (void *) &ReMapV);
                         break;
      } /* switch */
}
void MapOnBucketIn_ArrOfTransSet(void (* fp)(), int i)
{void ReMapV(void *P) { (*fp)((WordList) P);}
 if (ArrayOfTransSet == NULL) {fprintf(stderr, "Err: MapOnBucketIn_ArrOfTransSet\n"); exit(1);}
 else if (ArrayOfTransSet[i] != NULL) PListMap(ArrayOfTransSet[i], (void *) &ReMapV);
}
/**************************************************************************************/
/* fp takes (int start, int end, int word_serial_num, transition)                     */
/*                                                                                    */
/* Applies fp to all <start, end> such that there are transitions <start, end, word> in TheWG */
void MapOnWGsSetOfEntries(void (* fp)())
{int word_seq_num=-1;
 void ReMapQ(WordList trans)
    {if (trans != NULL) 
      {if (word_seq_num ==-1) word_seq_num = trans->WordNumber -1;
       (*fp)(trans->WordNumber -1, trans->EndPoint -1, word_seq_num, trans);
       word_seq_num++;
      }
    }
 MapOnArrayOfTransSet((void *) &ReMapQ, _rightwards);
}
void BkwdsMapOnWGsSetOfEntries(void (* fp)())
{int word_seq_num=-1;
 void ReMapQ(WordList trans)
    {if (trans != NULL) 
      {if (word_seq_num ==-1) word_seq_num = trans->WordNumber -1;
       (*fp)(trans->WordNumber -1, trans->EndPoint -1, word_seq_num, trans);
       word_seq_num++;
      }
    }
 MapOnArrayOfTransSet((void *) &ReMapQ, _leftwards);
}
/* for every j do <i,j> if a transition <i, j, word> exists */
void MapOnSetOfEntriesOfStart(void (* fp)(), int i)
{int word_seq_num=-1;
 void ReMapQ(WordList trans)
    {if (trans != NULL)
      {if (word_seq_num ==-1) word_seq_num = trans->WordNumber -1;
       (*fp)(trans->WordNumber -1, trans->EndPoint -1, word_seq_num, trans);
       word_seq_num++;
      }
    }
 MapOnBucketIn_ArrOfTransSet((void *) &ReMapQ, i);
}
/* Applies fp to each transition <start, end, word> in WG */
void MapOnTransitionOfWG(void (* fp)())
{int word_seq_num=-1;
 void ReMapQ(WordList trans)
    {if (trans != NULL) 
      {if (word_seq_num ==-1) word_seq_num = trans->WordNumber -1;
       (*fp)(trans->WordNumber -1, trans->EndPoint -1, word_seq_num, trans);
       word_seq_num++;
      }
    }
 MapSentenceWG_L(TheWG, (void *) &ReMapQ);
}


void PrntSetOfEntries()
{void PrintTransition(int start, int end, int w_num, WordList trans)
  {PrintQ(trans);
  }
 MapOnWGsSetOfEntries((void *) &PrintTransition);
}

void MapOnWGsWords(void (* fp)())
{void DoA_Word(int start, int end, int w_num, WordList trans)
  {(*fp)(trans->Rule);
  }
 MapOnWGsSetOfEntries((void *) &DoA_Word);
}

