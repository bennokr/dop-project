#include "./Universals.h"
#include "./Aux.h"
#include "./DefsGrammar.h"
#include "./PtrList.h"
#include "./CodeType.h"
#include "Queues.h"
#include "sentence.h"
#include "DinamicSets.h"
#include "./Item.h"
#include "./Trees.h"

extern ItemTree CpyItemFully(ItemTree I) ;
/************************************************/
inline
void InitTree(TreeType T)
{if (T!=NULL)
  {T->item = NULL; T->Right = NULL;   T->Left = NULL;}
}

inline
TreeType CrTree()
{TreeType RES = (TreeType) AllocElem(sizeof(struct ITEMPTR_STR));
 InitTree(RES);
 return RES;
}
inline
TreeType EnterI2Tree(TreeType T, ItemTree I)
{T->item = I; 
 return T;
}
inline
TreeType NewTreeFor(ItemTree I)
{TreeType RES = CrTree();
 return EnterI2Tree(RES, I);
}
/**************************/
/* searches for item in Tree and return a pointer to where */
/* the first time an item is encountred with the same RuleNo */
/* or else a pointer to where it should be entered (a pointer*/
/* to the last which is smaller than item.                   */
TreeType SearchTree(ItemTree item, TreeType Tree)
{if (Tree == NULL) return NULL;
 else if (EqItem(item, Tree->item)==true) return Tree;
      else if (GrItem(item, Tree->item)==true) 
             if (Tree->Right == NULL) return Tree;
             else return SearchTree(item, Tree->Right);
           else if (LeItem(item, Tree->item)==true) 
                   if (Tree->Left == NULL) return Tree;
                   else return SearchTree(item, Tree->Left);
                else return Tree;
}
/*************************/
inline
TreeType EnterTree(ItemTree item, TreeType Tree, Boolean *Change)
{TreeType This; 
 if (Tree==NULL) {*Change = true; return NewTreeFor(item);}           /** first item ***/
 else {This = (TreeType) SearchTree(item, Tree);
       if (EqItem(item, This->item)) {*Change = false; return Tree;}
       else if (GrItem(item, This->item)) {*Change = true; This->Right = NewTreeFor(item); return Tree;}
            else {*Change = true; This->Left = NewTreeFor(item); return Tree;}
      }
}
/*************************/
/* An NLR visit **********/
void TreeMap(TreeType Tree, void (* fp)())
{if (Tree != NULL) {(*fp)(Tree->item);
                    /* printf("\n left: ");*/
                    TreeMap(Tree->Left, fp);
                    /* printf("\n right: "); */
                    if (Tree->Left != Tree->Right) TreeMap(Tree->Right, fp);
                   }
}
/* fp takes ItemTree and returns ItemTree */
void XTreeMap(TreeType Tree, ItemTree (* fp)())
{if (Tree != NULL) {XTreeMap(Tree->Left, fp);
                    if (Tree->Left != Tree->Right) XTreeMap(Tree->Right, fp);
                    Tree->item = (*fp)(Tree->item);
                   }
}
void FreeTree(TreeType Tree)
{if (Tree != NULL) {FreeTree(Tree->Left);
                    if (Tree->Left != Tree->Right) FreeTree(Tree->Right);
                    Tree->item = FreeItem(Tree->item);
                    free(Tree);}
}

TreeType CompactTree(TreeType Tree)
{TreeType New = NULL; Boolean VOIDB = false;
   inline void CpyIf(ItemTree I)
     {if (NonEmptyDerForest(I) == true) {New = EnterTree(CpyItemFully(I), New, &VOIDB);}}
 TreeMap(Tree, &CpyIf);
 return New;
}

/*************************/
inline
RDomain TreeDepth(TreeType Tree)
{RDomain LD, RD;
 if (Tree == NULL) return 0;
 else {LD = TreeDepth(Tree->Left);
       RD = TreeDepth(Tree->Right);
       if (LD > RD) return (1+LD);
       else return (1+RD);
      }
}
inline
RDomain TreeCount(TreeType Tree)
{RDomain LD, RD;
 if (Tree == NULL) return 0;
 else {LD = TreeCount(Tree->Left);
       RD = TreeCount(Tree->Right);
       return (1+RD+LD);
      }
}
/**********************/
TreeType CPTree(TreeType T)
{TreeType IT;
    inline void CPItem(ItemTree I)
        {Boolean B;
         ItemTree New = FillItem(I->RuleNo, I->RT, I->Dot);
         New->Level = I->Level; New->Valid = I->Valid;
         /* New->Adds = NULL; */ New->AddedBy = NULL;
         /* New->Adds = UnitePLSet(New->Adds, I->Adds);*/
         New->AddedBy = UnitePLSet(New->AddedBy, I->AddedBy);
         IT = EnterTree(New, IT, &B);
        }
 TreeMap(T, &CPItem);
 return IT;
}
