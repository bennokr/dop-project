#include "PreRequisites.h"
#include "UnknownWords.h"

_Corpora_List _which_corpus = _GENERAL;
/***************************************/
Boolean _USE_ZQUOTE = false;
extern char *NewStringOf(char *text);



#define ZARRAYLENIII 9
/* the banned words and their corresponding postags */
char *ZARRAYIII[ZARRAYLENIII] =   {"ZLP", "ZLRB", "ZRP", "ZRRB","ZSCL","ZLCB","ZRCB","ZDSH","DELETE"};
char *PosTagArray[ZARRAYLENIII] = {"ZLP", "ZLRB", "ZRP", "ZRRB","ZCL", "ZLRB","ZRRB", "ZCL","RP"};

Boolean InZARRAYIII(char *TEXT)
{int i;
  if ((ZARRAYIII != NULL) && (_USE_ZQUOTE == false))
  for (i=0; i< ZARRAYLENIII; i++) if (strstr(TEXT,ZARRAYIII[i]) != NULL) return true;
 return false;
}
char *PosTagForZAWord(char *TEXT)
{int i;
 for (i=0; i< ZARRAYLENIII; i++) if (strstr(TEXT,ZARRAYIII[i]) != NULL) return PosTagArray[i];
}
/*---------*/
#define MAX_SEN_LENGTH 200
Boolean InitializedArray = false;
static PtrList ArrayOfBannedWords[MAX_SEN_LENGTH];
static Boolean ArrayOfPrinted[MAX_SEN_LENGTH];

void SaveBannedWord(char *TEXT, int bef_w_num)
{int i;
 if (InitializedArray == false) 
   for (i=0; i < MAX_SEN_LENGTH; i++) {ArrayOfBannedWords[i] = NULL; InitializedArray = true; ArrayOfPrinted[i] = false;}
 ArrayOfBannedWords[ bef_w_num ] = EnterQueue((void *) NewStringOf(TEXT), ArrayOfBannedWords[ bef_w_num ]);
 fprintf(stderr,"saved banned word:  %s\n", TEXT);
}
void PrintBannedWord(int bef_w_num, Boolean PrnCommaAfter, Boolean PrnCommaBef)
{PtrList Cu_List; char *ZAW; char *ZAT ;
 void PrnOneZW(PtrList This)
  {ZAW = (char *) This->Ptr;
   ZAT = PosTagForZAWord(ZAW);
   PRS("(");PRS(ZAT);PRS(",[(");PRS(ZAW);if (strstr(ZAW,"_") == NULL) PRS("_"); PRS(",[])");PRS("])");
   if (This->Next != NULL) PRS(",");
  }

 if (ArrayOfPrinted[ bef_w_num ] == false) 
  {
   Cu_List = ArrayOfBannedWords[ bef_w_num ]; 
   if (Cu_List != NULL) 
    {if (PrnCommaBef) PRS(",");
     PDListMap(Cu_List, (void *) &PrnOneZW); 
     if (PrnCommaAfter == true) PRS(",");
    }
   ArrayOfPrinted[ bef_w_num ] = true;
  }
}

/*****************************************************************/



/* we assume that the shortest BASIC word-form is 3 letters */
#define _MinLemmaLength 3
#define _PREF_DELIMSYM "i"
#define _POST_DELIMSYM "f"

static char RESULT[SymLength];


void CheckSPECbef(char *Word)
{char *temp; char *RES = RESULT;
 if (strstr(Word, "NUM") != NULL)  strcat(RES,"NUM"); 
 else if (isupper(Word[0]) != 0)   strcat(RES,"CAP");
}
void CheckSPECaft(char *Word)
{char *temp; char *RES = RESULT;
 if (strpbrk(Word, "0123456789") != NULL)  strcat(RES,"DASH"); 
}

void Check(char *Word, int suf)
{char *temp; int len = strlen(Word); char *RES = RESULT;
 if (len >= (suf + _MinLemmaLength)) 
  {temp = Word + (len - suf); 
   switch (suf) {
    case 1 : if (!strcmp(temp,"s")) strcat(RES,"Sx"); else
             if (!strcmp(temp,"o")) strcat(RES,"Ox"); 
           break;
    case 2 :  if (!strcmp(temp,"al")) strcat(RES,"AL"); else
             if (!strcmp(temp,"cy")) strcat(RES,"CY"); else
             if (!strcmp(temp,"ed")) strcat(RES,"ED"); else
             if (!strcmp(temp,"ee")) strcat(RES,"EE"); else
             if (!strcmp(temp,"en")) strcat(RES,"EN"); else
             if (!strcmp(temp,"er")) strcat(RES,"ER"); else
             if (!strcmp(temp,"es")) strcat(RES,"ES"); else
             if (!strcmp(temp,"et")) strcat(RES,"ET"); else
             if (!strcmp(temp,"fy")) strcat(RES,"FY"); else
             if (!strcmp(temp,"ic")) strcat(RES,"IC"); else
             if (!strcmp(temp,"my")) strcat(RES,"MY"); else
             if (!strcmp(temp,"or")) strcat(RES,"OR"); else
             if (!strcmp(temp,"um")) strcat(RES,"UM"); else
             if (!strcmp(temp,"ly")) strcat(RES,"LY"); 
           break;
    case 3 :  if (!strcmp(temp,"ary")) strcat(RES,"ARY"); else
             if (!strcmp(temp,"ate")) strcat(RES,"ATE"); else
             if (!strcmp(temp,"age")) strcat(RES,"AGE"); else
             if (!strcmp(temp,"ant")) strcat(RES,"ANT"); else
             if (!strcmp(temp,"ble")) strcat(RES,"BLE"); else
             if (!strcmp(temp,"day")) strcat(RES,"DAY"); else
             if (!strcmp(temp,"ean")) strcat(RES,"EAN"); else
             if (!strcmp(temp,"ern")) strcat(RES,"ERN"); else
             if (!strcmp(temp,"est")) strcat(RES,"EST"); else
             if (!strcmp(temp,"ent")) strcat(RES,"ENT"); else
             if (!strcmp(temp,"ers")) strcat(RES,"ERS"); else
             if (!strcmp(temp,"ery")) strcat(RES,"ERY"); else
             if (!strcmp(temp,"ist")) strcat(RES,"IST"); else
             if (!strcmp(temp,"ful")) strcat(RES,"FUL"); else
             if (!strcmp(temp,"ian")) strcat(RES,"IAN"); else
             if (!strcmp(temp,"ile")) strcat(RES,"ILE"); else
             if (!strcmp(temp,"ing")) strcat(RES,"ING"); else
             if (!strcmp(temp,"ion")) strcat(RES,"ION"); else
             if (!strcmp(temp,"ism")) strcat(RES,"ISM"); else
             if (!strcmp(temp,"ish")) strcat(RES,"ISH"); else
             if (!strcmp(temp,"ity")) strcat(RES,"ITY"); else
             if (!strcmp(temp,"ivy")) strcat(RES,"IVY"); else
             if (!strcmp(temp,"ize")) strcat(RES,"IZE"); else
             if (!strcmp(temp,"nce")) strcat(RES,"NCE"); else
             if (!strcmp(temp,"ory")) strcat(RES,"ORY"); else
             if (!strcmp(temp,"ous")) strcat(RES,"OUS"); else
             if (!strcmp(temp,"son")) strcat(RES,"SON"); 
            break;
    case 4 :
             if (!strcmp(temp,"ance")) strcat(RES,"ANCE"); else 
             if (!strcmp(temp,"ball")) strcat(RES,"BALL"); else 
             if (!strcmp(temp,"ions")) strcat(RES,"IONwSx"); else 
             if (!strcmp(temp,"logy")) strcat(RES,"LOGY"); else 
             if (!strcmp(temp,"ment")) strcat(RES,"MENT"); else 
             if (!strcmp(temp,"less")) strcat(RES,"LESS"); else
             if (!strcmp(temp,"ness")) strcat(RES,"NESS"); else
             if (!strcmp(temp,"ship")) strcat(RES,"SHIP"); else
             if (!strcmp(temp,"sive")) strcat(RES,"SIVE"); else
             if (!strcmp(temp,"some")) strcat(RES,"SOME"); else 
             if (!strcmp(temp,"sons")) strcat(RES,"SONS"); else 
             if (!strcmp(temp,"tive")) strcat(RES,"TIVE"); else
             if (!strcmp(temp,"oire")) strcat(RES,"OIRE"); 
           break;
   } /* switch */
  }
}
/********* ENGLISH MORPHOLOGY  for WSJ *********************/
/** #ifdef ENGLISH_MORPHO **/

char *GetMorphEnglish(char *word, Boolean FirstWord)
{char Word[SymLength]; char TEMP[SymLength]; strcpy(Word, word); 
 if (strchr(word,'_') != NULL) Word[strlen(word) -1] = '\0'; /* masking the "_" */
 strcpy(RESULT, "");

 if ((FirstWord == true) && (isupper(Word[0]) != 0)) {strcpy(RESULT,"FSTW"); return RESULT;}

 if (!strcmp(RESULT,"")) CheckSPECbef(Word);
 if (!strcmp(RESULT,"")) Check(Word, 4);
 if (!strcmp(RESULT,"")) Check(Word, 3);
 if (!strcmp(RESULT,"")) Check(Word, 2);
 if (!strcmp(RESULT,"")) Check(Word, 1);
 if (!strcmp(RESULT,"")) CheckSPECaft(Word);

 if (strcmp(RESULT,""))
  {if (!strcmp(RESULT,"CAP")) strcpy(TEMP,_PREF_DELIMSYM); 
   else strcpy(TEMP,_POST_DELIMSYM); 
   strcat (TEMP,RESULT); strcpy(RESULT,TEMP);
  }
 return RESULT;
}
void PrintUnknownWExtenEnglish(char *exten)
{PRS(UNKNOWNSYMwo);PRS(exten);PRS("_");
}

char *UnknownWExtenEnglish(char *Word, Boolean first)
{static char RES[SymLength];
 strcpy(RES, UNKNOWNSYMwo); strcat(RES,(GetMorphEnglish(Word,first)));strcat(RES,"_");
 return RES;
}

/** #endif **/

/****  HEBREW MORPHOLOGY   *********/
/** #ifdef HEBREW_MORPHO **/

extern char *FindMostSimilarWord(char *word);

char *GetMorphHebrew(char *word, Boolean FirstWord)
{strcpy(RESULT,"");
 strcpy(RESULT,FindMostSimilarWord(word)); 
 if (EQ_Strings(word,RESULT) == false)      
       fprintf(stderr,"Warning: word %s is unknown: has been replaced by similar word %s\n",word, RESULT);
 return RESULT; 
}

void PrintUnknownWExtenHebrew(char *exten)
{PRS(UNKNOWNSYMwo);PRS(exten);PRS("_");
}

char *UnknownWExtenHebrew(char *Word, Boolean first)
{static char RES[SymLength];
 strcpy(RES,(GetMorphHebrew(Word,first))); 
 if (strchr(RES,'_') == NULL) strcat(RES,"_");
 /* fprintf(stderr,"------------------>(%s)\n",RES); */
 return RES;
}

/** #endif **/
/********************************************************/
/** NEGRA **********************************************/
char *GetMorphNegra(char *word, Boolean FirstWord)
{char Word[SymLength]; char TEMP[SymLength]; strcpy(Word, word); 
 if (strchr(word,'_') != NULL) Word[strlen(word) -1] = '\0'; /* masking the "_" */
 strcpy(RESULT, "");

 if (!strcmp(RESULT,"")) CheckSPECbef(Word); /* check for prefix: capitalization or NUM */

 if (strcmp(RESULT,""))
  {if (!strcmp(RESULT,"CAP")) strcpy(TEMP,_PREF_DELIMSYM); 
   else strcpy(TEMP,_POST_DELIMSYM); 
   strcat (TEMP,RESULT); strcpy(RESULT,TEMP);
  }
 return RESULT;
}

void PrintUnknownWExtenNegra(char *exten)
{PRS(UNKNOWNSYMwo);PRS(exten);PRS("_");
}

char *UnknownWExtenNegra(char *Word, Boolean first)
{static char RES[SymLength];
 strcpy(RES, UNKNOWNSYMwo); strcat(RES,(GetMorphNegra(Word,first)));strcat(RES,"_");
 return RES;
}
/**********************************************/
/****  GENERAL MORPHOLOGY or NO MORPHOLOGY  *********/
/** #ifdef GEN_MORPHO **/
char *GetMorphGEN(char *word, Boolean FirstWord)
{strcpy(RESULT,""); return RESULT; }

void PrintUnknownWExtenGEN(char *exten)
{PRS(UNKNOWNSYMwo);PRS("_");
}

char *UnknownWExtenGEN(char *Word, Boolean first)
{static char RES[SymLength];
 strcpy(RES, UNKNOWNSYMwo); strcat(RES,"_");
 return RES;
}

/** #endif **/
/***************************************************************************/
char *UnknownWExten(char *Word, Boolean first)
{switch (_which_corpus)
	{
		case _WSJ: return UnknownWExtenEnglish(Word, first); break;
		case _Negra: return UnknownWExtenNegra(Word, first); break;
		case _Hebrew: return UnknownWExtenHebrew(Word, first); break;
		case _GENERAL: return UnknownWExtenGEN(Word, first); break;
	}
}
void PrintUnknownWExten(char *exten)
{switch (_which_corpus)
	{
		case _WSJ: PrintUnknownWExtenEnglish(exten); break;
		case _Negra: PrintUnknownWExtenNegra(exten); break;
		case _Hebrew: PrintUnknownWExtenHebrew(exten); break;
		case _GENERAL: PrintUnknownWExtenGEN(exten); break;
	}
}
char *GetMorph(char *Word, Boolean first)
{switch (_which_corpus)
	{
		case _WSJ: GetMorphEnglish(Word, first); break;
		case _Negra: GetMorphNegra(Word, first); break;
		case _Hebrew: GetMorphHebrew(Word, first); break;
		case _GENERAL: GetMorphGEN(Word, first); break;
	}
}
/***********************************************************************************************************************/
/*														       */
/*             LEXICALIZATION                                                                                          */
/***********************************************************************************************************************/
/* A lexical representation is always  ([a-z][a-z0-9\-]+); it contains  postag[-word[-extra]]                          */
/* ExtractToken assumes that LLex is such as representation                                                            */
/* we assume that the word is the only element that has the form [a-z][0-9]+                                           */


/* lexicalization is given i.e. [a-z][a-z0-9\-]+ in the form postag[-word[-extra]] but postag possibly contains minuses*/
/* this removes these minuses to allow postag[-word[-rest]] to be tokenized by the function below                      */
char *remove_minusFromPT(char *lexical)
{char *temp; Boolean FOUND = false; static char RES[SymLength]; char *word_begin = NULL;
 if (lexical == NULL) return NULL;
 if (!strcmp(lexical,"")) {strcpy(RES,""); return RES;}

 temp = lexical;
 while ((temp != NULL) && (FOUND == false))
  {temp = strpbrk(temp, "0123456789"); 
   if (temp != NULL) 
    if (isalpha(lexical[strlen(lexical) - strlen(temp)-1]) != 0) FOUND = true;
    else temp = temp+1;
  }
 if (FOUND == true) /* found the word : temp points to the first digit in it */
   word_begin = temp - 1;
 else word_begin = lexical + strlen(lexical); /* no word: */

 /* fprintf(stderr,"%s\n", word_begin); */
 if (word_begin != NULL)
   {int j=0; int i = 0;
    if (strlen(lexical) != strlen(word_begin))
      {while (i < (strlen(lexical) - strlen(word_begin)))
           {if (lexical[i] != '-') {RES[j] = lexical[i]; j++;} i++;}
       if (strlen(word_begin) != 0) { RES[j] = '-'; j++;}
      }
    RES[j] = '\0';
    strcat(RES, word_begin);
    /* fprintf(stderr, "%s   %s\n", lexical, RES); */
    return RES;
   }
 else {fprintf(stderr,"Err in remove_minusFromPT\n");exit(1);}
}

char *ExtractToken(char *LLex, int toknum)
{char *RES; char *temp; char Lex[SymLength]; 
 RES = (char *) MultAlloc(SymLength, sizeof(char));

 if (LLex == NULL) return NULL;
 strcpy(Lex, LLex);strcpy(RES,"");  /* printf("%d %s  ", toknum, Lex); fflush(stdout); */

 temp = strchr(Lex, '-'); 
 if (toknum == 1) if (temp != NULL) {temp[0] = '\0'; strcpy(RES,Lex); return (RES);}
                  else {strcpy(RES, Lex); return (RES);} 
 /* toknum must be >= 2 */
 if (temp == NULL) return NULL; if ((strlen(temp) == 0)) return NULL;
 if (toknum == 2) 
   {strcpy(Lex, temp+1); temp = strchr(Lex, '-'); 
    /* printf("%s\n", Lex); fflush(stdout); */
    if (temp != NULL) {temp[0] = '\0'; strcpy(RES,Lex); return RES;}
    else {strcpy(RES, Lex); return RES;}
   }

 fprintf(stderr,"Err: lexicalization request is weird !\n"); exit(1);
}

/* Return the lexical part of a nonterminal; if no lexical part returns NULL */
void ExtractLexicalizationFrom(char *nontermx, char *RES)
 {int i; int head_length; char nonterm[SymLength]; char *start; char *end; char *temp;
  strcpy(nonterm, nontermx); strcpy(RES,"");
  start = strstr(nonterm,_head_marker); 
  if (start == NULL) 
     {strcpy(nonterm,_head_marker); strcat(nonterm,nontermx); strcat(nonterm,_head_marker); /* we envelop it between head_markers */
      start = strpbrk(nonterm,_head_marker); 
     }
  if (start != NULL)  /* start points to the start of the head-info */
  {end = strstr(start+1,_head_marker);  /* end now point to the end of the head info */
   if (end != NULL) head_length = strlen(start) - strlen(end);
   else {i = 1; while ((isdigit(start[i])) || (islower(start[i])) || (start[i] == '-')) i++; head_length = i;}
   /* fprintf(stderr,"%30s   %s  %s\n", nonterm, start, end); */
   strncpy(RES, start+1, head_length-1 ); RES[head_length-1] = '\0';
   /* fprintf(stderr,"%30s  %s\n", nonterm, RES); */
   /* temp = remove_minusFromPT(RES); strcpy(RES,temp); NOT NECESSARY */
  }
}
/* extracting the word from the non-terminal */
char *ExtractWordRepFrom(char *nonterm)
{static char LexRepP[SymLength]; static char LexRep[SymLength]; static char RES[SymLength]; char *res;
 strcpy(LexRepP,""); strcpy(RES,""); strcpy(LexRep,"");
 ExtractLexicalizationFrom(nonterm, LexRepP);
 strcpy(RES,"");
 if (LexRepP == NULL) return NULL;
 else {strcpy(LexRep, LexRepP); res = ExtractToken(LexRep, (int) 2); 
       if (res != NULL) return res;
       else return RES;
      }
}
char *ExtractPosTagFrom(char *nonterm)
{static char LexRepP[SymLength]; static char LexRep[SymLength]; static char RES[SymLength]; char *res;
 strcpy(LexRepP,""); strcpy(RES,""); strcpy(LexRep,"");
 ExtractLexicalizationFrom(nonterm, LexRepP);
 strcpy(RES,"");
 if (LexRepP == NULL) return NULL;
 else {strcpy(LexRep, LexRepP); res = ExtractToken(LexRep, (int) 1); 
       if (res != NULL) return res;
       else return RES;
      }
}
/*******************/
/* given a symbol for a postag: return its internal representation */
char *EX_INTERN_REP_OF_POSTAG(char *postag)
{static char RES[SymLength]; char *post = (ExtractPosTagFrom((postag)));
 if (post != NULL) {strcpy(RES, post); free(post); return RES;}
 else return NULL;
}
char *EX_INTERN_REP_OF_WORD(char *word)
{static char RES[SymLength]; char *www; char TEMP[SymLength]; strcpy(TEMP, "postag-"); strcat(TEMP, word);
 if (strchr(word,'-') != NULL) www = ExtractWordRepFrom(word);
 else www = ExtractWordRepFrom(TEMP);
 if (www != NULL) {strcpy(RES, www); free(www); return RES;}
 else {strcpy(RES,""); return RES;}
}
char *TRANS_TO_INTERN_REP_OF_POSTAG(char *postag)
{static char RES[SymLength]; char *post = (ExtractPosTagFrom(TOLOWERx(postag)));
 if (post != NULL) {strcpy(RES, post); free(post); return RES;}
 else return NULL;
}
char *TRANS_TO_INTERN_REP_OF_WORD(char *word)
{static char RES[SymLength]; char *www; char TEMP[SymLength]; strcpy(TEMP, "postag-"); strcat(TEMP, word);
 if (strchr(word,'-') != NULL) www = ExtractWordRepFrom(word);
 else www = ExtractWordRepFrom(TEMP);
 if (www != NULL) {strcpy(RES, www); free(www); return RES;}
 else return NULL;
}
void RemoveHeadFromName(char *Name, char *RES)
{char *temp; char MARKER[SymLength];
 strcpy(RES, Name); 
 strcpy(MARKER,"--"); strcat(MARKER,_head_marker);
 temp = strstr(RES,MARKER); 
 if (temp != NULL) temp[0] = '\0';
 else { /* maybe there is only one minus before the head_marker */
       strcpy(MARKER,"-"); strcat(MARKER,_head_marker);
       temp = strstr(RES,MARKER); 
       if (temp != NULL) temp[0] = '\0';
      }
}
/************************************************************************/
/* dealing with the representations of the input words                  */
/* a mapping word-repres for every input word (array implemented)       */
static char **ArrayOfReps = NULL;
static int tot_array_length = 0;
static int cu_array_length = 0;

 void InitArrayOfReps(int sen_len)
  {int i; 
   if (ArrayOfReps == NULL) {
     tot_array_length = sen_len+2;
     ArrayOfReps = (char **) MultAlloc(tot_array_length, sizeof(char *)); 
     for (i=0; i< tot_array_length; i++) ArrayOfReps[i] = NULL;
     ArrayOfReps[0] = NewStringOf(non_lex_reps);  cu_array_length = 1;
   }
  }

 void EnterRepsToArr(char *A)
  {ArrayOfReps[cu_array_length] = NewStringOf(A); cu_array_length++; }

/* add the lexicalization of nonterminal to the array */
void UpdateRepresArrayForSentence(char *nontermI, int sen_len)
 {if (LEXICALIZED_WSJ == true) {
   static char nonterm[SymLength]; 
    strcpy(nonterm, EX_INTERN_REP_OF_WORD(nontermI)); /* because word is always assumed second to postag in lexicalization*/
    /* fprintf(stderr, "adding to array  %s  %s\n", nontermI, nonterm); */
    if (ArrayOfReps == NULL) InitArrayOfReps(sen_len);
    if (strcmp(nonterm,"")) if (Lex_In_Sen(nontermI) == false) EnterRepsToArr(nonterm);
    /* fprintf(stderr,"has been added\n"); */
  }
 }

/* Is lexicalization of nonterm acceptable                                            */
/* i.e. if nonterm is lexicalized: is the lexicalization of nonterm in the sentence  ?*/
/* else return true                                                                  */
Boolean Lex_In_Sen(char *nonterm)
 {int i; Boolean result = false; char *found; char *temp; char TEMP[SymLength];

  if (LEXICALIZED_WSJ == false) return true;
  if ((EQ_Strings(nonterm,"sss") == true) || (EQ_Strings(nonterm,"ssss") == true)) return true;
  strcpy(TEMP, EX_INTERN_REP_OF_WORD(nonterm));
     /* printf("%s --  %s\n", nonterm, TEMP); */
  if (!strcmp(TEMP,"")) return true;
  {for (i=0; i < cu_array_length; i++) 
     {/* printf("%s  %s   %s\n", nonterm, TEMP, ArrayOfReps[i]); */
      if (!strcmp(TEMP,ArrayOfReps[i])) {result = true; break;}}
   /* if (result == false) printf("%s --  %s\n", nonterm, TEMP);  */
   return result;
  }
 }

