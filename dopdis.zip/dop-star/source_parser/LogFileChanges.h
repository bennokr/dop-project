/****************************************************/
Changes 16.02.2006
Aux.c             inline
PtrList.c         inline and changed two functions into more efficient
                  1) MergePL
                  2) UnitePLSet

