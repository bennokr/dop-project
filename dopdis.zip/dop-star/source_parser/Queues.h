#include "Universals.h"
#include "Constants.h"

/*************************/
#ifndef NumOfWordsType
#define NumOfWordsType short int
#endif
/****************************************************************/
/*** The type char *must be defined externally         ************/
/******************************************************************/
/****** Queue of char *                                           */
struct QUnit {
        char Rule[MAXLENG];           /* the word */
        NumOfWordsType WordNumber; /* Start point of the transition */
        NumOfWordsType EndPoint;   /* End point of the transition   */
        struct QUnit *Next;
        ProbDomain   Probability;  /* log10 probability of transition */
        Boolean     UnknownWord;
        char Morpheme[MAXLENG];
        Boolean    WordBounary; /* end of sequence of morphemes for a word after this transition */
	int        WordReference;
};
typedef struct QUnit *Queue;  /* lists of rules */
/*****************************/
/* returns a Q with element R*/
extern Queue EnQUnit(char *R);
/*****************************/
extern Queue CrQ();
/*****************************/
/* Enqueues R in Q           */
extern Queue Enqueue(char *R, Queue Q);
/*****************************/
/* Maps func on Q            */
extern void QMap(Queue Q, void (* func)());
extern void QMapWG(Queue Q, void (* func)());
extern void QMapWG_L(Queue Q, void (* func)());
extern void PrintQUnit(char *R, void *Next);
extern Queue EnqueueWG(char *R, NumOfWordsType i, NumOfWordsType j, Queue Q);
extern void PrintQV(void  *QV);
extern NumOfWordsType EndPointOf(void *QV);
extern Queue EnqueueEx(char *R, NumOfWordsType i, Queue Q);
extern void UpdateMorpheme(Queue Q, char *morpheme); 
extern void FreeQueue(Queue Q);
