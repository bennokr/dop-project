#include "./ALL.h"    

void Double_PARSE(TableType *THETABLE, Sentence TheWG, TDomain **Tags, int length, ParForest *ParF, DuoPtr Duo)
{fprintf(stderr,"Err: when you use one grammar only, use PARSE.c instead of Double_PARSE\n");exit(1);}
void UseGrammar(int GramNumber)
{fprintf(stderr,"Err: use double parser instead !!\n"); exit(1);
}
