#include "ALL.h"

/* we assume we are parsing morphologically enriched postags rather than actual words */
#define VOID_CHAR 'b'
#define SEP_SYM "uu"
#define WEIGHT( place )                 (((float) 1.0) / ((float) (place+1)))


char *Pad_String(char *str, int uptolen)
{static char RESULT[SymLength]; int i;
 strcpy(RESULT,str);
 if (strlen(RESULT) < uptolen) 
     {for (i= strlen(RESULT); i<uptolen; i++) RESULT[i] = VOID_CHAR; RESULT[i+1] = '\0';} 
 return RESULT;
}

/* distance of word from referenceword */
float Distance(char *word, char *referenceword)
{float distance; int length; char *temp;
 char tempword[SymLength]; char temprefw[SymLength]; 
 char padded_word[SymLength]; char padded_refw[SymLength]; int i; 

 strcpy(tempword,word); strcpy(temprefw,referenceword);

 /* padding words to the same length */
 strcpy(padded_word,tempword); strcpy(padded_refw, temprefw);
 if (strlen(tempword) < strlen(temprefw)) 
     {strcpy(padded_word, Pad_String(tempword,strlen(temprefw))); }
 else {strcpy(padded_refw, Pad_String(temprefw,strlen(tempword))); }

 /* compute the distance between the padded... */
 distance = 0.0;
 length = strlen(padded_word); /* here it does not matter which padded length any more */
 for (i=0; i<length; i++)
  {if (padded_word[i] != padded_refw[i]) 
     if ((padded_word[i] == VOID_CHAR) || (padded_refw[i] == VOID_CHAR)) distance= distance + (0.5 * WEIGHT(i));
     else distance= distance + WEIGHT(i);
   else distance = distance - (0.25 * WEIGHT(i));
  }

 return distance;
}

/* Algorithm is similar to MBL: letters to the left of the word are more important than to the right */
char *FindMostSimilarWord(char *word)
{static char RESULT[SymLength]; static char EXT_WORD[SymLength]; float mindistance = 100000.0; /* largest distance we can think of */
  void ComputeDist(char *cuword)
   {char *temp; char TEMP1[SymLength]; char TEMP2[SymLength]; float curdist;
    strcpy(TEMP1, word); strcpy(TEMP2, cuword);

    if ((temp = strchr(TEMP1,'_')) != NULL) temp[0] = '\0';
    if ((temp = strchr(TEMP2,'_')) != NULL) temp[0] = '\0';

    curdist = Distance(TEMP1, TEMP2);
    if (curdist < mindistance) {strcpy(RESULT,TEMP2); mindistance = curdist;}
    /* fprintf(stderr,"%s  %f      %s\n", cuword, curdist, RESULT); */
   }

 strcpy(EXT_WORD, _VOID_PREFIX); strcat(EXT_WORD, word);

 if (_PoSTagSequencesInput == false) /* for morphemes in the input */
     if (strstr(word,"ttt") != NULL) {strcpy(RESULT,"t"); strcat(RESULT,UNKNOWNSYM);} /* an txxxunknown signifying VmorphV */
     else if (strstr(word,"lll") != NULL) {strcpy(RESULT,"l"); strcat(RESULT,UNKNOWNSYM);} /* an yxxxunknown signifying Vmorph */
          else if (strstr(word,"rrr") != NULL) {strcpy(RESULT,"r"); strcat(RESULT,UNKNOWNSYM);} 
               else {TDomain term_num = T_NUM_Of(TOLOWERx(EXT_WORD)); /* checking whether it is extra from e.g. morph-analyzer*/
                     if (term_num == UNVALID_SYMNUM) strcpy(RESULT,UNKNOWNSYM); /* just a usual xxxunknown */
                     else strcpy(RESULT,EXT_WORD);
                     term_num = T_NUM_Of(TOLOWERx(RESULT)); /* checking whether it is extra from e.g. morph-analyzer*/
                     fprintf(stderr,"trying %s instead of %s (%d)\n", RESULT, word, term_num);
                    }
 else /* for postags in the input */
     {/* run on all words: compute distance per word: keep most similar word: out it */
      Map_On_All_Terminals((void *) &ComputeDist);
     }

 return RESULT;
}
