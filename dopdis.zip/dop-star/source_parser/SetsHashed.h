#ifndef KeyType
#define KeyType ItemTree 
#endif

enum Entry_State_T {CLOSED_ENTRY=0,TO_BE_COMPLETED=1,OPEN_ENTRY=2};
#ifndef Entry_State
#define Entry_State enum Entry_State_T
#endif
/********************************************************/
/* This module assumes a module of item-structures   **/
/*  (e.g. trees) which implement sets                */
/********************************************************/
struct SetType {
        HashTable      ItemPtr;
        Entry_State    IsClosed;
        Boolean        SetBooleanAux;
        RDomain        Size;
        RDomain        EndedSize;
        RDomain        OthsSize;
        Boolean        *LHSNTOfEnded; /* read refNThash */
        Boolean        *RHS2NTOfOths;  /* read refNThash */
        PtrList        *LHSOfEndedPList;
        PtrList        *RHS2OfOthsPList;
        ProbDomain     RMax_Node_Prob;  /* the maximum prob of a node in this CKY entry */
        ProbDomain     OMax_Node_Prob;  /* the maximum prob of a node in this CKY entry */
        ProbDomain     AlphaXBeta;      /* ForwardProb multiplied with BackwardProb OUTSIDE this entry */
        ProbDomain     Max_Prob_To_Right;
};
typedef struct SetType *Set;

Set CreateSet();
Set InitSet(int i, int j);
/***********************************************************/
/* First the items in a tree. (key is an itemptr)       ****/
/***********************************************************/
extern Set Add(KeyType key, Set set);
extern Set XAdd(KeyType key, Set set);
RDomain ThisRuleNo(Set set);
int ThisDot(Set set);
/**************/
/* a subset of set is returned               */
/* in which the key is found and             */
/* directly reachable as its "chosen" member.*/
/* otherwise a pointer to where it should be entered is returned              */
KeyType SeekItem(KeyType key, Set set);
/*** Membership check ***/
Boolean Member(KeyType key, Set set);
Boolean IsHeadOf(KeyType key, Set set);
/** enter R of type RT as data for Key in set ***/
/**********/
void SetsMap(Set set, void (* fp)());
void SetsMapValid(Set set, void (* fp)())  ;
void SetsMapEnded(Set set, void (* fp)());
void SetsMapOths(Set set, void (* fp)());
/***********/
/* Size of the set. I.e. number of keys */
RDomain SetSize(Set set);
RDomain SetSizeEnded(Set set);
RDomain SetSizeOths(Set set);
/****************************************************************/
/* And now the part which deals with the extra CYK pointers.  ***/
/**********************************/
/* The pointer "new" should point to an item which is added by **/
/* "item" during the CYK algorithm (i.e. the upwards pointers **/
/* in the CYK table *****/
/*******
void ItemAdds(KeyType item, void *new);
*****/
/**********************************/
/* The pointer "old" should point to an item which added **/
/* "item" during the CYK algorithm (i.e. the downwards pointers **/
/* in the CYK table *****/
void ItemAddedBy(KeyType item, void *old);
/******
void MapAdds(KeyType item, void (* fp)());
******/
void MapAddedBy(KeyType item, void (* fp)());
/**********************************/
void PrintAdds(KeyType item);
void PrintAddedBy(KeyType item);
/****************/
/* WARNING WARNING WARNING 
   CopySet is not fully implemented: read the  implementation in .c file
****/
Set CopySet(Set S);
void FreeFastExtension(Set S);

ItemTree HeadOfSet(Set set);

void ItemEAddedBy(KeyType item, void *old);
void ItemEDAddedBy(KeyType item, void *itemKJ);
void ItemDAddedBy(KeyType item, void *itemKJ);
void FreeSet(Set S);
Boolean IsErLHSEnded(NTDomain NT, Set S);
Boolean IsErRHS2Oths(NTDomain NT, Set S);
/* fp takes an ItemTree and returns an ItemTree */
void XSetsMap(Set set, ItemTree (* fp)()); 

/* fp takes an ItemTree and returns an ItemTree */
void XSetsMapEnded(Set set, ItemTree (* fp)(), Boolean Ended);


/* fp takes an ItemPtr */
void MapOnLHSEndedByNonT(NTDomain NT, Set S, void (*fp)());
void MapOnLHSEnded(Set S, void (*fp)());
void MapOnLHSEndedValid(NTDomain NT, Set S, void (*fp)());

/* fp takes three things: non-terminal number, ItemTree and a pointer to a boolean */
void MapOnRHS2Oths(NTDomain NT, Set S, void (*fp)());
void MapOnRHS2OthsValid(NTDomain NT, Set S, void (*fp)());

/* fp takes three things: non-terminal number, ItemTree and a pointer to a boolean */
void MapAllRHS2Oths(Set S, void (*fp)(), Boolean CheckValidity);
void MapAllRHS2Oths_VDF(Set S, void (*fp)(), Boolean CheckDForest);
PtrList TheLHSOfEndedPListOf(Set set, NTDomain NT);
void MapOnLHSEndedUntill(NTDomain NT, Set S, void (*fp)());
/***************/
/**
refNThash:
 We added two arrays of length as many as there are nonterminals.

 LHSNTOfEnded is an array for the left-most nonterminal of ended item in this
 entry, if there is an ended item with this non-terminal on its lhs
 then its entry in LHSNTOfEnded is true.

 RHS2OfOths is an array for the RHS2 nonterminal of A->B*C items in this
 entry, if there is an item with this non-terminal on its rhs2
 then its entry in RHS2OfOths  is true.
***/
