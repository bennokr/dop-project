#include "./ALL.h"
#include "./UnknownWords.h"


#define _UNIFICATION_BASED false
#define _PERCULATE_ONLY    true
#define _INTERN_WORD_REP_VER   false     /* true implies PT->ax->word is the structure and  ax is the word representation*/
                                         /* else the structure is simply PT->word                                        */

extern RDomain LexicalRuleOf(NTDomain LHS, TDomain RHS);
/***********************************************************************************************/
Boolean IsModifier(char *Name)
{if ((strstr(Name, Left_Mod_Sym) != NULL) || (strstr(Name, Right_Mod_Sym) != NULL)) return true;
 else return false;
}
Boolean NotModifier(char *Name)
{return (Negate(IsModifier(Name)));
}

Boolean ECNF_MARKED(char *Name)
{if (strchr(Name, _ECNF_SYM) != NULL) 
  if (NotModifier(Name)== true) return true;
  else return false;
 else return false;
}

void FreeLexof(ItemTree I)
{FreeDinSet(I->lexic_set);
}
/****************************/
/* The an original rule (before ECNF) has one child not marked -L@/-R@ */
/* There is at most one single head-ch per item.                       */
/* The head of a Binary item is recognized as follows:                 */
/*   if both chilren are modifiers    --->  no head.                   */
/*   if the one is modifier and the other not --> the other child      */
/*   if no modifiers: if the one is ECNF  ---> the other is the head.  */
Boolean THIS_HEAD_CH(ItemTree I, int ChNum)
{Boolean RHS1_mod, RHS2_mod; int WhichHeadCh = 0; /* like ChNum, takes 1 or 2 */
 switch (I->RT) {
   case _Binary : 
            RHS1_mod = IsModifier(Name(RHS1_OfItem(I))); RHS2_mod = IsModifier(Name(RHS2_OfItem(I)));  

            if ((RHS1_mod == true) && (RHS2_mod == true)) return false; /* both are modifiers: none is head */

            if ((RHS1_mod == false) && (RHS2_mod == false))    /* none is modifier: in right-linear ECNF is always second child --> head is the first*/
              if (ECNF_MARKED(Name(RHS2_OfItem(I))) == true) WhichHeadCh = 1;  /* the second must be ECNF */
              else {fprintf(stderr, "err: what is head of  %s --> %s %s\n", 
                            Name(LHS_OfItem(I)), Name(RHS1_OfItem(I)), Name(RHS2_OfItem(I))); PItem(I); exit(1);}

            if (RHS1_mod == true) WhichHeadCh = 2; /* RHS1 is modifier and RHS2 --> RHS2 is head */
            else if (RHS2_mod == true) WhichHeadCh = 1;  /* RHS1 is not modifier and RHS2 is modifier --> RHS1 is head */

            if (WhichHeadCh == ChNum) return true;
            else return false;
           /* no head found: an error occurred */
          break; 
   case _Term  : return false; break;
  case  _Unary : return true; break;
 };
}
/**********************************************************/
/* always succeeds */
void AddToLexSetOf(ItemTree I, RDomain R)
{I->lexic_set = Enter_DinSet(I->lexic_set, (MemDomain) R);
}

Boolean AddLexSet(ItemTree target, ItemTree source)
{void EnToLex(RDomain R)
  {AddToLexSetOf(target, (MemDomain) R);}

 if (_UNIFICATION_BASED == true) {
 /* PItem(source); PrintDinSet(source->lexic_set); */
 MapOnDinSet(source->lexic_set, (void *) &EnToLex);
 /* PItem(target); PrintDinSet(target->lexic_set); PRS("+++++++++++++++++++++++++++++++++++++\n"); */
 }
 return true;
}

Boolean AddLexOnlyForThisPT(ItemTree target, ItemTree source, char *postag)
{Boolean result = false;
 void EnToLexIf(RDomain R)
   {/* printf("%s   %s\n", postag, EX_INTERN_REP_OF_POSTAG(Name(LHS_OfR(R, _Unary)))); */
    if ( !strcmp(postag, EX_INTERN_REP_OF_POSTAG(Name(LHS_OfR(R, _Unary)))) ) 
         {AddToLexSetOf(target, (MemDomain) R); 
          result = true;
         }
   }

 /* PItem(source); PrintDinSet(source->lexic_set);  */
 MapOnDinSet(source->lexic_set, (void *) &EnToLexIf);
 /* PItem(target); PrintDinSet(target->lexic_set); PRS("--------------------------------------\n"); */
 return result;
}
Boolean AddLexForPTandWord(ItemTree target, ItemTree source, char *postag, char *word)
{Boolean result = false;
 void EnToLexIf(RDomain R)
   {char PT[SymLength]; char WD[SymLength];
    strcpy(PT, EX_INTERN_REP_OF_POSTAG(Name(LHS_OfR(R, _Unary))));
    strcpy(WD, EX_INTERN_REP_OF_WORD(Name(RHS1_OfR(R, _Unary)))); 
    /* printf("%s ==> %s \n", Name(LHS_OfR(R, _Unary)), Name(RHS1_OfR(R, _Unary)));
       printf("%s   %s   %s  %s\n", postag, word, PT, WD);  */
    if ( (!strcmp(postag, PT)) && (!strcmp(word, WD)) )
      {AddToLexSetOf(target, (MemDomain) R); result = true;}
   }
 /* PItem(source); PrintDinSet(source->lexic_set); */
 MapOnDinSet(source->lexic_set, (void *) &EnToLexIf);
 /* PItem(target); PrintDinSet(target->lexic_set); PRS("=====================\n"); */
 return result;
}
/*******/
/* unifies ParentI's lexical info with ChI's and returns whether ChI unifies well with ParentI or not */
Boolean LexUnify(ItemTree ParentI, ItemTree ChI, int ChNum)
{static char HeadPT[SymLength]; static char HeadWord[SymLength]; char *temp; Boolean ErIsWord, ErIsPT; 

 if ((LEXICALIZED_WSJ == false) || (_UNIFICATION_BASED == false))  return true;

 strcpy(HeadPT,""); strcpy(HeadWord,"");
 if (((!strcmp(Name(LHS_OfItem(ParentI)),"sss")) || (!strcmp(Name(LHS_OfItem(ParentI)),"ssss"))) ||
      (THIS_HEAD_CH(ParentI, ChNum) == false) || (IsModifier(Name(LHS_OfItem(ParentI))) == true)) {return true;} 
 else
  {ErIsWord = false;   ErIsPT = false;
   if (_PERCULATE_ONLY == false) /* nonterminal labels carry no constraints */
    {temp = EX_INTERN_REP_OF_POSTAG(Name(LHS_OfItem(ParentI))); 
     if (temp != NULL) 
      if (strcmp(temp,""))
       {ErIsPT = true; strcpy(HeadPT, temp); 
        temp = EX_INTERN_REP_OF_WORD(Name(LHS_OfItem(ParentI)));
        if (temp != NULL) if (strcmp(temp,"")) {ErIsWord = true; strcpy(HeadWord, temp); }
       }
    }
  /* PItem(ParentI); PRS("   with\n        "); PItem(ChI); printf("\n%s      ---%s      ----%s\n", Name(LHS_OfItem(ParentI)), HeadPT, HeadWord); */
   /* now unify ChI's list with ParentI's PT and word */
   if ((ErIsWord == false) && (ErIsPT == false)) /* ParentI carries no constaints: unifies with all */
     {return AddLexSet(ParentI, ChI); }
   if (ErIsWord == false) /* ParentI's postag is a constraint on ChI's lexicals that are added to ParentI's */
     {return AddLexOnlyForThisPT(ParentI, ChI, HeadPT);}
   /* both exist: check both */
   return AddLexForPTandWord(ParentI, ChI, HeadPT, HeadWord);
  }
}
/* I must be a terminal rule  ax->word*                                      */
/* we add to its lexical all rule numbers PT->ax*  where PT must be a postag */
void InitUnificationFor(ItemTree I) 
{void UpdateLexSet(RDomain R) {AddToLexSetOf(I, R);}
 if ((LEXICALIZED_WSJ == true) && (_UNIFICATION_BASED == true))
  {if (_INTERN_WORD_REP_VER == true)
    {UpdateRepresArrayForSentence(Name(LHS_OfItem(I)), _sen_length);
     /* run on all items  PT->ax */
     MapOn_Rules_Of(NT_Ptr_Of(LHS_OfItem(I), RHS_1), _Unary, (void *) &UpdateLexSet); 
    }
   else AddToLexSetOf(I, (LexicalRuleOf(LHS_OfItem(I), RHS1_OfItem(I))));
   /* PItem(I); PrintDinSet(I->lexic_set); */
  }
}
/*********************************************/
RDomain LexicalRuleOf(NTDomain LHS, TDomain RHS)
{char WORD[SymLength];char TEMP[SymLength];
 strcpy(WORD,_VOID_PREFIX); strcpy(TEMP, TName(RHS));
 if (EQ_Strings(TEMP,UNVALID_SYM) == true)
   {/* No lexical prob rules */  /*{fprintf(stderr,"Err(LRO): no Terminal %d", RHS);exit(1);}*/
    return UNVALID_RNUM;
   }
 else {strcat(WORD,TEMP); return RNumOfT(Name(LHS), WORD);}
}
