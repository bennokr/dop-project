struct PtrLStr {
       void  *Ptr;
       struct PtrLStr *Next;
       void *Data;
};
typedef struct PtrLStr *PtrList;
typedef PtrList *PtrListArray;
/********************/
PtrList NewPtr(void *Ptr);
/************************** The observed functions are ***/
PtrList CrPList();
PtrList PrevTo(void *Ptra, PtrList L, Boolean *FOUND, void (* Eq)());
PtrList EnterP(void *Ptr, PtrList L);
PtrList EnterPStack(void *Ptr, PtrList L);
void PListMapRev(PtrList L, void (* fp)());
void PListMap(PtrList L, void (* fp)());
void PDListMapRev(PtrList L, void (* fp)());
void PDListMap(PtrList L, void (* fp)(void *));
void PListMapEx(PtrList L, void (* fp)(), int i);
/*****************************/
/* Maps fp on L, and elliminates
   eacht element on which fp 
   computes to true         
  fp takes an element and a pointer
  to a Boolean  which it returns the
  value in for filtering       */
PtrList PLRemoveIf(PtrList L, void (* fp)());
/*************************/
/* Checks whether any element
   fulfils fp and return true if so.
   Returns false otherwise. See
   former function for how fp works */
Boolean PLAnyFulfil_fp(PtrList L, void (* fp)());
PtrList PtrLRotate(PtrList P);
void FreePDList(PtrList L);
PtrList StackPList(PtrList Ptr, PtrList L);
void EnterToDataOfFirst(void *Ptr, PtrList P);
void FreePListN(PtrList L) ;
void *PListHeadPtr(PtrList PL);
void PListMapUntillN(PtrList L, void (* fp)());
PtrList QueueList(PtrList S, PtrList T);
PtrList MergePL(PtrList S, PtrList T);
PtrList UnitePLSet(PtrList P1, PtrList P2);
PtrList EnterQueue(void *Ptra, PtrList L);
extern PtrList CopyPtrList(PtrList L);

