#include "Universals.h"
#include "Aux.h"
#include "DefsGrammar.h"
#include "DinamicSets.h"

/*****************************************************************/
/* A unit for dealing with dinamically growing sets of MemDomain */


DinSet CrDinSet(int size)
{int i; DinSet res = NULL;
 res = (DinSet) AllocElem(sizeof(struct DinSetStruct));
 if (res == NULL) {fprintf(stderr,"Err: dinamic sets failure\n");exit(1);}
 res->members = (MemDomain *) MultAlloc(size, sizeof(MemDomain));
 if (res->members == NULL) {fprintf(stderr,"Err: dinamic sets failure\n");exit(1);}
 res->max_size = size; res->cu_size = 0;
 for (i=0; i < res->max_size; i++) res->members[i] = MemDomainZero;
 return res;
}
void FreeDinSet(DinSet set)
{if (set != NULL) {cfree(set->members); free(set);}
}

void CopyDinSet(DinSet target, DinSet source)
{int i;
 if ((target == NULL) || (source == NULL)) {fprintf(stderr,"Err: size of source and target !!\n"); exit(1);}
 if (target->max_size < source->max_size)  {fprintf(stderr,"Err: size of source and target !!\n"); exit(1);}

 for (i = 0; i < source->cu_size; i++) target->members[i] = source->members[i];
 target->cu_size = source->cu_size;    /* each DinSet has its own max_size !! */
}

DinSet AdaptDinSet(DinSet set)
{int cu_max_size; DinSet res = NULL; Boolean ExpandSet = false;
 if (set == NULL) ExpandSet = true;
 else ExpandSet = ( (set->max_size <= set->cu_size) ? true : false);

 if (ExpandSet == true)
  {if (set == NULL) cu_max_size = 0; else cu_max_size = set->max_size;
   res = CrDinSet((int) (cu_max_size + SetBlockSize));
   if (res == NULL) {fprintf(stderr,"Err: dinamic sets failure\n");exit(1);}
   if (set != NULL) {CopyDinSet(res, set); FreeDinSet(set);}
   else res->cu_size = 0;
   res->max_size = cu_max_size + SetBlockSize;
  }
 else res = set;
 return res;
}
/*****************************************/
int PlaceInSet(DinSet set, MemDomain mem)
{int i; if (set == NULL) return NOT_IN_SET;
 for (i=0; i < set->cu_size; i++) if (set->members[i] == mem) return i;
 return NOT_IN_SET;
}

Boolean MemberInSet(DinSet set, MemDomain mem)
{int place = PlaceInSet(set, mem); 
 if (place == NOT_IN_SET) return false;
 else return true;
}

DinSet Enter_DinSet(DinSet set, MemDomain new)
{DinSet res = set; 
 if (MemberInSet(set, new) == false)
   {res = AdaptDinSet(set);
    if (res != NULL) {res->members[res->cu_size] = new; res->cu_size++;}
    else {fprintf(stderr,"Err: dinamic sets failure\n");exit(1);}
   }
                           
 return res;
}
void MapOnDinSet(DinSet set, void (* fp)())
{int i;
 if (set != NULL) for (i=0; i < set->cu_size; i++) (*fp)(set->members[i]);
}
void PrintDinSet(DinSet set)
{void PrRDom(MemDomain X) {PRI((long int) X);printf("  ");}
 MapOnDinSet(set, (void *) &PrRDom);
 printf("\n");
}
/*****************************************/
