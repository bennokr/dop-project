   if (R_COUNT_BEAM_WIDTH < (V_BEAM_WIDTH-1)) /* keep last place for current one */
     {R_BeamMaxProbNonTArray[R_COUNT_BEAM_WIDTH]=MaxProbNonTArray[NTnum]; R_COUNT_BEAM_WIDTH++;}
   else {Boolean First =false; ProbDomain p = MaxProbs(MaxProbNonTArray[NTnum], R_BeamMaxProbNonTArray[V_BEAM_WIDTH-1], &First);
         if (First == true) {
           R_BeamMaxProbNonTArray[V_BEAM_WIDTH-1] = MaxProbNonTArray[NTnum];
           qsort((void *) &(R_BeamMaxProbNonTArray[0]), V_BEAM_WIDTH, (sizeof(ProbDomain)),  CompareH);
           /* now the smallest is last one so we can substitute next time */
            /*fprintf(stderr,"%e => ", R_BeamMaxProbNonTArray[V_BEAM_WIDTH-1]); fprintf(stderr,"\n");*/
          }
        }
