#include "./ALL.h"
#include "./RAMcodes.h"

Boolean _USE_RAM = false;

/************************************/
/* A buffer structure has the startpoint (StartP) of the Rule_Apps
   RApps on the file .CodesLists.bin. This start point is the start
   point where the Roots start unless there are no roots, then the
   Others. In case both are zero then a zero and a NULL will appear
   in the buffer (although this should not occur since rules have
   codes or else they won't be in the grammar !!).
struct Buf_Struct {
      PlacesT StartP;
      Rule_Apps RApps;
};
typedef struct Buf_Struct *BufPtr;

*/
/************************/
/* Two global variables which hold Rule_Apps for two items; 
   i.e. parent and child items which are multiplied        */
#ifndef WHICHBUFT
#define WHICHBUFT int
#endif
WHICHBUFT WhichBuf = 1; 
BufPtr BfPtr1 = NULL;
BufPtr BfPtr2 = NULL;
Ch_Ptr RChsPlacesBuff1 = NULL;
Ch_Ptr OChsPlacesBuff1 = NULL;
Ch_Ptr ChsPlacesBuff2 = NULL;
/** ItemTree ItemBuffer1 = NULL; ItemTree ItemBuffer2 = NULL; */
/************************/
/* For the outside world */
inline
Ch_Ptr PtrToChsBuff(Code_Soort CT)
{switch (CT) {
   case ROOT_enum   : return RChsPlacesBuff1; break;
   case OTHERS_enum : return OChsPlacesBuff1; break;
   otherwise        : fprintf(stderr, "Err in PtrToChsBuff\n"); exit(1); break;
 }/*----*/     
}
/************************/
inline
BufPtr NewBP()
{BufPtr BP = (BufPtr) AllocElem(sizeof(struct Buf_Struct));
 BP->StartP = -1;
 BP->RApps = NewRApps();
 return BP;
}
inline
void InitBuff(WHICHBUFT i)
{switch (i) {
   case 1: BfPtr1 = NewBP(); 
           break;
   case 2: BfPtr2 = NewBP();
           break;
 }/*switch*/
}

void FlushBuff(WHICHBUFT i)
{switch (i) {
   case 1: if (BfPtr1 != NULL) {
           if (OChsPlacesBuff1 != NULL) {cfree(OChsPlacesBuff1); OChsPlacesBuff1 = NULL;}
           if (RChsPlacesBuff1 != NULL) {cfree(RChsPlacesBuff1); RChsPlacesBuff1 = NULL;}
           BfPtr1->StartP = -1; if (_USE_RAM==false) FreePartsOfRApps(BfPtr1->RApps); 
           }
           break;
   case 2: if (BfPtr2 != NULL) {
           BfPtr2->StartP = -1; if (_USE_RAM==false) FreePartsOfRApps(BfPtr2->RApps); 
           /* free(ChsPlacesBuff2); ChsPlacesBuff2 = NULL; */
           }
           break;
   otherwise: exit(1); break;
 }/*switch*/
}
/*******/
inline
void ResetBuffering()
{FlushBuff(1); FlushBuff(2); WhichBuf = 1;
}
/*******/
/* If a rule has root-codes then its place in .CodesList.bin starts 
   with root codes, else then it starts with Others. Therefore 
   WhichStart return the place the codes start in .CodesList.bin  */
inline
PlacesT WhichStart(PlacePtr PP)
{if (PP == NULL) {PRS("WhichStart: PP is null\n"); exit(1);}
 else if (PP->Roots_StartPos != -1) return (PP->Roots_StartPos);
      else if (PP->Others_StartPos != -1) return (PP->Others_StartPos);
           else {fprintf(stderr,"%s\n","Err: A rule without any codes...\n");exit(1);}
                 
}
inline
Rule_Apps CheckBuff(WHICHBUFT bufnum, PlacesT WS)
{switch (bufnum) {
   case 1: if (BfPtr1->StartP == WS) return BfPtr1->RApps;
           else return NULL;
           break;
   case 2: if (BfPtr2->StartP == WS) return BfPtr2->RApps;
           else return NULL;
           break;
   otherwise: printf("\n CheckBuff: problems\n"); exit(1);
              break;
 }/*switch*/
}
/**********************/
void GetChsPls(PlacesT WS, TreeCodeT RSize, TreeCodeT OSize)
{int RD = 0;
 int Err ;
 PlacesT WStemp = (PlacesT) 
                  ((TreeCodeT) (WS / ((TreeCodeT) sizeof(struct Node_Type)))) * sizeof(struct Ch_Str);
 Ch_Ptr Result = NULL;

 Err = fseek(fpChsPl, WStemp, SEEK_SET);

  if (Err != 0) {printf("Error in Seeking children file.\n");exit(1);}
  else {if (RSize > 0) 
        {Result = (Ch_Ptr) MultAlloc((size_t) RSize, sizeof(struct Ch_Str));
         RD = fread((void *) Result, sizeof(struct Ch_Str), RSize, fpChsPl);
         if (RD != RSize) {printf("RError in reading codes file.\n");exit(1);}
        } else Result = NULL;
        RChsPlacesBuff1  = Result;
        if (OSize > 0) 
        {Result = (Ch_Ptr) MultAlloc((size_t) OSize, sizeof(struct Ch_Str));
         RD = fread((void *) Result, sizeof(struct Ch_Str), OSize, fpChsPl);
         if (RD != OSize) {printf("RError in reading codes file.\n");exit(1);}
        } else Result = NULL;
        OChsPlacesBuff1  = Result;
       }
}
inline
void GetChildPlaces(PlacePtr PP)
{PlacesT WS = WhichStart(PP);
 if (CheckBuff(1, WS) != NULL) ; /* the 1st buffer still contains the same codes and so also the children */
 else GetChsPls(WS, PP->Roots_Size, PP->Others_Size);
}
/**********************/
/* In order for this to
   work well, at least one of the buffers
   must be flushed before calling it  .   */
/* Returns RA from one of the two buffers
   if it is there, otherwise the empty
   buffer is filled with the records read from
   the file .CodeLists.bin and RA is returned.
*/
/**********************/
/* one of the two buffers must be empty for this update to succeed */
/**********************/
inline
void IntoBuff(PlacesT WS, Rule_Apps RA)
{
 if (WhichBuf == 1)  {FlushBuff(1);
                      BfPtr1->StartP = WS; BfPtr1->RApps = RA;
                      GetChsPls(WS, RA->Roots_Size, RA->Others_Size);
                     }
 else if (WhichBuf == 2) {FlushBuff(2);
         BfPtr2->StartP = WS; BfPtr2->RApps = RA;
        /* Not necessary in this implementation since Buff2 is child code*/
        /* ChsPlacesBuff2 = GetChsPls(WS, RA->Others_Size);*/
      }
      else {printf("Buffer Number is unclear\n"); exit(1);}
}
inline
void IntoBuffPPtr(PlacePtr PP, Rule_Apps RA)
{PlacesT WS = WhichStart(PP);
 IntoBuff(WS, RA);
}
/***************************/
Rule_Apps GetFromFile(PlacesT WS, TreeCodeT RS, TreeCodeT OS)
{int RD = 0;
 Rule_Apps RA = NewRApps();
 int Err = fseek(fpCodes, WS, SEEK_SET);
 if (Err != 0) {printf("Error in Seeking codes file.\n");exit(1);}
 else {RA->Roots_Size = RS; RA->Others_Size = OS;
       RA->Roots_Nodes = NewNP(RS); RA->Others_Nodes = NewNP(OS);
       if (RS != 0)
        {RD = fread((void *) RA->Roots_Nodes, sizeof(struct Node_Type), RS, fpCodes);
         if (RD != RS) {printf("RError in reading codes file.\n");exit(1);}
        } else RA->Roots_Nodes = NULL;
       if (OS != 0) 
         {RD = fread((void *) RA->Others_Nodes, sizeof(struct Node_Type), OS, fpCodes);
          if (RD != OS) {printf("OError in reading codes file.\n");exit(1);}
         } else RA->Others_Nodes = NULL;

       IntoBuff(WS, RA); return (RA);
      }
}
/***/
inline
Rule_Apps GetR_A(PlacePtr PP)
{Rule_Apps RA;
 PlacesT WS = WhichStart(PP);
 if (WS == -1) {exit(1); /* FlushBuff(WhichBuf); return NewRApps();*/}
 else {if (BfPtr1 == NULL) InitBuff(1); if (BfPtr2 == NULL) InitBuff(2);
       RA = CheckBuff(1, WS); /* is it already in Buff1 ? */
       if ((RA != NULL) && (WhichBuf == 1)) return RA;
       else {RA = CheckBuff(2, WS);
             if ((RA != NULL) && (WhichBuf == 2)) return RA;
             else 
             return (GetFromFile(WS, PP->Roots_Size, PP->Others_Size));
            } 
      }
}
/*********************************/
/*********************************/
/*********************************/
/*********************************/
