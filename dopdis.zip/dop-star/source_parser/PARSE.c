#include "./ALL.h"
#include "UnknownWords.h"

#define _USE_LINEAR_RULE_VERSION  true

/***************************************/
#define NUM_UNARIES        0
#define NUM_UNARIES_GROUND 1

/* When breaking chains: a chain is allowed to be of maximum length: */
#ifndef _MaxLengthForBrokenChains
#define _MaxLengthForBrokenChains NUM_UNARIES
#endif
#ifndef _MaxLengthForBrokenChains_GEntry
#define _MaxLengthForBrokenChains_GEntry NUM_UNARIES_GROUND
#endif

#ifndef _CYCLE_NUM
#define _CYCLE_NUM 10
#endif

#define _COMPACT_IMMIDIATE true

/**********************/
Boolean _Break_Cycles = true;
Boolean _PRUNE_UNARY     = true; 
Boolean _PRUNE_NOT_ENDED = false;

/* Garbage collection: minimum sentence length and how often */
#ifndef _MIN_LENGTH_GARBAGE_COL
#define _MIN_LENGTH_GARBAGE_COL  2
#define _MOD_LENGTH_GARBAGE_COL  1
#endif

/*************************************************************************/
Boolean _LHS_CATEGORY_ALLOWED(Boolean Allowed_Cat) 
{if ((_FilterPosTags ==  false) || ( (_FilterPosTags ==  true) && (Allowed_Cat == true) ) ) return true;
 return false;
}
/*************************************************************************/
/* This Version of the CYK algorithm allows for interleaved computation
   of the derivation-forest for an STSG. This can be done by assigning
   the value true to the global variable "Interleaved" in the file globals.c
   The following declaration of evaluation functions is meant for this
   case only.
**************************************************************************/
extern void FreeGarbageItems(TableType TAB, int span, int _sen_length);
extern Boolean InputPhraseLabel_AllowedQ(int i, int j, NTDomain NT);
/*-----------------------------------------------------------------------*/
/* In the double-parser: for the second grammar there is another version of this */
/* Compute derivation forest and probabilities and prune                         */
EntryPtr Do_Interleaved(TableType TAB, int i, int j, DuoPtr Duo, Boolean Ended, Boolean PruneAlso, Boolean Unaries)
{Boolean Prune = PruneAlso;
 if ((Semi_Interleaved == true) && (_DisambiguateB == true))
    {CompDFEntrySemiI(TAB, i, j, Duo, Ended, Unaries, PruneAlso);
     if ((_PRUNE_NOT_ENDED == false) && (Prune == true)) if (Ended == false) Prune = false;
     if ((_PRUNE_UNARY == false) && (Prune == true)) if (Unaries == true) Prune = false;
     if ((Prune == true)) PruneEntry(TAB, i, j, Ended, Unaries, _COMPACT_IMMIDIATE);
    }
 return (ENTRY_Of(TAB, i, j));
}
/*************************************************************************/
/* Adds an item I ot ENT and returns whether it is new (true) or has been there (false) */
Boolean Add_IsNew(EntryPtr ENT, ItemTree I)
{RDomain sizebef, sizeaf;
 sizebef = SetSize(*ENT); *ENT = Add(I, *ENT); sizeaf = SetSize(*ENT);
 if (sizebef == sizeaf) return false;
 else return true;
}
/****************************************/
/* Complete is a closure operation on entries: this is a single complete step */ 
/* It returns a copy of a set of items that has been added to the entry during this step */
EntryPtr A_Complete_Step(EntryPtr CYKEntPtr, EntryPtr Old, RType WhatRules)
{EntryPtr NEW; RDomain sizebef, sizeaf; PtrList ThisAddedByList;
    void UItemFromRuleEx(RDomain RuleNo, ItemTree Child, LevDomain i, LevDomain j)
         {Boolean UpdAddedByOfI = false; ItemTree S1 = NULL; Boolean Allowed_Cat = true;
          ItemTree I = FillItem(RuleNo, _Unary, mid); ItemTree I1 = FillItem(RuleNo, _Unary, mid); 
          I->i = i; I->j = j; I1->Valid = true; I1->i = i; I1->j = j;

           Allowed_Cat = ((InputPhraseLabel_AllowedQ(i,j, LHS_OfR(RuleNo, _Unary))==true) ? true : false); 

           if (_LHS_CATEGORY_ALLOWED(Allowed_Cat) == true) 
           {if (EqItem(I, S1 = SeekItem(I, *CYKEntPtr)) == false) /* is the item new ? */
                    {*CYKEntPtr = Add(I, *CYKEntPtr); Add(I1, *NEW); UpdAddedByOfI = true;}
            else {if ((_Break_Cycles == false) || (_APPLY_PRUNE == false)) /* see refCycles */  
                     {if ((Add_IsNew(NEW, I1)) == false) I1 = FreeItem(I1);}
                  else I1 = FreeItem(I1); 
                  I = FreeItem(I); I = S1; /* take the original from the entry */

                  if ( (EqItem(I, SeekItem(I, *NEW)) == true) ) /* added during Cu-step ?*/
                       UpdAddedByOfI = true;  /* see refCycles */
                  else UpdAddedByOfI = false;
                 }
            if ((_MakePForest == true) && (UpdAddedByOfI == true)) 
              {ItemAddedBy(I, (void *) Child); 
               if ((EqItem(I, Child) == true) ) {fprintf(stderr,"Err:items adds itself?\n");PItem(I); exit(1);}
              }
           } else {I = FreeItem(I); I1 = FreeItem(I1);}
         }
    void BItemFromRuleEx(RDomain RuleNo, ItemTree Child, LevDomain i, LevDomain j)
         {ItemTree S1; ItemTree IT = FillItem(RuleNo, _Binary, mid); ItemTree IT1 = FillItem(RuleNo, _Binary, mid);
           Boolean Allowed_Cat = true;
          IT->i = i; IT->j = j; IT1->Valid = true; IT1->i = i; IT1->j = j;

           /* TO AVOID PROBLEMS WITH UNARIES WE HAVE TO DELAY EXCLUSION OF BINARY RULES UNTIL DEDUCE!!
           Allowed_Cat = ((InputPhraseLabel_AllowedQ(i,j, LHS_OfR(RuleNo, _Binary))==true) ? true : false);
           fprintf(stderr, "(%d %d) %s %d\n", i, j, Name(LHS_OfR(RuleNo, _Binary)), Allowed_Cat); */

            {if ((EqItem(IT, S1 = SeekItem(IT, *CYKEntPtr))) == false)
                     {*CYKEntPtr = Add(IT, *CYKEntPtr); Add(IT1, *NEW);}
             else {
                   if ((Add_IsNew(NEW, IT1)) == false) IT1 = FreeItem(IT1);
                   IT = FreeItem(IT);  IT = S1; /* take the original from the entry */
                  }
             if (_MakePForest == true) 
               if (_USE_LINEAR_RULE_VERSION == false) 
                 ItemAddedBy(IT, (void *) Child); /* A Set: Changed 5.10.96 : refNoMakeSet*/
               else {IT->AddedBy = ThisAddedByList; IT->Level = Child->Level+1;}
            } 
         }
    void MoreItems(void *Ptr)
         {ItemTree Child; NTDomain NONT; Boolean UseThisItem; ItemTree CopyCh; 
          inline void UItemFromRule(RDomain RuleNo) 
            {UItemFromRuleEx(RuleNo, Child, Child->i, Child->j);}
          inline void BItemFromRule(RDomain RuleNo) 
            { BItemFromRuleEx(RuleNo, Child, Child->i, Child->j);}

          CopyCh = (ItemTree) Ptr; 
          Child = SeekItem(CopyCh, *CYKEntPtr); /* find the orig-copy in table (remember: Old holds copies) */
          UseThisItem = ( ((EqItem(Child, CopyCh)) == true) ? true : false );/* essential: see refPruning */
          if (Semi_Interleaved == true) UseThisItem = ((NonEmptyDerForest(Child) == true) ? true : false);
          
          if (UseThisItem == true)
           {NONT = LHS_Of(RulePtr_Of(Child->RuleNo, Child->RT)); 
             switch (WhatRules) {
               case  _Unary:  MapOn_Rules_Of(NT_Ptr_Of(NONT, RHS_1), _Unary, (void *) &UItemFromRule); break;
               case _Binary:  if (Child->j < _sen_length) /* final entries do not need to introduce A->B*C !!*/
                               MapOn_Rules_Of(NT_Ptr_Of(NONT, RHS_1), _Binary, (void *) &BItemFromRule); break;
                  otherwise:  fprintf(stderr,"Error in MoreItems\n"); exit(1); break;
             }/* switch */
           }
         }

 PtrList EndedItems = CrPList(); ItemTree MaxLevelItem;
 ThisAddedByList = CrPList();
 NEW = CrEntry(); /* NEW holds the items added at the current complete-step */
 
 if (_USE_LINEAR_RULE_VERSION == false) 
     SetsMapEnded(*Old, (void *) &MoreItems); 
     /* the next alternative maps one nonterminal at a time instead of SetsMapEnded above */
     //   MapOnLHSEnded(*Old, (void *) &MoreItems); 
 else
  if (WhatRules == _Unary) SetsMapEnded(*Old, (void *) &MoreItems); 
  else
  {NTDomain N;
   for (N=0;N<NonTSize; N++) /* per nonterminal item */
    {ThisAddedByList = CopyPtrList(TheLHSOfEndedPListOf(*Old, N));
     if (ThisAddedByList != NULL) /* there are ended items in this entry with LHS = (nonterm N): N->beta* */
      {MaxLevelItem = (ItemTree) ObtainMaxLevelItem(ThisAddedByList);
       MoreItems((void *) MaxLevelItem); /* only the max level is enough to add all A-> N * alpha   */
      }
    }
  }

 return NEW;
}
/*--------------------------------------------------*/
/* One Deduce step: deducing the items of C[i,j] from C[i,k] and C[k,j] */
/* LastPair is at the moment not used                                   */  
/* LastPair tells whether k refers to the last pair [i,k] [k,j] from   */
/* which the entry [i,j] is being deduced.                              */

Boolean A_Deduce_Step(TableType TAB, int i, int j, int k, Boolean LastPair)
{NTDomain ThisNont; RDomain sizebefore, sizeafter; Boolean CheckDForest = false;
 EntryPtr EntryPtrIJ; EntryPtr EntryPtrIK ; EntryPtr EntryPtrKJ ;

          /* Obtain A->BC* from A->B*C and C->beta* */
   void MvDot_Update(NTDomain NT, ItemTree ItemIK, Boolean *HALT)
     {ItemTree I=NULL; ItemTree S1=NULL; Boolean FirstTimeIK; Boolean Allowed_Cat =true;
               /* Stop is allowed to change to true if and only if _MakePF is false */
          void AlsoAdds(void *Ptr, Boolean *Stop)
            {ItemTree ItemKJ = (ItemTree) Ptr;
             Boolean UseThisItem = ((Semi_Interleaved == false) ? true :
                                    (NonEmptyDerForest(ItemKJ) == true) ? true : false);

             if (UseThisItem == true)
	     {if (RHS2_Of(RulePtr_Of(ItemIK->RuleNo, ItemIK->RT)) != LHS_Of(RulePtr_Of(ItemKJ->RuleNo, ItemKJ->RT)))
                 {fprintf(stderr,"\nErr: no match in deduce (%d, %d, %d) for  %d vs %d\n", i, j, k,
                          RHS2_Of(RulePtr_Of(ItemIK->RuleNo, ItemIK->RT)), LHS_Of(RulePtr_Of(ItemKJ->RuleNo, ItemKJ->RT))); exit(1);}
              else
               {I = FillItem(ItemIK->RuleNo, ItemIK->RT, rm);
           
                 {if (EqItem(I, (S1 = SeekItem(I, *EntryPtrIJ))) == false) UpdateEntry(TAB, I, i, j); 
                  else {I = FreeItem(I); I = S1;}

                  if (_MakePForest == true) 
                   {if (FirstTimeIK == true) /* refFirstTime */
                      {/* ItemEAdds(ItemIK, (void *) I);  HERE */
                       ItemEAddedBy(I, (void *) ItemIK); /* see refEAAdded */
                       FirstTimeIK = false; 
                      }
                    ItemEDAddedBy(I, (void *) ItemKJ);
                   } /*  */
                  else *Stop = true;  /* Only in case of pure recognition */
                 }
               }
	     }
            }

     FirstTimeIK = true;
     Allowed_Cat = ((InputPhraseLabel_AllowedQ(i,j, LHS_OfItem(ItemIK))==true) ? true : false);

     if (_LHS_CATEGORY_ALLOWED(Allowed_Cat) == true) 
       {
        MapOnLHSEndedUntill(NT, *EntryPtrKJ, (void *) &AlsoAdds);
       }
     /* else *HALT = true; for NT = C don't run on the list of items A->B*C in IK since there are no C->alfa*  in KJ */
    }

 EntryPtrIK = ENTRY_Of(TAB, i, k); EntryPtrKJ = ENTRY_Of(TAB, k, j);
 EntryPtrIJ = ENTRY_Of(TAB, i, j); sizebefore = SetSize(*EntryPtrIJ);
 CheckDForest = Semi_Interleaved;

 if ((SetSizeEnded(*EntryPtrKJ) > 0) && (SetSizeOths(*EntryPtrIK) > 0))
     MapAllRHS2Oths_VDF(*EntryPtrIK, (void *) &MvDot_Update, CheckDForest);  /* refSemiIntValids */

 sizeafter = SetSize(*EntryPtrIJ); 
 if (sizeafter > sizebefore) return true; else return false;
}
/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
extern Boolean PrefixOfString(char *str1, char *str2);
/********************************************************************************/
/* The CYK algorithm     CKY    CKY    CKY     CKY    CKY                      **/
/* The CYK algorithm     CKY    CKY    CKY     CKY    CKY                      **/
/* The CYK algorithm     CKY    CKY    CKY     CKY    CKY                      **/
/********************************************************************************/
/* For FSA kind of word-graphs: most general and now in use */
/* we allow 1 2 TAG/word_ [prob] style where TAG could be a Morpheme or a POSTAG */
/* the latter is used for filtering the POSTAGS using an external POSTAGGER      */
/* the global _FilterPosTags allows taking the TAG as a postag for filtering     */
/**/
TableType InitWG(TableType TAB, TDomain *S, int length, DuoPtr Duo)
{int start, end; WordList CuTrans, TempTrans; char POSTAG[SymLength];
    void Item_To_Table(RDomain RuleNo)
     {ItemTree I=NULL; Boolean Allowed_Cat;
      Allowed_Cat = ( (
	             /* (strchr(Name(LHS_OfR(RuleNo, _Term)), _ECNF_SYM)!=NULL) ||   see refUnaryPOSTAG */
		       (PrefixOfString(Name(LHS_OfR(RuleNo, _Term)), POSTAG)==true) || 
		       (EQ_Strings(POSTAG,"")==true) 
		     ) ? true : false);

      /*fprintf(stderr,"%s %s  %d\n", Name(LHS_OfR(RuleNo, _Term)), POSTAG, Allowed_Cat); */

      if (_LHS_CATEGORY_ALLOWED(Allowed_Cat) == true) /* XXXOldCode2: */
      {if (RuleNo >= 0) 
        {I = FillItem(RuleNo, _Term, mid); TempTrans=CuTrans; /* Some bug made me use TempTrans*/
	 XUpdateEntry(TAB, I, start, end, TempTrans);
         /* I->Transition = CuTrans;   pointing towards the transition */ 
         UpdateRepresArrayForSentence(Name(LHS_OfR(RuleNo, _Term)), length);
        }
       else {fprintf(stderr,"Err: rule-num is < 0\n"); exit(1);}
      }
     }
    void AddToTable(int start_t, int end_t, int word_seq_num, WordList transition)
     {start = start_t; end = end_t; CuTrans = transition;
      if (EQ_Strings(transition->Rule, _XXXPHRASE)==false) /* only actual POS-tag word pairs are added to table */
       {strcpy(POSTAG,transition->Morpheme); 
        if (EQ_Strings(POSTAG, "") == false) POSTAG[strlen(POSTAG)-1]='\0';/* removing the last "/" */
        if ((_match_on_unknown_only==true) && (transition->UnknownWord == false)) strcpy(POSTAG,"");  
        /*fprintf(stderr,"%d  %d  %s\n", start_t, end_t, POSTAG); */
        TMapOn_Rules_Of(Term_Ptr_Of(*(S + word_seq_num)), (void *) &Item_To_Table);
       }
     }
    void DoInterleavedInits(int start_t, int end_t, int word_seq_num, WordList transition)
     {( Do_Interleaved(TAB, start_t, end_t, Duo, true, Negate(_BIGRAM_PRUNE), false) );
     }
    void CompleteInits(int start_t, int end_t, int word_seq_num, WordList transition)
     {/* ComputeDF and if (we did not tag-prune) then prune the basic ended items */
      ( Complete(TAB, start_t, end_t, Duo));
     }

  MapOnTransitionOfWG((void *) &AddToTable);
  
  TAB = BiGramPosTagging(TAB, length, Duo);  /* only for interleaved version */
  MapOnWGsSetOfEntries((void *) &DoInterleavedInits); /* complete the entries (once for every <start,end>) */
  if (_BIGRAM_PRUNE == false) PruneForLength(TAB, length, 1);                    /* GLOBAL-THERSHOLDING */
  /* CHANGE INIT : complete on <i,i+1> entries takes place just before doing the other entries  */
     MapOnWGsSetOfEntries((void *) &CompleteInits); /* complete the entries (once for every <start,end>) */
  return TAB;
}
/******************/
/*---*/
/* A closure operation on the Entry. It adds all A->B*alpha for
   every B->beta* that is in Entry. The relation underlying this
   operation is a reflexive transitive closure relation.

   It returns whether anything was added to the entry or not.
*/
Boolean Complete(TableType TAB, int i, int j, DuoPtr Duo)
{Boolean TopEntryNow ; EntryPtr ThisEntryPtr ; EntryPtr OldItemsPtr ; EntryPtr OldItemsTemp ; 
 int change = -1; int MaxRounds_Break_Cycles = _CYCLE_NUM;

 TopEntryNow = ( ((i == 0) && (j==_sen_length)) ? true : false );
 ThisEntryPtr = ENTRY_Of(TAB, i, j); 
 OldItemsPtr = CopyEntry(ThisEntryPtr);

 if (_Break_Cycles == true)
    if ((j-i) == 1) MaxRounds_Break_Cycles = _MaxLengthForBrokenChains_GEntry;
    else MaxRounds_Break_Cycles = _MaxLengthForBrokenChains; 
 else MaxRounds_Break_Cycles = _CYCLE_NUM;

 if (TopEntryNow == true) MaxRounds_Break_Cycles = MaxRounds_Break_Cycles + 3;  /* for ssss and sss */

                                      /* while the closure adds items or this is the first time */
 for (change = 1; (((SetSize(*OldItemsPtr))!=0) && (change < MaxRounds_Break_Cycles)); change++) 
   {OldItemsTemp = OldItemsPtr;
    OldItemsPtr =  A_Complete_Step(ThisEntryPtr, OldItemsPtr, _Unary); 
    OldItemsTemp = FreeEntryPtr(OldItemsTemp); 
    ThisEntryPtr = Do_Interleaved(TAB, i, j, Duo, true, true, true);    /* ComputeDF and prune unaries */
   }  

 if (change >= _CYCLE_NUM) {fprintf(stderr, "Err: long chain of %d unary rules (cycle ?)\n", _CYCLE_NUM); exit(1);}
 if (SetSize(*OldItemsPtr) > 0) OldItemsPtr = FreeEntryPtr(OldItemsPtr);

 if (j != _sen_length) /* for final entries, the un-ended items are unnecessary */
   {OldItemsPtr = A_Complete_Step(ThisEntryPtr, ThisEntryPtr, _Binary); 
    if (SetSize(*OldItemsPtr) > 0) OldItemsPtr = FreeEntryPtr(OldItemsPtr);
    ThisEntryPtr = Do_Interleaved(TAB, i, j, Duo, false, true, false); /* ComputeDF and prune  A->B*C */
   }
 
 if (_COMPACT_IMMIDIATE==false) MakeCompactEntry(TAB, i, j, _sen_length); /* if we did not make it gradually compact: we do that now */

 if (change > 1) return true; else return false;
}
/************************************************/
/* For the right-linear computation             */
/* True iff right-linear, j==n and _FullSecRec  */
/* In a right-linear tree deduce is applied only*/
/* for entries [i,j] for which j=n              */
Boolean _TestFull(int j, int length)
{if (Right_Linear == true)
   if (_FullSenRec==true) 
     if (j == length) return true;
     else return false;
   else return true;
 else return true;
}
/******************************************************************************************/
/****** Deducing A->BC* given A->B*C and C->beta*  ****************************************/
/******************************************************************************************/
        extern void MapOnSetOfEntriesOfStart(void (* fp)(), int i); 
/*-*/
Boolean Deduce(TableType TAB, int i, int j)
{Boolean B = false;Boolean Last = false;
   void DeduceEntry(int k)
     {if (k == (j-1)) Last = true; B = (A_Deduce_Step(TAB, i, j, k, Last));}
   void DeduceEntryRL(int start, int end, int w_num, WordList trans)
     {if ((i < end) && (end < j))
       if (end == (j-1)) Last = true; B = (A_Deduce_Step(TAB, i, j, end, Last));
     }

 if (i == j) B = A_Deduce_Step(TAB, i, i, i,true);
 else if (j > i)
       if (Right_Linear != true) MapBetweenIJ(i, j, (void *) &DeduceEntry); /* general CFGs */
       else MapOnSetOfEntriesOfStart((void *) &DeduceEntryRL, i); /* assume right-linear */
      else PRS("Error: i > j !!!"); 

 ( Do_Interleaved(TAB, i, j, Duo, true, true, false) );/* ComputeDF+prune the basic ended items */
 return B;
}
/**********************************************/
/* TAB must already be iniltialized.        ***/
/* RedAddBy is used for the reduction of the */
/* Lists Adds and AddedBy which are redundunt*/
/* It makes a set out of them.               */

TableType PARSE(TableType *CKYTAB, TDomain *Sentence, int length, DuoPtr Duo)
{int k, j; Boolean B; EntryPtr ThisEntryPtr; TableType TAB;
   void DEDUCE_ENTRY(int i, int j, EntryPtr EPtr) {if ((j-i) > 1) if ((_TestFull(j, length))==true) B = Deduce(TAB, i, j);}
   void COMPLETE_ENTRY(int i, int j, EntryPtr EPtr) { if ((j-i) > 1) (Complete(TAB, i, j, Duo));}

   void DO_SPAN_BETWEEN(TableType TAB, int length, int span)
     {if (span > 1) 
          PruneForLength(TAB, length, span);              /* GT-pruning takes for every length */
     }
   void DO_SPAN_LAST(TableType TAB, int length, int span) 
     {if (span > 1) {FreeGarbageItems(TAB, span, length); FreeFastArraySpan(TAB, span, length);}
     }
   
 if (*CKYTAB == NULL) *CKYTAB = CrTable(length); 
 TAB = *CKYTAB;

 if (length > 0)
 {if (TAB == NULL) {fprintf(stderr,"Create the table first !!\n");exit(1);}
  else {
        TAB = InitWG(TAB, Sentence, length, Duo); 
        MapOnEntriesPerSpan(TAB, length, (void *) &DEDUCE_ENTRY, (void *) &DO_SPAN_BETWEEN, 
                            (void *) &COMPLETE_ENTRY, (void *) &DO_SPAN_LAST);
       } /* else */ 
 }
 else {/* fprintf(stderr, "%s\n", "tree(XXXempty,[])."); */ EXIT(EMPTY);};
 /* PrintTable(TAB, length); */
 return *CKYTAB;
}
/*********************************************************************************************************/
/*********************************************************************************************************/
/*********************************************************************************************************/
/* References and explanations */
/*                             */
/* refComp:  FOR RECOGNITION this closed line is sufficient
             BUT for computation of attributes YOU NEED THIS 
             the three lines that follow it  */
/* refEAAddedBy:
     In Deduce we have taken care of the double list of addedby
     items as follows:
      First of all we make a SET of all items A->B*C
      Then we also    make a SET of all items C->alfa *
     Then : for every A->B*C in the set we made
             for every C->alfa* in the other set we made
              add A->BC* and let
                A->B*C and C->alfa be in the AddedBy list
         
       thus: A->B*C is added only ONCE to the list of
             AddedBy, this way we do not need to make a set
             of the AddedBy list.
      MakeASetOfI does thus work only on the Data list containing
      all the possible C->alfa *
*/
/*refFirstTime:
  Since the doubly linked list is not maintained as a set then we enter the ItemIK
  only once and not again and again for every ItemKJ. ItemsEDAddedBy always enters
  ItemKJ into the list in Data of the first element in the list AddedBY i.e. the
  current ItemIK (until the next ItemIK comes in and FirstTimeIK changes back to
  true.
*/
/****
refNoMakeSet 
  MakeASetOfI is needed only when we use the EnterPStack for AddedBy lists by
  employing ItemEAddedBy instead of ItemAddedBY. EnterPStack just stacks the
  second parameter VX of ItemEAddedBy(I, VX) in the AddedBy list and does not
  take care for keeping a set, this is remedied by MakeASetOfI. Instead, ItemAddedBy 
  uses EnterP which does keep it as a set. 
  This issue is only due to the slow implementation of AddedBy structure as simple 
  lists. Sets implemented as lists can be really slow !!!
  Anyway, something to improve in the future when there is more time.
***/
/*
 refSemiInterValids:
   In the Semi-interleaved version, after pruning we are supposed to check the
   derivation-forest of the items. Items that has been fully pruned have an empty derivation-forest
   and should not participate in further parsing.
*/
/* OrigCode1
       for (k=2; k <= length; ++k)
	for (j=k; j <= length; ++j)
          {if ((_TestFull(j, length))==true) B = Deduce(TAB, (j-k), j);
           if (j == length) PruneForLength(TAB, length, k);            
           B = Complete(TAB, (j-k), j, Duo); 
          } 

   refCycles:
    When we break cycles we allow an unary to be added by Complete only the first time it is added:
    this means that it is added only during one iteration of Complete to the entry and that it in turn
    is used only during one iteration to add other items; 
    This way if we add (A->B* and B->C*) in round-1 then we do not add A-B* in round-2 (otherwise
    we have a cycle. Note that for the ssss and sss items, this does NOT apply.

   refPruning
    When we prune unaries, there is the possibility that an item is pruned from the entry in the CKY table
    but is still in the *OldItemsPtr, which keeps a copy of the last added items to the table.
    So when we want to use an items from OldItemsPtr, we have to check first whether it is in the table
    also (i.e. was not pruned earlier).
*/
void FreeGarbageItems(TableType TAB, int span, int _sen_length)
{
  void MarkIUnv(ItemTree I) {if (I != NULL) I->Valid = false;}
  void MarkIValid(ItemTree I) {if (I != NULL) I->Valid = true;}
  void MarkEntryUnv(int i, int j, EntryPtr EPtr) {SetsMap(*EPtr, (void *) &MarkIUnv);}
  void MarkUnEnded_Valid(int i, int j, EntryPtr EPtr) {SetsMapOths(*EPtr, (void *) &MarkIValid);}
  void MarkEnded_Valid(int i, int j, EntryPtr EPtr) {SetsMapEnded(*EPtr, (void *) &MarkIValid);}

 if (Semi_Interleaved == true)
  if ( (span >= _MIN_LENGTH_GARBAGE_COL) && ((Mod(span, _MOD_LENGTH_GARBAGE_COL)) == 0)  ) 
   {fprintf(stderr,"(%d", span); fflush(stderr);
    if (1==0)
    {
     {/* left-spine used to collect ended-items that are not participating in the sub- parse-forest */
      MapOnLeftSpineEntries(TAB, _sen_length, (void *) &MarkUnEnded_Valid); /* un-ended items marked valid */
      GenChunksLeftSpineOnly(TAB, _sen_length);  /* marking down the spine ended items as valid */
      FreeUnvalidItemsLeftSpine(TAB, _sen_length);
      MapOnLeftSpineEntries(TAB, _sen_length, (void *) &MarkEntryUnv);
     }
     {/* collect unended-items that will never become valid */
      GenChunksBetweenIJ(TAB, (_sen_length - span), _sen_length, _sen_length); /* marking down under <n-span, n> all items as valid */
      MapOnEntriesBetweenIJ(TAB, (_sen_length - span), _sen_length, (void *) &MarkEnded_Valid);    /* ended items marked valid */
      FreeUnvalidItemsBetweenIJ(TAB, (_sen_length - span),  _sen_length, _sen_length);
      MapOnEntriesBetweenIJ(TAB, (_sen_length - span), _sen_length, (void *) &MarkEntryUnv);    /* all items set back at unvalid */
     }
    }
    fprintf(stderr,")"); fflush(stderr);
   }
}
/**************************************/

/***

   void PARSE_ENTRY(int i, int j, EntryPtr EPtr)
     {if ((j-i) > 1)
       {if ((_TestFull(j, length))==true) B = Deduce(TAB, i, j);
        if (1==0) if (j == length) PruneForLength(TAB, length, (j-i));              
        B = Complete(TAB, i, j, Duo);
        if (j == length) 
          {FreeGarbageItems(TAB, j-i, length);              
           FreeFastArraySpan(TAB, j-i, length);
          }
       } 
     }
        MapOnTableEntries(TAB, length, (void *) &PARSE_ENTRY); * original code in OrigCode1 *




XXXOldCode2:
	if ((_FilterPosTags ==  false) ||
	          ((_FilterPosTags ==  true) &&
		             ( (PrefixOfString(Name(LHS_OfR(RuleNo, _Term)), POSTAG)==true) || (EQ_Strings(POSTAG,"")==true) )
			               )
				                )


refUnaryPOSTAG
When an unary dominates a postag and the unary is done internal to a subtree, the
input-postag filtering should not filter that unary label (which is labeled @).
**/
