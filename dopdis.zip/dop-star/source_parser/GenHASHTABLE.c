#include "Universals.h"
#include "Aux.h"
#include "Constants.h"
#include "PtrList.h"
#include "GenHashUnit.h"
#include "GenHASHTABLE.h"

extern ProbDomain SumProbs(ProbDomain P1, ProbDomain P2);        
extern PtrList RemoveIfNULL(PtrList PL);  
extern ProbDomain MaxProbs(ProbDomain P1, ProbDomain P2, Boolean *First);   

int String2Int(char *str)
{int sum = 0;
 int i =1;
 char *This = str;
 if (This == NULL) return -1;
 else if (This[0] == '\0') return -1;
      else
 do {
   sum = sum + ((int) This[0] * i); This = This+1;
 } while (This[0] != '\0');
 return sum;
} 
/******************************/
HASHTABLE AllocHashTable()
{HASHTABLE HT = (HASHTABLE) AllocElem(sizeof(struct HASHSTRUCT)); 
 HT->TheHT = (HASHLIST) MultAlloc((size_t) Maxvalue, sizeof(PtrList)); 
 HT->Num = 0;
 HT->SumFreq = 0;
 return HT;
}
/*****************************/
void InitHTable(HASHTABLE HTP)
{int i; HASHLIST HT = HTP->TheHT;
 for (i=0; i < Maxvalue; i++) HT[i] = NULL;}
/*****************************/
/* Allocates and initializes */
HASHTABLE NewHTable()
{HASHTABLE HT = AllocHashTable();
 InitHTable(HT);
 return HT;}
/*****************************/
int BucketOfStr(char *Rule)
{int result;
 int R = String2Int(Rule); 
 if (R < 0) {fprintf(stderr, "Err: BucketOfStr\n");exit(1);}
 else {result = (Mod(R, Maxvalue)); return result;}
}
int BucketOf(UnitPtr RU)
{int result;
 int R = String2Int(RU->Rule); 
 if (R < 0) {fprintf(stderr, "Err: BucketOf\n");exit(1);}
 else {result = (Mod(R, Maxvalue));
       return result;}
}
/***********************************************************************/
/*   Keeps the HASHTABLE as a set !!  */
UnitPtr ENT2HTableI(HASHTABLE HTP,char *String, Boolean *NEWB)
{int place; UnitPtr New; HASHLIST HT = HTP->TheHT;
 *NEWB = false;

 if (String != NULL)
  {
 New = FindUnitInHT(HTP, String);
 if (New == NULL)
  {*NEWB = true;
   New = NewUnit(String,(HTP->Num+1)); place = BucketOf(New);
   if (place >= 0) {HT[place] = (PtrList) EnterPStack((void *) New, HT[place]); 
                    HTP->Num++;
                    return ((UnitPtr)(HT[place])->Ptr);}
   else {printf("place is < 0 in HASHTABLE\n"); PRS("\n string is:"); 
         PRS(String);PRS("\n"); exit(1);};
  } 
 else {New->UnitFreq++; HTP->SumFreq++; return New;}
 }
 else return NULL;
}
UnitPtr ENT2HTable(HASHTABLE HTP,char *String)
{Boolean New = false;
 return ENT2HTableI(HTP, String, &New);
}
/* return whether it is new or not */
Boolean ENT2HTableAddProb(HASHTABLE HTP,char *String, ProbDomain Prob)
{Boolean New = false;
 UnitPtr UP = ENT2HTableI(HTP, String, &New); 
 if (UP != NULL) {
   /* fprintf(stderr,"%6.6e        %6.6e\n", Prob, UP->UnitProb); */
   if (New == true) UP->UnitProb = Prob;
   else UP->UnitProb = SumProbs(UP->UnitProb, Prob);
 }
 return New;
}
Boolean ENT2HTableUpdateProb(HASHTABLE HTP,char *String, ProbDomain Prob)
{Boolean New = false;
 UnitPtr UP = ENT2HTableI(HTP, String, &New); 
 if (UP != NULL) { UP->UnitProb = Prob; }
 return New;
}
/****************************/
/* Find the UnitPtr of String in HT or otherwise return NULL;
*/
UnitPtr FindUnitInHT(HASHTABLE HTP, char *String)
{int place; UnitPtr UnitRes; PtrList This; HASHLIST HT; UnitPtr temp;

          void CMPRRule(PtrList R)
           {UnitPtr AR;
            if (R != NULL)
              {AR = (UnitPtr) R->Ptr;
               if (AR != NULL) if (EQ_Strings(String, AR->Rule)==true) UnitRes = AR; else;
               else {fprintf(stderr,"Err: NULL in CMPRule\n");exit(1);}  
              }
            else;
           }

 HT = HTP->TheHT; temp = NULL; UnitRes = NULL;

 if (String != NULL) {
  /* temp = NewUnit(String,0); place = BucketOf(temp); if (temp != NULL) {temp = FreeNewUP(temp); } */
  place = BucketOfStr(String);

  if ((place >= 0) && (place < Maxvalue))
   {/* do limited  PListMap(HT[place], (void *) &CMPRRule); */
    This = HT[place];
    while ((This != NULL) && (UnitRes == NULL)) {CMPRRule(This); This = This->Next;}
   }
  else {fprintf(stderr,"Err: place in HASH is %d  for %s...\n", place, String);exit(1);}  

 return UnitRes;
 }
 else {return NULL;}
}
/**********************/
void RemoveHEntryOf(HASHTABLE HTP, char *String)
{PtrList This; int place; UnitPtr New; HASHLIST HT = HTP->TheHT;
    void FreeIfEq(PtrList PL)
     {UnitPtr AR = (UnitPtr) PL->Ptr;
      if (!strcmp(String, AR->Rule)) PL->Ptr = (void *) FreeNewUP(AR); 
     }
 if (String != NULL)
  {New = NewUnit(String,1); place = BucketOf(New);
   if ((place >= 0) && (place < Maxvalue))
    {This = HT[place]; while (This != NULL) {FreeIfEq(This); This = This->Next;}
     HT[place] = RemoveIfNULL(HT[place]);
    }
   New = FreeNewUP(New);
  }
}
/**********************/
/* -1 not found otherwise a number >=0 */
UnitNumType UnitNumOf(HASHTABLE HTP, char *String)
{UnitPtr UP = FindUnitInHT(HTP, String);
 if (UP == NULL) return -1;
 else return UP->UnitNum;
}
UnitNumType UnitNumOfEn(HASHTABLE HTP, char *String)
{UnitPtr UP;
 UP = ENT2HTable(HTP,String);
 return UP->UnitNum;
}
/**************/
void MapOnHTableKey(HASHTABLE HTP, void (* fp)())
{ int i; HASHLIST HT;
        void MapOnUnitsKeyI(void *VUP)
          {UnitPtr UP = (UnitPtr) VUP;
           MapOnUnitsKey(UP, fp);
          }
  HT = HTP->TheHT;
  for (i=0; i < Maxvalue; i++) 
      if (HT[i] != NULL)
         PListMap(((PtrList) HT[i]), (void *) &MapOnUnitsKeyI);
}
/**************/
void MapOnHTableUnits(HASHTABLE HTP, void (* fp)())
{ int i;HASHLIST HT;
        void MapOnUnit(void *VUP)
          {UnitPtr UP = (UnitPtr) VUP;
           (*fp)(UP);
          }
 HT = HTP->TheHT;
 if (HT !=NULL)
  for (i=0; i < Maxvalue; i++)
      if (HT[i] != NULL) PListMap(((PtrList) HT[i]), (void *) &MapOnUnit);
}
/*************/
FreqType TotalFreqOf(HASHTABLE HTP)
{FreqType Tot;
     void AddHUP(UnitPtr UP)
      {Tot = Tot + UP->UnitFreq;
      }
 Tot = 0;
 MapOnHTableUnits(HTP, (void *) &AddHUP);
 return Tot;
}
/*************/
float AverageFreq(HASHTABLE HTP)
{if (HTP == NULL) return ((float) 0.0);
 else if (HTP->Num == 0) return ((float) 0.0);
      else return ((float) ((float) HTP->SumFreq)/((float) HTP->Num));
}
/*************/
float FreqStdDev(HASHTABLE HTP)
{float stddev; float Avg;
    void CStdDev(UnitPtr UP)
     {stddev = stddev + ((float) pow((double) (((float) UP->UnitFreq) - Avg), (double) 2.0));
     }
 stddev = 0.0;
 Avg = AverageFreq(HTP);
 MapOnHTableUnits(HTP, (void *) &CStdDev);
 stddev = (float) sqrt((double) (stddev /((float) HTP->Num)));
 return stddev;
}
/*************/
void FreeHTable(HASHTABLE HTP)
{ int i;HASHLIST HT = HTP->TheHT;
  for (i=0; i < Maxvalue; i++)
      if (HT[i] != NULL) {FreePListN(HT[i]);HT[i] = NULL;}
  HTP->Num = 0;
}
/*************/
extern FreqType UnitFreqOf(UnitPtr UP);

char *MaxProbKeyOf(HASHTABLE HTP, ProbDomain *Prob)
{ProbDomain MAX = MaxNutralConst; char *RES = NULL;

  void SelectMaxProb(UnitPtr UP)
     {ProbDomain ThisProb; Boolean First = false;
      if (UP != NULL)
        {ThisProb = UP->UnitProb;
         MAX = MaxProbs(ThisProb, MAX, &First);
         if (First == true) RES = UP->Rule;
        }
     }

  if (HTP == NULL) return NULL;
  MapOnHTableUnits(HTP, (void *) &SelectMaxProb);
  *Prob = MAX;
  return RES;
}
/*************/
char *MaxFreqKeyOf(HASHTABLE HTP)
{FreqType MAX = 0; char *RES = NULL;
  void SelectMaxFreq(UnitPtr UP)
     {FreqType ThisFreq = UnitFreqOf(UP);
       if (UP != NULL)
        if (ThisFreq > MAX) {RES = UP->Rule; MAX = ThisFreq;}
     }

  if (HTP == NULL) return NULL;
  MapOnHTableUnits(HTP, (void *) &SelectMaxFreq);
  return RES;
}
/*************/
UnitNumType NumOfUnitsInHT(HASHTABLE HT)
{if (HT != NULL) return HT->Num;
 else return 0;
}
/**************/
ProbDomain HASHProbOf(HASHTABLE HTP, char *string)
{UnitPtr UP = FindUnitInHT(HTP, string); 
 if (UP!=NULL) return UP->UnitProb;
 else {fprintf(stderr,"Err: HASHProbOf"); exit(1); }
}
void ResetProbOfHTable(HASHTABLE HTP)
{
  void ResetProbOfUnit(UnitPtr UP)
   {if (UP!=NULL) UP->UnitProb=MaxNutralConst;
   }

  MapOnHTableUnits(HTP, (void *) &ResetProbOfUnit);
}
