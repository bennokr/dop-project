#include "./ALL.h"

/************************/
/* CodePtr and CodeType */
/************************/
inline CodePtr NewCPtr()
{CodePtr CdP = (CodePtr) AllocElem(sizeof(CodeType));
 CdP->TreeC = 0;
 /* CdP->ParentC = 0; */
 CdP->OwnC = 0;
 return CdP;
}

inline Boolean Parent(CodePtr CP, CodePtr Ch, Child_Type ChNum)
{if (CP->TreeC == Ch->TreeC)
    {switch (ChNum) {
       case Lch_enum : 
                   if (((InTreeCodeT) Ch->OwnC) == ((InTreeCodeT) CP->OwnC * 2))
                                 return true;
                  else return false;
                 break;
       case Rch_enum :
         if (((InTreeCodeT) Ch->OwnC - 1) == ((InTreeCodeT) CP->OwnC * 2))
                                 return true;
                  else return false;
                 break;
       otherwise : printf("Err Parent: ChildNum is not good\n");
                   return false;
                 break;
    }}
 else return false;
}
/* A root has code 1 always */
/* Has been changed to a macro for speed  */
inline Boolean IsRoot(CodeType *C)
{if (C->OwnC == 1) return true;
 else return false;
}
/******/
/* #define IsRoot(C) ((C->OwnC == 1) ? true : false) */
/************************/
/* Takes a string "/c1/c2/c3" and generates a pointer
   to a code.
*/
/************************
NOT USED IN THIS module
CodePtr FromStrToCode(char *C)
{InTreeCodeT i;
 char *y;
 char *x = C; 
 CodePtr CdP = NULL;
 if (C != NULL)
  {CdP = NewCPtr();
 y = C;
 y = strrchr(y, '/'); i = InTreeAToD(y+1); CdP->OwnC = (unsigned char) i;
         **** *y = '\0'; y = x; y = strrchr(y, '/'); 
             i = InTreeAToD(y+1); CdP->ParentC = (unsigned char) i; ****
 *y = '\0'; y =x; *y= '0';
 CdP->TreeC = TreeAToD(y);
 }
 return CdP;
}
*****************************/
/* Returns whether Chnum is open, i.e. a substitution-site */
inline Boolean IsOpenCh(OTS_Type OTS, Child_Type Chnum)
{if (OTS == BOTH_enum) return true; /* Both children are open-trees i.e. substitution-sites */
 else
  {
 switch (Chnum) {
   case Lch_enum : if (OTS == ONLYLHS_enum) return true;
                   else return false;
            break;
   case Rch_enum : if (OTS == ONLYRHS_enum) return true;
                   else return false;
            break;
   otherwise : PRS("Error: CHnum in IsAccCh"); return false;
               break;
 }
 }
}
/*--------------------------*/
/* Is now a Macro
inline Boolean TakeRsOnly(NodePtr NPp, Child_Type Chnum)
{if ((IsOpenCh(NPp->OTS, Chnum))==true) return true;
 else return false;
}
*/
/***********/
/*--------------------------*/
/* the general version for STSGs  */
inline Boolean IsViableNormal(NodePtr CP, NodePtr Ch, Child_Type ChNum)
{
 if ((IsOpenCh(CP->OTS, ChNum))==false) 
     if ((Parent(&CP->Code, &Ch->Code, ChNum)) == true) return true;
     else return false;
 else if ((IsRoot(&Ch->Code)) == true) return true;
      else return false;
}
/* The version for shortest-derivation using the whole treebank without subtree */
/* extraction: any node can combine with any, only the probabilities change     */
inline Boolean IsViableShortestDer(NodePtr CP, NodePtr Ch, Child_Type ChNum)
{return true;
}
inline Boolean IsViable(NodePtr CP, NodePtr Ch, Child_Type ChNum)
{
 return ( (_shortest_derivation == true) ? (IsViableShortestDer(CP, Ch,ChNum)) : (IsViableNormal(CP, Ch,ChNum)) );
}
/*---------------------------*/
inline int RelateCodes(NodePtr A, NodePtr B)
{CodePtr A1 = &(A->Code);
 CodePtr B1 = &(B->Code);
 enum Relate TR;
 TR = ((A1->TreeC == B1->TreeC) ? EQL : (A1->TreeC < B1->TreeC) ? SML : BIG);
 if (TR == SML) return -1;
 else if (TR == BIG) return 1;
      else return ((A1->OwnC == B1->OwnC) ? 0 :
                 (A1->OwnC < B1->OwnC) ? -1 : 1);
}
/*---------------------------*/
inline NodePtr NewNP(TreeCodeT num)
{NodePtr NP ;
 if (num == 0) return NULL;
 else {NP = (NodePtr) MultAlloc((size_t) num,sizeof(struct Node_Type));
       return NP;}
}
inline TreeCodeT TreeCodeOfNP(NodePtr NP)
{CodePtr CP;
 if (NP==NULL)  return -1;
 CP = &(NP->Code);
 return CP->TreeC;
}
inline TreeCodeT OwnCodeOfNP(NodePtr NP)
{CodePtr CP;
 if (NP==NULL)  return -1;
 CP = &(NP->Code);
 return CP->OwnC;
}
/*---------------------------*/
/*****************************************************************************************/
/************* CLOSED CLOSED ****************************/
/************* CLOSED CLOSED ****************************/
/************* CLOSED CLOSED ****************************/
/***********************/
/**********************
int CodeCMP(e1, e2)
  const void *e1;
  const void *e2;
{NodePtr A = (NodePtr) e1;
 NodePtr B = (NodePtr) e2;
 return RelateCodes(A, B);
}
int CodeCMP(e1, e2)
  const void *e1;
  const void *e2;
{C_Addr_Domain v1 = ((DerFPtr) e1)->CAdr;
 C_Addr_Domain v2 = ((DerFPtr) e2)->CAdr;
 return ((v1 < v2) ? -1 : (v1 > v2) ? 1 : 0);
}
*************/
