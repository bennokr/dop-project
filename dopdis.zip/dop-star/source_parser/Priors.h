extern NTDomain _NumOfPriorSym;

extern void Init_Various_PriorProbs_Tables();
extern void Init_PriorProbs();
extern ProbDomain Prior_ProbOfNT(NTDomain NT);
extern void Show_PriorProbs();
extern Boolean _PriorsExist;
extern ProbDomain PriorProbOfItem(ItemTree I); 

extern NTDomain _NumOfPriorSym;
enum PRIOR_KIND_TYPE  {_by_nont=1,_by_rule=2,_by_nont_w_lpos=3};
#define _PRIOR_KIND_DOMAIN    enum PRIOR_KIND_TYPE
static  _PRIOR_KIND_DOMAIN  _PRIOR_KIND_GLOB;
extern _PRIOR_KIND_DOMAIN _PRIOR_KIND_GLOB_EX;
