#include "./ALL.h"     
extern void GetICPOfItem(ItemTree IT, ItemCPtr ICP); extern void InitInternOfICP(ItemTree IT, ItemCPtr ICP); 
/**************************************************************************/
/***/
#define _TAG_ONLY_UNKNOWN           true
#define _EXTENSIONS_IN_POSTAGS      false
#define _DO_BKWD_PHASE            false
#define _DO_FULL_SENTENCE_TAGGING false
#define _PRUNE_ALL_ENTRIES          _DO_FULL_SENTENCE_TAGGING
#define _KEEP_FWD_BKWD_FOR_PRUNING  _DO_FULL_SENTENCE_TAGGING
/*
*/
#define _UB_ITEMSNUM_PER_ENTRY    1
/*----      LOCAL VARIABLES    -------------------------*/
static Boolean            V_KEEP_FWD_BKWD_FOR_PRUNING ; /*  = _KEEP_FWD_BKWD_FOR_PRUNING; */
static ProbDomain         V_BI_RATIO          ;/* = _BI_RATIO; */
static ProbDomain         V_BI_RATIO_UNKNOWNS ;/* _BI_RATIO_UNKNOWNS;*/
static enum _TAGGING_TYPE _BI_TAGGING_VERSION = _LOCAL_TAGGING;
static Boolean            V_PRUNE_ALL_ENTRIES = _PRUNE_ALL_ENTRIES;
/*
*/
/*--------- CONSTANTS ---- CONSTANTS -------------------*/
#define _UNSEEN_PROB_USUAL      ((ProbDomain) SumNutralConst)
#define _UNSEEN_PROB_SMOOTHED      ((ProbDomain) SumNutralConst)
/* The non-terminal number of a POS-TAG that precedes every other POS-TAG with probability 1.0 */
#define _NO_COND_NT_NUM  -2
/********************************************************************************************/
/* if _FIXED_MINIMUM_RATIO  is set true then this results in speedy but risky tagging       */
#define _FIXED_MINIMUM_RATIO      false

void Init_V_RATIOS()
{if (_FIXED_MINIMUM_RATIO == true) 
     {V_BI_RATIO  = _LB_RATIO; V_BI_RATIO_UNKNOWNS = _LB_RATIO;}
 else {V_BI_RATIO = _BI_RATIO; V_BI_RATIO_UNKNOWNS = _BI_RATIO_UNKNOWNS;}
}

/* returns:  back-off failed ? (cause there is no context leftover) */
Boolean BackOffOnWindow(int *l_win, int *r_win)
{if (*l_win > 0) *l_win = (*l_win) - 1;
 else if (*r_win > 0) *r_win = *r_win -1;
      else return true;
 return false;
}
/***************/
Boolean LARGE_ENTRIES(TableType TAB, int start, int end)
{int i; Boolean RESULT = false; EntryPtr CuEPtr;

 for (i=start; i < end; i++) 
  {CuEPtr = ENTRY_Of(TAB, i, i+1);
   if (SetSizeEnded(*CuEPtr) > _UB_ITEMSNUM_PER_ENTRY) {RESULT = true; break;}
  }
 return RESULT;
}
Boolean TAG_THIS_WORD(int i)
{if (_TAG_ONLY_UNKNOWN == false) return true;
 else if (strstr(TName(S[i]),UNKNOWNSYMwo) != NULL) /* is it an unknown word ? */
        return true;
      else return false;
}

/********************************************************************************************/
/* Pruning the least-probable POS-TAGS                                             **********/
void PrunePoSTagsByMax(TableType TAB, int start, int length, ProbDomain MaxSeqProb)
{int i; ProbDomain TempRatio; enum VERSION_TYPE TEMP = _VERSION ; EntryPtr CuEPtr; Boolean tempB;
 Boolean B_UNKNOWN ; int NUM_OF_ITEMS; Boolean TempInternRed;
  void Q_UNKNOWN_WD(ItemTree I)
   {if (I == NULL) ;
    else if (I->Transition != NULL) if (!strcmp((I->Transition)->Rule, UNKNOWNSYM)) B_UNKNOWN = true;
   }

 _VERSION = BEAM_THRESH;  TempInternRed = ValueOfInternRedDerF(); SetValueOfInterRedDF(true);
 TempRatio = V_R_PRUNE_RATIO;  V_R_PRUNE_RATIO = V_BI_RATIO; 
 tempB = _PriorsExist; _PriorsExist = false;

 for (i=start; i < start+length; i++) 
  {CuEPtr = ENTRY_Of(TAB, i, i+1);
   B_UNKNOWN = false; NUM_OF_ITEMS = 0;
   SetsMapEnded((*CuEPtr), (void *) &Q_UNKNOWN_WD);
    /* if unknown-entry  or huge entries are pruned firstly much faster */
   if ((B_UNKNOWN == true) || (SetSizeEnded(*CuEPtr) >= _LB_LARGE_ENTRY_SIZE )) V_R_PRUNE_RATIO = V_BI_RATIO_UNKNOWNS; 
   else V_R_PRUNE_RATIO = V_BI_RATIO;
   if ((V_PRUNE_ALL_ENTRIES == true) || (LARGE_ENTRIES(TAB, i, i+1) == true))
      {/* fprintf(stdout, "pruning [%d, %d] with MAX  %6.6e\n", i, i+1, MaxSeqProb); */
       PruneEntryI(TAB, i, i+1, MaxSeqProb, MultNutralConst, true, false);
      }
  }

 V_R_PRUNE_RATIO = TempRatio; _VERSION = TEMP; _PriorsExist = tempB; SetValueOfInterRedDF(TempInternRed);  
}
/********************************************************************************************/
/* lexicalized names consist of  originalname[-head[-rest]] where head must be [a-z][a-z]*  */
char *ExtractOrigName(char *Name)
{static char TEMP[SymLength]; char *temp;
 if (_EXTENSIONS_IN_POSTAGS == false) return Name;
 temp = strchr(Name,'-');
 while (temp != NULL) {if (islower(temp[1]) == 0) temp = strchr(temp+1,'-'); else break;} /* temp either NULL or pointing to -head-rest */
 if (temp == NULL) strcpy(TEMP, Name);
 else {strncpy(TEMP, Name, strlen(Name) - strlen(temp)); TEMP[strlen(Name) - strlen(temp)] = '\0';}
 /* PRS(Name); PRS("  "); PRS(TEMP); PRS("\n");  */
 return TEMP;
}
/* return the unigram probability of NonT  */
RDomain UniGramRuleNum(NTDomain NonT)
{char TEMPrhs1[SymLength]; char RHS1[SymLength];  
 strcpy(RHS1, _VOID_PREFIX);  /* adding "xxx" prefix */
 strcpy(TEMPrhs1, ExtractOrigName(Name(NonT))); 

 if ( (strcmp(TEMPrhs1, START_SYM)) && (strcmp(TEMPrhs1, STOP_SYM)) ) strcat(RHS1, TEMPrhs1); 
 else strcpy(RHS1, TEMPrhs1); /* xxxstart has an xxx*/

 if (!strcmp(TEMPrhs1, UNVALID_SYM)) 
   {fprintf(stderr, "Warning: in UniGramRuleNum: %s \n",TEMPrhs1);}
 
 /* printf("%s  ",RHS1); PRI(RNumOfNT_ByRHS1(_UNIGRAM_SYM, RHS1, UNVALID_SYM, _Unary)); PRS("\n"); */
 return (RNumOfNT_ByRHS1(_UNIGRAM_SYM, RHS1, UNVALID_SYM, _Unary));
}
/* return the prob P( <ConditioningNT,NonT> | ConditioningNT)  */
RDomain BiGramRuleNum(NTDomain ConditioningNT, NTDomain NonT)
{char TEMPrhs1[SymLength]; char TEMPrhs2[SymLength]; char RHS1[SymLength]; char RHS2[SymLength]; 
 strcpy(RHS1, _VOID_PREFIX); strcpy(RHS2, _VOID_PREFIX);  /* adding "xxx" prefix */
 strcpy(TEMPrhs1, ExtractOrigName(Name(ConditioningNT))); strcpy(TEMPrhs2, ExtractOrigName(Name(NonT)));

 if ( (strcmp(TEMPrhs1, START_SYM)) && (strcmp(TEMPrhs1, STOP_SYM)) ) strcat(RHS1, TEMPrhs1); 
 else strcpy(RHS1, TEMPrhs1); /* xxxstart has an xxx*/
 if ( (strcmp(TEMPrhs2, START_SYM)) && (strcmp(TEMPrhs2, STOP_SYM)) ) strcat(RHS2, TEMPrhs2);
 else strcpy(RHS2, TEMPrhs2); /* xxxstart has an xxx*/

 if ((!strcmp(TEMPrhs1, UNVALID_SYM)) || (!strcmp(TEMPrhs2, UNVALID_SYM))) 
                      {fprintf(stderr, "Err1: in BiGramRuleNum: %s %s\n",TEMPrhs1,TEMPrhs2);exit(1);}

 
 /* printf("%s %s  ",RHS1,RHS2); PRI(RNumOfNT_ByRHS1(_BIGRAM_SYM, RHS1, RHS2, _Binary)); PRS("\n"); */
 return (RNumOfNT_ByRHS1(_BIGRAM_SYM, RHS1, RHS2, _Binary));
}
/*
**
*/
ProbDomain Bigram_ProbOf(NTDomain ConditioningNT, NTDomain NonT)
{ProbDomain RESULT = MaxNutralConst; RDomain Bi_RNUM = UNVALID_RNUM; RDomain Uni_RNUM = UNVALID_RNUM;

 if ( (ConditioningNT == UNV_START_SYMNUM) || (NonT == UNV_STOP_SYMNUM) ) 
      ConditioningNT = _NO_COND_NT_NUM;   /* no start-bigrams or no stop-bigrams in grammar return prob 1.0 */

 if (ConditioningNT == _NO_COND_NT_NUM) {RESULT = MultNutralConst;} /* one */
 else {Bi_RNUM = BiGramRuleNum(ConditioningNT, NonT); 
      if (Bi_RNUM == UNVALID_RNUM) 
       {Uni_RNUM = UniGramRuleNum(NonT);
        if (Uni_RNUM == UNVALID_RNUM) RESULT = _UNSEEN_PROB_USUAL;
        else RESULT = Prob_From_R(UniGramRuleNum(NonT), _Unary, 0, ROOT_enum);
       }
      else RESULT = Prob_From_R(Bi_RNUM, _Binary, 0, ROOT_enum);
      }
 /* PRB(RESULT); PRS("   "); ShowItem(Bi_RNUM, _Binary, mid); PRS("\n"); */
 return RESULT;
}
/*************************************************************************************************/
void PRTabs(int length)
{int i; for (i=0; i<length; i++) PRS("_____");
}
/*-----------------------------------------*/
/* see RefMAXforSUM                        */
ProbDomain BackwardProb(TableType TAB, int start, int end,
                           NTDomain Prec_NT, ProbDomain ForwProbOfPrecSeq)
{EntryPtr CuEPtr ; ProbDomain MaxBackWD_For_PrecNT = MaxNutralConst; 
      void ComputeNodeProb(ItemTree I)
       {Boolean VOIDB; ProbDomain BI_DFP_PROB; ProbDomain TEMP;
        NTDomain LHS = LHS_OfItem(I); DerFPtr DFP = ((ItemCPtr) I->DerForest)->Roots;
        ProbDomain CuBACKWD_P = MaxNutralConst; ProbDomain BiProb = Bigram_ProbOf(Prec_NT, LHS);
        Boolean ZERO = true;

        if (I->Touched == false) 
           {I->Touched = true;  I->FORWARD_P = MaxNutralConst; I->FWD_BKWD_P = MaxNutralConst;}

        if ( (MaxProbs(BiProb, SumNutralConst, &VOIDB)) != SumNutralConst)
           {BI_DFP_PROB = MultProbs(DFP->MPD_Prob, BiProb);
            I->FORWARD_P = MaxProbs(I->FORWARD_P, MultProbs(BI_DFP_PROB, ForwProbOfPrecSeq), &VOIDB);
            TEMP = BackwardProb(TAB, start+1, end, LHS, I->FORWARD_P);
            I->FWD_BKWD_P = MultProbs(I->FORWARD_P, TEMP);
            CuBACKWD_P = MultProbs(TEMP, BI_DFP_PROB);
            ZERO = false;
           }
        else CuBACKWD_P = MaxNutralConst; 
        
        MaxBackWD_For_PrecNT = MaxProbs(MaxBackWD_For_PrecNT, CuBACKWD_P, &VOIDB);
        /* for debugging use reftoolFWDBKWD */
       }

 if (start < end)
  {CuEPtr = ENTRY_Of(TAB, start, start+1);
   SetsMapEnded((*CuEPtr), (void *) &ComputeNodeProb);
  }
 else if (start == end)
        if (end == _sen_length) /* add the stop-symbol probability */
           MaxBackWD_For_PrecNT = MultProbs(ForwProbOfPrecSeq, (Bigram_ProbOf(Prec_NT, _NumOfStopSym)));
        else MaxBackWD_For_PrecNT = MultNutralConst; /* return 1.0 */
      else {fprintf(stderr, "Err ForwardBackwardI: unvalid entry\n"); exit(1);}

 return MaxBackWD_For_PrecNT;
}
/*
**
*/
ProbDomain ForwardBackward(TableType TAB, int start, int end,
                           NTDomain Prec_NT, ProbDomain ForwProbOfPrecSeq)
{
 return (MultProbs((BackwardProb(TAB, start, end, Prec_NT, ForwProbOfPrecSeq)), ForwProbOfPrecSeq));
}
/*-------------------------------------------------------------------------------------------*/
void SwitchProbs(TableType TAB, int start, int length, ProbDomain MaxSeqProb)
{EntryPtr CuEPtr; int i; Boolean FOUNDinENTRY = false;
  void SwitchNodeProb(ItemTree I)
   {DerFPtr DFP; ItemCPtr ICP;
    if (I != NULL)
     {ICP = (ItemCPtr) I->DerForest; 
      if (ICP != NULL)
        {DFP = ICP->Roots; if (DFP != NULL) {DFP->MPD_Prob = I->FWD_BKWD_P;} }
      if (((float) MaxSeqProb) == ((float) I->FWD_BKWD_P) ) {FOUNDinENTRY = true;}
      else ;
      /* PRI(i); PRI(i+1); PRS(":"); PRBS(MaxSeqProb); PRS(" "); PRBS(I->FWD_BKWD_P); PRS("\n"); */
     } /* if I != NULL */
    }
 
 for (i=start; i < (start+length); i++)
  {CuEPtr = ENTRY_Of(TAB, i, i+1); 
     if (MaxSeqProb == MaxNutralConst) FOUNDinENTRY = true;
     else FOUNDinENTRY = false;
   SetsMapEnded(*CuEPtr, (void *) &SwitchNodeProb);
   if (FOUNDinENTRY == false) 
    {fprintf(stderr, "Err SwitchProbs: MaxSeqProb is not in entry [%d, %d]\n",i, i+1); exit(1);}
  }                                             
 /* PRS("\n=========================\n"); */
}
/*-----------------------------------*/
/* AfterPruning == true implies that the entry has been pruned; */
void ResetProbsOfEntries(TableType TABLE, int start, int end, int sen_length, Boolean AfterPruning)
{int j; EntryPtr EPtr; EntryType ENT; Boolean NonEmptyEntry = false;
  ItemTree ResetProbsOfI(ItemTree I) 
   {if ((Negate(AfterPruning)==true) || ( ((NonEmptyRootsDerForest(I)) == true) && (I->Touched == true)) ) 
     {FreeICPtr((ItemCPtr) I->DerForest); I->DerForest = NULL;
      GetICPOfItem(I, (ItemCPtr) I->DerForest); I->Touched = false; 
      I->FORWARD_P = MaxNutralConst; I->FWD_BKWD_P = MaxNutralConst; 
      UpdateEntry(TABLE, I, j, j+1);        
      NonEmptyEntry = true;
     }
    else (FreeItem(I)); 
    return NULL;
   }

 for (j=start; j < end; j++) 
  {EPtr = ENTRY_Of(TABLE,j,j+1); ENT = *EPtr; *EPtr = NULL;
   NewEntry(TABLE, j, j+1, sen_length); NonEmptyEntry =  false;
   XSetsMapEnded(ENT, &ResetProbsOfI, true);
   FreeSet(ENT);  
   if (NonEmptyEntry == false) 
     {fprintf(stderr,"Err: An Empty-Entry [%d, %d] was detected...\n", j, j+1); exit(1);}
  }
}
/******************************************************************************************/
/* LOCAL TAGGING LOCAL TAGGING  LOCAL TAGGING LOCAL TAGGING                               */
/* Compute the bigram probabilities for entry  [i,i+1] and return the maximum probability */
ProbDomain MaxLocalBiGram(TableType TAB, int start, int end, int length)
{NTDomain L_SYM_NUM; 

 if (start == 0) L_SYM_NUM = _NumOfStartSym; else L_SYM_NUM = _NO_COND_NT_NUM;
 
 return (ForwardBackward(TAB, start, end, L_SYM_NUM, MultNutralConst));
}
/*-----------------------------------*/
/* LOCAL, PER ENTRY node bigram computation: end_t is an extension for word-graphs */
void Local_Bi_POS_TAGGING_Entry(TableType TAB, int length, int i, int end_t)
{int r_win, l_win; ProbDomain CuMax = MaxNutralConst; int start; int end; Boolean GO_ON;

 if ((LARGE_ENTRIES(TAB, i, i+1) == true) && (TAG_THIS_WORD(i) == true)) 
   {/* fprintf(stderr,"%s %d \n", TName(S[i]), i); */
    CuMax = MaxNutralConst; r_win = R_WINDOW; l_win = L_WINDOW; GO_ON = false;
    while ((CuMax == MaxNutralConst) && (GO_ON == false )) {
      start = MAXOF(0, (i - l_win)); end = MINOF(length, ((i+1) + r_win));
      CuMax = MaxLocalBiGram(TAB, start, end, length); 
      /* fprintf(stderr,"[%d, %d]  %6.6e   (%d <--> %d)\n",i,i+1,CuMax,start,end); */
      if (CuMax == MaxNutralConst) 
        {/* fprintf(stderr, "Backing-off...\n"); */
         GO_ON = BackOffOnWindow(&l_win, &r_win);
         if (GO_ON == false) ResetProbsOfEntries(TAB, start, end, length, false);}
     } /* while */
    if (CuMax == MaxNutralConst) {fprintf(stderr,"Err: backoff failed in tagging\n");exit(1);}
    SwitchProbs(TAB, i, 1, CuMax); 
    PrunePoSTagsByMax(TAB, i, 1, CuMax); 
    ResetProbsOfEntries(TAB, start, end, length, true); 
   }
   /* fprintf(stderr,"[%d, %d]		%d\n", i, i+1, SetSizeEnded(*(ENTRY_Of(TAB, i, i+1)))); */
}
/*
**
*/
void Local_Bi_POS_TAGGING(TableType TAB, int length)
{int i; int j; int r_win, l_win; 
  void TagTransitionFWD(int start_t, int end_t, int word_seq_num, WordList transition)
    {Local_Bi_POS_TAGGING_Entry(TAB, length, start_t, end_t);}

  MapOnWGsSetOfEntries((void *) &TagTransitionFWD);
  if (_DO_BKWD_PHASE == true) BkwdsMapOnWGsSetOfEntries((void *) &TagTransitionFWD);
}
/*-----------------------------------*/
void Bi_POS_TAGGING(TableType TAB, int length)
{int i; ProbDomain MaxSeqProb; 

 if ((TOO_LARGE_Thresholds() == false) && (_DisambiguateB == true) )
 switch (_BI_TAGGING_VERSION) {
   case _GLOBAL_TAGGING :
          MaxSeqProb = ForwardBackward(TAB, 0, length, _NumOfStartSym, MultNutralConst);
          SwitchProbs(TAB, 0, length, MaxSeqProb); /* just because PruneEntryI does it with MPD_Prob instead */
          PrunePoSTagsByMax(TAB, 0, length, MaxSeqProb);
          break;
   case _LOCAL_TAGGING : Local_Bi_POS_TAGGING(TAB, length);
          break;
 } /* switch */
}
/**********************************************************************/

void MoveItems_NEDF(TableType Source, TableType Target, int length)
{EntryPtr CuEPtr; int i; int NUMOFITEMS =0;
       ItemTree MvItem(ItemTree I)
        {if ( ((NonEmptyRootsDerForest(I)) == true) && (I->Touched == true))
            {FreeICPtr((ItemCPtr) I->DerForest); I->DerForest = NULL;
             GetICPOfItem(I, (ItemCPtr) I->DerForest); I->Touched = false; 
             UpdateEntry(Target, I, i, i+1);
             NUMOFITEMS++;
            }
         else  (FreeItem(I)); 
         return NULL; 
        }

 for (i=0; i < length; i++) 
   { NUMOFITEMS =0;
     CuEPtr = ENTRY_Of(Source, i, i+1);  XSetsMapEnded(*CuEPtr, &MvItem, true); 
     /* PRS("[");PRI(i); PRS(", ");PRI(i+1);PRS("]");PRI(NUMOFITEMS);PRS("\n"); */
   }
}
/*------------------*/
void InitLexicalProbs(TableType TAB, int length, DuoPtr Duo)
{int i; Boolean TempSemi = Semi_Interleaved;
 Semi_Interleaved = true;
 for (i=0; i < length; i++) CompDFEntrySemiI(TAB, i, i+1, Duo, true, false, false);
 Semi_Interleaved = TempSemi;
}
/*-----------------------------------*/
/* only for the interleaved version  */
TableType BiGramPosTaggingBasic(TableType TAB, int length, DuoPtr Duo)
{TableType NewTable = TAB; 
 if ((_DisambiguateB == true) && (_BIGRAM_PRUNE == true) && 
     (_BIGRAM_SYM_NUM != UNVALID_SYMNUM) && (LARGE_ENTRIES(TAB,0,length) == true))
    {int i;
     InitLexicalProbs(TAB, length, Duo);
     Bi_POS_TAGGING(TAB, length); 
     if (_BI_TAGGING_VERSION == _GLOBAL_TAGGING)
       {NewTable = CrTable(length); MoveItems_NEDF(TAB, NewTable, length); FreeTable(TAB, length);} 
     else NewTable = TAB; /* PrintTable(NewTable, length); */
    }
 else NewTable = TAB;
 return NewTable;
}
/****************/
extern void Show_POSTAGS(TableType TAB, int length)  ;

TableType BiGramPosTagging(TableType TAB, int length, DuoPtr Duo)
{ProbDomain B_TEMP = V_BI_RATIO ; ProbDomain B_TEMP_UNKNOWNS = V_BI_RATIO_UNKNOWNS ; 

 Boolean TEMP_B  = _TAGGING_PHASE; _TAGGING_PHASE = true;

 Init_V_RATIOS(); V_KEEP_FWD_BKWD_FOR_PRUNING = _KEEP_FWD_BKWD_FOR_PRUNING; 
 
 if ((_DisambiguateB == true) && (_BIGRAM_PRUNE == true) && (_BIGRAM_SYM_NUM != UNVALID_SYMNUM))
 {
  if (_DO_FULL_SENTENCE_TAGGING == false) 
    {fprintf(stderr, "  (tagging ..."); 
     while ( (LARGE_ENTRIES(TAB,0,length) == true) && (V_BI_RATIO >= _LB_RATIO) && (V_BI_RATIO_UNKNOWNS >= _LB_RATIO)) 
      {_BI_TAGGING_VERSION = _LOCAL_TAGGING;
       TAB = BiGramPosTaggingBasic(TAB, length, Duo);
       V_BI_RATIO = V_BI_RATIO - _STEP_RATIO;
       V_BI_RATIO_UNKNOWNS = V_BI_RATIO_UNKNOWNS - _STEP_RATIO;
      } /* while */
     V_BI_RATIO  = B_TEMP; V_BI_RATIO_UNKNOWNS = B_TEMP_UNKNOWNS ;
    } /* local tagging */
  else  /* full sentence tagging */
   if (_KEEP_FWD_BKWD_FOR_PRUNING == true) /* the final step of global thresholding */
    {_BI_TAGGING_VERSION = _GLOBAL_TAGGING; V_PRUNE_ALL_ENTRIES  = true ; 
     TAB = BiGramPosTaggingBasic(TAB, length, Duo); 
     V_PRUNE_ALL_ENTRIES = _PRUNE_ALL_ENTRIES;
    }
   fprintf(stderr, " finished tagging)\n"); 
 } /* should we tag ? */
 if (_Show_PosTags_global == true) { Show_POSTAGS(TAB, length); exit(0);}
 _TAGGING_PHASE = TEMP_B;
 return TAB;
}
/****************************************************************************************************/
/****************************************************************************************************/
void ShowPTsEntry(EntryType Set, int i, int j)
{ void PrintLHS(ItemTree I)
	{if (I->RT==_Term) {PRI(i+1); PRI(j+1); PRS(" "); AppToItem(I, (void *) &ShowLHS); PRS("/"); AppToItem(I, (void *) &ShowRHS1); PRS("    ");}}
 SetsMapEnded(Set, &PrintLHS);
}
void Show_POSTAGS(TableType TAB, int length)
{int k, j; EntryPtr EPtr;
 for (k = 0; k < length; ++k)
   {EPtr = ENTRY_Of(TAB, k, k+1); ShowPTsEntry(*EPtr, k, k+1); }
 PRS(".\n");
}
/****************************************************************************************************/
/****************************************************************************************************/
/*
References:

 RefMAXforSUM:
  We use here Sum_Prob t hold the maximum of the forward probabilities of the current node.
  MPD_Prob still holds the node's probability as initialized by the parser
*/
/* TotallyFreeEmptyDFItems(TAB, i, i+1, true);  free the items that pruned */
/* FreeInsideOfItems(TAB, i, i+1, true);   Unnecessary free the derivation-forests */


/****
TOOLS FOR DEBUGGING

  reftoolFWDBKWD

        if ((1==0) && (ZERO == false)) {
        PRTabs(start); PRI(start); PRS("      "); PRI(start+1); PRS("\n");
        PRTabs(start); PRS(" BI_PROB  FORWARD_P   TEMP   FWD_BKWD  CuBACKWD_P  RESULT\n");
        PRTabs(start);
          PRBS(BI_DFP_PROB); PRS(" ");
          PRBS(I->FORWARD_P); PRS(" ");
          PRBS(TEMP); PRS(" ");
          PRBS(I->FWD_BKWD_P); PRS(" ");
          PRBS(CuBACKWD_P); PRS(" ");
          PRBS(MaxBackWD_For_PrecNT); PRS("\n");
        }
 if (1==0) 
   {PRTabs(start); PRI(start); PRS(" ----- "); PRI(start+1); PRS("  ("); PRI(start);PRI(end); PRS(")  \n");}
 if (1==0) 
  {PRTabs(start); PRS("===================================================\n");}
***/
