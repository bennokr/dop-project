#include "./ALL.h"


/* n is the length of the sentence */
/* S is a pointer to integers     */
void Which_Word(TDomain *S, int n)
{int i;
 for (i=0; (i < n); i++)
   if ((*(S+i)) == -1) printf("\n Word %d is not in lexicon \n", i+1);
}
