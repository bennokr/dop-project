#include "./ALL.h"
#include "G12G2.h"
#include "ExtractChunks.h"
#include "./InsideOutside.h"

/* if we want that the second grammar completes the space of the first: set the following to true */
#define _USE_OUTSIDE_FIRST_PHASE false
#define _COMPLETE_CHUNKS false

Boolean _Preserve_Probs_From_First = false;

extern void ShowParseSp(Boolean PASSFassume, PtrList LstOfChunkRs, PtrList RedLstOfChunkRs);
extern Boolean _APPLY_PRUNE;
extern Boolean _ShowChunks; 
/***********/
extern char CodeBINName1[]; 
extern char ChPlBINName1[]; 
extern char CodeBINName2[];
extern char ChPlBINName2[]; 
/**************************/
extern Boolean IsSentence();
extern Boolean IsSenAndCovered(int i, int j, int n);
extern TableType TAB;
extern void CompactEntry(TableType TABLE, int i, int j, int sen_length);
/**************************/
Entry_State StateOfEntry(TableType Tab, int i, int j)
{EntryPtr EPtr = ENTRY_Of(Tab,i,j);
 return ((*EPtr)->IsClosed);
}

void SetEntryState(TableType Tab, int i, int j, Entry_State ST)
{EntryPtr EPtr = ENTRY_Of(Tab, i,j);
 (*EPtr)->IsClosed = ST;  
}
void ResetEntry(EntryPtr EPtr)
{  ItemTree ResetItem(ItemTree I)
    {if (I != NULL)
      if (I->AlreadyCopied == true)
       {FreeDerForestOfItem(I); I->DerForest = NULL; I->Valid = false; 
        I->PseudoValid = false; I->AlreadyCopied = false; I->Touched = false; I->Num_OfParses = 0;
        if (_Preserve_Probs_From_First == false) {I->FORWARD_P = MaxNutralConst; I->FWD_BKWD_P = MaxNutralConst;}
       }
      else I = FreeItem(I);
     else I = NULL;
     return I;
    }
 if (EPtr != NULL) XSetsMap(*EPtr, &ResetItem);
}
void ResetTable(TableType TAB, int n)
{  void CleanEntry(int i, int j, EntryPtr ThisEPtr)
    {Entry_State TempC = StateOfEntry(TAB, i, j);
     ResetEntry(ThisEPtr); CompactEntry(TAB, i, j, n); SetEntryState(TAB, i, j, TempC);
    }

 MapOnTableEntries(TAB, n, (void *) &CleanEntry);
}

/*********************************/
/* This version does not prune: the pruning takes place after computing the DFs of every item of the same level */
/* See  CompDFEntrySemiI: the Active_Grammar_Number choice. The reason for the difference between the first grammar */
/* and the second grammar is: for the first grammar, the pruning takes place during building the entry; for the second */
/* the entry is assume already built and thus when building the DFs, we can't compute all DFs and then prune them */
/* since this implies that the MPD_PtrL/R will be referring to DFs that are pruned. Therefore, for the second grammar */
/* computing the DFs and pruning them has to take place at every level separately and in increasing level-order     */
/**/
EntryPtr Do_Interleaved_Sknd(TableType TAB, int i, int j, DuoPtr Duo, Boolean Ended, Boolean PruneAlso, Boolean DoUnaries)
{if ((Semi_Interleaved == true) && (_DisambiguateB == true))
    CompDFEntrySemiI(TAB, i, j, Duo, Ended, DoUnaries, PruneAlso);
 return (ENTRY_Of(TAB, i, j));
}
/*********************************/
void InitGrammarNumE(int GNum) {InitGrammarNum(GNum); }
void UseInternGrammar(int GramNumber) {InitGrammarNumE(GramNumber);}

void UseGrammar(int GramNumber)
{/* fprintf(stderr,"(initializing ..."); */
 if (GramNumber == 1)
   {if ((fpCodes = fopen(CodeBINName1, "r")) == NULL) {printf("Can't open %s\n", CodeBINName1); exit(1);}
    if ((fpChsPl = fopen(ChPlBINName1, "r")) == NULL) {printf("Can't open %s\n", ChPlBINName1); exit(1);}
   }
 else if (GramNumber == 2)
   {if ((fpCodes = fopen(CodeBINName2, "r")) == NULL) {printf("Can't open %s\n", CodeBINName2); exit(1);}
    if ((fpChsPl = fopen(ChPlBINName2, "r")) == NULL) {printf("Can't open %s\n", ChPlBINName2); exit(1);}
   }
 else {fprintf(stderr,"Err: GNum is not 1 or 2 in Init\n");exit(1);}
 InitGrammarNumE(GramNumber);      /* initializing grammar   */
 Init_Various_PriorProbs_Tables(); /* initializing prior probabilities */
 /* fprintf(stderr,"), "); fflush(stderr); */
}
void CloseGrammar(int GramNumber, DuoPtr Duo)
{fclose(fpCodes); fclose(fpChsPl); ResetBuffering(); Duo = CleanDuo(Duo); /* initializing the globals */
}
void CloseExternGrammar(int GramNumber)
{fclose(fpCodes); fclose(fpChsPl);  ResetBuffering(); 
}
/*****************************************************/
/* set the global RedDerForest to value and return the original value of RedDerForest */
extern Boolean RedDerForest;
Boolean SetRedDerF(Boolean value)
{Boolean Temp = RedDerForest; RedDerForest = value; return Temp;
}
/**********************************************************************************************************/
void CLOSED_Between(TableType NewTable, int i, int j, int length, Boolean start)
{ void CLOSEDunder(int k)
    {CLOSED_Between(NewTable, i , k, length, false); CLOSED_Between(NewTable, k , j, length, false);}
   
 if ((StateOfEntry(NewTable,i, j)) != CLOSED_ENTRY) MapBetweenIJ(i, j, (void *) &CLOSEDunder); 

 if ((start == false) || (IsSenAndCovered(i, j, length) == true)) SetEntryState(NewTable, i,j,CLOSED_ENTRY);
 else if ((StateOfEntry(NewTable,i, j)) != CLOSED_ENTRY) /* entry not closed by another chunk ? */
       if (_COMPLETE_CHUNKS == true) SetEntryState(NewTable, i,j, TO_BE_COMPLETED);
       else  SetEntryState(NewTable, i,j, CLOSED_ENTRY);
}
/*------
 given item, a root of chunks, and NewTable: mark all entries in NewTable which
 are within chunks under item as closed. 
*/
void MarkWholeChunks(ItemTree item, TableType NewTable, int length)
{CLOSED_Between(NewTable, item->i, item->j, length, true); /* mark entries under chunks in NewTable as closed */
}
/*------
   For every root of chunks :
   The entries in NewTable within the chunks are marked closed 
   (not allowed to be Init/Deduced/Completed using the second grammar unless explicitly wanted).
*/
void TransferChunks(PtrList LstOfChunkRs, TableType NewTable, int length)
{void TransI(void *VI)
  {RDomain RNUM; ItemTree item = (ItemTree) VI;
   if (item == NULL) {fprintf(stderr, "Err: a NULL rule found\n"); exit(1); }
   MarkWholeChunks(item, NewTable, length);     /* Mark Entries intern to chunks in table as closed */
  }
 PListMap(LstOfChunkRs, (void *) &TransI);
}
/********************************************************************************************************/
/* fp, takes an ItemTree, is applied to all items in AddedBy of item */
/* applying to right as well as left AddedBy lists                   */
void MapOnAllAddedBy(ItemTree item, void (* fp)())
{ void DoRight(void *VI)
   {(*fp)((ItemTree) VI);}
  void DoAddedByLeft(PtrList LstOfAddedBy)
   {if (LstOfAddedBy != NULL)
      {(*fp)((ItemTree) LstOfAddedBy->Ptr);
       PListMap((PtrList) LstOfAddedBy->Data, (void *) &DoRight);
      }
   }
 if (item != NULL) PDListMap(item->AddedBy, (void *) &DoAddedByLeft);
}
/***********************************************************************************************************/
/* item is the root of chunks in entry i,j of the original table.
   The function returns a list of all root items of chunks.
*/

PtrList GetRsChunksOfI(ItemTree item, PtrList ListOfChnkRs)
{if ((_COMPLETE_CHUNKS == true) || (StartSymbolsItem(item) == true))
    return (EnterPStack((void *) item, ListOfChnkRs));
 else return ListOfChnkRs;
}
/**/
/* THETABLE is the original table, length is the length of the input, 
   Get the roots of chunks and return them as a list. We assume that RedDerForest=true here always !!!!
*/
PtrList GetChunksOfTHETABLE(TableType THETABLE, int length)
{int i,j,k; EntryPtr EPtr;PtrList RootsOfChunks; Boolean NonCombinedEntry = false;

  void MarkIf(ItemTree item)
   {ItemCPtr CP = ((ItemCPtr) item->DerForest); 
    if (CP != NULL)  if (CP->RootsSize > 0) RootsOfChunks = GetRsChunksOfI(item, RootsOfChunks); 
   }
  void GetFromEntry(int i, int j, EntryPtr EPtr)
   {SetsMapEnded(*EPtr, (void *) &MarkIf);               /* construct the list of roots */
   }

 RootsOfChunks = NULL;
 if (_COMPLETE_CHUNKS == true)
    MapOnTableEntries(THETABLE, length, (void *) &GetFromEntry); /* original code is in OrigPlace1 */
 else GetFromEntry(0, _sen_length, ENTRY_Of(THETABLE, 0, _sen_length)); /* in case we are not completing 1st garm-space*/
      /* RootsOfChunks = StartItemsList(THETABLE, length); */
 return RootsOfChunks;
}
/***********************************************************************************************************/
/* Transfer the parse-forest under item to THETABLE. If IsRoot is true
   then  item is a root of a chunk. 
*/
ItemTree TransChnksOfI(ItemTree item, TableType THETABLE,  Boolean IsRoot) 
{ItemTree I; Boolean TransferThis ; PtrList PLOfTempL;
    void TransRight(void *VI)
     {ItemTree TempR = NULL;
      if (((ItemTree) VI)->Valid == true) 
       {TempR = TransChnksOfI((ItemTree) VI, THETABLE, false);}
     }
    void TransChs(PtrList This)
     {ItemTree TempL; 
      if (This != NULL) {
        if (((ItemTree) This->Ptr)->Valid == true) 
         {TempL = TransChnksOfI((ItemTree) This->Ptr, THETABLE, false);
          if ( This->Data != NULL) PListMapRev((PtrList) This->Data, (void *) &TransRight);
         }
      }
     }

 if (item == NULL) {fprintf(stderr, "Err: item is null in ExtractChunks.c\n");exit(1);}

 if (item->AlreadyCopied == false)
  {
 item->OldRNum = item->RuleNo;
 item->RuleNo = TransFormRNum(item); 
 if (item->RuleNo  == UNVALID_RNUM) {fprintf(stderr,"Err in translation in TransChnksOfI\n"); exit(1);}

 TransferThis = ( (IsRoot == true) ? true : ((item->AlreadyCopied == false) ? true : false)); 
                             /* Efficiency: this item and the structure under it has been done already 
                                                if not Root and marked AlreadyCopied */
 item->AlreadyCopied = true;     /* mark original item as AlreadyCopied: for efficiency */ 
 if (TransferThis == true) PDListMapRev(item->AddedBy, (void *) &TransChs); /* transferes children */
  }
 return item;                                  /* return the ItemTree of item that is in THETABLE */
}
void TransInternOfChunks(PtrList LstOfChunkRs, TableType THETABLE, int length)
{
  void TransChnksOfR(void *VI)
   {ItemTree root = (ItemTree) VI;
    (TransChnksOfI(root, THETABLE, true)); /* true means it is a root */
   }
 PListMap(LstOfChunkRs, (void *) &TransChnksOfR);
}
/***********************************************************************************************************/
void  SenOrWG()
{if ((IsSentence()) == false) {PRS("tree(wordgraph,[]).\n");exit(1);}
 else {PRS("tree(sentence,[]).\n");exit(1);}
}
Boolean IsSenAndCovered(int i, int j, int n)
{if ((IsSentence()) == true) 
   if ((i==0) && (j==n)) {return true;}
   else return false;
 else return false; 
}
/***********************************************************************************************************/
extern FILE *fpCodes; extern FILE *fpChsPl; extern Boolean TakeProbOfTrans;

void ComputeOutsideProbs(TableType TAB, ParForest PARF, int length)
{if (_USE_OUTSIDE_FIRST_PHASE == true)
 if ((Semi_Interleaved == true) && (ParsingMethod == _BOTH_G)) 
  {_Preserve_Probs_From_First = true; ComputeOutsidePerItem(TAB, PARF, length);} 
}

PtrList PRE_PARSE(TableType *THETABLEPtr, TDomain *Sentence, int length, DuoPtr Duo)
{ParForest InternPARF = CrParF(); Boolean TempRedDF; PtrList Result =NULL; Boolean tempB;
 TableType THETABLE = *THETABLEPtr;

 TempRedDF = SetRedDerF(true);   /* set the reduction of derivation space on */
 
 /* SenOrWG();        TESTING sentence/wordgraph */

 THETABLE = PARSE(THETABLEPtr, Sentence, length, Duo); 
 if (_COMPLETE_CHUNKS == true) InternPARF = GenChunks(THETABLE, length); 
 else InternPARF = GenParF(THETABLE, length);
 FreeUnvalidItems(THETABLE, length); 

 ComputeOutsideProbs(THETABLE, InternPARF, length); /* compute avg outside probabilities from first grammar to improve pruning second grammar */

 /* now we recognize chunks (without) taking the probabilities of transitions into account */
 {/* tempB = TakeProbOfTrans ; TakeProbOfTrans = false; */
  CompDFTable(THETABLE,length, Duo); 
  /* TakeProbOfTrans = tempB; */
 }
 /* free InternPARF LATER */ /* ShowMPD_OfPF(InternPARF); */

 (SetRedDerF(TempRedDF));       /* return the original value of RedDerForest */
 
 Result = GetChunksOfTHETABLE(THETABLE, length);  /* get the roots of chunks */
 /* ShowParseSp(false, Result, Result); */
 *THETABLEPtr = THETABLE;

 return Result;
}
/**********/
void SupplementEntry(TableType THETABLE, int i, int j, int length, DuoPtr Duo, Boolean CompleteIT)
{Boolean Temp_B; Boolean B; Boolean Semi_Temp; 
 if (CompleteIT == true) {
    Semi_Temp = Semi_Interleaved; Semi_Interleaved = false;
    B = Complete(THETABLE, i, j, Duo); /* completing the items' set without DF-computation */
    Semi_Interleaved = Semi_Temp;
 }
 if (1==0) {PRS("\nEntry");PRI(i);PRI(j);PRS("\n");} 
 Temp_B = _REMOVE_PRUNED_ITEMS; _REMOVE_PRUNED_ITEMS = false; /* second phase does not remove items from table */
 (Do_Interleaved_Sknd(THETABLE, i, j, Duo, true, true, false)); /* only basic ended items */
 (Do_Interleaved_Sknd(THETABLE, i, j, Duo, true,  true, true)); /* only unary ended items */
 (Do_Interleaved_Sknd(THETABLE, i, j, Duo, false, true, false)); /* un-ended items only  */
 _REMOVE_PRUNED_ITEMS = Temp_B;
 if (1==0) PRS("==================\n"); 
}
/**********/
extern TableType InitWG(TableType TAB, TDomain *S, int length, DuoPtr Duo);
 
TableType InitTermEntries(TableType THETABLE, TDomain *Sentence, int length, DuoPtr Duo)
{int i; Boolean B;
  void DoEntry(int start, int end, int word_serial_num, WordList transition) 
   {
    if (start == 0) fprintf(stderr, "<%d",end-start);
    switch ((StateOfEntry(THETABLE, start, end))) {
    case      OPEN_ENTRY: fprintf(stderr, "Err: impossible (InitTermEntries) %d %d \n", start, end); exit(1);
                     break;
    case TO_BE_COMPLETED: SupplementEntry(THETABLE, start, end, length, Duo, true);
                     break;
    case    CLOSED_ENTRY: SupplementEntry(THETABLE, start, end, length, Duo, false);
                     break;
    } /* switch */
    if (end == length) fprintf(stderr, ">");
    fflush(stderr);
   }

 if (ParsingMethod != _BOTH_G) {fprintf(stderr,"Err: Assuming double-parsing here !!\n");exit(1);}
 else MapOnWGsSetOfEntries((void *) &DoEntry);
 return THETABLE;
}
/**********/
TableType PARSE_AGAIN(TableType THETABLE, TDomain *Sentence, int length, DuoPtr Duo)
{  void ParseEntry(int i, int j, EntryPtr EPtr)
       {Boolean B; 
        if ((j-i) > 1) /* doing only deduced entries - InitWG does the word-entries */
         {if (1==0) 
            {PrintEntry(THETABLE, i, j); PRS("\n---------- NOW COMPUTING AND PRUNING IT -----------------\n");}

          if (i==0) fprintf(stderr, "<%d", j-i);
          switch ((StateOfEntry(THETABLE, i, j))) {
            case      OPEN_ENTRY:
                           fprintf(stderr,"Err: PARSE_AGAIN: not possible value (ParsingMethod != _BOTH_G)\n");exit(1);
                                  break;
            case TO_BE_COMPLETED: SupplementEntry(THETABLE, i, j, length, Duo, true);
                                  break;
            case    CLOSED_ENTRY: SupplementEntry(THETABLE, i, j, length, Duo, false);
                                  break;
          } /* switch */
          if (j==length) fprintf(stderr, ">", j-i);
         }
       }

 if (length > 0)
  {if (THETABLE == NULL) {fprintf(stderr,"Err: Create the CKY table first !!\n");exit(1);}
   else if (ParsingMethod != _BOTH_G) {THETABLE = PARSE(&THETABLE, Sentence, length, Duo);}
        else {THETABLE = InitTermEntries(THETABLE, Sentence, length, Duo); 
              MapOnTableEntries(THETABLE, length, (void *) &ParseEntry);
              fprintf(stderr, "      "); 
             } 
  }
 else EXIT(EMPTY);
 return THETABLE;
}
/***********************************************************************************************************/
/* EXTERNALS and globals */
extern TDomain *TagSentence(Sentence TheWG);
extern Boolean _DisambiguateB;
extern void PChItem(ItemTree item);
extern TDomain *TagUnknownWs(Sentence WG, TDomain *Sen); 
/************************/
/* Takes TheWG, fills Sentence by  tags of words, assigns to length the length of TheWG,
   Pre-Parses into an internal table and subsequently parses using the chunks into THETABLE
*/

void Double_PARSE(TableType *THETABLE, Sentence TheWG, TDomain **Tags, int length, ParForest *ParF, DuoPtr Duo)
{TDomain *InternTags = NULL; TableType InternTable=NULL; PtrList TheLstOfChunkRs = NULL; Boolean PASSFassume = false;

 *THETABLE = CrTable(length); InternTable = *THETABLE; 

                       /* PRE-PARSING  PHASE *********** using grammar 1 ***********/
 if (ParsingMethod == _BOTH_G) 
  {/* USING THE PARPAR ? */
   fprintf(stderr,"Parsing with the first grammar...      "); UseGrammar(1); 
   InternTags = TagSentence(TheWG); 
   if (ERROR == true)      /* there is an unknown word */
    {ERROR = false;        /* only for avoiding unknown words in a wordgraph */
     InternTags = TagUnknownWs(TheWG, InternTags); /*ERROR=true if "unknown_" is not there */
    }
   if ((ERROR == false) || (IsSentence() == false)) ; /* all words are known or a word-graph*/
   else { /* PRS("tree(XXXnonword,[]).\n"); */ EXIT(NONW);}

   TheLstOfChunkRs = PRE_PARSE(&InternTable, InternTags, length, Duo); 
   fprintf(stderr,"built parse-forest\n");
   

   _BIGRAM_PRUNE = false;  /* in double-parser: tagging only for first-phase */
   if (TheLstOfChunkRs == NULL) 
      {fprintf(stderr, "Empty-forest from first grammar\n");EXIT(NOPF);}

   fprintf(stderr,"(G1 -> G2...");

         {ConstructG1toG2(); /* construct transformation from rules of G1 to rules of G2 */    
          TransferChunks(TheLstOfChunkRs, *THETABLE, length); /* Transferring chunks to THETABLE */
          TransInternOfChunks(TheLstOfChunkRs, *THETABLE, length); 
          ResetTable(*THETABLE, length); /* clean derivation-forest of first phase*/
         }

   CloseGrammar(1, Duo); 
   fprintf(stderr,"finished)\n");
  } /* end of ParPar use (grammar 1) */

  if ((ParsingMethod == _BOTH_G) && (_ShowChunks == true)) ShowParseSp(false, TheLstOfChunkRs, TheLstOfChunkRs);
  else  /* use second grammar also */
    { /*********** using grammar 2 ***********/
     fprintf(stderr,"Parsing with the second grammar...     "); UseGrammar(2); 
     {*Tags = TagSentence(TheWG); 
      if (ERROR == true)      /* there is an unknown word */
       {ERROR = false;        /* only for avoiding unknown words in a wordgraph */
        *Tags = TagUnknownWs(TheWG, *Tags); /*ERROR=true if "unknown_" is not there */
       }
      if ((ERROR == false) || (IsSentence() == false)) ; /* all words are known or a word-graph*/
      else { /* PRS("tree(XXXnonword,[]).\n"); */ EXIT(NONW);}
     }

     {/*** see ref3: also concerning versions **/
      *THETABLE = PARSE_AGAIN(*THETABLE, *Tags, length, Duo); 
      fprintf(stderr,"Finished\n");
      *ParF = GenParF(*THETABLE, length);   
      /* if ((ParsingMethod != _BOTH_G) || (Semi_Interleaved == false)) */ 
      if (Semi_Interleaved == false) FreeUnvalidItems(*THETABLE, length); 
     }
    }

 /* 
  PrintTable(InternTable, length); 
  ShowParF(*ParF);     
  PrintTable(*THETABLE, length);  
 */
}
/******************************************************************************************************/
/* when viewing the parse space is desired */
void ShowParseSp(Boolean PASSFassume, PtrList LstOfChunkRs, PtrList RedLstOfChunkRs)
{ void PChItemI(void *VI)
   {if (EBL_ASSUMPTION == true)
     if (((ItemTree) VI)->AlreadyCopied == false) PChItem((ItemTree) VI);
     else ; /* skip it */
    else PChItem((ItemTree) VI);
   }
 PRS("The recognized chunks are :\n");
 UseInternGrammar(1);
 if (PASSFassume == true) PListMap(RedLstOfChunkRs, (void *) &PChItemI);
 else PListMap(LstOfChunkRs, (void *) &PChItemI);
 PRS("\n");
 UseInternGrammar(2);
}
/***************************************************/
/* refNewI: if I is not new in entry then its AddedBy was 
                not empty and must be kept a set and therefore use EnterP
            else I is new and its original copy (item) has an AddedBy that has been
                 kept as a set and thus you may use EnterPStack .
*/
void PChItem(ItemTree item)
{PRS("entry [");PRI(item->i);PRI(item->j);PRS("] :"); PItem(item);PRS("\n");
 ShowMPD_OfICP((ItemCPtr) item->DerForest);
 PRS("....................................\n");
}
/***********************************************************/
/* ref1:  
         For input sentences:
         Suppose that in the ParPar grammar there is in entry [i,j] a parse 
         which has a derivation 
                    t o l(i+1) o ... o lj
         where lk for all k are lexical rules PosTag->word, and t is a partial
         tree. Since we assume that ParPar assigns to SSFs that it recognizes
         all associated structures, then in this case also we have to maintain this.
         We implement this here by removing all derivations that are not of this
         form.

ref2: Currently this has no effect at all. It only passes the markings of the entries
      without exploiting these marking later on for anything.
***/
/** added on 16/7/98
ref4: if the input is a sentence and the whole sentence has been covered by the partial-parser
      then do not let the full parser extend the parse-space. Do this by closing all entries.
      ALLCLOSEDBETWEEN is a global that allows a generalization of this behaviour to all
      entries of a sentence (not only <1,n>).
**/
/*  ref5 
    Since we call MarkCopyable for all entries <i,i+k> starting with k=1 untill k=n-i
    then Touched plays an important role: if an item is marked Touched by some entry <i,j>
    then other entries <l,m> are not allowed to change the structure the item marked
    Touched; the Touched marking implies that the structure under that item must be
    copied (entry <i,j> licenses this).


OLD version
     {if (item->Touched == false) item->AlreadyCopied = true;
          MapOnAllAddedBy(item, (void *) &AllNonCopyable);
     }
*/
/**
refEBLASSUMPTION:
  This assumption that the parse-space of SSFs is always complete implies the elimination
  of combined partial-parses from the space IF there are other partial-parses that are not
  combined. However, the question that can be raised here is what is the interpretation of
  completeness of parse-space for an SSF: does it mean only the set with which it was learnt ?
  or that set together with what other SSFs add to it by combining structures ? Now the following 
  situation explaines the dillema here:
     suppose we have a sentence "van den bosch naar oss"
     and that the grammar has an ambiguity set of the SSF  "van den bosch"
     it also has an ambiguity-set for the SSF "naar oss",
     BUT it does not have an ambiguity set for the whole sentence "van den bosch naar oss".

  In this  case there is the following dillema about the parse-space of "van den bosch naar oss": 
    1) it contains only combinations of (learnt, i.e. non-combined) partial-parses from the 
       ambiguity-sets of the two smaller SSFs.
    2) it contains the parses in 1) together with other combined parses EVEN those that are
       combined also at the parts "van den bosch"  and  "naar oss".
  The first interpretation is implied by the "completeness of ambiguity-sets" assumption.
  The second interpretation is implied by this assumption together with the compositionality assumption. 

  Since the parse-space completeness is assumed to be implied by both assumptions together and
  not only by any one of the two alone, then we stick to the second interpretation.
  THIS IMPLIES THAT EBL_ASSUMPTION must stay always FALSE
********/
/** RefNOPARPAR
** if true: for a version that does not use the partial-parser, e.g. when second STSG is SDOP model *
** if false: use the partial-parser first, e.g. for Par+DOPDIS                                      
*/
/** OrigPlace1

 for (k=1;k<=length;++k)      * order here is not to be changed ...*
  for (i=k;i<=length;++i)     * the order has impact on what we do in ref1 *
    {EPtr = ENTRY_Of(THETABLE, i-k, i); 
     SetsMapEnded(*EPtr, (void *) &MarkIf);               * construct the list of roots *
    }
*/
