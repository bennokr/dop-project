/***************** CLOSED CLOSED ****** OLD FASHIONED
Boolean Deduce(TableType TAB, int i, int j)
{EntryPtr ThisEntryPtr = ENTRY_Of(TAB, i, j);
 int k; Boolean B1 = false; Boolean B = false;Boolean Last = false;

 if (i == j) B = A_Deduce_Step(TAB, i, i, i,true);
 else if (j > i) for (k = i+1; k < j; ++k) 
                    {if (k == (j-1)) Last = true;
                     B1 = (A_Deduce_Step(TAB, i, j, k, Last));
                     B = B || B1;
                    }
      else PRS("Error: i > j !!!"); 
 return B;
}
***
/* For parsing mere sentences 
void Init(TableType TAB, TDomain *S, int length)
{int i;
 Boolean B;
    void Item_To_Table(RDomain RuleNo)
     {ItemTree I;
      if (RuleNo >= 0) 
         UpdateEntry(TAB, (I = FillItem(RuleNo, Term, mid)), i, i+1);
        ** FillItem takes care to initialize Adds and AddedBy ***
      EvaluateItemN(I, NULL, NULL, NULL);
      * MakeASetOfI(I); If No Eps rules then this is closed *
     } 
  * FillDiagonal(TAB, length); Closed: No Eps rules *
  for (i=0; i < length; ++i)
  {TMapOn_Rules_Of(Term_Ptr_Of(*(S+i)), (void *) &Item_To_Table);
   B = Complete(TAB, i, i+1);  
  } 
}
************** For parsing Word-Graphs *****************
extern Sentence TheWG;
* For simplified word-graphs *
void InitSWG(TableType TAB, TDomain *S, int length)
{int i,j;
 WordList temp;
 Boolean B;
    void Item_To_Table(RDomain RuleNo)
     {ItemTree I;
      if (RuleNo >= 0) 
          UpdateEntry(TAB, (I = FillItem(RuleNo, Term, mid)), i, i+1);
           ** FillItem takes care to initialize Adds and AddedBy ***
      EvaluateItemN(I, NULL, NULL, NULL);
      * MakeASetOfI(I); If No Eps rules then this is closed *
     }

  * FillDiagonal(TAB, length); for epsilon possibility *
  temp = TheWG->WORDS; i = temp->WordNumber-1; j = i;
  while (temp != NULL)
    {* Next command Adds all terminal rules the word S+j in S *
     TMapOn_Rules_Of(Term_Ptr_Of(*(S+j)), (void *) &Item_To_Table);
     temp = temp->Next; 
     if (temp != NULL) 
       if (temp->WordNumber == (i+2)) {B = Complete(TAB, i, i+1);  i++;}
       else {B = Complete(TAB, i, i+1); }
     else {B = Complete(TAB, i, i+1);}
     j++;
    } 
  j = i;
  for (i=0; i <= j; i++)
   {* ReduceSpace(TAB, i, i+1);  Not meaningfull *
    MarkUnValid(TAB, i, i+1); } 
}
**************/
