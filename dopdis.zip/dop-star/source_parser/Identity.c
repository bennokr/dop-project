#include "Universals.h"
void ShowIdentity()
{
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"	Parser: dopdis (release IIII)\n");
 fprintf(stderr,"	Author: Khalil Sima'an (University of Amsterdam)\n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"   	COMMERCIAL USE AND REDISTRIBUTION FOR PROFIT ARE FORBIDDEN.\n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"	The parser or any of its files/parts (source, object or executable codes)\n");
 fprintf(stderr,"	may NOT be redistributed/duplicated/exploited without informing the author\n");
 fprintf(stderr,"	by email at simaan@science.uva.nl.\n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"	Work/research that makes use of this software is kindly asked to mention\n");
 fprintf(stderr,"	the name (dopdis), the author (Khalil Sima'an) and the owner (NWO) in every\n");
 fprintf(stderr,"	publication (on any kinds of media).\n");
 fprintf(stderr,"                                                                 \n");
 fprintf(stderr,"	Use of this software is at your own risk (no warranty/responsibility).\n");
 fprintf(stderr,"\n");
 fprintf(stderr,"\n");
 fprintf(stderr,"\n");
 fprintf(stderr,"\n");
 fprintf(stderr,"\n");
 fprintf(stderr,"\n");
}
