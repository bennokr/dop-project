/**********************/
/* To save space we have the address of a code
   in its array of codes. The address is in fact
   its place-number in the array. 
   Since this address belongs to a given item
   and hangs under either a root-list or a non-roots-list
   then its always possible to get its value and prob.
*/
/**********************/
struct DerFor_Struct {
      struct DerFor_Struct *MPD_PtrL, *MPD_PtrR; /* pointers to left and right children of the MPD */
      ItemTree             SelfItem  ; /* Pointer to item of this code */
      PtrList              ListOfChNodes; /* All codes that combine with this one in the derivation-forest*/

      ProbDomain	   TempProb; /* for any kind of termporary calculations: Initialized MaxNutralConst */
      ProbDomain           DF_OUTSIDE_PROB;
      ProbDomain           MPD_Prob;  /* MPD probability */
      ProbDomain           Sum_Prob;  /* Sum probability */

      C_Addr_Domain        CAdr ;  /* The address of the code */
      Code_Soort           CSoort;
      OTS_Type             OpenTrees; /* if any */
      /* short int            num_of_roots_in_der;*/

}; /*-------*/
typedef struct DerFor_Struct *DerFPtr;

DerFPtr ALLDerFPtr(TreeCodeT Num, Code_Soort CT);
/* Allocate an array of length m of type DerFor_Struct 
   and copy all codes of a PtrList P, in which pointers to
   all codes of type CT appear, into this aray .
  For this it is necessary to know the item of which this 
  P is the derivation-forest in order to update it.
*/

DerFPtr CpyDerF(int n, PtrList P, RDomain Rno, RType RT, Code_Soort CT);
/*****************************/
/*****************************/
/* Each item points to a structre which
   carries its root and non-root codes and their
   probabilities. Hereunder, this info is in Roots/Others.
   R_/O_valids are used during computation of the derivation forest,
   where they holds which of the codes has been found valid  
*/
/*****************************/
struct Item_DerFStr {
    C_Addr_Domain *R_NowAtPos;   /* Only for faster finding of */
    C_Addr_Domain *O_NowAtPos;     /* child code */
    Boolean *R_valids;  /* the valid code of roots */
    Boolean *O_valids;  /* the valid codes of others */
    DerFPtr  Roots;
    DerFPtr  Others;
    TreeCodeT RootsSize;
    TreeCodeT OthersSize;
};

typedef struct Item_DerFStr *ItemCPtr;

ItemCPtr NewICPtr();
Boolean NonEmptyICPtr(ItemCPtr ICP);

ItemCPtr UpdateICP(ItemCPtr ICP, PtrList P, int n, Code_Soort CT, RType RT,
                   RDomain Rno);

extern void Map_OnCodesOf(ItemTree I, Code_Soort CT, void (* fp)()) ;
/***********************/
/* item derivation forest */
/***********************/
void MapOnIDer(ItemTree it, Code_Soort CT, void (* fp)());
void PrntNPtr(void *P);
void prntnode(DerFPtr DF);
DuoPtr MultItems(ItemTree ItemP, ItemTree ItemCh,
                    Child_Type Chnum, Boolean *AnyValid, DuoPtr Duo);


/****************/
/* NOW NOW      */
void FreeDFPtr(DerFPtr DFP);
DerFPtr ALLDerFPtr(TreeCodeT Num, Code_Soort CT);
void CpyDerFPtr(DerFPtr target, DerFPtr source);
void CpyDerFPtrEx(ItemTree IT, DerFPtr target, DerFPtr source, Code_Soort CT);
/************************/
/* Update first by second */
void UpdateDFPtr(DerFPtr target, DerFPtr source, Child_Type ChNum);
/****************/
/* For interleaved version of algorithm        */
/* Version that multiplies with target's prob. */
void UpdateDFPtrEx(DerFPtr target, DerFPtr source, Child_Type ChNum, NodePtr NPp);
/*********************/
/* The multiplication of two codes !! Checking their viability */
/*********************/
Boolean MultDFPtrs(DerFPtr DFp, DerFPtr DFch, Child_Type ChNum,
                   NodePtr NPp, NodePtr NPch);
/********************************/
/* Interleaved version of it !! */
/* Multiplies with code prob    */
/* immidiately UNLESS                      */
/*   1. The rule of code is Binary (it is multiplied only later)
     2. code takes only roots, is also multiplied only later (because
        of O(1) implementation which multiplies once with all roots
        and then copies to all codes that take only roots.            */ 
Boolean MultDFPtrsIn(DerFPtr DFp, DerFPtr DFch, Child_Type ChNum,
                        NodePtr NPp, NodePtr NPch);
/*******************/
/* A->BC*->Res is updated from A->BC*->Giv which has been computed
   from one of the possible A->B*C with all its C->x*. For the update
   we need also the prob.'s and addresses from A->B*C->OrgGiv which
   is the "original" der.forest - Giv is a copy which enables the
   multiplication (i.e. has extras: R/O_valids arrays, probabilities
   which are 0.
*/
/*******************/
extern void UpdateDF1By2(DerFPtr Res, DerFPtr Giv, DerFPtr OrgGiv);
/*****************************/
/* BfPtr2 is always the child-item buffer while BfPtr1 is for the
   Parent-Item. */
TreeCodeT WhereIsChildOf(C_Addr_Domain P_CAdr, Code_Soort CT,
                         Child_Type Chnum, Boolean *Found);
/*****************************/
/* O_valids and R_valids arrays type */
/*****************************/
/* CONTEXT : if a code is viable with any of its children
   then it is marked valid. This is done in a
   speacial array parallel to the array of code place 
   holders which tells whether the code should remain
   or not in the Derivations forest of an item.

   This function just does the update.
*/
/*******************/
TreeCodeT BFIND(DerFPtr *Arr, TreeCodeT Leng, C_Addr_Domain CA);
/****************/
/* Just checks if already valid */
Boolean IsValidCode(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT);
Boolean IsValidCodeN(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT,
                    TreeCodeT *This);
/*********************/
/* Context: since a parent-code may take one and only one child-code
       of OTHERS on any of its branches then we search for this child
       using bsearch. This is possible cause the codes are ordered */
/********/
NodePtr ComputeChOf(NodePtr NPp, Child_Type Chnum);
/********/
TreeCodeT BFINDCodeG(DerFPtr *Arr, TreeCodeT Leng, 
                    NodePtr WantedC, Rule_Apps RAe2, Boolean *FOUND,
                    Code_Soort CT);

TreeCodeT BFINDCode(DerFPtr *Arr, TreeCodeT Leng, 
                    NodePtr WantedC, Rule_Apps RAe2, Boolean *FOUND);
/*********************/
void UpdateValidCodeN(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT,
                      TreeCodeT Place);
/*********************/
void UpdateValidCode(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT);
/****************/
TreeCodeT NumOfValids(Boolean *C, TreeCodeT Size);
/*****************************/
/*****************************/
/* ItemCPtrs type            */
/*****************************/
/* Each item points to a structre which
   carries its root and non-root codes and their
   probabilities             
   Or in fact, it carries only arrays of place-holders
   for these codes.
*/
/*****************************/
ItemCPtr NewICPtr();
void FreeICPtr(ItemCPtr IC);
void InitICPtr(ItemCPtr IC);
/*********************/
/***********************/
/* item derivation forest */
/***********************/
/* Not in use at the moment !!
void MapOnIDer(ItemTree it, Code_Soort CT, void (* fp)());
*/
/************/
/* Cpy the Rule appearences in RA into an item-code-ptr structure
   which in fact represents the D value for the item which has 
   this RA.
   This function is mainly meant for getting the initial value
   A(R) into D(item, i, j) before further multiplication.
*/
/************/
ItemCPtr CpyR_Apps(Rule_Apps RA, ItemTree I);
/***********************************/
/* Multiply the two sets of codes (D's) of two items.
  CT = ROOTS : RootsP x OthersCH ----> RootsP
  CT = OTHERS : OthersP x RootsCh ----> OthersP
  
  The number of codes found viable is returned. 
  AnyValid tells whether there are any derivations found
  from any code of ICPp to ICPch (i.e. any viablity holds) 
  so that: if AnyValid == false ====> the pointers AddedBy/Adds should
                                      be eliminated between the two
                                      items.
           else the pointers should stay.
  The validity is shown in a list of booleans R_valids and O_valids
  which are update if there are new valid codes which came by.

*/ 
/***********************************/
/* A global variable for the next function */
/* reduces allocations and freeing of memory */
/***/
DuoPtr MultICPs(ItemTree ItemP, ItemTree Ich, ItemCPtr ICPp, ItemCPtr ICPch, Child_Type Chnum,
                   RDomain Rnop, RType RTp,
                   RDomain Rnoch, RType RTch, Boolean *AnyValid,
                   DuoPtr Duo, int i, int j);
/****************/
/* Multiplies the codes sets of two items. */
/****************/
DuoPtr MultItems(ItemTree ItemP, ItemTree ItemCh, 
                    Child_Type Chnum, Boolean *AnyValid, DuoPtr Duo);
/**********************/
/* Copy ICP. If ProToo is false then make probability zero
   else copy it */ 
/**********************/
/** Copies ICP and either copies the probabilities or not,
    and then SelfItem of the result points to IT */
ItemCPtr CpyICPtr(ItemCPtr ICP, Boolean ProbToo, ItemTree IT, TreeCodeT OrigRsNum, TreeCodeT OrigOsNum);
/**************************************************************************/
/**************************/
/* Proc.s for testing     */
/**************************/
/***** Not in use 
void PrntNPtr(void *P);
********/
void prntnode(DerFPtr DF);
/******************************/
void ShowDerF(ItemTree I);
/******** Not in use
void VShowDF(void *P);
void PDList(void *This, void *list);
***********/
/****************************************************************/
extern void FillDFPtr(DerFPtr target,
               ProbDomain MPD_Prob, ProbDomain Sum_Prob,
               DerFPtr MPD_PtrL, DerFPtr MPD_PtrR,
               ItemTree SelfItem, C_Addr_Domain  CAdr, Code_Soort  CSoort,
               PtrList ListOfChNodes, OTS_Type OpenTrees);
extern ProbDomain InterpolatedProbValue(ProbDomain MPD, ProbDomain NGRAM);
extern ProbDomain InterpolatedProb(DerFPtr DFP);
extern TreeCodeT TreeCodeOfDFP(DerFPtr DFP);
extern TreeCodeT OwnCodeOfDFP(DerFPtr DFP);
extern TreeCodeT Ch_OwnCodeOfDFP(DerFPtr DFP,  Child_Type Chnum);
 
#ifndef _interpolate_ngram
#define _interpolate_ngram _ngram_is_used
#endif


/// when the following is open it uses a function definition instead of macro.
/* 
#ifndef MapOnNodesOfDEC
#define MapOnNodesOfDEC \
 void MapOnNodesOf(ItemCPtr ICP, Code_Soort CT,  void (* fp)(DerFPtr DFp)); 
#endif
*/
extern void MapOnNodesOfV(ItemCPtr ICP, Code_Soort CT,  void (* fp)(DerFPtr DFp)); 

#ifndef MapOnNodesOfDEC
#define MapOnNodesOf(ICP, CT, fp) \
{static TreeCodeT i; \
 if (ICP == NULL) ; \
 else { \
 switch (CT) { \
    case ROOT_enum   : if (ICP->RootsSize > 0) \
                       for (i = 0; i < ICP->RootsSize; i = i+1) \
                         { \
                          (*fp)((DerFPtr) ((ICP->Roots)+i)); \
                         } \
                      break; \
    case OTHERS_enum : if (ICP->OthersSize > 0) \
                       for (i = 0; i < ICP->OthersSize; i= i+1) \
                          { \
                           (*fp)((DerFPtr) ((ICP->Others)+i)); \
                          } \
                      break; \
    default     : printf("MapOnNodes Err: CT not good\n");break; \
 } \
 } \
}
#endif

/**********/
