#include "./ALL.h" 
extern Boolean ErIsUnknownW;
extern ProbDomain R_PRUNE_RATIO_GT;
extern ProbDomain O_PRUNE_RATIO_GT;
extern Boolean ECNF_MARKED(char *Name);
/*
**
**
*/
Boolean _REMOVE_PRUNED_ITEMS = true;  /* remove the items marked pruned from table ? */

/*  _UseInsideProb if true has two modes depending on _use_total_inside_item! */
Boolean _UseInsideProb = true;
Boolean _use_total_inside_item=false;           /* if true: SUM of Inside of DFPs of Item, else Inside of DFP */

Boolean _PRUNE_OTHER_DFPs = true;                  /* prune the non-root (tgram-iternal) nodes ? */
Boolean _PRUNE_ITEMS_IMMIDIATE = true;             /* if the largest DF of the item is too small prune whole */
Boolean _PRUNE_ECNF_NODES = false;

/*** externals ***/
extern Boolean _OVIS_BKF_Pruning;
extern Boolean BackOff_ItemOVIS(ItemTree I);

Boolean _GLOBAL_THRESH_ENABLED = false;                  /* Allow GLOBAL_THRESH for basic-ended items */
/***************************************************************************************/
/***************************************************************************************/
inline
Boolean IsModifier(char *Name)
{if ((strstr(Name, Left_Mod_Sym) != NULL) || (strstr(Name, Right_Mod_Sym) != NULL)) return true;
 else return false;
}
inline
Boolean NotModifier(char *Name)
{return (Negate(IsModifier(Name)));
}
                                                                                                                             
inline
Boolean ECNF_MARKED(char *Name)
{if (strchr(Name, _ECNF_SYM) != NULL)
  if (NotModifier(Name)== true) return true;
  else return false;
 else return false;
}
/***************************************************************************************/
/***************************************************************************************/
/************************/
/* ONLY FOR ROOTS of ENDED ITEMS */
#define MAX_NONT_SIZE (NonTSize+1)
static ProbDomain BeamR_PruneProb = MaxNutralConst;
static ProbDomain BeamO_PruneProb = MaxNutralConst;

ProbDomain *MaxProbNonTArray;                           /* array of max prob per non-terminal */
ProbDomain *R_BeamMaxProbNonTArray;                      /* array of positions */
Boolean CreatedMaxProbNonTArray = false;
int R_COUNT_BEAM_WIDTH = 0;  
int R_COUNT_IN_ENTRY = 0; 

int CompareH(const void *VVL1, const void *VVL2)
{Boolean First = false; ProbDomain p;
 ProbDomain VL1 = *((ProbDomain *) VVL1); ProbDomain VL2 = *((ProbDomain *) VVL2);

 if (VL1==VL2) return 0; 
 p = MaxProbs(VL1, VL2, &First);
 if (First == true)  return -1; else return 1;
}
/* Per non-terminal XP: keep its maximum probability of a derivation; this Prob is the first threshold for other XPs in the same entry */
inline
void InitMaxProbNonTArray()
{int i;
 if (CreatedMaxProbNonTArray==false)
    {CreatedMaxProbNonTArray=true;
     if (NonTSize > MAX_NONT_SIZE) {fprintf(stderr,"Err: enlarge MAX_NONT_SIZE !!\n"); exit(1);}
     MaxProbNonTArray= (ProbDomain *) MultAlloc(MAX_NONT_SIZE, sizeof(ProbDomain));
     R_BeamMaxProbNonTArray= (ProbDomain *) MultAlloc(V_BEAM_WIDTH, sizeof(ProbDomain));
    }

 for (i=0; i < MAX_NONT_SIZE; i++) {MaxProbNonTArray[i]=MaxNutralConst; }
 for (i=0; i < V_BEAM_WIDTH; i++) {R_BeamMaxProbNonTArray[i]=MaxNutralConst; }
 R_COUNT_BEAM_WIDTH = 0; 
 R_COUNT_IN_ENTRY = 0; 
}
inline
void UpdateBeamArray(ProbDomain Prob, Code_Soort CT)
{Boolean VOIDB; int i;
 if (R_COUNT_BEAM_WIDTH < (V_BEAM_WIDTH-1)) /* keep last place for current one */
   if (CT == ROOT_enum) {R_BeamMaxProbNonTArray[R_COUNT_BEAM_WIDTH]=Prob; R_COUNT_BEAM_WIDTH++;}
   else ;
 else {Boolean First =false; ProbDomain p; 

       p = MaxProbs(Prob, R_BeamMaxProbNonTArray[V_BEAM_WIDTH-1], &First);
       if (First == true) {
           R_BeamMaxProbNonTArray[V_BEAM_WIDTH-1] = Prob;
           qsort((void *) &(R_BeamMaxProbNonTArray[0]), V_BEAM_WIDTH, (sizeof(ProbDomain)),  CompareH); 
           /* now the smallest is last one so we can substitute next time */
           /*fprintf(stderr,"%e => ", R_BeamMaxProbNonTArray[V_BEAM_WIDTH-1]); fprintf(stderr,"\n");*/ 
          }
      R_COUNT_IN_ENTRY++;
     }
}
inline
void UpdateMaxProbNonTArray(ItemTree I, ProbDomain Prob, Code_Soort CT)
{Boolean VOIDB; int i; NTDomain NTnum;
 if (EndedItem(I)==true)  NTnum = LHS_OfR(I->RuleNo, I->RT);  
 else NTnum = LHS_OfR(I->RuleNo, I->RT); 
 MaxProbNonTArray[NTnum] = MaxProbs(MaxProbNonTArray[NTnum], Prob, &VOIDB); 
 UpdateBeamArray(Prob, CT); /* the array maitaining the beam */
}
/**/
inline
ProbDomain ValMaxProbNonTArray(ItemTree I)
{NTDomain NTnum;
 if (EndedItem(I)==true) NTnum = LHS_OfR(I->RuleNo, I->RT);  
 else NTnum = LHS_OfR(I->RuleNo, I->RT);  
 return MaxProbNonTArray[NTnum]; 
}
inline
void SetBeamValue(Boolean Ended, int i, int j)
{int beam_width = V_BEAM_WIDTH-1;
 if (_PRUNE_ITEMS_IMMIDIATE==false) {BeamR_PruneProb=MaxNutralConst; BeamO_PruneProb=MaxNutralConst;}
 else
 if (Ended==false) {BeamR_PruneProb = MaxNutralConst; BeamO_PruneProb = MaxNutralConst;}
 else
  if ((j-i) <= V_BEAM_WIDTH_SMALL_SPAN(j-i)) {BeamR_PruneProb= MaxNutralConst; BeamO_PruneProb=MaxNutralConst;}
  else {BeamR_PruneProb = R_BeamMaxProbNonTArray[beam_width]; BeamO_PruneProb = MaxNutralConst;}
}
inline
Boolean BeamWidthPossible(Code_Soort CT)
{
 if ((CT == ROOT_enum) && (BeamR_PruneProb!=MaxNutralConst)) return true;
 else return false;
}
/*******************************************************************************************************/
/*******************************************************************************************************/
/*******************************************************************************************************/
/*******************************************************************************************************/
/* The pruning ratio is handeled with some simple means hereunder */
/*----------------------------------------------------------------*/
/*((Active_Grammar_Number == 1) ?  ((ProbDomain)  1.20) : ((ProbDomain) 1.20) ) */
/* smoother pruning dependent on current parse-span */
#define _ADD_SPAN_SMALL    ((_sen_length > 30) ? ((ProbDomain)  0.00) : ((ProbDomain)  0.00)) 
#define _MIN_SEN_LENG_FOR_SPARE ((_SpareMemoryPruning == false) ?  40 : 30)  

#define _LARGE_SPAN_RATIO   ((ProbDomain)  0.85)
#define _MIN_SPAN_BIG       ((ProbDomain)  0.25)
#define _NOT_ENDED_ADD     ((_sen_length > 22) ? ((ProbDomain) 3.6) : ((ProbDomain) 4.6)) 

#define PROMPT_ADD_CLAUSE(ADD, SPAN) \
  {if (1==0) \
   {if (_TAGGING_PHASE == false) \
     if (_sen_length >= _MIN_SEN_LENG_FOR_SPARE ) \
            if ((((ProbDomain) SPAN)/((ProbDomain) _sen_length)) >= _LARGE_SPAN_RATIO) \
               ADD = ((ProbDomain) SPAN)/((ProbDomain) _sen_length) * _MIN_SPAN_BIG;\
    if (I->RT == _Term) ADD = ADD + _ADD_SPAN_SMALL; \
    else if ((EndedItem(I) == false)) ADD = ADD + _NOT_ENDED_ADD;\
    if (_SpareMemoryPruning == true) ADD = ADD - 0.3; \
   } \
  }
/*-----------*/
#define USE_AUTO_RATIO   false
/* values that must not be changed follow */
/* see refGlobalThresh: for the following global: */
#define _RATIO_SOORT  Per_Entry                          /* Per_NonT is not good yet */
enum RATIO_KIND_T _RATIO_KIND = _RATIO_SOORT;
Boolean _TAGGING_PHASE = false;                          /* during tagging MPD_Prob also for MPP */
enum VERSION_TYPE _VERSION = BEAM_THRESH;                /* need not be changes as GLOBAL + BEAM are combined */
/********************************************************************************************************/
/**** ----      GLOBALS variables    ---------*********/
static Boolean _InternRedDerF;
ProbDomain V_R_PRUNE_RATIO ;
static ProbDomain V_O_PRUNE_RATIO ;
static ProbDomain V_R_PRUNE_RATIO_GT ;
static ProbDomain V_O_PRUNE_RATIO_GT ;
static ProbDomain*** Max_SeqProb_Array = NULL;
static PtrList  _ToBeFreedRoots = NULL;
static PtrList  _ToBeFreedOthers = NULL; 

/***********************************************************************************************************/
/*------------- values for AUTO_RATIO computation      ------------*/

#define STD_PERC         ((ProbDomain) 1.5)               /* how many STDs from Mean is the pruning-ratio */
#define PERC_LEFTOVER    ((ProbDomain) 0.2)               /* percentage of nodes left over in an entry */
#define Thresh_NUM_OF_NODES ((long int)  200)             /* threshold number of nodes in an entry     */

/***********************/
extern ProbDomain Calc_Ratio(long int NumOfNodes, long int NumOfNodesGTMean, ProbDomain STD, ProbDomain Mean);
extern void AgainRedToValids(ItemTree IT, TreeCodeT Rnum, TreeCodeT Onum);
extern Boolean PruneThisQ(ItemTree I, Code_Soort CT, ProbDomain CurMax, ProbDomain ThisP);
extern ProbDomain InsideXPrior(ItemTree I, Code_Soort CT, ProbDomain *SUM_RootsOfItem);
/**************************************************************************************/
/* which probability to use ?       */
inline
ProbDomain ProbabilityOfDF(DerFPtr DFP)
{if (DFP == NULL) return SumNutralConst;
 if (_TAGGING_PHASE == true) return DFP->MPD_Prob;
 else if (_UseInsideProb == true) 
        if (_use_total_inside_item==true) return (DFP->SelfItem)->RInsideProb;
        else return DFP->Sum_Prob;
      else return DFP->MPD_Prob;
}
/***********************************************************************************/
inline
void SetValueOfInterRedDF(Boolean VAL) {_InternRedDerF = VAL;}
inline
Boolean ValueOfInternRedDerF()         {return _InternRedDerF;}
/***********************************************************************************/
inline
void EntryMapX(EntryType ENT, void (* fp)(), Boolean Ended)
{if (Semi_Interleaved == true) 
   if (Ended == true) SetsMapEnded(ENT, fp);
   else SetsMapOths(ENT, fp);
 else SetsMapValid(ENT, fp);
}
inline
void ByLevelEntryMapEnded(EntryType ENT, void (* fp)(), Boolean Ended, Boolean Only_Valid_Items)
{if (Only_Valid_Items == false) MapOnLevelsOfEnded(ENT, fp, Ended);
 else MapOnLevelsOfV(ENT, fp);
}
inline
void RevByLevelEntryMapEnded(EntryType ENT, void (* fp)(), Boolean Ended, Boolean Only_Valid_Items)
{if (Only_Valid_Items == false) RevMapOnLevelsOfEnded(ENT, fp, Ended);
 else RevMapOnLevelsOfV(ENT, fp);
}
inline
void ByLevelEntryMap(EntryType ENT, void (* fp)())
{if (Semi_Interleaved == true) MapOnLevelsOf(ENT, fp);
 else MapOnLevelsOfV(ENT, fp);
}
/*-----------------*/
/***************************************************/
/* either tagging-phase or I was marked for pruning */
Boolean Prunable_Item(ItemTree I)
{char temp[MaxRule];
 strcpy(temp, Name(LHS_OfItem(I)));
 if (strstr(temp,"sss")!=NULL) return false; /* FRIDAY HECTIC CHANGE do not prune those: these are backoff! */

 if (I == NULL) return false;
 else if ( (I->Attempt_Pruning_Item == true) || (_TAGGING_PHASE == true) ) 
          if (ECNF_MARKED(Name(LHS_OfR(I->RuleNo, I->RT)))==false) return true;
          else if (_PRUNE_ECNF_NODES==true) return true;
               else return false;
      else return false;
}

void MakeCompactEntry(TableType TABLE, int i, int j, int sen_length)
{EntryPtr NewEPtr; EntryPtr EPtr; EntryType ENT;

  ItemTree CheckI(ItemTree I)
   {if (I != NULL)
     {if (I->Pruned_Item == false) UpdateEntry(TABLE, I, i, j);
      else if (NonEmptyDerForest(I) == true) 
              {fprintf(stderr,"Err: an non-empty DF-item has been marked for pruning?\n");ShowDerF(I); exit(1);} 
           else I = FreeItem(I);
     }
    return NULL;
   }

  EPtr = ENTRY_Of(TABLE,i,j); ENT = *EPtr; 
  NewEntry(TABLE, i, j, sen_length); NewEPtr = ENTRY_Of(TABLE,i,j);

  (*NewEPtr)->Max_Prob_To_Right = (*EPtr)->Max_Prob_To_Right;
  (*NewEPtr)->AlphaXBeta = (*EPtr)->AlphaXBeta;
  (*NewEPtr)->RMax_Node_Prob = (*EPtr)->RMax_Node_Prob;
  (*NewEPtr)->OMax_Node_Prob = (*EPtr)->OMax_Node_Prob;
                                         
  XSetsMap(ENT, &CheckI);   FreeSet(ENT);
}
/***********************************************************************************/
/*             RATIOS                                                              */
/*             RATIOS                                                              */
/* A pair of standard prune-ratios */
extern int n; /* sentence length */

inline
void InitRatioVars()
{if ((NUM_OF_GRAMS() == SINGLE_G) || (Active_Grammar_Number == 1))
  {V_R_PRUNE_RATIO = R_PRUNE_RATIO ; V_O_PRUNE_RATIO = O_PRUNE_RATIO ;
   V_R_PRUNE_RATIO_GT = R_PRUNE_RATIO_GT; V_O_PRUNE_RATIO_GT = O_PRUNE_RATIO_GT; 
  }
 else {V_R_PRUNE_RATIO = Second_R_PRUNE_RATIO ; V_O_PRUNE_RATIO = Second_O_PRUNE_RATIO;
       V_R_PRUNE_RATIO_GT = R_PRUNE_RATIO_GT; V_O_PRUNE_RATIO_GT = O_PRUNE_RATIO_GT; 
      }
}

inline
ProbDomain OrigPruneRatio(Code_Soort CT)
{if (CT == ROOT_enum) return V_R_PRUNE_RATIO;
 else return V_O_PRUNE_RATIO;
}
/*-*/
/* A pair of prune-ratios per Entry */
inline
ProbDomain PruneRatioX(Code_Soort CT, int i, int j, ProbDomain ADD)
{if (_VERSION == BEAM_THRESH)
   if (CT == ROOT_enum) return ((ProbDomain) (V_R_PRUNE_RATIO + ADD));
   else return ((ProbDomain) V_O_PRUNE_RATIO + ADD);
 else /* GLOBAL_THRESH */
   if (CT == ROOT_enum) return ((ProbDomain) (V_R_PRUNE_RATIO_GT + ADD));
   else return ((ProbDomain) V_O_PRUNE_RATIO_GT + ADD);
}
inline
ProbDomain PruneRatio(ItemTree I, Code_Soort CT, int i, int j)
{ProbDomain ADD = 0.0; 
 PROMPT_ADD_CLAUSE(ADD, (j-i));
 return PruneRatioX(CT, i, j, ADD);
}
/*-*/
inline
Boolean TOO_LARGE_Thresholds() 
{if ( (OrigPruneRatio(ROOT_enum) >= _MIN_PRUNE_RATIO) && 
      (OrigPruneRatio(OTHERS_enum) >= _MIN_PRUNE_RATIO) ) return true;
 else return false;
}
/*--------------------------------------------------------------------------------------*/
/***********************************************************************************/
/*************************************************************************************/
/* The maximum subderivation-prob of I        */
ProbDomain Max_DerProb(ItemTree I, Code_Soort CT)
{Boolean VOIDB; ProbDomain MaxP; 
   void MaxValue(DerFPtr DFP) 
    {if ((CT==OTHERS_enum) && (ProbabilityOfDF(DFP) == MultNutralConst)) ; /* see refOTHERS */
     else MaxP = MaxProbs(MaxP, ProbabilityOfDF(DFP), &VOIDB);
    }
 
 MaxP = MaxNutralConst; 
 if (CT == ROOT_enum) {Map_OnCodesOf(I, ROOT_enum, &MaxValue);}
 else {Map_OnCodesOf(I, OTHERS_enum, &MaxValue);}
 return MaxP; 
}
/* The maximum subderivation-prob of I        */
ProbDomain Sum_DerProb(ItemTree I, Code_Soort CT)
{Boolean VOIDB; ProbDomain SumP; 
   void SumValue(DerFPtr DFP) 
    {if ((CT==OTHERS_enum) && (ProbabilityOfDF(DFP) == MultNutralConst)) ; /* see refOTHERS */
     else SumP = SumProbs(SumP, ProbabilityOfDF(DFP));
    }
 
 SumP = SumNutralConst; 
 if (CT == ROOT_enum) {Map_OnCodesOf(I, ROOT_enum, &SumValue);}
 else {Map_OnCodesOf(I, OTHERS_enum, &SumValue);}
 return SumP; 
}
/*--*/
/* The Inside probability of I is defined as the maximum subderivation-prob of I        */
inline
ProbDomain Max_InsideOf(ItemTree I, Code_Soort CT)
{return Max_DerProb(I,CT);}
inline
ProbDomain Sum_InsideOf(ItemTree I, Code_Soort CT)
{return Sum_DerProb(I,CT);}
/*------------------------*/
/* when we have an average-outside estimate, we prefer it */
inline
ProbDomain PriorProbOfItemOrOUTSIDE(ItemTree I)
{ProbDomain Prior;
 if (I !=NULL) 
  if (I->IN_X_OUT != MaxNutralConst) return I->IN_X_OUT;
  else {Prior = PriorProbOfItem(I); return Prior;}
 else return SumNutralConst;
}
/*------------------------*/
/* The inside probability of I is multiplied with the prior of the LHS of I */
inline
ProbDomain InsideXPrior(ItemTree I, Code_Soort CT, ProbDomain *SUM_RootsOfItem)
{Boolean VOIDB=false; ProbDomain Prob ; ProbDomain prior ; 
 ProbDomain sumprob = SumNutralConst;
 Prob = MaxNutralConst; 
 prior = PriorProbOfItemOrOUTSIDE(I); 

 if (prior == MultNutralConst) return SumNutralConst;

  switch (CT) {
   case ROOT_enum: Prob = MultProbs(prior, (Max_InsideOf(I,CT))); 
                   sumprob = MultProbs(prior, (Sum_InsideOf(I,CT))); 
                   if (_use_total_inside_item == true)  /* am I using the sum of insides of DFPs or their max */
                          *SUM_RootsOfItem = SumProbs(*SUM_RootsOfItem,sumprob);
                   else
                          *SUM_RootsOfItem = SumProbs(*SUM_RootsOfItem,Prob);
                   return Prob;
                   break;
   case OTHERS_enum: Prob = MultProbs(prior, (Max_InsideOf(I,CT))); 
                   return Prob;
                   break;
   } /* switch */

 return Prob;
}
/*------------------------*/
/* return the maximum probability of a node in [k, j], the prob of a node is its
   inside multiplied with the prior of its label
   SIDE-EFFECT: this probability is saved in [i, j]->Max_Node_Prob
*/
ProbDomain Max_InXPrior(TableType TAB, int k, int j, Code_Soort CT, Boolean Ended, Boolean CheckPrunableItem)
{ProbDomain MAX; EntryPtr EPtr; 
  void CompMax(ItemTree I)
   {Boolean VOIDT; 
    if ((CheckPrunableItem == false) || (Prunable_Item(I) == true)) 
       {ProbDomain SUM_RootsOfItem = MaxNutralConst; ProbDomain ValForImmdiatePrune;
        ProbDomain MaxOfThisItem = InsideXPrior(I,CT, &SUM_RootsOfItem); 
        if (CT==ROOT_enum) 
         {if (_UseInsideProb == true) 
          {UpdateMaxProbNonTArray(I,  SUM_RootsOfItem, CT); I->RInsideProb = SUM_RootsOfItem; 
           ValForImmdiatePrune=SUM_RootsOfItem;}
          else {UpdateMaxProbNonTArray(I,  MaxOfThisItem, CT); 
                I->RInsideProb = SUM_RootsOfItem; ValForImmdiatePrune= MaxOfThisItem;}
         }

        MAX = MaxProbs(MAX, MaxOfThisItem, &VOIDT);
        if (CT == ROOT_enum) I->RMaxPruneProbOfDer = MaxProbs(MaxOfThisItem, I->RMaxPruneProbOfDer, &VOIDT);
        else I->OMaxPruneProbOfDer = MaxProbs(MaxOfThisItem, I->OMaxPruneProbOfDer, &VOIDT);

        if (CT==ROOT_enum) (*EPtr)->AlphaXBeta = MaxProbs((*EPtr)->AlphaXBeta, ValForImmdiatePrune, &VOIDT);
       }
   }

 MAX = MaxNutralConst; EPtr = ENTRY_Of(TAB, k, j);

 if (MAX > MaxNutralConst) return MAX;
 else {EntryMapX((*EPtr), (void *) &CompMax, Ended );
       if (MAX == MaxNutralConst) MAX = MultNutralConst; /* no pruning ratio implies 1.0 i.e. don't prune at all */
       if (CT == ROOT_enum) (*EPtr)->RMax_Node_Prob = MAX;
       else (*EPtr)->OMax_Node_Prob = MAX;
       return MAX;
      }
}
/*----------------------------------*/
void FreeDFPList(PtrList P)
{ void FreeDFPArr(void *This)
   {cfree((DerFPtr) This);}
 if (P != NULL)
  {PListMap(P, (void *) &FreeDFPArr); FreePListN(P);}
}
/*----------------------------------*/
/* THE PRUNING PROCEDURES           */
/*----------------------------------*/
inline
ProbDomain THE_RATIO(ItemTree I, Code_Soort CT, ProbDomain MAX, ProbDomain ThisP)    
{ProbDomain num_of_chunks = 1; ProbDomain this_ratio = MultNutralConst;
 if (_VERSION==GLOBAL_THRESH)
  {num_of_chunks = (ProbDomain) _sen_length; /* ((ProbDomain) _sen_length)/((ProbDomain) I->j - I->i);*/
   this_ratio = NthRootOf(DevideProbs(MAX, ThisP), (I->j - I->i));  /* XXXX */
    if (1==0) fprintf(stderr, "\n %d %d   (MAX=%f This=%f) = %f  (prune when > by %f)", 
                         I->i, I->j, MAX, ThisP, this_ratio, (PruneRatioX(CT, I->i, I->j, 0)));
  }
 else this_ratio = DevideProbs(MAX, ThisP);
 return this_ratio;
}
Boolean PruneThisQ(ItemTree I, Code_Soort CT, ProbDomain CurMax, ProbDomain ThisP)
{ProbDomain MAX ; Boolean RESULT = false; ProbDomain this_ratio = MultNutralConst;  
 Boolean VOIDB=false;

 if (_RATIO_KIND == Per_Entry) MAX =  CurMax;
 else {fprintf(stderr,"Err: not implemented - works bad\n"); exit(1);}

 if (1==0) fprintf(stderr, "\n %d %d (MAX=%f This=%f) = %f  ", I->i, I->j, MAX, ThisP, this_ratio );

 if (ThisP == SumNutralConst) return true;

 if (BeamWidthPossible(CT)==true) {ProbDomain p = MaxProbs(BeamR_PruneProb, ThisP, &VOIDB); RESULT = VOIDB;}

 if (RESULT==false) /* VARIABLE-BEAM */
   {this_ratio = THE_RATIO(I, CT, MAX, ThisP);
    if ( this_ratio > (PruneRatio(I, CT, I->i, I->j)) ) RESULT = true;
    else RESULT = false;
   }

 return RESULT; 
}
/**/
inline
Boolean TooSmallProb(ItemTree I, ProbDomain ThisP, ProbDomain MAX, int i, int j,  Code_Soort CT, Boolean add_something)
{Boolean RESULT = false; ProbDomain num_of_chunks = 1; ProbDomain this_ratio = MultNutralConst;
 ProbDomain ratio_to_use; Boolean VOIDB=false;

 /* if (_PRUNE_ITEMS_IMMIDIATE == false) return false; */

 if (add_something == true) ratio_to_use = PruneRatio(I, CT, i, j);
 else ratio_to_use =  PruneRatioX(CT, i, j, 0);

 if (ThisP == MultNutralConst) return false;

 if (ThisP != SumNutralConst)
  {this_ratio = THE_RATIO(I, CT, MAX, ThisP);

   if ( this_ratio > ratio_to_use ) RESULT = true;
   else RESULT = false;
  }
 else if (CT != ROOT_enum) return false;
      else RESULT = true;
 
 return RESULT;
}
/*-*/
/*----*/
inline
Boolean CanBeRemovedItem(TreeCodeT Rnum, TreeCodeT Onum)
{if (_REMOVE_PRUNED_ITEMS == false) return false;
 else
  if (_TAGGING_PHASE == true) {if (Rnum == 0) return true; else return false;}
  else if ((Rnum == 0) && (Onum == 0)) return true;
       else return false;
}
inline
Boolean ImmidiateRemoveItem(ItemTree I, ProbDomain CurMax, ProbDomain ThisIMax, Code_Soort CT)
{Boolean VOIDB=false; 
 ProbDomain ValToPrune = ((CT==ROOT_enum) ? ((_UseInsideProb==true) ? I->RInsideProb : ThisIMax) : ThisIMax); 

 if (_PRUNE_ITEMS_IMMIDIATE == true) {

  if (BeamWidthPossible(CT)==true) {ProbDomain p = MaxProbs(BeamR_PruneProb, ValToPrune, &VOIDB); return VOIDB;}

  /* pruning same non-terminal LHS ended items that are ROOT_enum */
  if ((CT==ROOT_enum) && (TooSmallProb(I, ValToPrune, ValMaxProbNonTArray(I), I->i, I->j, CT,false)==true)) return true;

  /* pruning rule that have a MAX that is smaller than global max of entry by threshold */
  if (TooSmallProb(I, ValToPrune, CurMax, I->i, I->j, CT, true)==true) return true;
 }

 return false;
}
/*------------------------------------------------*/
/* MaxInEntry is used for debugging: pruning assumes that the maximum is in the entry */
TreeCodeT PruneInheritNodesOf(ItemTree I, ProbDomain AlphaXBeta, Code_Soort CT, ProbDomain CurMax, Boolean *MaxInEntry)
{ItemCPtr ICP ; TreeCodeT Total; TreeCodeT i = 0; TreeCodeT TotalUnvalid = 0; TreeCodeT j = 0;
 Boolean A_PRUNABLE_DFP = false; Boolean REMOVEanyway = false; ProbDomain ThisIMax;

  void PruneNode(DerFPtr DFP)
   {ProbDomain TEMP = ProbabilityOfDF(DFP); Boolean PruneIT = false;

    if (TEMP != MultNutralConst) /* see refOTHERS */
     {A_PRUNABLE_DFP = true;
      if (_VERSION == GLOBAL_THRESH) TEMP = MultProbs(AlphaXBeta, TEMP);
      if (_TAGGING_PHASE == false) TEMP = MultProbs(TEMP, (PriorProbOfItemOrOUTSIDE(I))); 
      else ; /* no priors during tagging */
 
      if (EQUAL_Probs(TEMP, CurMax) == true) *MaxInEntry = true;/* keeping an eye on things to avoid bugs */
      /* fprintf(stderr,"%d %d %d : %e %e %d\n", I->i, I->j, CT, TEMP, CurMax, *MaxInEntry); */

      /* if (DevideProbs(ThisIMax,TEMP) < 0) fprintf(stderr,"%d %d : IMax=%e DFP=%e MAX=%e \n", I->i, I->j, ThisIMax, TEMP, CurMax); */

      PruneIT = PruneThisQ(I, CT, CurMax, TEMP);

      if ( PruneIT == true ) 
       switch (CT) {
         case ROOT_enum: ICP->R_valids[DFP->CAdr] = false; 
                         DFP->MPD_Prob = SumNutralConst; DFP->Sum_Prob = SumNutralConst; 
                   break;
         case OTHERS_enum: ICP->O_valids[DFP->CAdr] = false; 
                         DFP->MPD_Prob = SumNutralConst; DFP->Sum_Prob = SumNutralConst; 
                   break;
       } /* switch */
    }
  } /* end-of PruneNode */
  void PruneInherit(DerFPtr DFP)
   {
    PruneNode(DFP); 
    if ((CT == ROOT_enum) && (ICP->R_valids[DFP->CAdr] ==  false))   {TotalUnvalid++;} 
    if ((CT == OTHERS_enum) && (ICP->O_valids[DFP->CAdr] ==  false)) {TotalUnvalid++;}
    i++;
   }

 i=0;

 if (I == NULL) {*MaxInEntry = true; return 0;}
 else ICP = (ItemCPtr) I->DerForest;
 
 if (ICP == NULL)   {*MaxInEntry = true; return 0;} 
 else {if (CT == ROOT_enum) Total = ICP->RootsSize; else Total = ICP->OthersSize;
       if (CurMax == MaxNutralConst)  {*MaxInEntry = true; return 0;} /* maximum is zero: nothing remains after pruning */
       else if (CurMax == MultNutralConst) {*MaxInEntry = true; return Total;} /* 1.0: all remains after pruning */
            else if (Total == 0) {*MaxInEntry = true; return 0;}
                 else {ThisIMax = ((CT == ROOT_enum) ? I->RMaxPruneProbOfDer : I->OMaxPruneProbOfDer);
                       if ((_TAGGING_PHASE == false) && 
                           (ImmidiateRemoveItem(I, CurMax, ThisIMax, CT) == true) && (ThisIMax != MaxNutralConst)
                          ) {*MaxInEntry = true; return 0;} /* all defs are too small */
                       else {Map_OnCodesOf(I, CT, &PruneInherit); return (Total - TotalUnvalid);}
                      }
       if (_TAGGING_PHASE == false) PRI((int) Total);
      }
}
/*----------------------------------*/
/* Alpha = MaxSeqProb(0...i) and Beta = MaxSeqProb(j...n)
   for all N in [i, j]: Prob(N, i, j) = Alpha x Beta x InsideXPrior(N);
*/
extern DuoPtr Duo;

void PruneEntryI(TableType TAB, int i, int j, ProbDomain RMax, ProbDomain OMax, Boolean Ended, Boolean Only_Valid_Items)
{ EntryPtr EPtr ; ProbDomain AlphXBet; Boolean FOUND_R = false;  Boolean FOUND_O = false; static Boolean TempB_R = false; 
  static Boolean TempB_O = false; Boolean NoPrunableItems = true;

   void PruneThis(ItemTree I)
    {TreeCodeT Rnum = 0; TreeCodeT Onum = 0;
     if (Prunable_Item(I) == true)
       {I->Attempt_Pruning_Item = false; /* must be set to false before pruning since PseudoValid is overloaded */
        Rnum = PruneInheritNodesOf(I, AlphXBet, ROOT_enum, RMax, &TempB_R);   
        if (_TAGGING_PHASE == false) Onum = PruneInheritNodesOf(I, AlphXBet, OTHERS_enum, OMax, &TempB_O); 
        else FOUND_O = true;
        if (TempB_O == true) FOUND_O = true; if (TempB_R == true) FOUND_R = true;
        I->Pruned_Item = CanBeRemovedItem(Rnum, Onum);
        AgainRedToValids(I, Rnum, Onum); 
        /* fprintf(stderr, "%d %d  %d \n", I->i, I->j, (int) Onum+Rnum); */
        NoPrunableItems = false;
       }
     else I->Attempt_Pruning_Item=false; /* 2002 NOT SURE */
    }

 _ToBeFreedRoots = NULL;    _ToBeFreedOthers = NULL; 
 EPtr = ENTRY_Of(TAB, i, j); AlphXBet = (*EPtr)->AlphaXBeta;  

 if ((RMax == MaxNutralConst) || (RMax == MultNutralConst)) FOUND_R = true;
 if ((OMax == MaxNutralConst) || (OMax == MultNutralConst)) FOUND_O = true;

 if ((*EPtr)->Size > 0) ByLevelEntryMapEnded((*EPtr), (void *) &PruneThis, Ended, Only_Valid_Items); 
 else {FOUND_R = true; FOUND_O = true;}

 if (NoPrunableItems == true)  {FOUND_R = true; FOUND_O = true;} 
 FreeDFPList(_ToBeFreedRoots); FreeDFPList(_ToBeFreedOthers); 

 if (FOUND_R == false)
  {fprintf(stderr,"Err R1: Pruning assumes that the maximum is in the entry (Ended==%d)!!\n",Ended); exit(1);}
 if (FOUND_O == false) 
  {fprintf(stderr,"Err O1: Pruning assumes that the maximum is in the entry (Ended==%d)!!\n",Ended); exit(1);}
}
/*----------------------------------------------------------------------*/
/* Pruning the items of an entry: either ended items or non-ended items */
void PruneEntry(TableType TAB, int i, int j, Boolean Ended, Boolean UnaryItems, Boolean Compact)
{EntryPtr EPtr; ProbDomain MaxRootProb; ProbDomain MaxOthsProb;
 enum VERSION_TYPE TEMP = _VERSION ;

 _VERSION = BEAM_THRESH; 
 InitRatioVars(); InitMaxProbNonTArray();

 if ((_APPLY_PRUNE == true) && (TOO_LARGE_Thresholds() == false) && (_DisambiguateB == true))
   if ((_GLOBAL_THRESH_ENABLED == false) || (Ended == false) || (UnaryItems == true) ||
       ((ParsingMethod == _BOTH_G) && (Active_Grammar_Number == 2)) )   /* see ref glob-thresh */
  {_InternRedDerF = RedDerForest; 
    MaxRootProb = Max_InXPrior(TAB,i, j, ROOT_enum, Ended, true);
    SetBeamValue(Ended, i, j);

    if (_PRUNE_OTHER_DFPs == true) MaxOthsProb = Max_InXPrior(TAB,i, j, OTHERS_enum, Ended, true);
    else MaxOthsProb = MultNutralConst;

   EPtr = ENTRY_Of(TAB, i, j); /* (*EPtr)->AlphaXBeta = MultNutralConst; */

   PruneEntryI(TAB, i, j, MaxRootProb, MaxOthsProb, Ended, (Negate(Semi_Interleaved)));

   if ((_REMOVE_PRUNED_ITEMS == true) && (Compact == true))
                       MakeCompactEntry(TAB, i, j, _sen_length);
  }
 _VERSION = TEMP;
}             
/*****************************************************************************************************/
/*****************************************************************************************************/
/*********************************************************************************/
/* REDUCING DERIVATION-FORESTS */
/*********************************************************************************/
/* Reduces the  DFPs that were pruned out (marked as unvalid */
void AgainRedToValids(ItemTree IT, TreeCodeT Rnum, TreeCodeT Onum)
{TreeCodeT i,j, rsizeBefRed, osizeBefRed, WasAt; 
 TreeCodeT RsizeTemp, OsizeTemp; DerFPtr RootDFTemp;
 ProbDomain MaxR = MaxNutralConst; ProbDomain SumR = SumNutralConst;
 ItemCPtr ICP; DerFPtr Roots; DerFPtr Others;
    void Red_ROOTS()
     {j = 0;
      if (Rnum > 0)
        for (i=0; i < rsizeBefRed; ++i)
         {WasAt = (Roots[i]).CAdr; 
          if (ICP->R_valids[WasAt] == true)
             {CpyDerFPtr(&(ICP->Roots[j]), &(Roots[i])); ICP->R_NowAtPos[WasAt] = j; j++;}
          else ICP->R_NowAtPos[WasAt] = _C_Addr_UNV ;
         }
      else {for (i=0; i < rsizeBefRed; ++i) {ICP->R_NowAtPos[i] = _C_Addr_UNV; ICP->R_valids[i] = false;} }
     }/*--------*/
     void Red_OTHERS()
      {j = 0;
       if (Onum > 0) 
        for (i=0; i < osizeBefRed; ++i)
           {WasAt = (Others[i]).CAdr; 
            if (ICP->O_valids[WasAt] == true) 
               {CpyDerFPtr(&(ICP->Others[j]), &(Others[i])); ICP->O_NowAtPos[WasAt] = j; ++j;}
            else ICP->O_NowAtPos[WasAt] = _C_Addr_UNV ; 
           }
       else {for (i=0; i < osizeBefRed; ++i) {ICP->O_NowAtPos[i] = _C_Addr_UNV; ICP->O_valids[i] = false;} }
      }/*-------*/ 

 if (IT != NULL) {
  ICP = (ItemCPtr) IT->DerForest; 
  if (ICP != NULL) {
    Roots = ICP->Roots; Others = ICP->Others;

    rsizeBefRed = ICP->RootsSize; osizeBefRed = ICP->OthersSize; 

    /* PRI(rsizeBefRed); PRI(Rnum); PRS("           "); PRI(osizeBefRed); PRI(Onum); PRS("\n"); */

    if (_InternRedDerF == true) 
     {ICP->RootsSize = Rnum; ICP->OthersSize = Onum;

     if (rsizeBefRed != Rnum) 
       {
        if (Rnum > 0) ICP->Roots = ALLDerFPtr(Rnum, ROOT_enum);
        else ICP->Roots = NULL;
        Red_ROOTS();
        /* See refFree */
        _ToBeFreedRoots = EnterPStack((void *) Roots, _ToBeFreedRoots); 
       }

     if (osizeBefRed != Onum) 
       {
        if (Onum > 0) ICP->Others = ALLDerFPtr(Onum, OTHERS_enum); 
        else ICP->Others = NULL;
        Red_OTHERS();
        /* See refFree */
        _ToBeFreedOthers = EnterPStack((void *) Others, _ToBeFreedOthers);
      }

      /* cfree(Roots); cfree(Others);  done later */
      /* cfree(ICP->R_valids); cfree(ICP->O_valids); ICP->R_valids = NULL; ICP->O_valids = NULL; */
      /* IT->DerForest = (void *) ICP; */
    }
  } /* end of if ICP is NULL */
 else {fprintf(stderr,"Err: AgainRed... item has a NULL DerForest ?\n"); exit(1);}
 } /* end of if IT is NULL */
}
/*********************************************************************************/
/***
  References:

   refEfficComp
     We compute each Max_Seq_Prob once and save it in a table in order to improve
     the efficiency.

  refCurSeqMax 
     For a given L: we inspect all possible sequences of nodes from [0,k_0]...[k_h, n] 
     (for any k_0,...,k_h), such that (k_i - k_(i-1))<= L. Cur_SeqMaxProb contains the
     largest probability of such sequence.

  refAlphaBeta:
   Function Max_Seq_Prob
   Finds the maximum probability of a sequence of nodes SEQ = N_0,...,N_h, where
   each N_x belongs to some entry [K_x, K_{x+1}], for 0<=x<=h (K_0=i and K_{h+1}=j),
   and each entry [K_x, K_{k+1}] fulfills: (K_{x+1}-K_x) <= L.
   Thus, we choose sequences of nodes from sequences of entries [i,K_1][K_1,K_2]...[K_h,j], 
   (each node in an entries spans at most L words), and the we maximize over their probabilities.
   The probability of the sequence of nodes SEQ is defined by
 
        \product_{x=0}^{h} InXPrior(N_x, K_x, K_{x+1})
   
   where InXPrior(N_x, K_x, K_{x+1}) = Inside(N_x, K_x, K_{x+1}) x  Prior(N_x) .

  refVERSION
    Depending on _VERSION: compute the maximum prob of a sequence (GLOBAL_THRESH)
                           compute the maximum prob of every entry (BEAM_THRESH);

  refOTHERS: when the code is of type OTHERS_enum, it can be equal to 1.0 before reaching
             a root of a subtree. These should not be included in the pruning.

  ref Unaries:
  Unaries result from complete: they inherit and prune 

  refFreeing:
    We can free DFS but we need them first in order to redirect the
    MPD_LPtr of other DFSs that point to them.
*/
/****************************************************************************************************************************************/
/****************************************************************************************************************************************/
/****************************************************************************************************************************************/
/**********************************************************************************/
/*           GLOBAL THRESHOLDING                                                  */
/*                                                                                */
/* ONLY FOR ENDED ITEMS THAT ARE not unary ITEMS (AVOIDNING TROUBLE)              */
/**********************************************************************************/
/* This pruning is meant for PCFGs only. That is why only roots are addressed: it is     */
/* very hard to imagine what to do with the mixture of roots and internal nodes in STSGs */

/* Arrays for GLOBAL THRESHOLDING */
#define A_MAX 120
 
static Boolean _TABLE_INITIALIZED = false;
static ProbDomain MAX_TO_RIGHT_TABLE[A_MAX];
static ProbDomain MAX_TO_LEFT_TABLE[A_MAX];
 
 
void InitMAX_TO_RIGHT_TABLE()
{int i;
  for (i=0; i < A_MAX; i++) MAX_TO_LEFT_TABLE[i]=MaxNutralConst;
  MAX_TO_LEFT_TABLE[0] = MultNutralConst;
  for (i=0; i < A_MAX; i++) MAX_TO_RIGHT_TABLE[i]=MaxNutralConst;
  MAX_TO_RIGHT_TABLE[_sen_length] = MultNutralConst;
}
void UpdateMAX_TO_LEFT_TABLE(int i, ProbDomain PROB)
{Boolean VOIDB;  MAX_TO_LEFT_TABLE[i] = MaxProbs(MAX_TO_LEFT_TABLE[i], PROB, &VOIDB);
}
void UpdateMAX_TO_RIGHT_TABLE(int i, ProbDomain PROB)
{Boolean VOIDB;  MAX_TO_RIGHT_TABLE[i] = MaxProbs(MAX_TO_RIGHT_TABLE[i], PROB, &VOIDB);
}
ProbDomain ValOf_MAX_TO_RIGHT(int i) {return MAX_TO_RIGHT_TABLE[i]; }
ProbDomain ValOf_MAX_TO_LEFT(int i) {return MAX_TO_LEFT_TABLE[i]; }
/****************************/


Boolean DO_OTHERS_ALSO = false;
/*----------*/
void SetAllItemsPrunable(TableType TAB, int n, int L)
{ void SetItemPrunable(ItemTree I)               
          {char temp[MaxRule]; 
           if (I !=NULL) {
	     strcpy(temp, Name(LHS_OfItem(I)));
             if (strstr(temp,"sss")!=NULL) ; /* FRIDAY HECTIC CHANGE do not prune those: these are backoff! */
	     else I->Attempt_Pruning_Item = true;
	   }
	  }
  void SetThisEntry(int i, int j, EntryPtr EPtr) 
        {SetsMap(*EPtr, (void *) &SetItemPrunable);}

 MapOnEntriesForSpan(TAB, L, n, (void *) &SetThisEntry); 
}
/* computing the maximuma for the items of an entry: either ended items or non-ended items */
void ComputeMaxForEntry(TableType TAB, int i, int j, Boolean Ended)
{EntryPtr EPtr; ProbDomain MaxRootProb; ProbDomain MaxOthsProb;
 
  {_InternRedDerF = RedDerForest; 
    MaxRootProb = Max_InXPrior(TAB,i, j, ROOT_enum, Ended, false);

    if (_PRUNE_OTHER_DFPs == true) MaxOthsProb = Max_InXPrior(TAB,i, j, OTHERS_enum, Ended, false);
    else MaxOthsProb = MultNutralConst;

   EPtr = ENTRY_Of(TAB, i, j); (*EPtr)->RMax_Node_Prob = MaxRootProb; (*EPtr)->OMax_Node_Prob = MaxOthsProb;
   (*EPtr)->AlphaXBeta = MaxNutralConst;
  }
}
/*--*/
void PruneEntryGT(TableType TAB, int i, int j, ProbDomain RMax, ProbDomain OMax, Boolean Ended, Boolean Only_Valid_Items)
{ EntryPtr EPtr ; Boolean TempB_R; Boolean TempB_O; ProbDomain AlphXBet; Boolean NoPrunableItems = true;

   void PruneThis(ItemTree I)
    {TreeCodeT Rnum = 0; TreeCodeT Onum = 0;
     if (Prunable_Item(I) == true)
       {I->Attempt_Pruning_Item = false; /* must be set to false before pruning since PseudoValid is overloaded */
        Rnum = PruneInheritNodesOf(I, AlphXBet, ROOT_enum, RMax, &TempB_R);
        Onum = PruneInheritNodesOf(I, AlphXBet, OTHERS_enum, OMax, &TempB_O);
        I->Pruned_Item = CanBeRemovedItem(Rnum, Onum);
        AgainRedToValids(I, Rnum, Onum);
       }
     else I->Attempt_Pruning_Item=false; /* 2002 NOT SURE */
    }

 _ToBeFreedRoots = NULL;    _ToBeFreedOthers = NULL; 
  EPtr = ENTRY_Of(TAB, i, j); AlphXBet = (*EPtr)->AlphaXBeta;

  if ((*EPtr)->Size > 0) ByLevelEntryMapEnded((*EPtr), (void *) &PruneThis, Ended, Only_Valid_Items);
  FreeDFPList(_ToBeFreedRoots); FreeDFPList(_ToBeFreedOthers);
}
/*--*/
ProbDomain Max_EntryProb(EntryPtr EPtr, Code_Soort soort)
{switch (soort) {
  case ROOT_enum   : return (*EPtr)->RMax_Node_Prob; break;
  case OTHERS_enum : return (*EPtr)->OMax_Node_Prob; break;
 };
}
void UpdateAlphaXBetaOfEntry(EntryPtr EPtr, ProbDomain Max_AlphaXBeta, Code_Soort soort)
{(*EPtr)->AlphaXBeta = Max_AlphaXBeta;
}
/*
void UpdateMaxToRightOfEntry(EntryPtr EPtr, int i, int j, ProbDomain NewMax)
{Boolean VOIDB; (*EPtr)->Max_Prob_To_Right  = MaxProbs((*EPtr)->Max_Prob_To_Right, NewMax, &VOIDB);
}
ProbDomain MaxToRightOfEntry(EntryPtr EPtr)
{return (*EPtr)->Max_Prob_To_Right;
}
*/
/*-------------------*/

ProbDomain MaxPathProbToRight(TableType TAB, int L, int n,  Code_Soort soort, ProbDomain Max_ProbToLeft)
{int end; int start; Boolean VOIDB; int i; int max_possible_span; ProbDomain NextMax_ProbToLeft;
 ProbDomain MAX_AlphaXBeta_PROB = MaxNutralConst; ProbDomain Max_Prob_ToRight = MaxNutralConst; 
 ProbDomain Overall_Max_ToRight = MaxNutralConst; ProbDomain NextMax_ProbToRight = MaxNutralConst;
 ProbDomain Max_Prob_ToLeft = MaxNutralConst;
 
 max_possible_span = L;

 for (start = 0; start < n; start++)                          /* for all start positions update their end positions */
  {i=max_possible_span; /* for (i=1; i <= max_possible_span; i++) XXXX */ 
   if (start+i <= n)
   {EntryPtr EPtr = ENTRY_Of(TAB, start, start+i); 
    ProbDomain ProbOfEntry = Max_EntryProb(EPtr, soort); 
    NextMax_ProbToLeft = MultProbs(ProbOfEntry, ValOf_MAX_TO_LEFT(start)); 
    UpdateMAX_TO_LEFT_TABLE(start+i, NextMax_ProbToLeft);
   }
  }

 for (end = n; end > 0; end--)                              /* for all end positions update their start positions */
  {i=max_possible_span; /* for (i=1; i <= max_possible_span; i++) XXXX */
   if (end-i >= 0)
   {EntryPtr EPtr = ENTRY_Of(TAB, end-i, end); 
    ProbDomain ProbOfEntry = Max_EntryProb(EPtr, soort); 
    NextMax_ProbToRight = MultProbs(ProbOfEntry, ValOf_MAX_TO_RIGHT(end)); 
    UpdateMAX_TO_RIGHT_TABLE(end-i, NextMax_ProbToRight);
   }
  }

 for (start = 0; start < n; start++)                       /* for every entry compute the alphaXbeta value */
  {i=max_possible_span; /* for (i=1; i <= max_possible_span; i++) XXXX */
   if (start+i <= n)
    {EntryPtr EPtr = ENTRY_Of(TAB, start, start+i);  
     ProbDomain ProbOfEntry = Max_EntryProb(EPtr, soort);
     Max_Prob_ToLeft = ValOf_MAX_TO_LEFT(start);
     Max_Prob_ToRight = ValOf_MAX_TO_RIGHT(start+i); 
     MAX_AlphaXBeta_PROB = MultProbs(Max_Prob_ToRight, Max_Prob_ToLeft);
     UpdateAlphaXBetaOfEntry(EPtr, MAX_AlphaXBeta_PROB, soort);          
     Overall_Max_ToRight = MaxProbs(Overall_Max_ToRight, MultProbs(MAX_AlphaXBeta_PROB,ProbOfEntry), &VOIDB);    

    }
  }

 return Overall_Max_ToRight;
}
/*---------------------------------------------------*/
void PruneForLengthGT(TableType TAB, int n, int L)
{ProbDomain RMax, OMax;
  void CompMaxPerEntry(int i, int j, EntryPtr EPtr) {ComputeMaxForEntry(TAB, i, j, true);}       

  void PrunePerSpanEntry(int i, int j, EntryPtr EPtr) 
    {Boolean NoPrunableItems = false;
     PruneEntryGT(TAB, i, j, RMax, OMax, true, false);

     if (_REMOVE_PRUNED_ITEMS == true) MakeCompactEntry(TAB, i, j, n);
    }

 RMax = MaxNutralConst; OMax = MaxNutralConst;
 if (L == 2 ) /* L>1: XXXX added on 2 March 2002 */
    MapOnEntriesForSpan(TAB, L-1, n, (void *) &CompMaxPerEntry); /* compute maxima for all span L-1 (last pruned) entries refUNA*/

 MapOnEntriesForSpan(TAB, L, n, (void *) &CompMaxPerEntry); /* compute maxima for all span L entries */

 RMax = MaxPathProbToRight(TAB, L, n, ROOT_enum, MultNutralConst); 
 if (DO_OTHERS_ALSO == true) OMax = MaxPathProbToRight(TAB, L, n, OTHERS_enum, MultNutralConst);
 else OMax = MultNutralConst;
 
 MapOnEntriesForSpan(TAB, L, n, (void *) &PrunePerSpanEntry); /* prune for all span L entries */
}
/*--*/
void PruneForLength(TableType TAB, int n, int L)
{enum VERSION_TYPE TEMP = _VERSION ;
 InitRatioVars(); if (_TABLE_INITIALIZED == false) {InitMAX_TO_RIGHT_TABLE(); _TABLE_INITIALIZED = true;}

 if (Semi_Interleaved == true)
  if ((_APPLY_PRUNE == true) && (TOO_LARGE_Thresholds() == false) && (_DisambiguateB == true) && (_GLOBAL_THRESH_ENABLED == true) )
  {_InternRedDerF = RedDerForest; 
   _VERSION = GLOBAL_THRESH;
    SetAllItemsPrunable(TAB, n, L);
    PruneForLengthGT(TAB, n, L); 
   _VERSION = TEMP;
  } 
}
/******************************************/
/* REFERENCES                             */
/* Reference  ref glob-thresh 
   Globals thresholding is used only for pruning the terminal items and those items introduced by DEDEUCE.
   Thus, unary and not-ended items are pruned by PruneEntry and Global-Thresholding prunes the basic-ended items.

   In the double-parser: for the second grammar we do not use global thresholding since the OUTSIDE probs of the first grammar 
   serve for pruning.
*/
/* refUNA
  Because GTpruning takes place only on ended items (before complete takes place), unary items are not taken into consideration
  and we must recalculate
*/
/************************************************************************************************************************/
/* AN OVIS VERSION */
Boolean BackOff_ItemOVIS(ItemTree I)
{char lhs[SymLength]; char rhs[SymLength];

 if (_OVIS_BKF_Pruning == false) return false;

 strcpy(lhs, Name(LHS_OfR(I->RuleNo, I->RT))); strcpy(rhs, Name(RHS1_OfR(I->RuleNo, I->RT)));

 if (I->RT != _Unary)
  if ((strstr(lhs,"-L@") == NULL) && (strstr(lhs,"-R@") == NULL))  /* not a tgram node */
    if (strchr(lhs,'x') != NULL) return false;  /* semantics ? */
    else return true; /* backoff on semantics */
  else /* is the Markov there ? */
    if ((strstr(lhs,"-LL") != NULL) || (strstr(lhs,"-RR") != NULL)) return false;
    else return true; /* backoff on Markov */
 else if ((strchr(lhs,'x') != NULL) && (strchr(rhs,'x') == NULL)) return true; /* semantics is not on rhs but on lhs: bkf unary*/
      else return false; /* non-backoff unaries */

 return true;
}

