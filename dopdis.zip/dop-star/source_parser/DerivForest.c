
#include "./ALL.h"
#include "./Debug.h"
#include "./NgramProbModule.h"
#include "./OptimizeLexicals.h"

/**********************************************************/
#define lambda ((ProbDomain) 0.6666)
#define Lambda (log10(lambda))
#define OneMinLambda  ((lambda==1) ?  MaxNutralConst : (log10(1 - lambda)))
/**********************/

ProbDomain InterpolatedProbValue(ProbDomain MPD, ProbDomain NGRAM)
{ProbDomain P1,P2; /* fprintf(stderr,"%e    \n", NGRAM); */
 if (_interpolate_ngram == false)  return MPD;
 else if (lambda==1) return MPD; 
      else if (lambda==0) return NGRAM;
      else
      {if (MPD==MultNutralConst) return MultNutralConst;
       if (NGRAM==MultNutralConst) return MPD;

       P1 = MultProbs(Lambda, MPD); P2= MultProbs((OneMinLambda), NGRAM);
       return (SumProbs(P1,P2)); 
      }
}
/* became a dummy after removing the Ngram probs */
inline ProbDomain InterpolatedProb(DerFPtr DFP)
{return DFP->MPD_Prob;
}
inline ProbDomain ProbOfDFP(DerFPtr DFP) {return DFP->MPD_Prob; }
/******************************/
extern void ShowDerF(ItemTree I);
extern void Vprntself(void *DF);
extern void PrntDList(PtrList PL);
extern C_Addr_Domain *AllocPos(TreeCodeT Size);
extern void ShowTestHere1(DerFPtr DFp);


int I, J;

void FreeDFPtr(DerFPtr DFP)
{if (DFP != NULL)
   {FreePDList(DFP->ListOfChNodes); 
    free(DFP);
   }
}
void FreeDFPsListOfChNodes(DerFPtr DFP)
{if (DFP != NULL)
   {FreePDList(DFP->ListOfChNodes);DFP->ListOfChNodes = NULL;}
}
/**/
TreeCodeT RootsSizeOfDF(ItemCPtr IC)
{if (IC == NULL) return 0;
 else return IC->RootsSize;
}
TreeCodeT OthersSizeOfDF(ItemCPtr IC)
{if (IC == NULL) return 0;
 else return IC->OthersSize;
}
/**********************/
/* WHY THIS MODULE ?
   To save space we have the address of a code
   in its array of codes. The address is in fact
   its place-number in the array (we call it place holder).
   Since this address belongs to a given item
   and hangs under either a root-list or a non-roots-list
   then its always possible to get its value and prob.
*/
/****************************/
/* DerFPtr type */
/****************************/
/**********************/
/* Allocates space for m code place holders */
/**********************/
void InitDerFPtr(DerFPtr target, Code_Soort CT)
{target->MPD_Prob = (ProbDomain) MaxNutralConst;
 target->Sum_Prob = (ProbDomain) SumNutralConst;
 target->DF_OUTSIDE_PROB = (ProbDomain) SumNutralConst;

 target->MPD_PtrL = NULL;
 target->MPD_PtrR = NULL;
 target->SelfItem = NULL;
 target->ListOfChNodes = NULL;

 target->CAdr = 0;
 target->CSoort = CT;
 target->OpenTrees = NEITHER_enum;
 /* target->num_of_roots_in_der =0; */
 
 target->TempProb= (ProbDomain) SumNutralConst;
}
/*--------------------------------*/
/* template:
FillDFPtr(target, MPD_Prob, Sum_Prob, MPD_PtrL, MPD_PtrR, SelfItem, CAdr, CSoort, ListOfChNodes, OpenTrees)
*/
void FillDFPtr(DerFPtr target,
               ProbDomain MPD_Prob, ProbDomain Sum_Prob,
               DerFPtr MPD_PtrL, DerFPtr MPD_PtrR,
               ItemTree SelfItem, C_Addr_Domain  CAdr, Code_Soort  CSoort,
               PtrList ListOfChNodes, OTS_Type OpenTrees)
{target->MPD_Prob = MPD_Prob;
 target->Sum_Prob = Sum_Prob;
 target->MPD_PtrL = MPD_PtrL;
 target->MPD_PtrR = MPD_PtrR;
 target->SelfItem = SelfItem;
 target->CAdr = CAdr;
 target->CSoort = CSoort;
 target->ListOfChNodes = ListOfChNodes;
 target->OpenTrees = OpenTrees;
 target->DF_OUTSIDE_PROB = SumNutralConst;
 /* target->num_of_roots_in_der =0; */

 target->TempProb=MaxNutralConst;
}
/*-----------------------------*/
DerFPtr ALLDerFPtr(TreeCodeT Num, Code_Soort CT)
{DerFPtr DFP;
 TreeCodeT i;
 if (Num == 0) DFP = NULL ;
 else {DFP = (DerFPtr) MultAlloc(Num, sizeof(struct DerFor_Struct));
       for (i=0; i < Num; ++i) InitDerFPtr(DFP+i, CT);
      }
 return DFP;
}
/***/
inline
DOTPLACE DotOf(DerFPtr DF)
{return DF->SelfItem->Dot;
}
/****/
/* Originally: Child of DFp is reduced iff:
    either RedDerForest is true 
    or     RedDF_CEntries is true and the parent has a rm-dot, i.e. is a Binary item A->BC*. 
   See refChDF_Reduced
   Later On I went back to reducing only after Deduce !!
   So the only children-DF that are reduced are those of A->BC*
*/
inline
Boolean Version_Reduced(ItemTree I)
{if (RedDerForest == true) return true;
 else if ((RedDF_CEntries == true) && (I->Dot==rm)) return true;
      else return false;
}
inline
Boolean ChDF_Reduced(DerFPtr DFp, DerFPtr DFch)
{if (RedDerForest == true) return true;
 else if (DFch == NULL) return false;
 else if ((RedDF_CEntries == true) && ((DotOf(DFch))==rm)) return true;
      else return false;
}
/************************************************************/
/* Important: does not copy ListOfChNodes */
void CpyDerFPtr_Partial(DerFPtr target, DerFPtr source)
{/* OLDVER Cpy1  */
 FillDFPtr(target, source->MPD_Prob, source->Sum_Prob, source->MPD_PtrL, source->MPD_PtrR,
           source->SelfItem, source->CAdr, source->CSoort, NULL,  source->OpenTrees);

 target->DF_OUTSIDE_PROB = source->DF_OUTSIDE_PROB;
 /* target->num_of_roots_in_der = source->num_of_roots_in_der; */
}
/* Copies all */
void CpyDerFPtr(DerFPtr target, DerFPtr source)
{/* OLDVER Cpy1  */
 FillDFPtr(target, source->MPD_Prob, source->Sum_Prob, source->MPD_PtrL, source->MPD_PtrR,
           source->SelfItem, source->CAdr, source->CSoort, source->ListOfChNodes,  source->OpenTrees);

 target->DF_OUTSIDE_PROB = source->DF_OUTSIDE_PROB;
 /* target->num_of_roots_in_der = source->num_of_roots_in_der; */
}
/************************/
/************************/
void MultDFProbability(ItemTree I, DerFPtr DFp, Code_Soort CT)
{ProbDomain P = MultNutralConst;
 P = CodeProbability(I, DFp, CT); 
 DFp->MPD_Prob = MultProbs(DFp->MPD_Prob, P);
 DFp->Sum_Prob = MultProbs(DFp->Sum_Prob, P);
}
/*---
 Extra on usual copy: lets the code point to its item and multiplies all probabilities with code-probs except for A->B*C.
  --*/
void CpyDerFPtrEx(ItemTree IT, DerFPtr target, DerFPtr source, Code_Soort CT)
{ProbDomain P;
 {/* changed from OldMultPractice1 to the following */
  FillDFPtr(target, source->MPD_Prob, source->Sum_Prob, source->MPD_PtrL, source->MPD_PtrR,
                   IT, source->CAdr, source->CSoort, source->ListOfChNodes,  source->OpenTrees);     
  MultDFProbability(IT, target, CT);  /* we do all the necessary multiplications here */
 }

 target->DF_OUTSIDE_PROB = source->DF_OUTSIDE_PROB;
 /* target->num_of_roots_in_der = source->num_of_roots_in_der; */
}
/************************/
/* Update first by second: the second is the temporary DFPtr used to calculate the
   maximum for a substitution: for all substitution-sites of target, only for first one
   we do the calculation over all roots of the child: for the other sub-sites we
   update them by what we kept in the temp (which is source here).
   This function does the update.
*/
void Update_OpenTree_DFPtr(DerFPtr target, DerFPtr source, Child_Type ChNum, Code_Soort CT )
{Boolean First = false; Boolean FirstFinal = false;

  {/* First will be now the choice of the maximum interpolated measure of DOP and Ngram  probs */
    (MaxProbs(ProbOfDFP(source), ProbOfDFP(target), &FirstFinal)); 
    if (FirstFinal == true) target->MPD_Prob = source->MPD_Prob; 
    First = FirstFinal; 
  }

 switch (ChNum) {
    case Lch_enum : if (First == true) {target->MPD_PtrL = source->MPD_PtrL;
                                       }
            /* order important: the following puts source's list at the end of target's list */
            target->ListOfChNodes =  MergePL(source->ListOfChNodes, target->ListOfChNodes); 
                                
            if (1==0) DEBUG000;
           break;
    case Rch_enum : if (First == true) {target->MPD_PtrR = source->MPD_PtrR; 
                                        }
         if (source->ListOfChNodes != NULL) {
            /* for a target DFP of an item A->B*C i.e. ItemIJ we stack the DFP */
           if (target->ListOfChNodes == NULL) /* only first time: rest we stack the children */
            target->ListOfChNodes = EnterPStack((void *) target, target->ListOfChNodes);
                     /* next: we should make a copy of the list but for efficiency we don't: see refO1 */
           (target->ListOfChNodes)->Data = MergePL((PtrList) (source->ListOfChNodes)->Data, (PtrList) (target->ListOfChNodes)->Data);
            if (1==0) DEBUG001;
         }
           break;
      } /* switch */                        

 /* if (First == true) target->num_of_roots_in_der = source->num_of_roots_in_der; *//* updating the number of substitutions in derivation */

 target->Sum_Prob = SumProbs(target->Sum_Prob, source->Sum_Prob);
}
/*--------------------*/
/********************************************************************/
/*********************/
/* The multiplication of two codes !! Checking their viability */
/*********************/
Boolean MultDFPtrs(DerFPtr DFp, DerFPtr DFch, Child_Type ChNum, NodePtr NPp, NodePtr NPch)
{Boolean First = false; Boolean FirstFinal = false; 

 if ((IsViable(NPp, NPch, ChNum)) == true)
  {/* short int old_num_of_roots_in_der = ((DFp->num_of_roots_in_der == 0) ? 0 : (DFp->num_of_roots_in_der -1)); */

 /** if (_interpolate_ngram==false) DFp->MPD_Prob = 
    MaxProbs(((ProbDomain)  DFch->MPD_Prob), ((ProbDomain) DFp->MPD_Prob), &First); updating the parent MPD else interpolate with Ngram */

    {/* First will be now the choice of the maximum interpolated measure of DOP and Ngram  probs */
     (MaxProbs(ProbOfDFP(DFch), ProbOfDFP(DFp), &FirstFinal)); 
     if (FirstFinal == true) DFp->MPD_Prob = DFch->MPD_Prob;
     First = FirstFinal; 
    }

 if (1==0) DEBUGIBefore00;

   switch (ChNum) {
      case Lch_enum : if (First == true) 
                        {DFp->MPD_PtrL = DFch; 
                        }
             if (_Whole_DFSpace == true) /* build whole derivation-forest (not doing MPD) */
                  DFp->ListOfChNodes = EnterPStack((void *) DFch, DFp->ListOfChNodes);
                break;
      case Rch_enum : if (First == true) 
                        {DFp->MPD_PtrR = DFch; 
                        }
             if (_Whole_DFSpace == true) {
               if (DFp->ListOfChNodes == NULL)  /* only first time: rest we stack the children */
                     DFp->ListOfChNodes = EnterPStack((void *) DFp, DFp->ListOfChNodes);
             EnterToDataOfFirst((void *) DFch, (PtrList) (DFp->ListOfChNodes));

             if (1==0) ShowTestHere1(DFp); /* just for exploring values */
             } 
                break;
          otherwise : fprintf(stderr, "Err: ChNum in MultDFPtrs\n"); break;
   } /* end of switch */

       /* summing up all children der's-probs in DFp->Sum_Prob, later on they are multiplied with prob of parent-code*/
   DFp->Sum_Prob = SumProbs(DFch->Sum_Prob, DFp->Sum_Prob);

   /* if (First == true) * updating the number of substitutions in derivation *
        {if (IsRoot(&(NPp->Code)) == true) DFp->num_of_roots_in_der = DFch->num_of_roots_in_der + 1;
         else  DFp->num_of_roots_in_der = DFch->num_of_roots_in_der;
        }
   */

 if (1==0) DEBUGIAfter00;

   return true;
  }
 else return false;
}
/********************************/
/*****************************/
/* BfPtr2 is always the child-item buffer while BfPtr1 is for the Parent-Item. 
   The child code (represented by This) must be an OTHERS_enum code
   since it is internal to a subtree
*/
inline TreeCodeT WhereIsChildOf(C_Addr_Domain P_CAdr, Code_Soort CT, Child_Type Chnum, Boolean *Found)
{PlacesT This; PlacesT Diff; Ch_Ptr TheBuffer;
 *Found = false;   TheBuffer = PtrToChsBuff(CT); 
 if (TheBuffer == NULL) {*Found = false; return _C_Addr_UNV;}
 else
 switch (Chnum) {
   case Lch_enum : This = (TheBuffer[P_CAdr]).LeftCh;
                   break;
   case Rch_enum : This = (TheBuffer[P_CAdr]).RightCh;
                   break;
  };
 if (BfPtr2->StartP == -1) {PRS("Error Problems with buffering\n"); exit(1);}
 else Diff = This - (BfPtr2->StartP + (BfPtr2->RApps->Roots_Size * ((TreeCodeT) sizeof(struct Node_Type))));
 /* If child of this code belong to another rule (item) than this child-item */
 /* then This does not point right (Diff < 0) or ....and should be discarded */ 
 if (Diff < 0) {*Found = false; return _C_Addr_UNV;}
 else if (Diff >= (BfPtr2->RApps->Others_Size* (TreeCodeT) sizeof(struct Node_Type))) 
          {*Found = false; return _C_Addr_UNV;}
      else {*Found = true; return ((TreeCodeT) (Diff / (TreeCodeT) sizeof(struct Node_Type)));}
}
/*****************************/
/* O_valids and R_valids arrays type */
/*****************************/
/* CONTEXT : if a code is viable with any of its children
   then it is marked valid. This is done in a
   speacial array parallel to the array of code place 
   holders which tells whether the code should remain
   or not in the Derivations forest of an item.

   This function just does the update.
*/
int AddrCMP(e1, e2)
  const void *e1;
  const void *e2;
{C_Addr_Domain v1 = ((DerFPtr) e1)->CAdr;
 C_Addr_Domain v2 = ((DerFPtr) e2)->CAdr;
 return ((v1 < v2) ? -1 : (v1 > v2) ? 1 : 0);
}
/*******************/
TreeCodeT BFIND(DerFPtr *Arr, TreeCodeT Leng, C_Addr_Domain CA)
{DerFPtr Key = (DerFPtr) ALLDerFPtr(1, ROOT_enum); /* ROOT_enum is fake */
 DerFPtr HERE;
 Key->CAdr = CA;
 if (Leng == 0) return 0;
 else {
 HERE = (DerFPtr) bsearch((void *) Key, (void *) &(*Arr)[0],
                                  (size_t) Leng, (sizeof(struct DerFor_Struct)),
                                   &AddrCMP);
 FreeDFPtr(Key);
 if (HERE != NULL)
     return (TreeCodeT) (HERE - *Arr) ;
 else {return 0;}
 }
}
/****************/
/* See RefIsValid: Checks if already valid and returns also its index */
inline Boolean IsValidCodeN(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT, TreeCodeT *This)
{TreeCodeT Place; TreeCodeT Place2;
 Boolean RES;
 if (ICP == NULL) {PRS("IsValidCode Err: ICP NULL\n"); return false ; }
 else { 
 switch (CT) {
   case ROOT_enum  : if (ICP->RootsSize != 0) {
                     if (RedDerForest == true)  
                        { Place = ICP->R_NowAtPos[CA]; /* Place = BFIND(&(ICP->Roots), ICP->RootsSize, CA); */}
                     else Place = CA;
                     if (Place == _C_Addr_UNV) RES = false;
                     else if ((Place >= 0) && (Place < ICP->RootsSize)) RES = (ICP->R_valids[Place]);
                          else RES = false;
                     *This = Place;
                     }
                     else {RES = false; *This = 0;}
                      break;
   case OTHERS_enum : if (ICP->OthersSize != 0) {
                     if (RedDerForest == true)  
                        {Place = ICP->O_NowAtPos[CA]; /* Place = BFIND(&(ICP->Others), ICP->OthersSize, CA); */}
                     else Place = CA;
                      if (Place == _C_Addr_UNV) RES = false;
                      else if ((Place >= 0) && (Place < ICP->OthersSize)) RES = (ICP->O_valids[Place]);
                           else RES = false;
                     *This = Place;
                      }
                      else {RES = false;*This = 0;}
                      break;    
   otherwise        : RES = false; break;
 }/*----*/
 return RES;
 }
}
/*********************/
/* Context: since a parent-code may take one and only one child-code
       of OTHERS on any of its branches then we search for this child
       using bsearch. This is possible cause the codes are ordered */
/********/
inline NodePtr ComputeChOf(NodePtr NPp, Child_Type Chnum)
{static struct Node_Type Node; NodePtr Ch = &(Node);
 Ch->Code.TreeC = NPp->Code.TreeC;
 Ch->Code.OwnC = (NPp->Code.OwnC * 2);
 if (Chnum == Rch_enum) Ch->Code.OwnC = Ch->Code.OwnC +1 ;
 return Ch;
}
/********/
TreeCodeT BFINDCodeG(DerFPtr *Arr, TreeCodeT Leng, 
                    NodePtr WantedC, Rule_Apps RAe2, Boolean *FOUND,
                    Code_Soort CT)
{
        int CodeCMP(const void *e1, const void *e2)
        {C_Addr_Domain v1 = ((DerFPtr) e1)->CAdr;
         C_Addr_Domain v2 = ((DerFPtr) e2)->CAdr;
          
         return (RelateCodes(WantedC, (NodePtrOf(v2, RAe2, CT))));
        }

 DerFPtr HERE;
 DerFPtr Key = (DerFPtr) ALLDerFPtr(1, ROOT_enum);/* ROOT_enum is fake */
 Key->CAdr = 0; /* just fooling bsearch */
 if (Leng == 0) {*FOUND = false; FreeDFPtr(Key); return 0; }
 else {
 HERE = (DerFPtr) bsearch((void *) Key, (void *) &(*Arr)[0],
                                  (size_t) Leng, sizeof(struct DerFor_Struct),
                                  CodeCMP);
 FreeDFPtr(Key);
 if (HERE != NULL)
     {*FOUND = true; return (TreeCodeT) (HERE - *Arr) ;}
 else {*FOUND = false; return 0;}
 }
}
inline
TreeCodeT BFINDCode(DerFPtr *Arr, TreeCodeT Leng, 
                    NodePtr WantedC, Rule_Apps RAe2, Boolean *FOUND)
{ return (BFINDCodeG(Arr, Leng, WantedC, RAe2, FOUND, OTHERS_enum));
}
/*********************/
inline
void UpdateValidCodeN(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT, TreeCodeT Place)
{if (ICP == NULL) PRS("UpdateValidCode Err: ICP NULL\n");
 else {
 switch (CT) {
   case ROOT_enum : if (ICP->RootsSize != 0) {
                     if ((Place == 0) && (ICP->Roots[0].CAdr != CA)); 
                     else ICP->R_valids[Place] = true;
                    }
                    else ;
                     break;    
   case OTHERS_enum : if (ICP->OthersSize != 0) {
                      if ((Place == 0) && (ICP->Others[0].CAdr != CA)) ;
                      else ICP->O_valids[Place] = true;
                    }
                    else ;
                      break;    
      otherwise        :  break;
 }/*----*/
 }
}
/*********************/
inline
void UpdateValidCode(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT)
{TreeCodeT Place;
 if (ICP == NULL) PRS("UpdateValidCode Err: ICP NULL\n");
 else {
 switch (CT) {
   case ROOT_enum : if (ICP->RootsSize != 0) {
                     Place = BFIND(&(ICP->Roots), ICP->RootsSize, CA);
                     /* PRS("Place");PRI(Place);PRS("\n");*/
                     if ((Place == 0) && (ICP->Roots[0].CAdr != CA)); 
                     else ICP->R_valids[Place] = true;
                    }
                    else ;
                     break;    
   case OTHERS_enum : if (ICP->OthersSize != 0) {
                      Place = BFIND(&(ICP->Others), ICP->OthersSize, CA);
                      if ((Place == 0) && (ICP->Others[0].CAdr != CA)) ;
                      else ICP->O_valids[Place] = true;
                    }
                    else ;
                      break;    
      otherwise        :  break;
 }/*----*/
 }
}
/****************/
inline
TreeCodeT NumOfValids(Boolean *C, TreeCodeT Size)
{TreeCodeT i, num;
 num = 0; for (i = 0; i < Size; ++i) if (C[i] == true) ++num;
 return num;
}
inline
Boolean NonEmptyICPtr(ItemCPtr ICP)
{if (ICP == NULL) return false;
 else if ((ICP->RootsSize == 0) && (ICP->OthersSize == 0)) return false;
      else return true;
}
inline
Boolean NonEmptyRootsICPtr(ItemCPtr ICP)
{if (ICP == NULL) return false;
 else if (ICP->RootsSize == 0) return false;
      else return true;
}
/**************/
/**************/
TreeCodeT TreeCodeOfDFP(DerFPtr DFP)
{Rule_Apps RA = Item_AppsOf(DFP->SelfItem);
 NodePtr NP = NodePtrOf(DFP->CAdr, RA, DFP->CSoort);
 return TreeCodeOfNP(NP);
}
TreeCodeT OwnCodeOfDFP(DerFPtr DFP)
{Rule_Apps RA = Item_AppsOf(DFP->SelfItem);
 NodePtr NP = NodePtrOf(DFP->CAdr, RA, DFP->CSoort);
 return OwnCodeOfNP(NP);
}
/* return OwnCode for the left child of DFP */
TreeCodeT Ch_OwnCodeOfDFP(DerFPtr DFP,  Child_Type Chnum)
{Rule_Apps RA = Item_AppsOf(DFP->SelfItem); NodePtr NP = NodePtrOf(DFP->CAdr, RA, DFP->CSoort);
 NodePtr CH_NP = ComputeChOf(NP, Chnum);
 return OwnCodeOfNP(CH_NP);
}
/*
**
*/
/********************************************************************************************************/
/********************************************************************************************************/
/* ItemCPtrs type                                                                                       */
/********************************************************************************************************/
/* Each item points to a structre which
   carries its root and non-root codes and their
   probabilities             
   Or in fact, it carries only arrays of place-holders
   for these codes.
*/
/*****************************/
ItemCPtr NewICPtr()
{ItemCPtr ICP = (ItemCPtr) AllocElem((size_t) sizeof(struct Item_DerFStr));
 ICP->R_NowAtPos = NULL;
 ICP->O_NowAtPos = NULL;
 ICP->R_valids = NULL;
 ICP->O_valids = NULL;
 ICP->Roots = NULL;
 ICP->Others = NULL;
 ICP->RootsSize = 0;
 ICP->OthersSize = 0;
 return ICP;
}
void FreeInsideDFPtr(DerFPtr DFP)
{if (DFP != NULL) FreePListN(DFP->ListOfChNodes); 
}

void FreeICPtr(ItemCPtr IC)
{if (IC != NULL)
  {if (IC->R_valids != NULL) cfree(IC->R_valids);
   if (IC->O_valids != NULL) cfree(IC->O_valids);
   if (IC->Roots != NULL) { MapOnNodesOf(IC, ROOT_enum, &FreeInsideDFPtr); cfree(IC->Roots); }
   if (IC->Others != NULL) { MapOnNodesOf(IC, OTHERS_enum, &FreeInsideDFPtr); cfree(IC->Others); }
   if (IC->O_NowAtPos != NULL) cfree(IC->O_NowAtPos);
   if (IC->R_NowAtPos != NULL) cfree(IC->R_NowAtPos);
   cfree(IC);
  }
}
void InitICPtr(ItemCPtr IC)
{if (IC != NULL)
  {if (IC->R_valids != NULL) cfree(IC->R_valids); IC->R_valids = NULL;	
   if (IC->O_valids != NULL) cfree(IC->O_valids); IC->O_valids = NULL;
   if (IC->Roots != NULL) cfree(IC->Roots); IC->Roots = NULL;
   if (IC->Others != NULL) cfree(IC->Others); IC->Others = NULL;
   if (IC->O_NowAtPos != NULL) cfree(IC->O_NowAtPos); IC->O_NowAtPos = NULL;
   if (IC->R_NowAtPos != NULL) cfree(IC->R_NowAtPos); IC->R_NowAtPos = NULL;
   IC->RootsSize = 0;
   IC->OthersSize = 0;
  }
}
/************************************************/

/* This one is Only on valid codes */
inline void MapOnNodesOfV(ItemCPtr ICP, Code_Soort CT, void (* fp)(DerFPtr DFp))
{TreeCodeT i;
 if (ICP == NULL) ; /* {fprintf(stderr, "MapOnNodesOf Err: ICP NULL\n"); exit(1);} */
 else {
 switch (CT) {
    case ROOT_enum   : if (ICP->RootsSize > 0)
                       for (i = 0; i < ICP->RootsSize; ++i) 
                        if (ICP->R_valids[i] == true)
                           (*fp)((DerFPtr) (ICP->Roots+i));
                      break;    
    case OTHERS_enum : if (ICP->OthersSize > 0)
                       for (i = 0; i < ICP->OthersSize; ++i) 
                        if (ICP->O_valids[i] == true)
                           (*fp)((DerFPtr) (ICP->Others+i));
                      break;    
    otherwise        : printf("MapOnNodes Err: CT not good\n");break;
 }/*----*/
 }
}
/********/ 
/** The following definition allows a fast macro version */
#ifdef MapOnNodesOfDEC
// takes a function   void (*fp)(DerFPtr DFp) //
inline void MapOnNodesOf(ItemCPtr ICP, Code_Soort CT, void (* fp)(DerFPtr DFp))
{TreeCodeT i;
 if (ICP == NULL) ; /* {fprintf(stderr, "MapOnNodesOf Err: ICP NULL\n"); exit(1);} */
 else {
 switch (CT) {
    case ROOT_enum   : if (ICP->RootsSize > 0)
                       for (i = 0; i < ICP->RootsSize; i = i+1) 
                         {
                          (*fp)((DerFPtr) ((ICP->Roots)+i)); 
                         }
                      break;    
    case OTHERS_enum : if (ICP->OthersSize > 0)
                       for (i = 0; i < ICP->OthersSize; i= i+1) 
                          {
                           (*fp)((DerFPtr) ((ICP->Others)+i));
                          }
                      break;    
    otherwise        : printf("MapOnNodes Err: CT not good\n");break;
 }
 }
}
#endif
/******/
/* The following map takes care of whether the derivation-forest is reduced or not */
/* See also refRed                                                                 */
inline void Map_OnCodesOf(ItemTree I, Code_Soort CT,  void (* fp)(DerFPtr DFp))
{ItemCPtr ICP = (ItemCPtr) I->DerForest;
 if (Version_Reduced(I)==false) MapOnNodesOfV(ICP, CT, fp); 
 else MapOnNodesOf(ICP, CT, fp); 
}
/**********************************************************************************************/
/* item derivation forest */
/***********************/
/* Not in use at the moment !!
void MapOnIDer(ItemTree it, Code_Soort CT, void (* fp)())
{if (it->DerForest != NULL)
  MapOnNodesOf(((ItemCPtr) it->DerForest), CT, fp);
}
*/
/************/
/* Cpy the Rule appearences in RA into an item-code-ptr structure
   which in fact represents the D value for the item which has 
   this RA.
   This function is mainly meant for getting the initial value
   A(R) into D(item, i, j) before further multiplication.
*/
/************/
inline ItemCPtr CpyR_Apps(Rule_Apps RA, ItemTree I)
{TreeCodeT i;   ItemCPtr NewICP; NodePtr NP; int NumOfWs;
 TDomain Term_IfTermRule = GetTerminalOfItemIfAny(I);

 if (Term_IfTermRule != UNVALID_SYMNUM) NumOfWs = 1; else NumOfWs =0;

 if (RA == NULL) return NULL;
 else {
 NewICP = NewICPtr(); NewICP->RootsSize = RA->Roots_Size; NewICP->OthersSize = RA->Others_Size;
 NewICP->Roots = ALLDerFPtr(RA->Roots_Size, ROOT_enum);
 NewICP->Others = ALLDerFPtr(RA->Others_Size, OTHERS_enum);
 NewICP->R_NowAtPos =  AllocPos(NewICP->RootsSize); NewICP->O_NowAtPos =  AllocPos(NewICP->OthersSize);
 if (RA->Roots_Size != 0) 
   {NewICP->R_valids = (Boolean *) MultAlloc(RA->Roots_Size , sizeof(Boolean));
    for (i = 0; i < NewICP->RootsSize; ++i)
                  {NP = NodePtrOf(i, RA, ROOT_enum); 
                   /* OLDCpyRAPS1 */
                   FillDFPtr(&(NewICP->Roots[i]),
                      MaxNutralConst, SumNutralConst, NULL, NULL, I, i, ROOT_enum, NULL, NP->OTS);
                   NewICP->R_valids[i] = false;
                   NewICP->R_NowAtPos[i] = i; 
                  }
   } else NewICP->R_valids = NULL;

 if (RA->Others_Size != 0) 
   { NewICP->O_valids = (Boolean *) MultAlloc(RA->Others_Size , sizeof(Boolean));
     for (i = 0; i < NewICP->OthersSize; ++i) 
               {NP = NodePtrOf(i, RA, OTHERS_enum); 
                /* OLDCpyRAPS2 */
                FillDFPtr(&(NewICP->Others[i]),
                      MaxNutralConst, SumNutralConst, NULL, NULL, I, i, OTHERS_enum, NULL, NP->OTS);
                NewICP->O_valids[i] = false;
                NewICP->O_NowAtPos[i] = i; 
               }
   } else NewICP->O_valids = NULL;
 return NewICP;
 }
}
/***********************************/
/* A global variable for the next function */
/* reduces allocations and freeing of memory */
/** extern Boolean SubstitutionAllowed(int i, int j); **/

/* Multiply the two sets of codes (D's) of two items.
  CT = ROOTS : RootsP x OthersCH ----> RootsP
  CT = OTHERS : OthersP x RootsCh ----> OthersP
  
  The number of codes found viable is returned. 
  AnyValid tells whether there are any derivations found
  from any code of ICPp to ICPch (i.e. any viablity holds) 
  so that: if AnyValid == false ====> the pointers AddedBy/Adds should
                                      be eliminated between the two
                                      items.
           else the pointers should stay.
  The validity is shown in a list of booleans R_valids and O_valids
  which are update if there are new valid codes which came by.

*/ 
/***********************************/
DuoPtr MultICPs(ItemTree Ip, ItemTree Ich,
                   ItemCPtr ICPp, ItemCPtr ICPch, Child_Type Chnum,
                   RDomain Rnop, RType RTp,
                   RDomain Rnoch, RType RTch, Boolean *AnyValid,
                   DuoPtr Duo, int i, int j)
{TreeCodeT Num; Code_Soort CT, CTch; Boolean FstOnlyRs; NodePtr NPtemp; DerFPtr temp2DFP_; 
 static struct DerFor_Struct TEMPDFP_; 
 DerFPtr tempDFP_ ; Boolean ViableTRs; Rule_Apps RAp, RAch; 
   void filterP(DerFPtr DFp)
        {TreeCodeT Here; NodePtr NPp; 
         Boolean viable = false; Boolean FoundCh = false; 
         TreeCodeT Chplace = 0; Boolean AlreadyValid = false; Boolean TksRsOnly = false;

              void MultCh(DerFPtr DFch)
                {NodePtr NPch = NodePtrOf(DFch->CAdr, RAch, CTch);
                 if (MultDFPtrs(DFp, DFch, Chnum, NPp, NPch) == true) viable = true;
                }/*MultCh*/

              /* RefQuad: testing A^2 ***** * End of A^2*****/ 

         NPp = NodePtrOf(DFp->CAdr, RAp, CT);

         if (CheckSubtreeActivity(TreeCodeOfNP(NPp), S, _sen_length)==true) /* lexicalized with a word that is not in input*/
         {
          /* if ((TakeRsOnly(NPp, Chnum)) == false) TksRsOnly = false; 
             else if ((TakeRsOnly(NPp, Chnum)) == true) TksRsOnly = true;
                  else {fprintf(stderr, "Err: Problems in MultICPs\n"); exit(1);};

             switch (TksRsOnly) {
           */

          /* See RefOptimization */
          switch (TakeRsOnly(NPp, Chnum)) {/* switch optimization */
           case false: /* Case1: Parent takes on Chnum only OTHERS_enum children */
              if (ICPch->OthersSize == 0) ; /* no valid children for DFp in ICPch */
              else {
                CTch = OTHERS_enum;  /** RefLogSearch: This is the O(1) search */
                Chplace = WhereIsChildOf(DFp->CAdr, CT, Chnum, &FoundCh);
                if ((FoundCh == true) && (Chplace != _C_Addr_UNV))
                 {Chplace = ICPch->O_NowAtPos[Chplace];
                  if ((Chplace < ICPch->OthersSize) && (Chplace != _C_Addr_UNV))   /* is the child code valid */
                   if (Version_Reduced(Ich) == false) /*refRed and OLDVersionRed1*/
                    if (ICPch->O_valids[Chplace] == true) MultCh(ICPch->Others+Chplace);
                    else ; 
                   else {MultCh(ICPch->Others+Chplace);}
                  else if (Chplace != _C_Addr_UNV) /* for controle only !! */
                         {fprintf(stderr, "Err: Problems in MultICPs %u\n", Chplace); exit(1);}; 
                 }
               else ;  /* PRS("Child not found \n");  for testing */
              } /* else */
              break;
           case true: /* Case2: Parent takes on Chnum only roots: has an OT */
              CTch = ROOT_enum; 
              if (FstOnlyRs == true) /* see refO1 for explanation */
                {
                 {/*----*/
                  /* the following FillDFPtr was used instead of text found at CHANGE2111011: does not work, why ? */
                  /* if (1==0) FillDFPtr(tempDFP_, MaxNutralConst, SumNutralConst, NULL, NULL, 
                              DFp->SelfItem, 0, DFp->CSoort, NULL, NEITHER_enum);
                  */
                  tempDFP_->CSoort = DFp->CSoort; tempDFP_->SelfItem = DFp->SelfItem;  
                  tempDFP_->ListOfChNodes = NULL; 
                  }/*----*/


                 {temp2DFP_ = DFp; DFp = tempDFP_; 
                  Map_OnCodesOf(Ich, ROOT_enum, &MultCh); /*refRed and OLDVersionRed2 */
                  DFp = temp2DFP_;
                 }

                 if (viable == true)
                  {ViableTRs = true; FstOnlyRs = false; Update_OpenTree_DFPtr(DFp,tempDFP_, Chnum, CT);   } 
                }
              else if (ViableTRs == true)
                      {viable = true; Update_OpenTree_DFPtr(DFp,tempDFP_, Chnum, CT);}
              break;
          }/* End of switch */
          /************************/
          if (viable == true) 
            {AlreadyValid = IsValidCodeN(ICPp, DFp->CAdr, CT, &Here); 
             *AnyValid = true;
             if (AlreadyValid != true)
                {Num++; UpdateValidCodeN(ICPp, DFp->CAdr, CT, Here);}
            }
         }/* end checking lexicalization */
        }/* end of Filter *********************************** */

  Num = 0; *AnyValid = false; FstOnlyRs = true; ViableTRs = false;
  tempDFP_ = (DerFPtr) &TEMPDFP_ ; temp2DFP_ = NULL; 
  InitDerFPtr(tempDFP_, ROOT_enum); /*ROOT_enum is fake */


  if ((ICPp == NULL) || (ICPch == NULL)) {*AnyValid = false; return Duo;}
  else {RAp = IR_AppsOf(Rnop, RTp, 1);  /* get codes of parent rule into buff1 */
        RAch = IR_AppsOf(Rnoch, RTch, 2); /* get codes of child rule into buff2 */

        InitDerFPtr(tempDFP_, ROOT_enum); /* ROOT_enum is fake */
        CT = ROOT_enum;
        MapOnNodesOf(ICPp, ROOT_enum, &filterP); 
        Duo->RsNum = Num;
        CT = OTHERS_enum; Num = 0;
        MapOnNodesOf(ICPp, OTHERS_enum, &filterP); 
        Duo->OsNum = Num; 
        FreeDFPsListOfChNodes(tempDFP_);
        return (Duo); 
      } /* -- */
}
/****************/
/* Multiplies the codes sets of two items. */
/****************/
inline
DuoPtr MultItems(ItemTree ItemP, ItemTree ItemCh, Child_Type Chnum, Boolean *AnyValid, DuoPtr Duo)
{ItemCPtr ICPp, ICPch;
 RDomain Rnop, Rnoch;
 RType RTp, RTch;
 TreeCodeT Sum;
 ICPp = (ItemCPtr) ItemP->DerForest; ICPch = (ItemCPtr) ItemCh->DerForest;
 Rnop = ItemP->RuleNo; Rnoch = ItemCh->RuleNo; RTp = ItemP->RT; RTch = ItemCh->RT; 

 return 
  (MultICPs(ItemP, ItemCh, ICPp, ICPch, Chnum, Rnop, RTp, Rnoch, 
            RTch, AnyValid, Duo, (int) ItemP->i, (int) ItemP->j));
}
/**********************/
/* Copy ICP. If ProToo is false then make probability zero else copy it; 
   Exactly:
    1. Copies ICP and then either copies the probabilities or not (depending on ProbToo),
    2. makes SelfItem of the result point to IT, 
    3. copies the R/O_NowAtPos Arrays  from ICP 
*/
inline
ItemCPtr CpyICPtr(ItemCPtr ICP, Boolean ProbToo, ItemTree IT, TreeCodeT OrigRsNum, TreeCodeT OrigOsNum)
{TreeCodeT i;
 ItemCPtr NewICP = NewICPtr();

 if (ICP == NULL) {free(NewICP); return NULL;}
 else {NewICP->RootsSize = ICP->RootsSize;
       NewICP->OthersSize = ICP->OthersSize;
       NewICP->Roots = ALLDerFPtr(ICP->RootsSize, ROOT_enum);
       NewICP->Others = ALLDerFPtr(ICP->OthersSize, OTHERS_enum);

       /* if ((OrigRsNum < ICP->RootsSize) || (OrigOsNum < ICP->OthersSize)) {fprintf(stderr,"Err in CpyICPtr\n"); exit(1);}*/

       if (NewICP->RootsSize == 0) {NewICP->R_valids = NULL; NewICP->R_NowAtPos = NULL;}
       else {NewICP->R_valids = (Boolean *) MultAlloc(NewICP->RootsSize , sizeof(Boolean));
             NewICP->R_NowAtPos =  AllocPos(OrigRsNum); 
             for (i = 0; i < NewICP->RootsSize; ++i) 
               {CpyDerFPtr_Partial(&(NewICP->Roots[i]), &(ICP->Roots[i])); 
                NewICP->Roots[i].SelfItem = IT;   NewICP->R_valids[i] = false;
                NewICP->R_NowAtPos[i] = ICP->R_NowAtPos[i];
                if (ProbToo == false)
                 {NewICP->Roots[i].MPD_Prob = MaxNutralConst; NewICP->Roots[i].Sum_Prob = SumNutralConst;
                 }
               }
                 /* continueing till the end */
             for (i = NewICP->RootsSize; i < OrigRsNum; ++i) NewICP->R_NowAtPos[i] = ICP->R_NowAtPos[i];
            }/* else */

       if (NewICP->OthersSize == 0) {NewICP->O_valids = NULL; NewICP->O_NowAtPos = NULL;}
       else {NewICP->O_valids = (Boolean *) MultAlloc(NewICP->OthersSize, sizeof(Boolean));
             NewICP->O_NowAtPos =  AllocPos(OrigOsNum);
             for (i = 0; i < NewICP->OthersSize; ++i)
               {CpyDerFPtr_Partial(&(NewICP->Others[i]), &(ICP->Others[i])); 
                NewICP->Others[i].SelfItem = IT;   NewICP->O_valids[i] = false;
                NewICP->O_NowAtPos[i] = ICP->O_NowAtPos[i];
                if (ProbToo == false) 
                 {NewICP->Others[i].Sum_Prob = SumNutralConst; NewICP->Others[i].MPD_Prob = MaxNutralConst;
                 }
               }
                 /* continueing till the end */
             for (i = NewICP->OthersSize; i < OrigOsNum; ++i) NewICP->O_NowAtPos[i] = ICP->O_NowAtPos[i];
            }/*else*/
       return NewICP;
      }
}
/**************************************************************************/
/**************************/
/* Proc.s for testing     */
/**************************/
void prntnode(DerFPtr DF)
{PItem(DF->SelfItem); PRS("<");PRI(DF->CAdr);PRS(", "); PRB(DF->DF_OUTSIDE_PROB); PRS(", "); PRB(DF->Sum_Prob); PRS(">"); PRS("\n");
}
void checkself(DerFPtr DF)
{if (DF->SelfItem == NULL) PRS("NULL\n");
 else if (((DF->SelfItem->Dot>= lm) && (DF->SelfItem->Dot <= rm)) &&
         ((DF->SelfItem->RT >= _Unary) && (DF->SelfItem->RT <= _Term))) 
            switch (DF->SelfItem->RT) {
              case _Term :  if ((DF->SelfItem->RuleNo >= 0) && (DF->SelfItem->RuleNo < TRSize));
                            else {PRS("trouble with some item"); exit(1);}
                          break;
              case _Unary:  if ((DF->SelfItem->RuleNo >= 0) && (DF->SelfItem->RuleNo < URSize)); 
                            else {PRS("trouble with some item"); exit(1);}
                          break;
              case _Binary: if ((DF->SelfItem->RuleNo >= 0) && (DF->SelfItem->RuleNo < BRSize)); 
                            else {PRS("trouble with some item"); exit(1);}
                           break;
            }
      else {PRS("trouble with some item"); exit(1);}
}
void prntself(DerFPtr DF)
{PItem(DF->SelfItem); 
}
void Vprntself(void *DF)
{VPItem(((DerFPtr) DF)->SelfItem); PRS(" ");
}
void PrntDList(PtrList PL)
{ void PrntOne(PtrList P)
   {DerFPtr DF = (DerFPtr) P->Ptr;
    PRS(" (");
    prntself(DF); PRS("; [");
    PListMap((PtrList) P->Data, (void *) &Vprntself); PRS("]");
    PRS(")");
   }
 PDListMap(PL, (void *) &PrntOne);
}
/******************************/
void ShowDerF(ItemTree I)
{ItemCPtr ICP = (ItemCPtr) I->DerForest;
 Rule_Apps RA = R_AppsOf(I->RuleNo, I->RT); 
 NodePtr NP;
 TreeCodeT i;
 {
  /* PItem(I); PRS("\n----\n"); */
   if (ICP == NULL) PRS("NO DF");
   else 
     {/* PRS("RS: ");PRI(ICP->RootsSize);PRS("\n"); PRS("OS: ");PRI(ICP->OthersSize);PRS("\n"); */
       if (ICP->RootsSize != 0) {
         PRS("Roots:");
         for (i=0; i < ICP->RootsSize; ++i) checkself(&(ICP->Roots[i]));
         PRS("\n");
        }
       
       if (ICP->OthersSize != 0) {
           PRS("Others:");
           for (i=0; i < ICP->OthersSize; ++i) checkself(&(ICP->Others[i]));
           PRS("\n");
        }
     }
 }
}
/*---------*/
void ShowValidDerF(ItemTree I)
{ItemCPtr ICP = (ItemCPtr) I->DerForest;
 Rule_Apps RA = R_AppsOf(I->RuleNo, I->RT); 
 NodePtr NP;
 TreeCodeT i;
 if ((I->Valid != false)) 
 {
   PItem(I); 
   PRS("\n----\n");
   if (ICP == NULL) PRS("NO DF");
   else 
     {PRS("RS: ");PRI(ICP->RootsSize);PRS("\n");
       PRS("OS: ");PRI(ICP->OthersSize);PRS("\n");
       if (ICP->RootsSize != 0) {
         PRS("Roots:");
         for (i=0; i < ICP->RootsSize; ++i)
          if (ICP->R_valids != NULL) 
           if (ICP->R_valids[i] == true) prntnode(&(ICP->Roots[i]));
           else ;
          else prntnode(&(ICP->Roots[i]));
         PRS("\n");
         /* if (ICP->R_valids != NULL) 
        for (i=0; i < ICP->RootsSize; ++i) 
           {PRI(ICP->R_valids[i]);PRS(", ");}*/
       }
       else PRS("NO R_valids\n");
       
       PRS("\n");
       if (ICP->OthersSize != 0) {
           PRS("Others:");
           for (i=0; i < ICP->OthersSize; ++i)
            if (ICP->O_valids != NULL) 
              if (ICP->O_valids[i] == true) prntnode(&(ICP->Others[i]));
              else ;
            else prntnode(&(ICP->Others[i]));
           PRS("\n");
           /*
           if (ICP->O_valids != NULL) 
            for (i=0; i < ICP->OthersSize; ++i)
                        {PRI(ICP->O_valids[i]);PRS(", ");}*/
        }
       else PRS("NO O_valids\n");
       PRS("\n");
     }
 }
}
void ShowTestHere1(DerFPtr DFp)
{if (!strcmp(PartOfItem(DFp->SelfItem, RHS_1),"S")) 
                  {PRS("\n In Mult-----------------\n"); PRS("RCH	");PRI(DFp->CAdr); PItem(DFp->SelfItem);
                   PRS(" has "); PrntDList(DFp->ListOfChNodes); PRS("\n  ----------------\n");
                  }
}
/****************************************************************/
/* README explanations with label:
***************** 
Explanation refO1

In the optimized version of the algorithm we distinguish two
cases for the relation between Code (PC) and code (CC) on the 
jth-child of PC: 
 1. CC is indeed the jth child of PC in an elementary-tree.
    So we know how to get the child in O(1) by looking whether it
    is in the derivation forest of the child item (denoted ICPch).
    (the file .ChildsPlace.bin contains refrences to the addresses
     of the children of each code ).
 2. PC has a substitution-site (OT) as jth child. Therefore all
    codes CC that are roots maybe substituted there. However, for
    every PC that has a substitution-site jth-child the same must
    be done. So what we do, we do this only once and then copy the
    results to the other PC's.
****************/ 
/* refRed
   We allowed partial reduction of space during Interleaved computation.
   Also in case of the serial version we allowed full reduction of space.
   In the first case it implies that only when a chart entry is complete
   then it is reduced. 

   refChDF_Reduced
   When Interleaved and RedDF_CEntries:
    items derivation-forest are reduced only after completing a
    chart entry. This means that only when deducing a new entry
    the children derivation-forests are reduced. Otherwise they
    are not yet. (Further any derivation-forest of A->B*C is 
    never reduced when Interleaved). 
*/
/* RefLogSearch:
 This is the logarithmic search **************************
                Chplace = BFINDCode(&(ICPch->Others), ICPch->OthersSize, 
                 (NPtemp = ComputeChOf(NPp, Chnum)), RAch, &FoundCh);
               free(NPtemp); if (FoundCh == true) MultCh(ICPch->Others+Chplace);
****End of logarithmic search *****************************/
/** RefIsValid: OLD one 
Boolean IsValidCode(ItemCPtr ICP, C_Addr_Domain CA, Code_Soort CT)
{TreeCodeT Place;
 Boolean RES;
 if (ICP == NULL) {PRS("IsValidCode Err: ICP NULL\n");
                   return false ; }
 else { 
 switch (CT) {
   case ROOT_enum  : if (ICP->RootsSize != 0) {
                     Place = BFIND(&(ICP->Roots), ICP->RootsSize, CA);
                     if ((Place == 0) && (ICP->Roots[0].CAdr != CA)) 
                        RES = false;
                     else RES = (ICP->R_valids[Place]);
                     }
                     else RES = false;
                      break;
   case OTHERS_enum : if (ICP->OthersSize != 0) {
                      Place = BFIND(&(ICP->Others), ICP->OthersSize, CA);
                      if ((Place == 0) && (ICP->Others[0].CAdr != CA)) 
                         RES = false;
                      else RES = (ICP->O_valids[Place]);
                      }
                      else RES = false;
                      break;    
   otherwise        : RES = false; break;
 }
 return RES;
 }
}
***/
/** RefQuad:  The A^2 code 
                   CTch = ROOT_enum; 
                   MapOnNodesOf(ICPch, ROOT_enum, (void *) &MultCh); 
                   CTch = OTHERS_enum; 
                   MapOnNodesOf(ICPch, OTHERS_enum, (void *) &MultCh); 
*******/
/* RefOptimization:                                        
Two cases since :                                      
A parent takes on Chnum either roots or others NOT both 
Case 1: Parent has no OT but a child at Chnum          
See refO1 for further explanation                       */
/* OLDversionRed1
                  if (ChDF_Reduced(DFp, (ICPch->Others+Chplace))==false) 

   OLDversionRed2
                 if (ChDF_Reduced(DFp, (ICPch->Roots))==false)
                      MapOnNodesOfV(ICPch, ROOT_enum, (void *) &MultCh);
                 else MapOnNodesOf(ICPch, ROOT_enum, (void *) &MultCh);

 OLDVER Cpy2: 
* target->MPD_Prob = MultProbs(source->MPD_Prob, P);
* target->Sum_Prob = MultProbs(source->Sum_Prob, P);
*
* target->MPD_PtrL = source->MPD_PtrL;
* target->MPD_PtrR = source->MPD_PtrR;
* target->SelfItem = IT;
* target->CAdr = source->CAdr;
* target->CSoort = source->CSoort;
* target->ListOfChNodes = source->ListOfChNodes;                            
* target->OpenTrees = source->OpenTrees;                            
*/
/* OLDVER Cpy1
* target->MPD_Prob = source->MPD_Prob;
* target->Sum_Prob = source->Sum_Prob;
* target->MPD_PtrL = source->MPD_PtrL;
* target->MPD_PtrR = source->MPD_PtrR;
* target->SelfItem = source->SelfItem;
* target->CAdr = source->CAdr;
* target->CSoort = source->CSoort;
* target->ListOfChNodes = source->ListOfChNodes;  should be copied as a list 
*/
/* OLDCpyRAPS1
*                   NewICP->Roots[i].CAdr = i;
*                   NewICP->Roots[i].SelfItem = I;
*                   NewICP->Roots[i].MPD_PtrL = NULL;
*                   NewICP->Roots[i].MPD_PtrR = NULL;
*                   NewICP->Roots[i].MPD_Prob = MaxNutralConst;
*                   NewICP->Roots[i].Sum_Prob = SumNutralConst;
*                   NewICP->Roots[i].OpenTrees = NP->OTS;
*/
/* OLDCpyRAPS2
*                NewICP->Others[i].CAdr = i;
*                NewICP->Others[i].SelfItem = I;
*                NewICP->Others[i].MPD_PtrL = NULL;
*                NewICP->Others[i].MPD_PtrR = NULL;
*                NewICP->Others[i].MPD_Prob = MaxNutralConst;
*                NewICP->Others[i].Sum_Prob = SumNutralConst;
*                NewICP->Others[i].OpenTrees = NP->OTS;
*/
/*

CHANGE2111011

                 tempDFP_->CSoort = DFp->CSoort; tempDFP_->SelfItem = DFp->SelfItem;  
                 tempDFP_->ListOfChNodes = NULL; 

*/
/* OldMultPractice1
P = CodeProbability(IT, source, CT); 
  FillDFPtr(target, MultProbs(source->MPD_Prob, P), MultProbs(source->Sum_Prob,P), source->MPD_PtrL, source->MPD_PtrR,
                   IT, source->CAdr, source->CSoort, source->ListOfChNodes,  source->OpenTrees );     
}
*/
