#include "./ALL.h"
#include "./RAMcodes.h"


/****************************/
/* Node-pointers            */
/****************************/
inline NodePtr NodePtrOf(C_Addr_Domain CA, Rule_Apps RA, Code_Soort CT)
{switch (CT) {
    case ROOT_enum : return ((RA->Roots_Nodes)+CA);
                 break;
    case OTHERS_enum : return((RA->Others_Nodes)+CA);
                 break;
    otherwise : return NULL;
 }
}
void FreeNPtr(NodePtr NP)
{cfree(NP);}
/*****************************/
/* Rule_Apps type   */
/* Declaration of this type can be found in CodeType.h*/
/******************************/
inline Rule_Apps NewRApps()
{Rule_Apps New = (Rule_Apps) AllocElem(sizeof(struct Nodes_Struct));
 New->Roots_Size = 0;
 New->Others_Size = 0;
 New->Roots_Nodes = NULL;
 New->Others_Nodes = NULL;
 return New;
}
inline Rule_Apps CopyRApps(Rule_Apps RA)
{Rule_Apps New = NewRApps();
 New->Roots_Size = RA->Roots_Size;
 New->Others_Size =  RA->Others_Size;
 New->Roots_Nodes =  RA->Roots_Nodes;
 New->Others_Nodes =  RA->Others_Nodes;
 return New;
}
inline void FreeRApps(Rule_Apps RA)
{if (RA == NULL);
 else {FreeNPtr(RA->Roots_Nodes);
       FreeNPtr(RA->Others_Nodes); cfree(RA);}
}

inline void FreePartsOfRApps(Rule_Apps RA)
{if (RA == NULL);
 else {FreeNPtr(RA->Roots_Nodes); RA->Roots_Nodes = NULL;
       FreeNPtr(RA->Others_Nodes); RA->Others_Nodes = NULL;
       RA->Roots_Size = 0; RA->Others_Size = 0;
      }
}
/************/
inline PlacePtr WhatPlacePtr(RDomain Rno, RType RT)
{if (Rno != UNVALID_RNUM)
 switch (RT) {
    case _Unary  :
           if ((Rno >= 0) && (Rno < URSize)) return (U_R_Apps+Rno);
           else {fprintf(stderr, "Err1: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Binary :
           if ((Rno >= 0) && (Rno < BRSize)) return (B_R_Apps+Rno);
           else {fprintf(stderr, "Err2: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Eps    :
           if ((Rno >= 0) && (Rno < EpsRSize)) return (Eps_R_Apps+Rno);
           else {fprintf(stderr, "Err3: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Term   :
           if ((Rno >= 0) && (Rno < TRSize)) return (T_R_Apps+Rno);
           else {fprintf(stderr, "Err4: in R_AppsOf %d\n", (int) Rno);exit(1);}
                 break;
    otherwise   : fprintf(stderr, "\nErr: ruletype impossible %d %d\n", (int) Rno, (int) RT);
                  exit(1);
                 break;
 }/*--*/
 else {fprintf(stderr, "Err: UNVALID_RNUM in R_AppsOf %d %d\n", Rno, (int) RT);exit(1);}
}
/************/
/* Rule_Apps GetR_A(PlacePtr PP) { if in buffer already then return the buffer
    else go and get it into buffer from file  and return its value } */
/************/

inline Rule_Apps XR_AppsOf(RDomain Rno, RType RT)
{if (Rno != UNVALID_RNUM)
 switch (RT) {
    case _Unary  : 
           if ((Rno >= 0) && (Rno < URSize)) return (GetR_A(U_R_Apps+Rno));
           else {fprintf(stderr, "Err1: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Binary :
           if ((Rno >= 0) && (Rno < BRSize)) return (GetR_A(B_R_Apps+Rno));
           else {fprintf(stderr, "Err2: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Eps    :
           if ((Rno >= 0) && (Rno < EpsRSize)) return (GetR_A(Eps_R_Apps+Rno));
           else {fprintf(stderr, "Err3: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Term   :
           if ((Rno >= 0) && (Rno < TRSize)) return (GetR_A(T_R_Apps+Rno));
           else {fprintf(stderr, "Err4: in R_AppsOf %d\n", (int) Rno);exit(1);}
                 break;
    otherwise   : fprintf(stderr, "\nErr: ruletype impossible %d %d\n", (int) Rno, (int) RT); 
                  return NULL;
                 break;
 }/*--*/
 else {fprintf(stderr, "Err: UNVALID_RNUM in R_AppsOf %d %d\n", Rno, (int) RT);exit(1);}
}
/************************************************************************************/
/* Gets the child place vectors into the buffers: we keep this working with buffers */
inline void GetChildPlacesFor(RDomain Rno, RType RT)   
{if (Rno != UNVALID_RNUM)
 switch (RT) {
    case _Unary  :
           if ((Rno >= 0) && (Rno < URSize)) GetChildPlaces(U_R_Apps+Rno);
           else {fprintf(stderr, "Err1: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Binary :
           if ((Rno >= 0) && (Rno < BRSize)) GetChildPlaces(B_R_Apps+Rno);
           else {fprintf(stderr, "Err2: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Eps    :
           if ((Rno >= 0) && (Rno < EpsRSize)) GetChildPlaces(Eps_R_Apps+Rno);
           else {fprintf(stderr, "Err3: in R_AppsOf %d\n",(int)  Rno);exit(1);}
                 break;
    case _Term   :
           if ((Rno >= 0) && (Rno < TRSize)) GetChildPlaces(T_R_Apps+Rno);
           else {fprintf(stderr, "Err4: in R_AppsOf %d\n", (int) Rno);exit(1);}
                 break;
    otherwise   : fprintf(stderr, "\nErr: ruletype impossible %d %d\n", (int) Rno, (int) RT);
                  exit(1);
                 break;
 }/*--*/
 else {fprintf(stderr, "Err: UNVALID_RNUM in R_AppsOf %d %d\n", Rno, (int) RT);exit(1);}
}
/* get it from RAM, if there, else get it from file */
inline Rule_Apps RAM_FetchRApps(RType RT, RDomain RNum) 
{Rule_Apps RES = FetchRAppsFromRAM(RT, RNum); 

 if (RES!=NULL) 
   {IntoBuffPPtr(WhatPlacePtr(RNum, RT), RES); 
    /* Unnecessary since done in IntoBuffPPtr !!  GetChildPlacesFor(RNum, RT); */
   }
 else
   {RES = (XR_AppsOf(RNum, RT));
    /* save this is RAM */
    SaveRAppsInRAM(RT, RES, RNum);
   }
 return RES;
}
/**************************************************/
/* THE INTERFACE TO THE OUTSIDE WORLD ARE THE FOLLOWING TWO */
inline Rule_Apps R_AppsOf(RDomain Rno, RType RT)
{return RAM_FetchRApps(RT, Rno);
}
/* USE THE FOLLOWING rather than the one above */
inline Rule_Apps IR_AppsOf(RDomain Rno, RType RT, WHICHBUFT WF)
{Rule_Apps Result; 
 WhichBuf = WF; /* Result = (XR_AppsOf(Rno, RT)); */
 Result = RAM_FetchRApps(RT, Rno);
 return Result;
}
/***************************************************/
inline Rule_Apps Item_AppsOf(ItemTree it)
{return XR_AppsOf(it->RuleNo, it->RT);
}
/******************************/
/* ViabSetOf computes a subset of Item_AppsOf(itP)
   of codes CP which have at least one code Ch in Item_AppsOf(itCh)
   such that IsViable(CP, Ch, j) is true for some j.
   P.S. We assume here that no ROOT CP is in the Viability
   relation with another ROOT Ch. If this is the case in the
   future then change it.
*/
void ShowR_Apps(Rule_Apps RA)
{if (RA == NULL) PRS("NULL RA\n");
 else {
   PRI((PlacesT) RA->Roots_Size);
   PRI((PlacesT) RA->Others_Size);
 }
}
inline C_Addr_Domain ArrNumOf(Rule_Apps RA, NodePtr NP, Code_Soort CT)
{C_Addr_Domain CD;
 switch (CT) {
    case ROOT_enum : return (NP - RA->Roots_Nodes);
                    break;
    case OTHERS_enum : return (NP - RA->Others_Nodes); 
                    break;
    otherwise      : return 0; break;
 }
}
/****************************/
