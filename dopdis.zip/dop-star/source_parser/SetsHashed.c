#include "./Universals.h"
#include "./Aux.h"
#include "./DefsGrammar.h"
#include "./PtrList.h"
#include "Queues.h"
#include "CodeType.h"
#include "sentence.h"
#include "./Item.h"
#include "./Trees.h"
#include "./HashTable.h"
#include "./SetsHashed.h"
extern int _sen_length;
extern Boolean LEXICALIZED_WSJ;
extern Boolean _APPLY_PRUNE;

#define _OVIS         false
#define MAX_SPAN_FAST 500
Boolean _REMAIN_FAST= true;

inline
Boolean FREE_FAST_ARRAYS(int span)
{if (_REMAIN_FAST==true) return false;

 if (NonTSize > 50000) return true; 
 if ((NonTSize > 4000) || (TotalRootsNum >= 200000) || (_sen_length > 70))
   if ((_sen_length >= 26) && (span >= MAX_SPAN_FAST)) return true;
   else return false;
 return false;
}
inline
Boolean USE_FAST_ARRAYS(int i, int j)
{int lb_for_freeing;

 if (_REMAIN_FAST==true) return true;

 if ((LEXICALIZED_WSJ == true) && (_sen_length <=20)) return true;
 if ((_OVIS == true) && (_sen_length <= 100)) return true;

 if ((j==0) && (i==0)) return false;
 if (NonTSize > 50000) return false; 
 if ((NonTSize > 4000) || (_sen_length > 60))
  {if ((NonTSize > 20000) || (_sen_length > 60)) lb_for_freeing = 24;
   else lb_for_freeing = MAX_SPAN_FAST;

   if (_sen_length <= lb_for_freeing) return true; 
   else if (_sen_length <= 40)
           if ((j-i) <= MAX_SPAN_FAST) return true; 
           else return false;
        else return false;
  }
 return true;
}
/******************************************************************************/
/********   PROCEDURES concerning the data-type: Set                    *******/
/********                                                               *******/
/******************************************************************************/
/************************/
/*Pre: set must exist   */
/************************/
inline
KeyType SeekItem(KeyType key, Set set)
{HashUnit HT;
 if (set == NULL) return NULL; 
 else  {HT = (SearchHT(key, set->ItemPtr)); 
        if (HT != NULL) return HT->item;
        else return NULL;
       }
}
inline
Boolean F_USE_FAST_ARRAYS(Set set)
{if ((set->LHSNTOfEnded != NULL) && (set->RHS2NTOfOths != NULL) && 
     (set->LHSOfEndedPList != NULL) && (set->RHS2OfOthsPList != NULL)) return true;
 else return false;
}
/********************/
inline void AssignToLHSNTOfEndedOf(Set set, NTDomain NT, Boolean val)
{if (set->LHSNTOfEnded != NULL) set->LHSNTOfEnded[NT] = val; }

Boolean ValLHSNTOfEndedOf(Set set, NTDomain NT)
{if (set->LHSNTOfEnded != NULL) return set->LHSNTOfEnded[NT];
 else return true;
}

inline void AssignToRHS2NTOfOths(Set set, NTDomain NT, Boolean val)
{if (set->RHS2NTOfOths != NULL) set->RHS2NTOfOths[NT] = val; }

Boolean ValRHS2NTOfOths(Set set, NTDomain NT)
{if (set->RHS2NTOfOths != NULL) return set->RHS2NTOfOths[NT];
 else return true;
}

inline void CrFastArrays(Set set, int m, int n)
{int i;
 if (USE_FAST_ARRAYS(m,n) == true) {
   set->LHSNTOfEnded = (Boolean *) MultAlloc(NonTSize, sizeof(Boolean));
   set->RHS2NTOfOths = (Boolean *) MultAlloc(NonTSize, sizeof(Boolean));
   for (i=0;i<NonTSize;i++) {set->LHSNTOfEnded[i] = false; set->RHS2NTOfOths[i] = false;}
 }
 else {set->LHSNTOfEnded = NULL; set->RHS2NTOfOths = NULL;}
}
inline void FreeFastArraysOf(Set S)
{if (S->LHSNTOfEnded != NULL) cfree(S->LHSNTOfEnded); S->LHSNTOfEnded = NULL;
 if (S->RHS2NTOfOths != NULL) cfree(S->RHS2NTOfOths); S->RHS2NTOfOths = NULL;
}
/*******************************************/
inline void EnStackInLHSOfEndedPListOf(Set set, NTDomain NT, void *P)
{if (set->LHSOfEndedPList != NULL) set->LHSOfEndedPList[NT] = EnterPStack(P, set->LHSOfEndedPList[NT]);
}
inline void EnStackInRHS2OfOthsPListOf(Set set, NTDomain NT, void *P)
{if (set->RHS2OfOthsPList != NULL) set->RHS2OfOthsPList[NT] = EnterPStack(P, set->RHS2OfOthsPList[NT]);
}

inline
PtrList TheLHSOfEndedPListOf(Set set, NTDomain NT)
{return set->LHSOfEndedPList[NT];
}
inline
PtrList TheRHS2OfOthsPListOf(Set set, NTDomain NT)
{return set->RHS2OfOthsPList[NT];
}

inline void AssignToLHSOfEndedPListOf(Set set, NTDomain NT, PtrList L)
{if (set->LHSOfEndedPList != NULL) set->LHSOfEndedPList[NT] = L;
}
inline void AssignToRHS2OfOthsPListOf(Set set, NTDomain NT, PtrList L)
{if (set->RHS2OfOthsPList != NULL) set->RHS2OfOthsPList[NT] = L;
}

inline void CrFastPLists(Set set, int m, int n)
{int i;
 if (USE_FAST_ARRAYS(m, n) == true) {
   set->LHSOfEndedPList = (PtrList *) MultAlloc(NonTSize, sizeof(PtrList));
   set->RHS2OfOthsPList = (PtrList *) MultAlloc(NonTSize, sizeof(PtrList));
   for (i=0;i<NonTSize;i++) { set->LHSOfEndedPList[i] = NULL; set->RHS2OfOthsPList[i] = NULL;}
 }
 else {set->LHSOfEndedPList = NULL; set->RHS2OfOthsPList = NULL; }
}
inline void FreeFastPListsOf(Set S)
{int i;
 if (S->LHSOfEndedPList != NULL) 
   {for (i=0;i<NonTSize;i++) FreePListN(S->LHSOfEndedPList[i]); cfree(S->LHSOfEndedPList); S->LHSOfEndedPList = NULL;}
 if (S->RHS2OfOthsPList != NULL) 
   {for (i=0;i<NonTSize;i++) FreePListN(S->RHS2OfOthsPList[i]); cfree(S->RHS2OfOthsPList); S->RHS2OfOthsPList = NULL;}
}
/***************************************************************************************************************/
/*                        SETS SETS   SETS                                                                     */
/***************************************************************************************************************/
inline
Set CreateSet()
{return NULL;
}

inline
Set InitSet(int i, int j)
{Set set;
 set = (Set) AllocElem(sizeof(struct SetType));
 set->ItemPtr = InitHashTB();
 set->Size = 0;
 set->EndedSize = 0;
 set->OthsSize = 0;
 set->IsClosed = OPEN_ENTRY;
 set->SetBooleanAux = false;
 set->RMax_Node_Prob = MaxNutralConst;
 set->OMax_Node_Prob = MaxNutralConst;
 set->AlphaXBeta = MaxNutralConst; 
 set->Max_Prob_To_Right = MaxNutralConst;
 CrFastArrays(set, i, j); CrFastPLists(set, i, j);
 return set;
}
/**********************************************************/
/* The following part deals with the tree of items. *******/
/************************/
/*Pre: set must exist   */
inline
Set Add(KeyType key, Set set)
{Boolean b = false; NTDomain lhs, rhs2; Rule_Ptr rptr; Set set1 = NULL; 
 if (key != NULL) {
  set1 = ((set == NULL) ? InitSet(0, 0) : set);
  EnterHT(key, set1->ItemPtr, &b); 
  if (b == true) 
   {(set1->Size)++; /* else  no change in Size */
    rptr = RulePtr_Of(key->RuleNo, key->RT);

   if ((EndedItem(key)) == true) 
    {(set1->EndedSize)++;           lhs = LHS_Of(rptr); 
     AssignToLHSNTOfEndedOf(set1, lhs, true); /* set1->LHSNTOfEnded[lhs] = true; */
     EnStackInLHSOfEndedPListOf(set1, lhs, (void *) key);
    }
   else 
    {(set1->OthsSize)++;            rhs2 = RHS2_Of(rptr);
     AssignToRHS2NTOfOths(set1, rhs2, true); /* set1->RHS2NTOfOths[rhs2] = true; */
     EnStackInRHS2OfOthsPListOf(set1, rhs2, (void *) key);
    }
  }
 } 
 return set1;
}

inline
Set XAdd(KeyType key, Set set)
{KeyType I; Boolean new = false; Boolean First=false; NTDomain lhs, rhs2; Rule_Ptr rptr; Set set1 = NULL; 
 if (key != NULL) {
  set1 = ((set == NULL) ? InitSet(0, 0) : set);

  /* takes care of duplicates with different probabilities in the wordgraph input */
  I = SeekItem(key, set); 
  if (EqItem(key, I) == true) /* item is in entry already */
    {(MaxProbs(I->Transition->Probability, key->Transition->Probability, &First));
     if (First==false) {I->Transition=key->Transition;}
     new=false;
    }
  else EnterHT(key, set1->ItemPtr, &new);

  if (new == true) 
   {(set1->Size)++; /* else  no change in Size */
    rptr = RulePtr_Of(key->RuleNo, key->RT);

   if ((EndedItem(key)) == true) 
    {(set1->EndedSize)++;           lhs = LHS_Of(rptr); 
     AssignToLHSNTOfEndedOf(set1, lhs, true); /* set1->LHSNTOfEnded[lhs] = true; */
     EnStackInLHSOfEndedPListOf(set1, lhs, (void *) key);
    }
   else 
    {(set1->OthsSize)++;            rhs2 = RHS2_Of(rptr);
     AssignToRHS2NTOfOths(set1, rhs2, true); /* set1->RHS2NTOfOths[rhs2] = true; */
     EnStackInRHS2OfOthsPListOf(set1, rhs2, (void *) key);
    }
  }
 } 
 return set1;
}
/************************/
inline
KeyType HeadOfSet(Set set)
{if (set == NULL) return NULL;
 else if (set->ItemPtr[0] != NULL) return (set->ItemPtr[0])->item ;
      else return NULL;
}
/************************
Boolean Member(KeyType key, Set set)
{
 if (set == NULL) return false;
 else return (EqItem(key, (HeadOfSet(Seek(key, set)))));
}
************************/
/* Checks whether key is first element in set when viewed as a list*/
/************************/
inline
Boolean IsHeadOf(KeyType key, Set set)
{
 if (set == NULL) return false;
 else return (EqItem(key, (HeadOfSet(set))));
}
/************************/
/* fp takes an ItemTree */
inline void SetsMap(Set set, void (* fp)())
{if (set == NULL) ; /* printf("Err: empty set");*/
 else {HashTMap(set->ItemPtr, fp); } 
}
/* fp takes an ItemTree and returns an ItemTree */
inline void XSetsMap(Set set, ItemTree (* fp)())
{if (set == NULL) ; /* printf("Err: empty set");*/
 else { XHashTMap(set->ItemPtr, fp); } 
}
/* fp takes an ItemTree and returns an ItemTree */
inline void XSetsMapEnded(Set set, ItemTree (* fp)(), Boolean Ended)
{if (set == NULL) ; /* printf("Err: empty set");*/
 else { XHashTMapEnded(set->ItemPtr, fp, Ended); } 
}
inline void XSetsCompact(Set set, Boolean Ended)
{if (set == NULL) ; /* printf("Err: empty set");*/
 else { CompactHashT(set->ItemPtr, Ended); } 
}
void SetsMapValid(Set set, void (* fp)())
{ void CheckIValidity(ItemTree I)
   {if (I != NULL) if (I->Valid == true) (*fp)(I);}
 if (set == NULL) ; /* printf("Err: empty set");*/
 else {HashTMap(set->ItemPtr, (void *) &CheckIValidity); } 
}
inline void SetsMapEnded(Set set, void (* fp)())
{
 if (set == NULL) ; /* printf("Err: empty set");*/
 else {HashTMapEnded(set->ItemPtr, fp); } 
}
void SetsMapEndedValid(Set set, void (* fp)())
{ void CheckIValidity(ItemTree I)
   {if (I!=NULL) if (I->Valid == true) (*fp)(I);}
 SetsMapEnded(set, (void *) &CheckIValidity);
}
inline void SetsMapOths(Set set, void (* fp)())
{
 if (set == NULL) ; /* printf("Err: empty set");*/
 else {HashTMapOths(set->ItemPtr, fp); } 
}
void SetsMapOthsValid(Set set, void (* fp)())
{ void CheckIValidity(ItemTree I)
   {if (I!=NULL) if (I->Valid == true) (*fp)(I);}
 SetsMapOths(set, (void *) &CheckIValidity);
}
/**********************************/

inline
RDomain SetSizeOths(Set set)
{if (set == NULL) return 0;
 else return (set->OthsSize);
} 
inline
RDomain SetSizeEnded(Set set)
{if (set == NULL) return 0;
 else return (set->EndedSize);
} 
inline
RDomain SetSize(Set set)
{if (set == NULL) return 0;
 else return (set->Size);
} 
/**********************************/
/**********************************/
/* Things that has much to do with sets */
/**********************************/
/**********************************/
inline
RDomain ThisRuleNo(Set set)
{if (set != NULL) return (HeadOfSet(set)->RuleNo);
 else {
       /* printf("There is no item here !!\n");*/
       return -1; /** a not existing rule no ***/
      }
}
inline
int ThisDot(Set set)
{if (set != NULL) return (HeadOfSet(set)->Dot);
 else {/* printf("There is no item here !!\n");*/
       return -2; /** a not existing dot ***/
      }
}
/***/
/* NOTE THAT THIS Copy Does not copy the PtrLists but points to the old
   ones. In case you need this copy please do copy the ptrlists also by changing that in here
***/
inline
Set CopySet(Set S)
{NTDomain i; Set S1 = InitSet(0, 0);
 S1->Size = S->Size;
 CPHashTable(S1->ItemPtr, S->ItemPtr);
 for (i=0; i < NonTSize; i++)
  {AssignToLHSNTOfEndedOf(S1, i, ValLHSNTOfEndedOf(S, i)); /* S1->LHSNTOfEnded[i] = S->LHSNTOfEnded[i]; */
   AssignToLHSOfEndedPListOf(S1, i, TheLHSOfEndedPListOf(S, i));
   AssignToRHS2NTOfOths(S1, i, ValRHS2NTOfOths(S, i)); /* S1->RHS2NTOfOths[i] = S->RHS2NTOfOths[i]; */
   AssignToRHS2OfOthsPListOf(S1, i, TheRHS2OfOthsPListOf(S, i));
   S1->Max_Prob_To_Right = S->Max_Prob_To_Right;
   S1->AlphaXBeta = S->AlphaXBeta;
   S1->RMax_Node_Prob = S->RMax_Node_Prob;
   S1->OMax_Node_Prob = S->OMax_Node_Prob;
  }
 return S1;
}
/*********************/
inline void FreeFastExtension(Set S)
{FreeFastPListsOf(S); FreeFastArraysOf(S);}

inline void FreeSet(Set S)
{NTDomain i;
 FreeHash(S->ItemPtr); 
 FreeFastPListsOf(S);
 FreeFastArraysOf(S);
 cfree(S);
}
/*********************/
/* is there an Item A-> alfa *  where A has nonterminal number NT ? */ 
inline
Boolean IsErLHSEnded(NTDomain NT, Set S)
{if (S == NULL) return false;
 else return ValLHSNTOfEndedOf(S, NT); /* S->LHSNTOfEnded[NT]; */
}
/* is there an Item A-> B*C  where C has nonterminal number NT ? */ 
inline
Boolean IsErRHS2Oths(NTDomain NT, Set S)
{if (S == NULL) return false;
 else return ValRHS2NTOfOths(S, NT); /* S->RHS2NTOfOths[NT]; */
}
/***********************************************************/
/* MAPS: fp takes only an ItemTree                         */
void MapOnLHSEndedByNonT(NTDomain NT, Set S, void (*fp)())
{    void ReMap(void *P) {(*fp)((KeyType) P);}
     void ReMapCheck(KeyType I) {if (LHS_OfItem(I) == NT) (*fp)(I);}

 if (F_USE_FAST_ARRAYS(S) == true) PListMap(TheLHSOfEndedPListOf(S, NT), (void *) &ReMap);
 else SetsMapEnded(S, (void *) &ReMapCheck);
}
inline void MapOnLHSEnded(Set S, void (*fp)())
{NTDomain i;
   void ReMap(void *P) {(*fp)((KeyType) P);}

 if (F_USE_FAST_ARRAYS(S) == true) /* we use the fast arrays mapping everytime on another nonterminal */
    for (i=0;i<NonTSize; i++) PListMap(TheLHSOfEndedPListOf(S, i), (void *) &ReMap);
 else SetsMapEnded(S, fp); 
}
/*******************/
void MapOnLHSEndedValid(NTDomain NT, Set S, void (*fp)())
{    void ReMap(void *P) {if (((KeyType) P)->Valid == true)  (*fp)((KeyType) P);}
     void ReMapCheck(KeyType I) {if (((KeyType) I)->Valid == true) if (LHS_OfItem(I) == NT) (*fp)(I);}

 if (F_USE_FAST_ARRAYS(S) == true) PListMap(TheLHSOfEndedPListOf(S, NT), (void *) &ReMap);
 else SetsMapEnded(S, (void *) &ReMapCheck);
}
/*--*/
void MapOnLHSEndedUntill(NTDomain NT, Set S, void (*fp)())
{Boolean BOOLVOID = false;
    void ReMap(void *P, Boolean *BOOL) {(*fp)((KeyType) P, BOOL);}
     void ReMapCheck(KeyType I) {if (LHS_OfItem(I) == NT) (*fp)(I, &BOOLVOID);}

 if (F_USE_FAST_ARRAYS(S) == true) PListMapUntill(TheLHSOfEndedPListOf(S, NT), (void *) &ReMap);
 else SetsMapEnded(S, (void *) &ReMapCheck);
}
void MapOnRHS2Oths(NTDomain NT, Set S, void (*fp)())
{Boolean BOOLVOID = false;
     void ReMap(void *P, Boolean *Stop) {(*fp)(NT, (KeyType) P, Stop);}
     void ReMapCheck(KeyType I) {if (RHS2_OfItem(I) == NT) (*fp)(I, &BOOLVOID);}

 if (F_USE_FAST_ARRAYS(S) == true) PListMapUntill(TheRHS2OfOthsPListOf(S, NT), (void *) &ReMap);
 else SetsMapOths(S, (void *) &ReMapCheck);
}
/*--*/
/* fp takes three things: non-terminal number, ItemTree	 and a pointer to a boolean */
void MapOnRHS2OthsValid(NTDomain NT, Set S, void (*fp)())
{Boolean BOOLVOID = false;
     void ReMap(void *P, Boolean *Stop) {if (((KeyType) P)->Valid == true) (*fp)(NT, (KeyType) P, Stop);}
     void ReMapCheck(KeyType I) 
       {if (((KeyType) I)->Valid == true) if (RHS2_OfItem(I) == NT) (*fp)(I, &BOOLVOID);}

 if (F_USE_FAST_ARRAYS(S) == true) PListMapUntill(TheRHS2OfOthsPListOf(S, NT), (void *) &ReMap);
 else SetsMapOths(S, (void *) &ReMapCheck);
}
/* fp takes three things: non-terminal number, ItemTree	 and a pointer to a boolean */
void MapOnRHS2Oths_VDF(NTDomain NT, Set S, void (*fp)())
{Boolean BOOLVOID = false;
     void ReMap(void *P, Boolean *Stop)
       {if (NonEmptyDerForest((KeyType) P) == true) (*fp)(NT, (KeyType) P, Stop);}
     void ReMapCheck(KeyType I) 
       {if (NonEmptyDerForest((KeyType) I) == true) if (RHS2_OfItem(I) == NT) (*fp)(NT, I, &BOOLVOID);}

 if (F_USE_FAST_ARRAYS(S) == true) PListMapUntill(TheRHS2OfOthsPListOf(S, NT), (void *) &ReMap);
 else SetsMapOths(S, (void *) &ReMapCheck);
}
/*------------------------------------*/
/* fp takes three things: non-terminal number, ItemTree and a pointer to a boolean */
void MapAllRHS2Oths(Set S, void (*fp)(), Boolean CheckValidity)
{NTDomain i; Boolean BOOLVOID;
 void ReMap(KeyType I) {(*fp)(RHS2_OfItem(I), I, &BOOLVOID);}

 if (F_USE_FAST_ARRAYS(S) == true)
   if (CheckValidity == true) for (i=0;i<NonTSize; i++) MapOnRHS2OthsValid(i, S, fp);
   else for (i=0;i<NonTSize; i++) MapOnRHS2Oths(i, S, fp);
 else if (CheckValidity == true) SetsMapOthsValid(S, (void *) &ReMap); 
      else SetsMapOths(S, (void *) &ReMap);
}

/* fp takes three things: non-terminal number, ItemTree and a pointer to a boolean             */
/* CheckDForest is false: Map on all items A->B*C in S  ;                                      */
/* CheckDForest is true : Map on all items A->B*C in S that have a non-empty derivation-forest */
void MapAllRHS2Oths_VDF(Set S, void (*fp)(), Boolean CheckDForest)
{NTDomain i; Boolean BOOLVOID;
     void ReMap(KeyType I) {(*fp)(RHS2_OfItem((KeyType) I), (KeyType) I, &BOOLVOID);}
     void ReMapCheck(KeyType I) 
       {if (NonEmptyDerForest((KeyType) I) == true) (*fp)(RHS2_OfItem((KeyType) I), (KeyType) I, &BOOLVOID);}

 if (F_USE_FAST_ARRAYS(S) == true)
   if (CheckDForest == true) for (i=0;i<NonTSize; i++) MapOnRHS2Oths_VDF(i, S, fp);
   else for (i=0;i<NonTSize; i++) MapOnRHS2Oths(i, S, fp);
 else if (CheckDForest == true) SetsMapOths(S, (void *) &ReMapCheck);
      else SetsMapOths(S, (void *) &ReMap);
}
/************************************************************************************/
/***********                                                                *********/
/***********      Dealing with the parse-forest: AddedBy and Adds pointers  *********/
/***********                                                                *********/
/************************************************************************************/
/* A is addedby B  iff (A->Level > B->Level) for all A and B ************************/
/* LEVELS_UPDATE */
inline void UpdateLevel(KeyType item, KeyType AdderI)
{if ((item == NULL) || (AdderI == NULL)) ;
 else {/* if (item->Level > 0) {fprintf(stderr,"Err: item has two levels ?\n"); PItem(item); exit(1);} */
       if (Same_Entry_Items(item, AdderI) == true) 
         if (item->Level <= AdderI->Level) item->Level = AdderI->Level+1; 
      }
}

inline void ItemEAddedBy(KeyType item, void *old)
{item->AddedBy = EnterPStack(old, item->AddedBy);
 UpdateLevel(item, (KeyType) old);
}
/**/
/* Assumes that itemKJ should be added at the first in item->AddedBy */
/* This implies that item->AddedBy must be kept as a stack           */ 
inline void ItemEDAddedBy(KeyType item, void *itemKJ)
 {item->AddedBy->Data = (void *) EnterPStack(itemKJ, (PtrList) item->AddedBy->Data);
  UpdateLevel(item, (KeyType) itemKJ);
 }
/* just stack it **
inline void ItemEAdds(KeyType item, void *new) 
{item->Adds = EnterPStack(new, item->Adds);}
********/
/***********************************/
/* Stack it but the result remains a set */
inline void ItemAddedBy(KeyType item, void *old)
{item->AddedBy = EnterP(old, item->AddedBy);
 UpdateLevel(item, (KeyType) old);
}
/**/
void MapAddedBy(KeyType item, void (* fp)())
 {PListMap(item->AddedBy, fp); }
void MapDAddedBy(KeyType item, void (* fp)())
{   void OnData(PtrList P)
       {fp(P->Ptr, P->Data);}
  PDListMap(item->AddedBy, (void *) &OnData); 
}
/********* NOT IN USE  NOT IN USE 
inline void ItemAdds(KeyType item, void *new)
 {item->Adds = EnterP(new, item->Adds);}
inline void ItemDAddedBy(KeyType item, void *itemKJ)
 {item->AddedBy->Data = (void *) EnterP(itemKJ, (PtrList) item->AddedBy->Data);
  UpdateLevel(item, (KeyType) itemKJ);
 }
inline void MapAdds(KeyType item, void (* fp)())
 {PListMap(item->Adds, fp); }
END of NOT IN USE section *******************/
/***********************************************************************************************/
/******** NOT IN USE NOT IN USE
inline void PrintAdds(KeyType item)
 {AppToItem(item, (void *) &ShowItem);
  PRS("   Adds: ");
  MapAdds(item, (void *) &VPItem);
  PRS("\n");
 }
END of NOT IN USE section *******/
/**/
inline void PrintAddedBy(KeyType item)
 {AppToItem(item, (void *) &ShowItem);
  PRS("   AddedBy: ");
  MapAddedBy(item, (void *) &VPItem);
  PRS("\n");
 }
