#include "Universals.h"
#include "Aux.h"
#include "Queues.h"
/**************/
#ifndef MaxLeng
#define MaxLeng SymLength
#endif
#ifndef AssignRule
#define AssignRule(Targ, Src) strcat(Targ, Src)
#endif
#ifndef AssignRuleI
#define AssignRuleI(Targ, Src) strcpy(Targ, Src)
#endif
/**************************************************************/
/*******        Queues of rules                         *******/
/*** NOTE : if duplications in the queue are  prohibited*******/
/***        take care yourself that that doesn't happen *******/
inline
Queue EnQUnit(char *R)
{Queue Q = (Queue) AllocElem(sizeof(struct QUnit));
 AssignRuleI(Q->Rule, R);  Q->Next = NULL; Q->UnknownWord = false;
 return Q; 
}
inline
Queue EnQUnitEx(char *R, NumOfWordsType i)
{Queue Q = (Queue) AllocElem(sizeof(struct QUnit));
 AssignRuleI(Q->Rule, R);  Q->Next = NULL;
 Q->WordNumber = i; Q->UnknownWord = false;
 Q->WordBounary = false;
 Q->WordReference= -1;
 return Q; }
inline
Queue EnQUnitWG(char *R, NumOfWordsType i, NumOfWordsType j)
{Queue Q = (Queue) AllocElem(sizeof(struct QUnit));
 AssignRuleI(Q->Rule, R);  Q->Next = NULL;
 Q->WordNumber = i;
 Q->EndPoint = j;
 Q->Probability = MultNutralConst;
 Q->UnknownWord = false;
 Q->WordBounary = false;
 Q->WordReference= -1;
 strcpy(Q->Morpheme,"");
 return Q; }
/***/
/*** Allowing also probabilities for words: Prob is assumed the log10 of the
    probability                                                             */
inline
Queue EnQUnitWGP(char *R, NumOfWordsType i, NumOfWordsType j, ProbDomain Prob)
{Queue Q = (Queue) AllocElem(sizeof(struct QUnit));
 AssignRuleI(Q->Rule, R);  Q->Next = NULL;
 Q->WordNumber = i;
 Q->EndPoint = j;
 Q->Probability = Prob;
 Q->UnknownWord = false;
 strcpy(Q->Morpheme,"");
 Q->WordBounary = false;
 Q->WordReference= -1;
 return Q; }

void FreeQueue(Queue Q)
{if (Q != NULL) FreeQueue(Q->Next);
 cfree(Q);
}
/*****************************************/
inline
Queue CrQ()
{return NULL;}
/*****************************************/
inline
Queue Enqueue(char *R, Queue Q)
{Queue This = EnQUnit(R);
 Queue Last = Q;
 if (Last != NULL) {while (Last->Next != NULL) Last = Last->Next;
                    Last->Next = This; 
                    return Q;}
 else return This;
}
inline
Queue EnqueueEx(char *R, NumOfWordsType i, Queue Q)
{Queue This = EnQUnitEx(R,i);
 Queue Last = Q;
 if (Last != NULL) {while (Last->Next != NULL) Last = Last->Next;
                    Last->Next = This; 
                    return Q;}
 else return This;
}
inline
Queue EnqueueWG(char *R, NumOfWordsType i, NumOfWordsType j, Queue Q)
{Queue This = EnQUnitWG(R,i, j);
 Queue Last = Q;
 if (Last != NULL) {while (Last->Next != NULL) Last = Last->Next;
                    Last->Next = This; 
                    return Q;}
 else return This;
}
inline
Queue EnqueueWGP(char *R, NumOfWordsType i, NumOfWordsType j, Queue Q, ProbDomain Prob)
{Queue This = EnQUnitWGP(R,i, j,Prob);
 Queue Last = Q;
 if (Last != NULL) {while (Last->Next != NULL) Last = Last->Next;
                    Last->Next = This; 
                    return Q;}
 else return This;
}
NumOfWordsType EndPointOf(void *QV)
{return ((Queue) QV)->EndPoint;
}
/*****************************************/
inline
void QMap(Queue Q, void (*func)())
{ while (Q != NULL) {(*func)(Q->Rule, Q->Next); Q = Q->Next;}
}
inline
void QMapEx(Queue Q, void (*func)())
{ while (Q != NULL) {(*func)(Q->Rule, Q->WordNumber); Q = Q->Next;}
}
inline
void QMapWG(Queue Q, void (*func)())
{ while (Q != NULL) {(*func)(Q->Rule, Q->WordNumber, Q->EndPoint); Q = Q->Next;}
}
inline
void QMapWG_L(Queue Q, void (*func)())
{ while (Q != NULL) {(*func)(Q); Q = Q->Next;}
}
/*****************************************/
void PrintQUnit(char *R, void *Next)
{WRITE(R);WRITE(" ");}
void PrintQV(void  *QV)
{Queue Q = (Queue) QV;
 if (Q != NULL) {PRS(Q->Rule);PRC(" "); PRI(Q->WordNumber);PRI(Q->EndPoint);PRS("\n");}
}
void PrintQ(Queue Q)
{if (Q != NULL) {PRS(Q->Rule);PRC(" "); PRI(Q->WordNumber);PRI(Q->EndPoint);PRB(Q->Probability);PRS("\n");}
}
/*************/
inline
void UpdateProb(Queue Q, ProbDomain Prob)
{ if (Q != NULL) Q->Probability = Prob;
}
inline
void UpdateMorpheme(Queue Q, char *morpheme)
{
  if (Q != NULL) strcpy(Q->Morpheme,morpheme);
}
