#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"

#include "./Universals.h"
#include "./Aux.h"
#include "./CodeType.h"
#include "./DefsGrammar.h"

#include "./OptimizeLexicals.h"

/* _NumOfSubtrees is the number of subtrees in STSG */


/* global for one time initialization */
Boolean _Initialization_Done = false;
/*************************/
/* when we have no access to optimization concerning lex info */
#ifndef _OPTIMIZE_SUBTREE_LEX

TreeCodeT **N_ArrSubTListOfWord; /* for each subtree/tgram we keep the words that lexicalize it in an array */
int     *N_ArrOfListLengthPWord;     /* for each subtree/tgram we keep number of words......                    */

#define _NumOfSubtrees 0
#define _NUM_OF_TERMINALS 0

void Init_ArrayOfAllSubtreeWords() 
{N_ArrSubTListOfWord = NULL;
 N_ArrOfListLengthPWord = NULL;
}

Boolean *SubtreeArrayActivity = NULL;
void InitializeSubtreeActivity(TDomain *S, int _sen_length)  
{/* do nothing */
}

#endif
#ifdef _OPTIMIZE_SUBTREE_LEX
/**************************************************************************************/
/* Build an array for every word: is the word in input or not */
Boolean Q_WordInInput[ _NUM_OF_TERMINALS ];
Boolean SubtreeArrayActivity[ _NumOfSubtrees ];

void Init_Q_WordsInInput(TDomain *S, int _sen_length)
{int i; 
 for (i=0;i<_NUM_OF_TERMINALS;i++) Q_WordInInput[i]=false; /* initialize to false */
 for (i=0;i<_sen_length;i++) 
  if ((((int) S[i]) >= 0) && (((int) S[i]) < _NUM_OF_TERMINALS))
     Q_WordInInput[((int) S[i])] = true;     /* word in input--> true */
  else {fprintf(stderr,"Err: an unknown word in input ? message from LexOpt\n");exit(1);}
}
void Init_SubTreeArray()
{int i;
 for (i=0;i<_NumOfSubtrees;i++) SubtreeArrayActivity[i]=true; /* initialize to true*/
}
/* if word is NOT in input, go to its list of subtrees and mark those as false */
void MarkInactivityIfNotInInput()
{int i;
 for (i=0;i<_NUM_OF_TERMINALS;i++)            /* for every word          */
  if (Q_WordInInput[i]==false)                /* if word is not in input */
    for (j=0;j< N_ArrOfListLengthPWord[i];j++) /* for every subtree lexicalized by this word   */
      SubtreeArrayActivity[ (N_ArrSubTListOfWord[i])[j] ] = false; /* mark subtree as inactive */
}
/************************************************/
void InitializeSubtreeActivity(TDomain *S, int _sen_length)
{ Init_Q_WordsInInput(S, _sen_length);
  Init_SubTreeArray();
  MarkInactivityIfNotInInput();
}

#endif
/********************************************************************************/

Boolean CheckSubtreeActivity(TreeCodeT CodeT, TDomain *S, int _sen_length)
{
 if (_Initialization_Done==false) {InitializeSubtreeActivity(S, _sen_length); _Initialization_Done =true;}
 if (SubtreeArrayActivity != NULL) /* there is an optimization at all ? */
   return SubtreeArrayActivity[CodeT]; /* lookup if this subtree is active */
 else return true;
}

