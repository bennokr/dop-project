#include "Universals.h"
#include "Aux.h"
#include "DefsGrammar.h"
#include "PtrList.h"
#include "CodeType.h"
#include "Queues.h"
#include "sentence.h"
#include "Item.h"
#include "Trees.h"
#include "HashTable.h"

/**********/

inline
HashTable InitHashTB()
{int i; HashTable HT = (HashTable) MultAlloc((size_t) HashValue, (size_t) sizeof(TreeType) );
 for (i=0; i < HashValue; i++) HT[i] = NULL;
 return HT;
} 
/**************/
/* Two buckets: first for ended items, second for other items */
/**************/
inline
int HashInBuck(ItemTree item, HashTable HT)
{RDomain Rn; RType rt; int place; int Bucket;
 Rn = item->RuleNo; rt = item->RT;
 if (EndedItem(item) == true) Bucket = 1; else Bucket = 2;
 place = (int) Rn; 
 if (Bucket == 1) return ((StartEnded+ (Mod(place, EndedBuckSize))));
 else return (StartOths + (Mod(place, OthsBuckSize)));
}
/**************************/ 
/* returns a tree under which Rn rt is an item to be entered or to be found */
inline
TreeType SearchHT(ItemTree item, HashTable HT)
{
 return (SearchTree(item, HT[(HashInBuck(item, HT))]));
}
/*************************/
inline
void EnterHT(ItemTree item, HashTable HT, Boolean *Change)
{int ThisPlace;
 ThisPlace = HashInBuck(item, HT);
 HT[ThisPlace] = EnterTree(item, HT[ThisPlace], Change); 
}
/*************************/
/* Map on the items ItemTree */
inline
void HashTMap(HashTable HT, void (* fp)())
{int i; for (i=0; i < HashValue; i++) if (HT[i] != NULL) TreeMap(HT[i], fp); }
/*---------------*/
/* Map on the items ItemTree: fp take ItemTree and returns ItemTree */

inline
void XHashTMap(HashTable HT, ItemTree (* fp)())
{int i; for (i=0; i < HashValue; i++) if (HT[i] != NULL) XTreeMap(HT[i], fp); }

/* Map on the Ended/Oths items: fp take ItemTree and returns ItemTree */
inline
void XHashTMapEnded(HashTable HT, ItemTree (* fp)(), Boolean Ended)
{int i;
 if (Ended == true)
   for (i = StartEnded; i < EndedBuckSize; i++) {XTreeMap(HT[i], fp);}
 else
   for (i= StartOths; i < HashValue; i++) {XTreeMap(HT[i], fp);} 
}
inline
void CompactHashT(HashTable HT, Boolean Ended)
{int i; HashUnit temp;
  
 if (Ended == true)
   for (i = StartEnded; i < EndedBuckSize; i++) {temp = HT[i]; HT[i] = CompactTree(HT[i]); FreeTree(temp);} 
 else
   for (i= StartOths; i < HashValue; i++) {temp = HT[i]; HT[i] = CompactTree(HT[i]); FreeTree(temp);}
}
/********/
inline
void FreeHash(HashTable HT)
{int i; for (i=0; i < HashValue; i++) if (HT[i] != NULL) FreeTree(HT[i]); 
 free(HT); 
}
/*************************/
inline
void HashTMapEnded(HashTable HT, void (* fp)())
{int i; for (i = StartEnded; i < EndedBuckSize; i++) if (HT[i] != NULL) TreeMap(HT[i], fp); }
/*************************/
inline
void HashTMapOths(HashTable HT, void (* fp)())
{int i; for (i= StartOths; i < HashValue; i++) if (HT[i] != NULL) TreeMap(HT[i], fp); }
/************************/
inline
void CPHashTable(HashTable Dest, HashTable SR)
{int i;
 for (i=0; i < HashValue; i++) Dest[i] = CPTree(SR[i]);
}
/*************************/
