#include "ALL.h"

/* An array of PtrLists */

inline
PtrList *CrStaticArray()
{return ((PtrList *) MultAlloc(MAXLevels, sizeof(PtrList)));
}
inline
PtrList *InitStaticArray()
{PtrList *StaticArray; LevDomain i;
 StaticArray = CrStaticArray();
 if (StaticArray == NULL) {fprintf(stderr, "Err: StaticArray not initialized\n");exit(1);}
 for (i=0; i<= MAX_LEVEL; i++) StaticArray[i] = NULL;
 return StaticArray;
}

/* fp takes a void * which is an ItemTree */
inline
void RevMapOnStaticArr(PtrList *StaticArray, void (* fp)())
{LevDomain i;
 if (StaticArray == NULL) {fprintf(stderr, "Err: StaticArray not initialized\n");exit(1);}
 for (i=MAX_LEVEL; i>=0; i--) PListMap(StaticArray[i], fp);
}

inline
void MapOnStaticArr(PtrList *StaticArray, void (* fp)())
{LevDomain i;
 if (StaticArray == NULL) {fprintf(stderr, "Err: StaticArray not initialized\n");exit(1);}
 for (i=0; i<=MAX_LEVEL ; i++) PListMap(StaticArray[i], fp);
}
/* fp takes a void *Ptr ; fpFinal takes the current-level after the level items has been finished */
inline
void ExMapOnStaticArr(PtrList *StaticArray, void (* fp)(), void (* fpFinal)())
{LevDomain i;
 if (StaticArray == NULL) {fprintf(stderr, "Err: StaticArray not initialized\n");exit(1);}
 for (i=0; i<=MAX_LEVEL ; i++) {PListMap(StaticArray[i], fp); if (StaticArray[i] != NULL) (*fpFinal)(i); }
}

/* Only Free the PtrLists without touching the items */
void FreeStaticArray(PtrList *StaticArray)
{LevDomain i;
 if (StaticArray == NULL) {fprintf(stderr, "Err: StaticArray not initialized\n");exit(1);}
  for (i=0; i<= MAX_LEVEL; i++) {FreePListN(StaticArray[i]); StaticArray[i] = NULL;}
 cfree(StaticArray);
}

void EnterToArr(PtrList *StaticArray, ItemTree I)
{if (StaticArray == NULL) {fprintf(stderr, "Err: StaticArray not initialized\n");exit(1);}
 if (I != NULL)
  if ((I->Level >= 0) && (I->Level <= MAX_LEVEL))
    StaticArray[I->Level] = EnterPStack((void *) I, StaticArray[I->Level]);
  else {fprintf(stderr,"Err: in EnterToArr in ItemLevels.c (level %d)\n",I->Level); exit(1);}
 else ;
}

/**************************/
/* ON VALID ITEMS ONLY */
PtrList *OrderVIsOf(Set SET)
{PtrList *StaticArray;
 void En2Array(ItemTree I) {if (I != NULL) if (I->Valid == true) EnterToArr(StaticArray,I);}
 StaticArray = InitStaticArray();
 if (SET->Size > 0) SetsMap(SET, (void *) &En2Array);
 return StaticArray;
}

/* Lower levels are served first */
inline
void MapOnLevelsOfV(Set SET, void (* fp)())
{PtrList *StaticArray;
 if (SET->Size != 0) 
  {StaticArray = OrderVIsOf(SET); MapOnStaticArr(StaticArray, fp); FreeStaticArray(StaticArray);}
}
/* higher levels are served first */
inline
void RevMapOnLevelsOfV(Set SET, void (* fp)())
{PtrList *StaticArray; 
 if (SET->Size != 0) 
  {StaticArray = OrderVIsOf(SET); RevMapOnStaticArr(StaticArray,fp); FreeStaticArray(StaticArray);}
}
/**************************/
/* ON ALL ITEMS */
PtrList *OrderIsOf(Set SET)
{PtrList *StaticArray; 
  void En2Array(ItemTree I) {EnterToArr(StaticArray, I);}
 StaticArray = InitStaticArray();  
 if (SET->Size > 0) SetsMap(SET, (void *) &En2Array);
 return StaticArray; 
}

/* depends on Ended */
PtrList *OrderIsOfEnded(Set SET, Boolean Ended)
{PtrList *StaticArray; 
 void En2Array(ItemTree I) { EnterToArr(StaticArray, I);}
 StaticArray = InitStaticArray();  
 if (SET->Size == 0) ;
 else if (Ended == true) SetsMapEnded(SET, (void *) &En2Array);
      else SetsMapOths(SET, (void *) &En2Array);
 return StaticArray; 
}
PtrList *Controlled_OrderIsOf(Set SET, Boolean (* CheckFP) (), Boolean Ended, Boolean Unaries)
{PtrList *StaticArray; 
 void En2Array(ItemTree I) {if (((*CheckFP)(I, Ended, Unaries)) == true) EnterToArr(StaticArray, I);}
 StaticArray = InitStaticArray();  
 if (SET->Size > 0) SetsMap(SET, (void *) &En2Array);
 return StaticArray; 
}
/****************************************/
/* We assume that item with lower levels have higher priority */
/* Lower priority are served first                            */
inline
void MapOnLevelsOf(Set SET, void (* fp)())
{PtrList *StaticArray;
 if (SET->Size != 0) {StaticArray = OrderIsOf(SET); MapOnStaticArr(StaticArray, fp); FreeStaticArray(StaticArray);}
}
inline
void RevMapOnLevelsOf(Set SET, void (* fp)())
{PtrList *StaticArray;
 if (SET->Size != 0) {StaticArray = OrderIsOf(SET); RevMapOnStaticArr(StaticArray, fp); FreeStaticArray(StaticArray);}
}

/* Ended == true ==> do ended items   */
/* Ended == false ==> do A->B*C items */
inline
void MapOnLevelsOfEnded(Set SET, void (* fp)(), Boolean Ended)
{PtrList *StaticArray;
 if (SET->Size != 0)
  {StaticArray = OrderIsOfEnded(SET, Ended); MapOnStaticArr(StaticArray, fp); FreeStaticArray(StaticArray);}
}
inline
void RevMapOnLevelsOfEnded(Set SET, void (* fp)(), Boolean Ended)
{PtrList *StaticArray;
 if (SET->Size != 0)
  {StaticArray = OrderIsOfEnded(SET, Ended); RevMapOnStaticArr(StaticArray, fp); FreeStaticArray(StaticArray);}
}

/* fp takes a void *Ptr (which is an ItemTree) ; fpFinal does something after a level has been finished */
inline
void ExMapOnLevelsOfEnded(Set SET, void (* fp)(), void (* fpFinal)(), Boolean Ended)
{PtrList *StaticArray;
 if (SET->Size != 0)
   {StaticArray = OrderIsOfEnded(SET, Ended); ExMapOnStaticArr(StaticArray, fp, fpFinal); FreeStaticArray(StaticArray);}
}

/* fp takes a void *Ptr (which is an ItemTree) ; fpFinal does something after a level has been finished */
inline
void ExMapOnLevelsOfEntry(Set SET, void (* fp)(), void (* fpFinal)())
{PtrList *StaticArray;
 if (SET->Size > 0) 
  {StaticArray = OrderIsOf(SET); ExMapOnStaticArr(StaticArray, fp, fpFinal); FreeStaticArray(StaticArray);}
}
/*************************/
/* fp takes a void *Ptr (which is an ItemTree) ; fpFinal does something after a level has been finished */
/* CheckFP selects which items in the entry are involved in the Map                                     */
/* CheckFP takes ItemTree, Boolean DoEnded, Boolean DoUnaries and returns Boolean                       */
inline
void Controlled_MapOnLevelsOf(Set SET, void (* fp)(), void (* fpFinal)(), Boolean  (* CheckFP)(), Boolean Ended, Boolean Unaries)
{PtrList *StaticArray;
 if (SET->Size != 0)
   {StaticArray = Controlled_OrderIsOf(SET, CheckFP, Ended, Unaries); 
    ExMapOnStaticArr(StaticArray, fp, fpFinal); FreeStaticArray(StaticArray);
   }
}
