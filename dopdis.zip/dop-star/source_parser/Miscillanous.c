#include "./ALL.h"

/***********/
/* This file contains functions that can be used in order to
   compile out parts of the Grammar from the Disambiguator.
   For example one can compile out rules and their presentaions
   in the Grammar. An application is within the CoLa (Constituent
   Labeling) Mechanism that supports the parser. CoLa needs a
   file that contains for the grammar at hand its internal 
   representation of the grammar rules.
*/ 
void PrintOut(RDomain i, Rule_Ptr RP, RType RT)
{PRI(i); PRS("  ");
 PRI((int) RT); PRS("  ");

 /* G_Array = NTArray; */
 PRS(NT_Name_Of(NT_Ptr_Of(LHS_Of(RP), LHS_)));PRS("  ");
 switch (RT) {
      case _Unary : 
                  /* G_Array = Rhs1Array; */
                  PRS(NT_Name_Of(NT_Ptr_Of(RHS1_Of(RP), RHS_1)));
                  PRS("\n");
               break;
      case _Binary :
                  /* G_Array = Rhs1Array; */
                  PRS(NT_Name_Of(NT_Ptr_Of(RHS1_Of(RP), RHS_1)));PRS("  ");
                  /* G_Array = Rhs2Array; */
                  PRS(NT_Name_Of(NT_Ptr_Of(RHS2_Of(RP), RHS_2)));
                  PRS("\n");
               break;
      case _Term   :
                  PRS(Term_Name_Of(Term_Ptr_Of(RHS1_Of(RP))));
                  PRS("\n");
               break;
      case _Eps    : PRS("\n");
               break;
      default : printf("Unknown rule soort\n"); exit(1);
               break;
    
 };
}
   
void PrintOut_Rules(RType RT)
{RDomain i;
   switch (RT) {
      case _Unary : 
                   for (i =0; i < URSize; i++) PrintOut(i, &URules[i], RT);
               break;
      case _Binary :
                   for (i =0; i < BRSize; i++) PrintOut(i, &BRules[i], RT);
               break;
      case _Term   :
                   for (i =0; i < TRSize; i++) PrintOut(i, &TRules[i], RT);
               break;
      case _Eps    : 
                   for (i =0; i < EpsRSize; i++) PrintOut(i, &EpsRules[i], RT);
               break;
      default : printf("Unknown rule soort\n"); exit(1);
               break;
    }; /* switch */
}
void CompileRuleNums()
{PrintOut_Rules(_Term);
 PrintOut_Rules(_Unary);
 PrintOut_Rules(_Binary);
 PrintOut_Rules(_Eps);
}
