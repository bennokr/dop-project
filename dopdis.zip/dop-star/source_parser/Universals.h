#include <sys/types.h>
#include <sys/times.h>
#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <math.h> 
#include <float.h> 
#include <malloc.h>
/********************************/
/* The types of codes and operations
   of of conversion on them     */
#ifndef TreeCodeT 
#define TreeCodeT  unsigned int
#endif
#ifndef InTreeCodeT
#define InTreeCodeT  unsigned int
#endif

#ifndef TreeAToD
#define TreeAToD (unsigned int) atol
#endif
#ifndef InTreeAToD
#define InTreeAToD (unsigned int) atol
#endif
#ifndef C_Addr_Domain 
#define C_Addr_Domain unsigned int
#endif

/* The unvalid value for C_Addr_Domain */
#ifndef _C_Addr_UNV
#define _C_Addr_UNV UINT_MAX
#endif
/********************************/
#ifndef ProbDomain
#define ProbDomain double
#define MaxNutralConst ((ProbDomain) (-(DBL_MIN)))
#define SumNutralConst ((ProbDomain) (-(DBL_MIN)))
#endif

/*
#ifndef ProbDomain
#define ProbDomain float
#define MaxNutralConst ((ProbDomain) (-(FLT_MIN)))
#define SumNutralConst ((ProbDomain) (-(FLT_MIN)))
#endif
*/



#ifndef MultNutralConst 
#define MultNutralConst ((ProbDomain) 0.0)
#endif
