extern void SampleDerfromPF(ParForest PF);
