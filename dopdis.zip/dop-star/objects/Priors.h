extern NTDomain _NumOfPriorSym;

extern void Init_Various_PriorProbs_Tables();
extern void Init_PriorProbs();
extern ProbDomain Prior_ProbOfNT(NTDomain NT);
extern void Show_PriorProbs();
extern Boolean _PriorsExist;
extern ProbDomain PriorProbOfItem(ItemTree I); 
