
enum _Corpora_Names {_WSJ = 0, _Hebrew = 1, _Negra = 2, _New = 3, _GENERAL = 4};
#ifndef _Corpora_List
#define _Corpora_List enum _Corpora_Names
#endif

extern _Corpora_List _which_corpus;
