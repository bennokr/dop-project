#ifndef EntryType
#define EntryType Set
#endif

typedef EntryType *EntryPtr;
typedef EntryPtr *TableType;



EntryPtr CrEntry();
TableType CrTable(int n);
EntryPtr ENTRY_Of(TableType TAB, int i, int j);

/*** HERE et should be of an item type **/
/*** also, in TABLE.c UpdateEntry should be corrected accordingly **/
extern void UpdateEntry(TableType TAB, ItemTree et, int i, int j);
extern void PrintEntry(TableType TAB, int i, int j);
extern void PrintTable(TableType TAB, int n);
extern void PrDecen(ItemTree item);
extern void VPrDecen(void *item, int i);
extern void PrTopDown(TableType TAB, int n);
/*********/
/* The following two are defined in RedPtrL.c under ../D-EntryCYK */
extern void ReduceAddsBy(TableType TAB, int i, int j);
extern void  FreeUnvalidItems(TableType TAB, int n);
extern void  FreeEmptyDFItems(TableType TAB, int i, int j, Boolean Ended);
extern void  TotallyFreeEmptyDFItems(TableType TAB, int i, int j, Boolean Ended);
extern void  FreeInsideOfItems(TableType TAB, int i, int j, Boolean Ended);
extern void FreeTable(TableType TAB, int length);
extern void NewEntry(TableType TB, int i, int j, int length);
extern void FreeWholeDerivForest(TableType TAB, int n);
extern void MapOnTableEntries(TableType TAB, int n, void (* fp)()); 
extern void RevMapOnTableEntries(TableType TAB, int n, void (* fp)()); 
extern void MapBetweenIJ(int i, int j, void (* fp)()); 
extern void FreeUnvItemsInEntry(int i, int j, EntryPtr ThisEPtr);
extern void MapOnEntriesForSpan(TableType TAB, int span, int n, void (* fp)())  ;
extern void  FreeUnvalidItemsLeftSpine(TableType TAB, int n); 
extern void MapOnLeftSpineEntries(TableType TAB, int n, void (* fp)());
extern EntryPtr FreeEntryPtr(EntryPtr EP);
extern EntryPtr CopyEntry(EntryPtr EPtr) ;
extern void MapOnEntriesPerSpan(TableType TAB, int n, void (* fpBef)(), void (* spanFP_A)(), void (* fpAft)(), void (* spanFP_B)());
extern void MapOnRightSpineEntries(TableType TAB, int n, void (* fp)()); 
extern void  FreeUnvalidItemsRightSpine(TableType TAB, int n) ;
extern void MapOnEntriesBetweenIJ(TableType TAB, int i, int j, void (* fp)()) ; 
extern void  FreeUnvalidItemsBetweenIJ(TableType TAB, int i, int j, int n);
extern void XUpdateEntry(TableType TAB, ItemTree et, int i, int j, WordList trans);
extern void MakeCompactEntry(TableType TABLE, int i, int j, int sen_length);
extern void FreeFastArraySpan(TableType TAB, int span, int length);
