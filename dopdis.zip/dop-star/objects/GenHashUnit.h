#include "Universals.h"

typedef int FreqType;
typedef int UnitNumType;

struct UnitType {
   char *Rule;   /* A string denoting for example a tree */
   UnitNumType UnitNum; /* The serial number of this unit */
   FreqType UnitFreq;
   ProbDomain UnitProb;
};
typedef struct UnitType *UnitPtr;
/***********************************************************************/
UnitPtr NewUnit(char *String, UnitNumType N);
UnitPtr FreeNewUP(UnitPtr UP);
/****************************/
void MapOnUnitsKey(UnitPtr UP, void (*fp)());
void EqUnitKey(void *ua, void *ub, Boolean *EQ);
void EqUnitPtrs(void *A, void *B, Boolean *Found);

void PrntUnitsNum(UnitPtr UP);
void ShowFreqOf(void *VUP);
void ShowOUT(void *VUP);
