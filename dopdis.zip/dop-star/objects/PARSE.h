extern DuoPtr Duo;
extern Boolean _MakePForest;
extern Boolean Interleaved;
extern Boolean Right_Linear;
extern Boolean _FullSenRec;

void Init(TableType TAB, TDomain *Sentence, int length);
Boolean Complete(TableType TAB, int i, int j, DuoPtr Duo);
void CompleteAll(TableType TAB, int i, int j);
Boolean Deduce(TableType TAB, int i, int j);
TableType PARSE(TableType *CKYTAB, TDomain *Sentence, int length, DuoPtr Duo);
/*****************************/
extern PtrListArray ArrayOfTransSet;
extern void CompItem(void *Ptr, Boolean InitDFofItem, DuoPtr Duo);
extern void CompItemInter(void *Parent, void *Child, PtrList ChsKJ, Boolean InitDFofItem, DuoPtr Duo);
extern void CompDFEntry(EntryPtr EPtr, DuoPtr Duo);
extern Boolean _TestFull(int j, int length);
extern void EvaluateItemN(ItemTree Parent, ItemTree Child, PtrList ChsKJ, ItemTree ParentCopy);
extern void EvaluateItem(ItemTree I);
extern void EvaluateEntry(EntryPtr EP);
extern void MarkUnValid(TableType TAB, int i, int j);
extern void ReduceSpace(TableType TAB, int i, int j);
/* fp takes an ItemPtr */
extern void MapOnLHSEnded(NTDomain NT, Set S, void (*fp)());
extern void MapOnLHSEndedValid(NTDomain NT, Set S, void (*fp)());
/* fp takes three things: non-terminal number, ItemTree  and a pointer to a boolean */
extern void MapOnRHS2Oths(NTDomain NT, Set S, void (*fp)());
extern void MapOnRHS2OthsValid(NTDomain NT, Set S, void (*fp)());
/* fp takes three things: non-terminal number, ItemTree and a pointer to a boolean */
extern void MapAllRHS2Oths(Set S, void (*fp)(), Boolean CheckValidity);
extern void PListMapUntill(PtrList L, void (*fp)());
extern Boolean IsErLHSEnded(NTDomain NT, Set S);
extern Boolean IsErRHS2Oths(NTDomain NT, Set S);

