extern Boolean RedDF_Item(ItemTree I);
extern void ShowAllStartItems(TableType TAB, int n);
extern void ShowAllStartItemsWG(TableType TAB, int n);
extern void ShowMPD_OfDF(DerFPtr DFP,Boolean showsubs, Boolean top);
extern void ShowProbs_OfDer(DerFPtr DFP);
extern void ShowMPD_OfICP(ItemCPtr I);
extern void VShowMPD_OfItem(void *I);
extern void ShowMPD_OfPF(ParForest PF);
/****************************************/
extern void ShowProbOfICP(ItemCPtr I);
extern void ShowProbOfItem(ItemTree I);
/*************/
extern void ShowMPD_OfI(ItemTree I);
/****************/
extern void ShowProb_OfMPD(ItemTree I);
extern void MarkVByChunks(TableType TAB, int length);
