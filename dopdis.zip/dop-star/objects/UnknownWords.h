#ifndef _Corpora_List
enum _Corpora_Names {_WSJ = 0, _Hebrew = 1, _Negra = 2, _OVIS = 3, _GENERAL = 4, _ANY = 4};
#define _Corpora_List enum _Corpora_Names
#endif

extern _Corpora_List _which_corpus;
/*****************************************************/
#define non_lex_reps    "a0"
extern Boolean LEXICALIZED_WSJ;

extern void UpdateRepresArrayForSentence(char *nonterm, int sen_len);
extern Boolean Lex_In_Sen(char *nonterm); 

extern char *ExtractWordRepFrom(char *nonterm);
extern char *ExtractPosTagFrom(char *nonterm);
/* given a symbol for a postag: return its internal representation */
extern char *EX_INTERN_REP_OF_POSTAG(char *postag);
extern char *TRANS_TO_INTERN_REP_OF_POSTAG(char *postag);
extern char *EX_INTERN_REP_OF_WORD(char *word);
extern char *TRANS_TO_INTERN_REP_OF_WORD(char *word);
extern void RemoveHeadFromName(char *Name, char *RES); 

/********8*************************/                                                                                                     
extern void PrintUnknownWExten(char *exten);
extern char *UnknownWExten(char *Word, Boolean first);
extern char *GetMorphHebrew(char *word, Boolean FirstWord);
extern void PrintUnknownWExtenHebrew(char *exten);
extern char *UnknownWExtenHebrew(char *Word, Boolean first);
extern char *GetMorphEnglish(char *word, Boolean FirstWord);
extern void PrintUnknownWExtenEnglish(char *exten);
extern char *UnknownWExtenEnglish(char *Word, Boolean first);
extern char *GetMorphGEN(char *word, Boolean FirstWord);
extern void PrintUnknownWExtenGEN(char *exten);
extern char *UnknownWExtenGEN(char *Word, Boolean first);                                                                                        
extern char *UnknownWExten(char *Word, Boolean first);
extern void PrintUnknownWExten(char *exten);
extern char *GetMorph(char *Word, Boolean first);

