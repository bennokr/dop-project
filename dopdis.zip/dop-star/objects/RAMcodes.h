extern Boolean _USE_RAM;

extern void InitializeRAM_RApps();
extern void SaveRAppsInRAM(RType RT, Rule_Apps RApps, RDomain RNum);
extern Rule_Apps FetchRAppsFromRAM(RType RT, RDomain RNum);
