#ifndef DIN_SETS_SEC
#define DIN_SETS_SEC

#define MemDomainZero  -1
#define NOT_IN_SET     -1
#define MemDomain      RDomain
#define SetBlockSize   2

struct DinSetStruct {
    MemDomain *members;     /* an expanding array */
    int       cu_size;
    int       max_size;
};
typedef struct DinSetStruct DinSetStr;
typedef struct DinSetStruct *DinSet;

/*****************************************************************/
/* A unit for dealing with dinamically growing sets of MemDomain */
/*****************************************/
extern int PlaceInSet(DinSet set, MemDomain mem);
extern Boolean MemberInSet(DinSet set, MemDomain mem);
extern DinSet Enter_DinSet(DinSet set, MemDomain new);
extern void MapOnDinSet(DinSet set, void (* fp)());

#endif
