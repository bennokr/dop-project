/** General declations and definitions */
/*******************/
#include <Universals.h>
#include <Aux.h>
#include <CodeType.h>
#include <DefsGrammar.h>
#include "./NgramsGrammar.h"
/**************************/
#include <NgramsGrammar.c>
/**************************/                                                                                                                         
/** The globals **/
Boolean ThereAreNgrams = false;
struct GlobalNgramStruct GlobalNgram;

/* if the module is defined, use the following definitions */
#ifdef NGRAMMODULE
void initialize_ngrams()
{ThereAreNgrams = true;
 GlobalNgram.unigram_size = UNIGRAMS_SIZE;
 GlobalNgram.unigram_array = UNIGRAMS_ARRAY; 
 GlobalNgram.bigram_size = BIGRAMS_SIZE;
 GlobalNgram.bigram_array = BIGRAMS_ARRAY; 
}
#endif
/* if the module is NOT defined, use the following definitions */
#ifndef NGRAMMODULE
void initialize_ngrams()
{ThereAreNgrams = false;
 GlobalNgram.unigram_size = 0;
 GlobalNgram.unigram_array = NULL; 
 GlobalNgram.bigram_size = 0;
 GlobalNgram.bigram_array = NULL; 
}
#endif
