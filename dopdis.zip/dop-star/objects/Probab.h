/*********************************/

/* All the following should become simply macros */
void IsTooSmall(ProbDomain P);
/***/
extern ProbDomain Trans_2_log10(double A);
extern ProbDomain ProbOf(CodePtr CP);
extern ProbDomain MultProbs(ProbDomain P1, ProbDomain P2);
extern ProbDomain SumProbs(ProbDomain P1, ProbDomain P2);
extern ProbDomain SubtractProbs(ProbDomain P1, ProbDomain P2);
extern ProbDomain MaxProbs(ProbDomain P1, ProbDomain P2, Boolean *First);
extern ProbDomain Prob_From_R(RDomain RuleNo, RType RT, C_Addr_Domain CAdr, Code_Soort CT);
extern ProbDomain SumRsProbs(Rule_Apps RA);
extern ProbDomain ProbOfWord(ItemTree I);
extern ProbDomain ProbOfWordOrOne(ItemTree I);
extern ProbDomain DevideProbs(ProbDomain P1, ProbDomain P2);
extern ProbDomain CodeProbability(ItemTree IT, DerFPtr DFP, Code_Soort CT);
/*******************/
extern Boolean TakeProbOfTrans; /* a global */
extern Boolean EQUAL_Probs(ProbDomain A, ProbDomain B);
extern ProbDomain NthRootOf(ProbDomain P, short int N);
