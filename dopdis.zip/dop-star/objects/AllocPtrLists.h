#ifndef blok_size
#define blok_size 500
#define _free 1
#define not_free ((_free==1)?0:1)
#endif

Binary arr_free_or_not[blok_size];

void init_array()
{int i;
 _num_of_free = 500;
 for (i=0;i<blok_size;i++) arr_free_or_not[i]= _free; /* all free */
}


