
struct ITEMPTR_STR  {
    ItemTree                 item;
    struct ITEMPTR_STR       *Right  ; 
    struct ITEMPTR_STR       *Left  ;     
};
typedef struct ITEMPTR_STR *TreeType;

/************************************************/
TreeType CrTree();
/**************************/
/* searches for item in Tree and return a pointer to where */
/* the first time an item is encountred with the same RuleNo */
/* or else a pointer to where it should be entered (a pointer*/
/* to the last which is smaller than item.                   */
TreeType SearchTree(ItemTree item, TreeType Tree);
/*************************/
TreeType EnterTree(ItemTree item, TreeType Tree, Boolean *Change);
void TreeMap(TreeType Tree, void (* fp)());
RDomain TreeDepth(TreeType Tree);
RDomain TreeCount(TreeType Tree);
/********************/
TreeType CPTree(TreeType T);
/* fp takes ItemTree and returns ItemTree */
void XTreeMap(TreeType Tree, ItemTree (* fp)()); 
TreeType CompactTree(TreeType Tree);
