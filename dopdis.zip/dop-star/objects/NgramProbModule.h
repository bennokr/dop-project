extern ProbDomain GetStartProbOf(TDomain WordNum);
extern ProbDomain GetEndProbOf(TDomain WordNum); 
extern ProbDomain GetNgramProbFor(TDomain ContextW1, TDomain Word); 
extern ProbDomain NgramProbFuncForRight(DerFPtr DFp, DerFPtr DFch, Child_Type ChNum);
ProbDomain NgramProbOfComb(DerFPtr DFp, DerFPtr DFch, Child_Type ChNum);
