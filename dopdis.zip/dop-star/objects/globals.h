extern Boolean _USE_WBIGRAM_RATIOS; /* whether to multiply with bigram ratios or not */ 

extern Boolean LEXICALIZED_WSJ;
enum ParserType {_SKND_G_ONLY=1,_BOTH_G=2};
#ifndef WhichParserT
#define WhichParserT enum ParserType
#endif

enum GramCountT {SINGLE_G=1,DOUBLE_G=2};
#ifndef GRAM_COUNT
#define GRAM_COUNT enum GramCountT
#endif
extern GRAM_COUNT _NumOfGrammars_Used;
/*****/
extern WhichParserT ParsingMethod;

enum _WORDGRAPH_PROBS_COMB {_REGULAR_INTEGRATION=0,_INTERP_INTEGRATION=1};
#ifndef _WORDGRAPH_PROBS_COMB_T
#define _WORDGRAPH_PROBS_COMB_T enum _WORDGRAPH_PROBS_COMB
#endif
extern _WORDGRAPH_PROBS_COMB_T _WORDGRAPH_PROBS_METHOD;
extern ProbDomain _Lambda_WG;
/* Original implementation: Interleaved = false; RedDerForest = true;    */
/* Interleaved = true; RedDerForest = false;                             */

extern Boolean Interleaved ; 
extern Boolean Semi_Interleaved ; 
extern Boolean _DisambiguateB;
extern Boolean _APPLY_PRUNE;
extern Boolean _BIGRAM_PRUNE;
extern Boolean _Whole_DFSpace;
extern Boolean _Show_PosTags_global;
extern Boolean _ShowChunks ;
extern Boolean _SpareMemoryPruning;
extern Boolean _Allow_Same_Level; 
extern Boolean _FilterPosTags;
extern Boolean HEBREW_POSTAG_SIMILARITY;

enum _PARSER_VERSION_TYPE {_MPP_VERSION=1,_MPD_VERSION=2,_GLRR_VERSION=3,_LRRMPD_VERSION=4};
extern enum _PARSER_VERSION_TYPE _PARSER_VERSION;

extern int MPP_Sample_Size;
extern Boolean _Print_All_Sampled;
extern Boolean _Print_All_Sampled_DER;

                   /* Interleaved prob computation with CKY    */

/* NOTICE: If Interleaved = true then RedDerForest must be false         */ 

/* #define RedDerForest true           true: saves memory use/costs time */
extern Boolean RedDerForest;
extern Boolean CoLaM_On;
extern Boolean RedDF_CEntries;/* Reduce der-forests of chart-entries that are compelted */
extern Boolean _MakePForest;
extern Boolean _FullSenRec;

extern Sentence TheWG ;
extern Sentence TheSen ;
extern PtrListArray ArrayOfTransitions;
extern PtrListArray ArrayOfTransSets;

extern TDomain *S; /*** The input sentence encoded */
extern int _sen_length ;         /*** The length of the input sentence **/
extern Boolean ERROR;
extern TableType CKYTAB;     /*** The CYK table.             */
extern ParForest PARF ;   /* The Parse-Forest structure   */
extern Boolean Right_Linear ;
extern Boolean TakeProbOfTrans; /* include probabilities of transitions of wordgraphs or not */
extern FILE *fpOUT, *fpIN, *fpCodes, *fpChsPl;
extern NTDomain _NumOfStartSym ;
extern NTDomain _NumOfStopSym;

extern  DuoPtr Duo;

/****/
extern GRAM_COUNT NUM_OF_GRAMS();
extern void TestGlobalSetting();
extern void TestCodeFiles();
extern Boolean _Resolve_Unknown;
extern Boolean _PoSTagSequencesInput;
extern Boolean _OVIS_BKF_Pruning;
extern Boolean  _ngram_is_used ;

#ifndef _USE_WBIGRAM_RATIOS
#define  _USE_WBIGRAM_RATIOS _ngram_is_used
#endif
