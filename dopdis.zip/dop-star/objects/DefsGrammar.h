#ifndef UNVALID_SYM
#define UNVALID_SYM "---"
#endif
#ifndef UNVALID_SYMNUM
#define UNVALID_SYMNUM -1 
#endif
#ifndef UNVALID_RNUM                      
#define UNVALID_RNUM -1 
#endif
/**************************************/
/* Check TDomain en NTDomain of unsigned mogelijk is */
#ifndef RDomain
#define RDomain   int
#endif

/* SymDomain is the largest between NTDomain and TDomain */
#ifndef Sym_Domain 
#define Sym_Domain  int
#endif
#ifndef NTDomain
#define NTDomain  int
#endif
#ifndef TDomain
#define TDomain   NTDomain               /* keep same as NTDomain */
#endif
#ifndef LevDomain
#define LevDomain  short
#endif
/**************************************/

enum SYM_LOCATION {LHS_ = 1,RHS_1 = 2,RHS_2 = 3};
#ifndef SYM_LOC
#define SYM_LOC enum SYM_LOCATION
#endif
/***************************/
/* DO NOT CHANGE THE ORDER OF the FIELDS IN THIS STRUCT because of the grammar generator */
struct NTStruct {
char *NT;
RDomain *TRules;
RDomain TCount;
RDomain *URules;
RDomain UCount;
RDomain *BRules;
RDomain BCount;
RDomain *EpsRules;
RDomain EpsCount;
ProbDomain NTprior;
};

/* DO NOT CHANGE THE ORDER OF the FIELDS IN THIS STRUCT because of the grammar generator */
struct RuleStruct {
       NTDomain lhs; 
       TDomain rhs1; 
       NTDomain rhs2; 
};
/** ** *** *****/
/* DO NOT CHANGE THE ORDER OF the FIELDS IN THIS STRUCT because of the grammar generator */

struct TermStruct {
char *Term;
RDomain *TRules;
RDomain TCount;
};
/********************************/
/* Operations on R. I.e.
   operations on the arrays of 
   rules.                       */
/***********************************/
typedef struct RuleStruct *Rule_Ptr;
/*-----------------*/
/* returns Rule_Ptr or NULL        */

Rule_Ptr RulePtr_Of(RDomain RNumber, RType RT);

/*-----------------*/
NTDomain LHS_Of(Rule_Ptr RPtr);
NTDomain RHS1_Of(Rule_Ptr RPtr);
NTDomain RHS2_Of(Rule_Ptr RPtr);

NTDomain LHS_OfR(RDomain RNumber, RType RT);
NTDomain RHS1_OfR(RDomain RNumber, RType RT);
NTDomain RHS2_OfR(RDomain RNumber, RType RT);
/**********************************/
/* Operations on the Nonterminals
   type. I.e. on the three arrays
   NT-, Rhs1- and Rhs2Array.    
   G-Array is a global which must be
   set first to one of these three
   arrays before the use of any of 
   the following functions.       */
/*------------*/
typedef struct NTStruct *NT_Ptr;
NT_Ptr G_Array;
NT_Ptr NT_Ptr_Of(NTDomain NT, SYM_LOC loc);
char *NT_Name_Of(NT_Ptr Ptr);
RDomain *Rules_Of(NT_Ptr Ptr, RType RT);
RDomain R_Count_Of(NT_Ptr Ptr, RType RT);
/*--------------*/
/* Map func on the RT rules of Ptr. func takes a rule number RDomain only.             */
void MapOn_Rules_Of(NT_Ptr Ptr, RType RT, void (* func)());

/* func(NT_Ptr A, NTDomain B) */
void MapOnAllNonterminals(void (* func)());
/********************************/
/* The type Terminals and its 
   operation on TermArray       */
typedef struct TermStruct *Term_Ptr;

Term_Ptr Term_Ptr_Of(TDomain TermNo);
char *Term_Name_Of(Term_Ptr Ptr);
RDomain *T_Rules_Of(Term_Ptr Ptr);
RDomain T_R_Count_Of(Term_Ptr Ptr);
void TMapOn_Rules_Of(Term_Ptr Ptr, void (* func)());
char *TName(NTDomain NTno);
char *Name(NTDomain NTno);
/******************************************************/
/*************************************/
/** Tagging the input sentence with the numbers 
    of the words as preparation for parsing        ****/
NTDomain NT_NUM_Of(char *NONT);
TDomain T_NUM_Of(char *Word);
/*******************************/
/* Operations on a list of words
   (i.e. Sentence). An array of
   wordnumbers is constructed for
   the sentence. All the parsing 
   will take place on this array *

TDomain *TagSentence(Sentence S);
TDomain *TagUnknownWs(Sentence WG, TDomain *Sen); */
/*****************************/
/* The Grammar parameters are declared hereunder */
 int      Active_Grammar_Number ;
 NTDomain StartNonterminal ;
 NTDomain NonTSize ;
 TDomain TermsSize ;
 RDomain TRSize  ;
 RDomain URSize  ;
 RDomain BRSize  ;
 RDomain EpsRSize  ;

 struct RuleStruct  *EpsRules;
 struct RuleStruct *TRules ;
 struct RuleStruct *URules ;
 struct RuleStruct *BRules ;

 struct NTStruct *NTArray ;
 struct NTStruct *Rhs1Array ;
 struct NTStruct *Rhs2Array ;
 struct TermStruct *TermsArray ;

 struct Place_Struct *T_R_Apps ;
 struct Place_Struct *B_R_Apps ;
 struct Place_Struct *Eps_R_Apps ;
 struct Place_Struct *U_R_Apps ;
 TreeCodeT TotalRootsNum ;
 ProbDomain *TheProbOf ;
 NTDomain _BIGRAM_SYM_NUM;


/***************************************************/
extern RDomain RNumOfNT_ByLHS(char *LHS, char *RHS1, char *RHS2, RType RT);
extern RDomain RNumOfNT_ByRHS1(char *LHS, char *RHS1, char *RHS2, RType RT); 
extern char *Name(NTDomain NTno);
/***************************************************/
extern int NUMofGRAMMARS_Used();
extern void InitGrammar(); 
