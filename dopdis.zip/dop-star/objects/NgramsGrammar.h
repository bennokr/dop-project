enum NGRAM_KINDS {UNIGRAM_ENUM=1, BIGRAM_ENUM=2};

#ifndef ngram_kind
#define ngram_kind enum NGRAM_KINDS 
#endif

/* The structure of an entry: <ngram>, probability and the backoff weight */
struct ngram_struct {
   char *word_ngram;
   ProbDomain probability;
   ProbDomain bkf_weight_as_context;
};
typedef struct ngram_struct *Ngram_Ptr;

struct GlobalNgramStruct {
  int unigram_size;
  Ngram_Ptr unigram_array; 
  int bigram_size;
  Ngram_Ptr bigram_array; 
};

/* The globals of this module */
extern Boolean ThereAreNgrams;
extern struct GlobalNgramStruct GlobalNgram;
