int V_BEAM_WIDTH;
ProbDomain L_WINDOW              ; 
ProbDomain R_WINDOW              ;
ProbDomain _STEP_RATIO           ;
ProbDomain _BI_RATIO             ;
ProbDomain _BI_RATIO_UNKNOWNS    ;
ProbDomain _LB_LARGE_ENTRY_SIZE  ;
ProbDomain _LB_RATIO             ;

ProbDomain R_PRUNE_RATIO        ;
ProbDomain O_PRUNE_RATIO        ;
ProbDomain Second_R_PRUNE_RATIO  ;
ProbDomain Second_O_PRUNE_RATIO  ;
ProbDomain R_PRUNE_RATIO_GT;
ProbDomain O_PRUNE_RATIO_GT;                 

extern int _sen_length;
extern void Init_pruning_parameters();
