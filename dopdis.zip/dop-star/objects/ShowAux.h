void NumOfNodesInPF(ParForest PF);
