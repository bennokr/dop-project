
#define MaxGRR_ENTRY AlphaXBeta

extern void ComputeOutsidePerItem(TableType TAB, ParForest PARF, int length);
extern void ShowMaxGRR(ParForest PARF);
void MaxGlobalRecallRate(TableType TAB, ParForest PARF, int length);
 
extern ProbDomain _Lambda_LRR;
