#ifndef Direction_Type
#define Direction_Type Boolean
#define _rightwards true
#define _leftwards  false
#endif
/************/
void WriteTo(char *word, Queue Q);
void WriteToEx(char *word, NumOfWordsType i);
void WriteToWG(char *word, NumOfWordsType i, NumOfWordsType j);
void AddUndSc(char *word, NumOfWordsType j);
char *ReadInputstring();
void Analyse(FILE *IN);
/************/
PtrListArray ReadWordGraph();
/**********************/
char *ReadInputstring();


extern void BkwdsMapOnWGsSetOfEntries(void (* fp)()); 
extern void MapOnWGsSetOfEntries(void (* fp)()); 
extern void MapOnTransitionOfWG(void (* fp)());

#define FreeWordGraph FreeSentence
