extern NTDomain StartNonterminal ;
extern NTDomain NonTSize ;
extern TDomain TermsSize ;
extern RDomain TRSize  ;
extern RDomain URSize  ;
extern RDomain BRSize  ;
extern RDomain EpsRSize  ;

extern struct RuleStruct  *EpsRules;
extern struct RuleStruct *TRules ;
extern struct RuleStruct *URules ;
extern struct RuleStruct *BRules ;

extern struct NTStruct *NTArray ;
extern struct NTStruct *Rhs1Array ;
extern struct NTStruct *Rhs2Array ;
extern struct TermStruct *TermsArray ;

extern struct Place_Struct *T_R_Apps ;
extern struct Place_Struct *B_R_Apps ;
extern struct Place_Struct *Eps_R_Apps ;
extern struct Place_Struct *U_R_Apps ;
extern TreeCodeT TotalRootsNum ;
ProbDomain *TheProbOf ;
