void PRHS1V(void *IV);
void ShowRHS1(RDomain Rno, 
     RType RT, DOTPLACE dot);
void ShowLHS(RDomain Rno, 
     RType RT, DOTPLACE dot);
void ShowItem(RDomain Rno, 
     RType RT, DOTPLACE dot);
void LarLevel(void *PtrA, void *PtrB, Boolean *LAR);
void VEqItems(void *PtrA, void *PtrB, Boolean *EQ);
/*************************************************/
Boolean IsEnded_Item(ItemTree item);
/****************/
void Disconnect(ItemTree Parent, ItemTree Child);
/********************/
void PRHS1(ItemTree item);
void PRHS2(ItemTree item);

void PLHS(ItemTree item);
