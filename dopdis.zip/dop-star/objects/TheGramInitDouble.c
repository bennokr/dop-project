/** General declations and definitions */
/*******************/
#include "/home/simaan/D-Programs/D-NEWPARSER/Universals.h"
#include "/home/simaan/D-Programs/D-NEWPARSER/Aux.h"
#include "/home/simaan/D-Programs/D-NEWPARSER/CodeType.h"
#include "/home/simaan/D-Programs/D-NEWPARSER/DefsGrammar.h"
/**************************/
extern NTDomain StartNonterminal ;
extern NTDomain NonTSize ;
extern TDomain TermsSize ;
extern RDomain TRSize  ;
extern RDomain URSize  ;
extern RDomain BRSize  ;
extern RDomain EpsRSize  ;

extern struct RuleStruct  *EpsRules;
extern struct RuleStruct *TRules ;
extern struct RuleStruct *URules ;
extern struct RuleStruct *BRules ;

extern struct NTStruct *NTArray ;
extern struct NTStruct *Rhs1Array ;
extern struct NTStruct *Rhs2Array ;
extern struct TermStruct *TermsArray ;

extern struct Place_Struct *T_R_Apps ;
extern struct Place_Struct *B_R_Apps ;
extern struct Place_Struct *Eps_R_Apps ;
extern struct Place_Struct *U_R_Apps ;
extern TreeCodeT TotalRootsNum ;
extern ProbDomain *TheProbOf ;
/**************************/
#include <Grammar1.c>
#include <Grammar2.c>
/**************************/
/** NOTE: 
 The macro's IVStartNonterminal and IVGrammarNumber enable identifying the case where 
 one single grammar is being compiled. The case when both are not defined is equal to 
 the case where IVStartNonterminal1, IVStartNonterminal2 and IVGrammarNumber is defined:
 this is exactly when two grammars are being integrated. This enables us to use this file
 for both cases, i.e. including one or two grammars.
****/
/************************************************************/
/* NEXT: conditional definition of initialization functions */
/************************************************************/
/**/
#ifndef IVStartNonterminal
#ifndef IVGrammarNumber
int NUMofGRAMMARS_Used() {return 1;}  
void InitGrammarNum()
{fprintf(stderr, "Err: No grammar at all in Grammar.c ...\n");exit(1);}
void InitGrammar()
{fprintf(stderr, "Err: No grammar at all in Grammar.c ...\n");exit(1);}
#endif
#endif

#ifdef IVStartNonterminal
void InitGrammar()
{
 Active_Grammar_Number = 1 ;
 StartNonterminal = IVStartNonterminal ;
 NonTSize = IVNonTSize ;
 TermsSize = IVTermsSize ;
 TRSize  = IVTRSize  ;
 URSize  = IVURSize ; 
 BRSize  = IVBRSize ;
 EpsRSize  = IVEpsRSize ;

 EpsRules = IVEpsRules;
 TRules = IVTRules ;
 URules = IVURules ;
 BRules = IVBRules ;

 NTArray = IVNTArray ;
 Rhs1Array = IVRhs1Array ;
 Rhs2Array = IVRhs2Array ;
 TermsArray = IVTermsArray ;

 T_R_Apps = IVT_R_Apps ;
 B_R_Apps = IVB_R_Apps ;
 Eps_R_Apps = IVEps_R_Apps ;
 U_R_Apps = IVU_R_Apps ;
 TotalRootsNum = IVTotalRootsNum ;
 TheProbOf = IVTheProbOf;
}
void InitGrammarNum(int GNum)
{fprintf(stderr,"Err: please use InitGrammar instead\n");exit(1);}
#endif

#ifndef IVStartNonterminal
#ifdef IVGrammarNumber
char *CodeBINName=NULL;
char *ChPlBINName=NULL;

int NUMofGRAMMARS_Used() {return 2;}  
void InitGrammar()
{fprintf(stderr,"Err: please use InitGrammarNum instead\n");exit(1);}

void InitGrammarNum(int GNum)
{if ((IVGrammarNumber != 1) && (IVGrammarNumber != 2))
    {fprintf(stderr,"Err: GNum is not 1 or 2 in Init\n");exit(1);}
 
 Active_Grammar_Number = GNum;
 if (GNum == 1) 
 {
 StartNonterminal = IVStartNonterminal1 ;
 NonTSize = IVNonTSize1 ;
 TermsSize = IVTermsSize1 ;
 TRSize  = IVT1RSize  ;
 URSize  = IVU1RSize ; 
 BRSize  = IVB1RSize ;
 EpsRSize  = IVEps1RSize ;

 EpsRules = IVEps1Rules;
 TRules = IVT1Rules ;
 URules = IVU1Rules ;
 BRules = IVB1Rules ;

 NTArray = IVNTArray1 ;
 Rhs1Array = IVRhs1Array1 ;
 Rhs2Array = IVRhs2Array1 ;
 TermsArray = IVTermsArray1 ;

 T_R_Apps = IVT_R_Apps1 ;
 B_R_Apps = IVB_R_Apps1;
 Eps_R_Apps = IVEps_R_Apps1 ;
 U_R_Apps = IVU_R_Apps1 ;
 TotalRootsNum = IVTotalRootsNum1 ;
 TheProbOf = IVTheProbOf1;
 }
 else if (GNum == 2)
  {
 StartNonterminal = IVStartNonterminal2 ;
 NonTSize = IVNonTSize2 ;
 TermsSize = IVTermsSize2 ;
 TRSize  = IVT2RSize  ;
 URSize  = IVU2RSize ; 
 BRSize  = IVB2RSize ;
 EpsRSize  = IVEps2RSize ;

 EpsRules = IVEps2Rules;
 TRules = IVT2Rules ;
 URules = IVU2Rules ;
 BRules = IVB2Rules ;

 NTArray = IVNTArray2 ;
 Rhs1Array = IVRhs1Array2 ;
 Rhs2Array = IVRhs2Array2 ;
 TermsArray = IVTermsArray2 ;

 T_R_Apps = IVT_R_Apps2 ;
 B_R_Apps = IVB_R_Apps2;
 Eps_R_Apps = IVEps_R_Apps2 ;
 U_R_Apps = IVU_R_Apps2 ;
 TotalRootsNum = IVTotalRootsNum2 ;
 TheProbOf = IVTheProbOf2;
 }
 else {fprintf(stderr,"Err: GNum is not 1 or 2 in Init\n");exit(1);}
}
#endif
#endif
