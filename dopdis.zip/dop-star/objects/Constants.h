/* to compensate for yylex on a PC */
/* overridden by -lfl library
#ifndef yywrap
#define YY_SKIP_YYWRAP
#define yywrap() 1
#endif
*/

/* All symbols should be renamed before any other transformations 
   to avoid change in maximum length of NT/terminal symbol 
representations  and extra memory use.*/
#ifndef TermSymLngt
#define TermSymLngt 12
#endif
#ifndef NTSymLngt
#define NTSymLngt 12
#endif
/******* This initialization in of length NTSymLngt above ***/
/** This enables more than 17000 nonterminals             ***/
#ifndef InitNTArray
#define InitNTArray {'a', 'a', 'a'}
#endif
/******* This initialization in of length TermSymLngt above ***/
/** This enables more than 17000 terminals             ***/
#ifndef InitTermArray
#define InitTermArray   {'a', 'a', 'a', '_'}
#endif
/*************************/
/* 30 characters for a non-terminal/terminal name was too long
   so a renaming program reduces this to 5 charcters */
/**** #define SymLength 12      2*TermSymLngt i.v.m. ECNF  ***/
#ifndef SymLength
#define SymLength 300
#endif
/* Max depth of subtrees of DOP */
#ifndef MaxDepth
#define MaxDepth 200
#endif
/* Max rule length in the form hereunder */
#ifndef MaxRule
#define MaxRule (4*(SymLength+6))
#endif
    /* tree(0123456789,[tree(0123456789,[]),tree(0123456789,[])])*/
/* Max characters in rule A->BC in the form: A_B_C */
#ifndef MaxRuleSkel
#define MaxRuleSkel MaxRule
#endif
/* Max tree length in characters when written as here above.
   This allows around than 100 tree-nodes each of two children where
   symbol length is 5 characters
*/
#ifndef MaxTreeL 
#define MaxTreeL 50000
#endif
/***********************************/
/* Number of subtrees expected. This is only for the unit for finding
   the children of each code: FindChs */
#ifndef NumOfSubs 
#define NumOfSubs 3000000
#endif
/*******************************/
/* A fixed value as fake probability for subtrees of ParPar */
#ifndef FIXEDPROBVALUE 
#define FIXEDPROBVALUE -7.0
#endif
/***********************/
/* To pass the prior probability of XP we use a subtree: NP->PRIOR_SYM */
#ifndef PRIOR_SYM
#define PRIOR_SYM "xxxprior"
#endif

#ifndef UNKNOWNSYMwo
#define UNKNOWNSYMwo "xxxunknown"
#endif

#ifndef UNKNOWNSYM
#define UNKNOWNSYM "xxxunknown_"
#endif       

#ifndef START_SYM
#define START_SYM "xxxstart"
#endif

#ifndef UNV_START_SYMNUM
#define UNV_START_SYMNUM -3
#endif

#ifndef STOP_SYM
#define STOP_SYM "xxxstop"
#endif

#ifndef UNV_STOP_SYMNUM
#define UNV_STOP_SYMNUM -4
#endif

/*************************/
/* In lex input files, the following could not be used: so if this is changed one has to change there too */
#ifndef _ECNF_SYM
#define _ECNF_SYM '@'
#endif       

#ifndef _ECNF_LEX
#define _ECNF_LEX  @
#endif       
/*************************/
#ifndef _UNIGRAM_SYM
#define _UNIGRAM_SYM  "xxxUI"
#endif       
#ifndef _BIGRAM_SYM
#define _BIGRAM_SYM  "xxxBI"
#endif       
#ifndef _VOID_PREFIX
#define _VOID_PREFIX  "xxx"
#endif
#ifndef _LEFT_VOID_PREFIX
#define _LEFT_VOID_PREFIX  "lll"
#endif
#ifndef _RIGHT_VOID_PREFIX
#define _RIGHT_VOID_PREFIX  "rrr"
#endif

#ifndef _head_marker
#define _head_marker  ""
#endif

#ifndef _rule_parts_marker 
#define _rule_parts_marker "^"
#endif
#ifndef _rule_parts_marker_c 
#define _rule_parts_marker_c '^'
#endif

#ifndef _GLOB_TERM_SYM
#define _GLOB_TERM_SYM "TERMINAL-SYM"
#endif

#ifndef _ANY_NONT_SYM
#define _ANY_NONT_SYM "-ANY-NONT-XXX"
#endif

#ifndef _SIMILARITY_PROB
#define _SIMILARITY_PROB  -10.00
#endif

#ifndef _XXXPHRASE
#define _XXXPHRASE "xxxphrase_"
#endif
