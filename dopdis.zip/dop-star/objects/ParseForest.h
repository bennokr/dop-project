enum TravDef {B_U=0,T_D=1,O_THER=2};
#ifndef TravType
#define TravType enum TravDef
#endif
struct ParseForestStr {
     PtrList Starts;  
     PtrList Ends;  
     PtrList StructBU;
     PtrList StructTD;
};
typedef struct ParseForestStr *ParForest;
ParForest CrParF();
ParForest InitParF();
ParForest GenParF(TableType TAB, int n);
PtrList AllStartItems(TableType TAB, int n);
void ParForestMap(ParForest PF, void (* fp)(), TravType Trav);
/* TopDown parseforest traversal in depth-first applying fp on each item */
void TDParFMap(ParForest PF, void (* fp)());
/* BottomUp parseforest traversal in depth-first applying fp on each item */
void BUParFMap(ParForest PF, void (* fp)());
/* Bottom-Up Breadth first trav applying fp */
void BU_BF_Trav(ParForest PF, void (* fp)());
/* Top_Down Breadth first trav applying fp */
void TD_BF_Trav(ParForest PF, void (* fp)());
void Scan_Level(PtrList P, void (* fp)(), TravType Trav);
/*****************************/
/* Underlying functions */
PtrList MarkAndRET(PtrList Ends, PtrList Starts, RType RT, int i);
void MapDown(PtrList P, void (* fp)());
void MapUp(PtrList P, void (* fp)());
/****************/
PtrList StartItemsList(TableType TAB, int n);
void MarkParseF(TableType TAB, int n);
void MarkPF(PtrList P, LevDomain i);
ParForest  GenChunks(TableType TAB, int n);
/**************************************/
/* For testing: print facilities.     */
/**************************************/
void VoidPrnt(void *J, int i);
void PrntLst(PtrList P, int i, RType RT);
void PrntTD(TableType TAB, int n);
void FreeParForest(ParForest PF);
extern void GenChunksLeftSpineOnly(TableType TAB, int n);
extern void GenChunksBetweenIJ(TableType TAB, int i, int j, int n);
