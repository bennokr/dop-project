extern void Double_PARSE(TableType *THETABLE, Sentence TheWG, TDomain **Tags, int length, ParForest *ParF, DuoPtr Duo);
