/*
#ifndef FORWARD_P
#define FORWARD_P Sum_Prob
#endif
#ifndef FWD_BKWD_P
#define FWD_BKWD_P Sum_Prob
#endif
*/

TableType BiGramPosTagging(TableType TAB, int length, DuoPtr Duo);
enum _TAGGING_TYPE {_GLOBAL_TAGGING=1,_LOCAL_TAGGING=2};    
