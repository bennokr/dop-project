#ifndef HashUnit
#define HashUnit TreeType
#endif

#ifndef MAXOF
#define MAXOF(A, B)  ((A > B) ? A : B)
#endif 
#ifndef MINOF
#define MINOF(A, B)  ((A < B) ? A : B)
#endif 
/**************************/
/* A hashtable with buckets */
/* Ended Items take the first buckets and other items the last buckets */
/**************************/
/* This is the maximum number of hashing buckets: we allow at most 2*X_MAX+3 buckets - for memory reasons */
#define X_MAX 3000

/* We take the minimum between the number of Binary rules and X_MAX, similarly for Unary rules */
#define X_BRSize (MINOF(BRSize, X_MAX))
#define X_URSize (MINOF(URSize, X_MAX))

#ifndef HashValue
#define HashValue (X_BRSize + MAXOF(X_BRSize, X_URSize) + 3)
#endif

/* BuckFact buckets of HashValue are reserved for ended items */
#ifndef BuckFact
#define BuckFact (HashValue - (X_BRSize+1))
#endif

#ifndef EndedBuckSize
#define EndedBuckSize BuckFact
#endif
#ifndef OthsBuckSize
#define OthsBuckSize (HashValue - BuckFact)
#endif
#ifndef StartEnded
#define StartEnded 0
#endif
#ifndef StartOths
#define StartOths BuckFact
#endif

typedef HashUnit *HashTable;

/************/
int Mod(int x, int y);
HashTable InitHashTB();
/* Two buckets: first for ended items, second for other items */
int HashInBuck(ItemTree item, HashTable HT);
/**************************/ 
/* returns a tree under which Rn rt is an item to be entered or to be found */
TreeType SearchHT(ItemTree item, HashTable HT);
/*************************/
void EnterHT(ItemTree item, HashTable HT, Boolean *Change);
/*************************/
void HashTMap(HashTable HT, void (* fp)());
/*************************/
void HashTMapEnded(HashTable HT, void (* fp)());
/*************************/
void HashTMapOths(HashTable HT, void (* fp)());
/*************************/
/* fp takes an ItemTree and returns an ItemTree */
void XHashTMap(HashTable HT, ItemTree (* fp)());

void XHashTMapEnded(HashTable HT, ItemTree (* fp)(), Boolean Ended);
void CompactHashT(HashTable HT, Boolean Ended);
