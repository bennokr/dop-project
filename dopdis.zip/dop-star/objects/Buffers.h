#ifndef SEEK_SET
#define SEEK_SET 0
#endif
/************************************/
/* A buffer structure has the startpoint (StartP) of the Rule_Apps
   RApps on the file .CodesLists.bin. This start point is the start
   point where the Roots start unless there are no roots, then the
   Others. In case both are zero then a zero and a NULL will appear
   in the buffer. 
*/
struct Buf_Struct {
      PlacesT StartP;
      Rule_Apps RApps;
};
typedef struct Buf_Struct *BufPtr;

/************************/
/* Two global variables which hold Rule_Apps for two items; 
   i.e. parent and child items which are multiplied       */
/************************/
#ifndef WHICHBUFT
#define WHICHBUFT int
#endif
extern WHICHBUFT WhichBuf;
extern BufPtr BfPtr1;
extern BufPtr BfPtr2;
/**********************/
BufPtr NewBP();
void InitBuff(int i);
void FlushBuff(int i);
PlacesT WhichStart(PlacePtr PP);
Rule_Apps CheckBuff(int bufnum, PlacesT WS);
/**********************/
/* In order for this to
   work well, at least one of the buffers
   must be flushed before calling it  .   */
/* Returns RA from one of the two buffers
   if it is there, otherwise the empty
   buffer is filled with the records read from
   the file .CodeLists.bin and RA is returned.
*/
/**********************/
/* one of the two buffers must be empty for this update to succeed */
/**********************/
void IntoBuff(PlacesT WS, Rule_Apps RA);
Rule_Apps GetFromFile(PlacesT WS, TreeCodeT RS, InTreeCodeT OS);
Rule_Apps GetR_A(PlacePtr PP);
/***********************************/
/** Look in CodeType.h 
struct Ch_Str {
      PlacesT LeftCh;
      PlacesT RightCh;
};
typedef struct Ch_Str *Ch_Ptr;
***/
/**************/
/* Global buffer holding the places of the children of the parents 
   so they can be found faster during multiplication.
  Of course its length is as that of the parent number of codes, and
  its startplace in the file .ChildPlace.bin is the same as its code 
  in .CodesList.bin */

extern Ch_Ptr OChsPlacesBuff1 ;
extern Ch_Ptr RChsPlacesBuff1 ;
extern Ch_Ptr ChsPlacesBuff2 ;
Ch_Ptr PtrToChsBuff(Code_Soort CT);
extern void ResetBuffering();
extern void GetChildPlaces(PlacePtr PP);
extern void IntoBuffPPtr(PlacePtr PP, Rule_Apps RA);
