#ifndef PlacesT
#define PlacesT long int
#endif
/**************************************/
/**/
enum Relate {SML = 0, EQL = 1, BIG =2, NIKS =3};

enum ChildType {Lch_enum=1, Rch_enum=2};
typedef enum ChildType Child_Type; 

/* #define Lch_enum 1 #define Rch_enum 2 #define Child_Type char */

#ifndef _SMALL_IMPLEMENTATION 
enum CodeSoort {ROOT_enum=1, OTHERS_enum=2};
typedef enum CodeSoort Code_Soort; 
#endif

#ifdef _SMALL_IMPLEMENTATION 
#ifndef Code_Soort
#define ROOT_enum 1 
#define OTHERS_enum 2 
#define Code_Soort char 
#endif
#endif

/********************************/
/* The types of codes and operations
   of of conversion on them     */
/* typedef unsigned int TreeCodeT; typedef unsigned short int InTreeCodeT; */
/* #define TreeAToD (unsigned int) atol */
/* #define InTreeAToD (unsigned short int) atol */
/********************************/
/* #define C_Addr_Domain unsigned int  */
#ifndef RealProbDomain
#define RealProbDomain ProbDomain
#endif
/* float */
/********************************/
struct CodeTStruct {
     TreeCodeT TreeC;
     InTreeCodeT OwnC;
};
typedef struct CodeTStruct CodeType;
typedef CodeType *CodePtr; 
/********************************/
enum OTSTYPE {NEITHER_enum=0,ONLYLHS_enum=1,ONLYRHS_enum=2,BOTH_enum=3};
typedef enum OTSTYPE OTS_Type; 

/*
#ifndef NEITHER_enum
#define NEITHER_enum 0
#endif
#ifndef ONLYLHS_enum
#define ONLYLHS_enum 1
#endif
#ifndef ONLYRHS_enum
#define ONLYRHS_enum 2
#endif
#ifndef BOTH_enum 
#define BOTH_enum 3
#endif
#ifndef  OTS_Type 
#define  OTS_Type char
#endif
*/
/************************/
CodePtr NewCPtr();
Boolean Parent(CodePtr CP, CodePtr Ch, Child_Type ChNum);
/***
Boolean IsRoot(CodeType *C);
*****/
/************************/
/* Takes a string "/c1/c2/c3" and generates a pointer to a code.  */
/************************/
/*****************************/
/****************************/
/* Node-pointers            */
/****************************/
struct Node_Type {
   CodeType Code;
   OTS_Type OTS;
   /* void *Data;  put probability here */
 }; /* -- */
typedef struct Node_Type *NodePtr;

NodePtr NewNP(TreeCodeT num);
/******
******/
/******************************/
/*****************************/
/* Rule_Apps type   */
/******************************/
 struct Nodes_Struct {
         TreeCodeT Roots_Size;
         TreeCodeT Others_Size;
     struct Node_Type *Roots_Nodes,
                     *Others_Nodes;
 };/* --- */
typedef struct Nodes_Struct *Rule_Apps;
/*******************************/
/* The file .CodesLists.bin is a stream of strcutures Node_Type
   and the Grammar.c include their place for each rule.       */
struct Place_Struct {
    TreeCodeT Roots_Size; 
    InTreeCodeT Others_Size;
    PlacesT Roots_StartPos;
    PlacesT Others_StartPos;
};
typedef struct Place_Struct *PlacePtr;
Boolean IsRoot(CodeType *C);
/**************************/

/* The places of Children of codes (structures in file .ChPlacesCodes.bin) */
struct Ch_Str {
      PlacesT LeftCh;
      PlacesT RightCh;
};
typedef struct Ch_Str *Ch_Ptr;              
/**/
extern NodePtr FromStrToCode(char *C);
extern Boolean TakeRsOnly(NodePtr NPp, Child_Type Chnum);
extern TreeCodeT TreeCodeOfNP(NodePtr NP);
extern TreeCodeT OwnCodeOfNP(NodePtr NP);
extern Boolean IsOpenCh(OTS_Type OTS, Child_Type Chnum)    ;
extern int RelateCodes(NodePtr A, NodePtr B);
extern Boolean IsViable(NodePtr CP, NodePtr Ch, Child_Type ChNum);
