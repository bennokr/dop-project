#include "DinamicSets.h"

/***
#ifndef IN_X_OUT
#define IN_X_OUT     FORWARD_P
#endif
#ifndef MAX_GRR_PROB
#define MAX_GRR_PROB FWD_BKWD_P
#endif
***/
/*******************************/
#ifndef _SMALL_IMPLEMENTATION
enum DotPlace  {lm=1, mid=2, rm=3};
#ifndef DOTPLACE
#define DOTPLACE enum DotPlace 
#endif
#endif
#ifdef _SMALL_IMPLEMENTATION
#define lm 1
#define mid 2
#define rm 3
#define DOTPLACE char 
#endif

#ifndef _SMALL_IMPLEMENTATION
#ifndef NUM_OF_PARSES_T 
#define NUM_OF_PARSES_T int
#endif
#endif
#ifdef _SMALL_IMPLEMENTATION
#ifndef NUM_OF_PARSES_T
#define NUM_OF_PARSES_T  short int
#endif
#endif

struct ITEMS {
    RDomain            RuleNo;       /*** The item is a ruleno and a dot ****/
    RDomain            OldRNum;
    DOTPLACE           Dot   ;
    RType              RT;
    /* PtrList         Adds;*/       /***  refAddedBy                   ***/
    PtrList            AddedBy; 
    PtrList            AddedByMaxGRR; 
    Boolean            Valid;        /***  Validity and other issues    ***/
    Boolean            PseudoValid;
    Boolean            Touched;  
    LevDomain          i;            /***  which entry and what level   ***/
    LevDomain          j;
    LevDomain          Level;
    NUM_OF_PARSES_T    Num_OfParses; 
    ProbDomain         FORWARD_P ;
    ProbDomain         FWD_BKWD_P; 
    ProbDomain	       RMaxPruneProbOfDer;
    ProbDomain	       OMaxPruneProbOfDer;
    ProbDomain	       RInsideProb;           /* sum of inside probs of roots */
    ProbDomain         IN_X_OUT;
    ProbDomain         MAX_GRR_PROB;
    void               *DerForest;   /*** The derivation forest pointer codes ***/
    WordList           Transition;   /*** which transition: for Terminal items ***/
};
typedef struct ITEMS *ItemTree;
ItemTree FillItem(RDomain Rno, RType RT, DOTPLACE dot);
void PTreeItem(RDomain Rno, RType RT, DOTPLACE dot, ItemTree left, ItemTree right);
/***************************************************/
/* AppToItem applies fp to a given item.           */
/* fp takes rule#, RType, DotPlace, right, left.   */
/* right and left are pointers in the tree to resp */
/* all "larger" items, all "smaller" items.        */
/* For Example: see PTreeItem                      */
void AppToItem(ItemTree item, void (* fp)());
/** for printing items use:          **/
	void PItem(ItemTree item);
/** for printing Adds or AddedBy use: **/
	void VPItem(void *item);
Boolean EqItem(ItemTree item1, ItemTree item2);
Boolean GrItem(ItemTree item1, ItemTree item2);
Boolean LeItem(ItemTree item1, ItemTree item2);
Boolean LeqItem(ItemTree item1, ItemTree item2);
Boolean LeqItem(ItemTree item1, ItemTree item2);
/********************************/
void ShowItem(RDomain Rno, RType RT, DOTPLACE dot);

void VEqItems(void *PtrA, void *PtrB, Boolean *B);
Boolean IsEnded_Item(ItemTree item);
Boolean EndedItem(ItemTree item);
void LarLevel(void *PtrA, void *PtrB, Boolean *LAR);
void ShowDerF(ItemTree I);
/*****************/
ItemTree CpyItem(ItemTree I);
ItemTree CpyItemFully(ItemTree I); 
void IVPItem(void *J);
void VEqItems(void *PtrA, void *PtrB, Boolean *EQ);
/*********/
NTDomain LHS_OfItem(ItemTree I);
NTDomain RHS1_OfItem(ItemTree I);
NTDomain RHS2_OfItem(ItemTree I);     
ItemTree FreeUnVItem(ItemTree I);
ItemTree FreeItemEmptyDF(ItemTree I);
/***********************************************************/
/* References:
   refAddedBy: An Item has a list of pointers each to an item which is either added 
        (Adds list) by this item.  And a list of pointers, each to an item of which added
            this item to this entry (AddedBy list). These pointers constitute the parse-forest. 
*/



char *TerminalOf(ItemTree item);
char  *PartOfItem(ItemTree I, SYM_LOC  LOC);
TreeCodeT DFSizeOfItem(ItemTree I, Code_Soort CT);
Boolean NonEmptyDerForest(ItemTree I);
ItemTree TotFreeIifEmpDF(ItemTree I);
ItemTree FreeInsideItem(ItemTree I);
ItemTree FreeItem(ItemTree I);
extern void FreeDerForestOfItem(ItemTree I)     ;
extern Boolean StartSymbolsItem(ItemTree I); 
extern Boolean Same_Entry_Items(ItemTree I1, ItemTree I2);
extern Boolean GoodItem(ItemTree item);
extern TDomain GetTerminalOfItemIfAny(ItemTree I);
extern ItemTree FreeItemNotDF(ItemTree I)    ;
extern Boolean NonEmptyRootsDerForest(ItemTree I);
extern void fPItem(ItemTree item, FILE *file);
