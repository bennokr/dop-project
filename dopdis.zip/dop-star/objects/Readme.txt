The fully interleaved version computes the wrong sentence-probability.
Therefore it was closed. Instead, we have now a Semi-interleaved version
that seems to work well.
