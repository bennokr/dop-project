struct G1toG2Struct {
   RDomain URSizeG1;
   RDomain BRSizeG1;
   RDomain TRSizeG1;
   RDomain EpsRSizeG1;
   RDomain *UG1toG2Arr;
   RDomain *BG1toG2Arr;
   RDomain *TG1toG2Arr;
   RDomain *EpsG1toG2Arr;
};
typedef struct G1toG2Struct *G1toG2;
G1toG2 NewG1toG2(RDomain US, RDomain BS, RDomain TS, RDomain EpsS);

RDomain TransFormRNum(ItemTree I);

RDomain TransFormRNumII(RDomain RNumOrig, RType RT);

extern void ConstructG1toG2();
extern G1toG2 GlobalG1toG2;
extern void UseInternGrammar(int GramNumber) ;
extern void InitGrammarNum(int GNum);
