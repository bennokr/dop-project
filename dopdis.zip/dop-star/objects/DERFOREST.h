C_Addr_Domain *AllocPos(TreeCodeT Size);
/****
 Inits the set A(R) for R which is a Term/Eps rule:
 Assigns to Sum_Prob and MPD_Prob of each OTHERS-code (ROOT-code)
 value 1 (resp. the probability of its tree) as a start value. 
 Also initialize all MPD_PtrL/R to NULL, SelfItem to IT and
 O/R_valids to NULL unless the global RedDerForest is false.
 This global is set to false in order NOT to reduce the derivation-forest 
 to only the viable codes. In that case, one must not set R_valids
 and O_valids to NULL.
*****/
void InitValuesICP(ItemTree IT, ItemCPtr ICP);
/***************/
void FREE(void *IC);
/***********************************************************************/
/* Two tasks for this procedure:
   1. For saving space: this procedure reduces the DerForest of IT only
        to those viable codes (given as valid in R_valids and O_valids). 
       The number of Roots/Others codes that are viable is given resp. 
       Rnum and Onum. Thus it copies the viable codes into a more compact 
       structure.
   2. It multiplies each remaining code with its prob. as defined in the
      RB-STSG.
  
 The global RedDerForest switches the reduction of space to on/off when 
 set to resp. true/false. In case of interleaved CKY attribute computation
 it must be set to false.
******************************/

void RedToValids(ItemTree IT, TreeCodeT Rnum, TreeCodeT Onum);
/*****************************************/
/* Notice: ResI should be complete such that  */
/*     if ResI->Roots[i]==CAdr then CAdr == i */
/*     same for ResI->Others.                 */
/* OrigGivI is the original item A->B*C of which */
/* the derivation-forest was copied into GivI to */
/* be used for the computation of der.forest of  */
/* A->BC* (i.e. ResI). The MPD_PtrL's of the     */
/* codes of ResI should point to the codes       */
/* of OrigGivI which resulted in MPDs, not to    */
/* in GivI (which is temporary and will disppear.*/ 
/*****************************************/
TreeCodeT Update1By2(ItemTree ResI, ItemTree GivI, Code_Soort CT, 
                                    ItemTree OrigGivI);
/*******************************/
/* Computes the derivation forest of the item given by Ptr. */
/* InitDFofItem = true implies initialize the derivation forest of the Item */
/*              Otherwise : Don't                                           */      
/* The Item must have a list of AddedBy that points to those items that made*/
/* the given item be in the chart.                                          */ 
/* Items A->BC* are computed from all A->B*C with their respective C->beta* */
/* For every A->B*C and its resp. C->beta* the computation is curried out   */
/* in a temporary copy of A->B*C (incl derivation-forest) called DupI.      */
/* Subsequently A->BC* is updated  by the results from DupI.                */
/**/
void CompItem(void *Ptr, Boolean InitDFofItem, DuoPtr Duo);
/***********************/
/* The interleaved version */
void CompItemInter(void *Parent, void *Child, PtrList ChsKJ,
                   Boolean InitDFofItem, DuoPtr Duo);
/***************************/
void CompDFEntry(EntryPtr EPtr, DuoPtr Duo);
/***************************/
/* The computation of the derivation-forest and MPD takes place on
   the CFG-parse-forest. The forest contains valid and unvalid
   items which AddedBy relationship. The computation is done
   only for valid items. Unvalid items stay in the AddedBy relationship
   but do not contribute anything to the computation since they always
   have a derivation-forest which is NULL.
*/
/***************************/
extern void CompDFTable(TableType TAB, int n, DuoPtr Duo);
extern void CompDFEntrySemiI(TableType TAB, int i, int j, DuoPtr Duo, Boolean Ended, Boolean Unaries, Boolean PrepForPruning);
