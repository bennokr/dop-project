/******************************/
/* Rule_Apps is declared in CodeType.h */
/******************************/
NodePtr NodePtrOf(C_Addr_Domain CA, Rule_Apps RA, Code_Soort CT);
Rule_Apps R_AppsOf(RDomain Rno, RType RT);
Rule_Apps IR_AppsOf(RDomain Rno, RType RT, WHICHBUFT WF);

Rule_Apps Item_AppsOf(ItemTree it);
/******************************/
/* ViabSetOf computes a subset of Item_AppsOf(itP)
   of codes CP which have at least one code Ch in Item_AppsOf(itCh)
   such that IsViable(CP, Ch, j) is true for some j.
   P.S. We assume here that no ROOT CP is in the Viability
   relation with another ROOT Ch. If this is the case in the
   future then change it.
*/
Rule_Apps NewRApps();

void ShowR_Apps(Rule_Apps RA);

/*****************/
/* Given a Code in NP and its soort, ArrNumOf returns its 
   array number (place) in RA (i.e. in A(R) for some R).
*/
C_Addr_Domain ArrNumOf(Rule_Apps RA, NodePtr NP, Code_Soort CT);
/******************/
void FreeNPtr(NodePtr NP);
/*****************************/
/* Rule_Apps type   */
/* Declaration of this type can be found in CodeType.h*/
/******************************/
Rule_Apps NewRApps();
void FreeRApps(Rule_Apps RA);
void FreePartsOfRApps(Rule_Apps RA);
/************/
/* Rule_Apps GetR_A(PlacePtr PP) { if in buffer already then return the buffer
    else go and get it into buffer from file  and return its value } */
/************/
