/* don't prune when the minimum ratio P1/P2 is larger than 10^100 */
#ifndef _MIN_PRUNE_RATIO
#define _MIN_PRUNE_RATIO ((ProbDomain) 100.0)
#endif 

#ifndef Pruned_Item 
#define Pruned_Item PseudoValid
#endif

#ifndef Attempt_Pruning_Item 
#define Attempt_Pruning_Item PseudoValid
#endif

extern Boolean _TAGGING_PHASE;
extern Boolean _REMOVE_PRUNED_ITEMS;

enum RATIO_KIND_T {Per_NonT=0,Per_Entry=1};
enum VERSION_TYPE {GLOBAL_THRESH=0,BEAM_THRESH=1};

extern void PruneEntryI(TableType TAB, int i, int j, ProbDomain RMax, ProbDomain OMax, Boolean Ended, Boolean Only_Valid_Items);
extern void PruneEntry(TableType TAB, int i, int j, Boolean Ended, Boolean UnaryItems, Boolean Compact);
extern void PruneForLength(TableType TAB, int n, int L);
extern void PruneItem(ItemTree I, ProbDomain RMax, ProbDomain OMax);

extern enum VERSION_TYPE _VERSION ;
extern ProbDomain V_R_PRUNE_RATIO; 
extern void SetValueOfInterRedDF(Boolean VAL);
extern Boolean ValueOfInternRedDerF();

extern int V_BEAM_WIDTH;
extern int V_BEAM_WIDTH_SMALL_SPAN(int span);
