#ifndef WordList
#define WordList Queue
#endif

/**********************/
struct Sentences {
  int    length;
  WordList  WORDS;
  WordList Last;
};

typedef struct Sentences *Sentence;

extern Sentence CrSen();
extern Sentence EnterWord(Sentence Sen, char *word);
extern char *ThisWord(Sentence Sen);
extern Sentence RestOfSentence(Sentence Sen);
/* func takes a string and a Queue */
extern void MapSentence(Sentence Sen, void (* func)());
extern void MapSentenceWG(Sentence Sen, void (* func)());
extern void MapSentenceWG_L(Sentence Sen, void (* func)());
extern void Store(char *a);
extern Sentence EnterWordWG(Sentence Sen, char *w, NumOfWordsType i, NumOfWordsType j);
extern Sentence StoreWG(Sentence S, char *a, NumOfWordsType i, NumOfWordsType j);
extern Sentence StoreWGP(Sentence S, char *a, NumOfWordsType i, NumOfWordsType j,ProbDomain Prob);
extern int UpdateProbOfLast(Sentence S, ProbDomain Probs);
int UpdateMorphemeOfLast(Sentence S, char *Morpheme);
extern int UpdateBounaryOfLast(Sentence S);
extern void FreeSen(Sentence Sen);
