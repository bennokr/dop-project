#define DEBUG000 if (!strcmp(PartOfItem(target->SelfItem, RHS_1),"S")) \
                  {PRS("LCH     "); PRI(target->CAdr); PItem(target->SelfItem); PRS(" has ");\
                   PListMap(target->ListOfChNodes, (void *) &Vprntself); \
                   PRS("\n");}
#define DEBUG001  if (!strcmp(PartOfItem(target->SelfItem, RHS_1),"S")) \
                  {PRS("\n In Update-----------------\n");\
                   PRS("RCH     ");PRI(target->CAdr); PItem(target->SelfItem); PRS(" has ");\
                   PrntDList(target->ListOfChNodes);\
                  }
#define  DEBUGIBefore00 {PRS("\n");\
  fprintf(stderr,"(%e   %e) (%e   %e)\n", DFp->MPD_Prob, DFp->MPD_Prob,  DFch->MPD_Prob, DFch->MPD_Prob);\
  PItem(DFp->SelfItem);PRS("           "); PItem(DFch->SelfItem);PRS("\n");\
 }

#define DEBUGIAfter00 {\
 fprintf(stderr,"(%e   %e) (%e   %e)\n", DFp->MPD_Prob, DFp->MPD_Prob,  DFch->MPD_Prob, DFch->MPD_Prob);\
 PItem(DFp->SelfItem);PRS("           "); PItem(DFch->SelfItem);PRS("\n");\
 PRS("-----------------\n");}

