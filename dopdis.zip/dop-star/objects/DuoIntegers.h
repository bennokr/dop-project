struct DuoStr {
     TreeCodeT RsNum;
     TreeCodeT OsNum;
};
typedef struct DuoStr *DuoPtr;
DuoPtr NewDuo();
DuoPtr CleanDuo(DuoPtr Duo);
