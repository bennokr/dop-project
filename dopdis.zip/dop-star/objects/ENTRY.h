/*******************************************************
In this directory the files which are toplevel are
   Set.h
   Set.c
   Item.h
   Item.c

Their use is for physical representation of entries of CYK tables.
Build a higher level on it which implements the operations necessary
for the CYK algorithm using the operations in these files.

Implementation:
----------------
An entry is a set (ordered tree) of items (in the future balancing of 
the tree might give better efficiency). An item is a Rule-number and
a DOT-place with the type of the rule (Binary, Unary or Term(inal)).
Each item I has two lists of pointers: Adds and AddedBy. Adds is a
list of pointers, each pointing to another item II which has been added
to an entry by the CYK algorithm because I is in the table. 
AddedBy pointers of I point to all those items II which resulted in 
adding I into this entry by the CYK algorithm. These pointer serve
for preventing the use of the CYK each time we want to find the
derivations in the CYK-table.
****************************************************************/
#include "PtrList.h"
#include "Item.h"  /* <------- declarations known outside this module */
#include "Trees.h"
#include "HashTable.h"
/*#include "Sets.h"   <------- declarations known outside this module */
#include "SetsHashed.h"
#include "RedPtrL.h"
