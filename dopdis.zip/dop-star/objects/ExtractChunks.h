/***/
#define EBL_ASSUMPTION false        /* Assume complete ambiguity sets ?: see refEBL_ASSUMPTION and ref1 */

#define REMOVEPARTSOFSSFs false     /* tells whether to care for SSF's of 100% PA-SSFs or not */
/***********/
/***/
/**/
#define AlreadyCopied PseudoValid
#define FromEBLMemory SetBooleanAux   
/*
**
*/
extern void Double_PARSE(TableType *THETABLE, Sentence TheWG, TDomain **Tags, int length, ParForest *ParF, DuoPtr Duo); 
