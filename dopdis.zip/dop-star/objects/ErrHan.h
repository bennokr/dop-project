/****************/
/* Are all words in S in the lexicon  ?*/
/* Which aren't ?                      */
/* n is the length of the sentence     */
void Which_Word(TDomain *S, int n);
