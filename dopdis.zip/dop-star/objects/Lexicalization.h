#define LexicalStruct DinSet
#define Left_Mod_Sym  "-L@"
#define Right_Mod_Sym  "-R@"

/*******/
/* unifies PI's lexical info with ChI's : returns whether ChI unifies well with PI or not  and updates PI's lexical set */
extern Boolean LexUnify(ItemTree ParentI, ItemTree ChI, int ChNum);
extern void FreeLexof(ItemTree I);
extern Boolean AddLexSet(ItemTree target, ItemTree source);
extern void InitUnificationFor(ItemTree I);
