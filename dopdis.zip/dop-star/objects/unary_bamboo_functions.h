/** contains the functions that accompany the unary-bamboo package */

struct Bamboo_Struct {
	 TreeCodeT TreeC;
	 InTreeCodeT NodeC;
	 char *PrefixSub;
	 char *SuffixSub;
};

typedef struct Bamboo_Struct *NodeUnaryPtr;


extern char *PrefixOfUnariesAbove(TreeCodeT TCode, InTreeCodeT NCode);
extern char *SuffixOfUnariesAbove(TreeCodeT TCode, InTreeCodeT NCode);
extern char *PrefixOfUnariesUnder(TreeCodeT TCode, InTreeCodeT NCode);
extern char *SuffixOfUnariesUnder(TreeCodeT TCode, InTreeCodeT NCode);

