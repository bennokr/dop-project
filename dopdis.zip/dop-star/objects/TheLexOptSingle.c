#include "stdlib.h"
#include "stdio.h"
#include "stddef.h"
#include "string.h"
#include "time.h"
#include "math.h"

#include <Universals.h>
#include <Aux.h>
#include <CodeType.h>
#include <DefsGrammar.h>

#include "LexOptArrays.c"
