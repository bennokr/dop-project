#define _ArrSubTListOfWord "ArrayOfSubTreeListPerWord"
#define _ArrOfListLengthPWord "ArrayOfListLengthPerWord"

#define N_ArrSubTListOfWord    ArrayOfSubTreeListPerWord
#define N_ArrOfListLengthPWord ArrayOfListLengthPerWord

extern Boolean CheckSubtreeActivity(TreeCodeT CodeT, TDomain *S, int _sen_length);
