
/* A maximum of 200 levels in an entry */
#define MAXLevels 20
#define MAX_LEVEL MAXLevels-1

/* Only Free the PtrLists without touching the items */
extern void MapOnLevelsOf(Set SET, void (* fp)());
extern void MapOnLevelsOfV(Set SET, void (* fp)());
extern void RevMapOnLevelsOfEnded(Set SET, void (* fp)(), Boolean Ended)  ;
extern void RevMapOnLevelsOfV(Set SET, void (* fp)())  ; 
extern void RevMapOnLevelsOf(Set SET, void (* fp)())  ; 
extern void ExMapOnLevelsOfEnded(Set SET, void (* fp)(), void (* fpFinal)(), Boolean Ended);
extern void ExMapOnLevelsOfEntry(Set SET, void (* fp)(), void (* fpFinal)());   
extern void Controlled_MapOnLevelsOf(Set SET, void (* fp)(), void (* fpFinal)(), Boolean  (* CheckFP)(), Boolean Ended, Boolean Unaries);
extern void MapOnLevelsOfEnded(Set SET, void (* fp)(), Boolean Ended);
